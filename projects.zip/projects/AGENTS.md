# 智能日程助手 - 项目文档

## 项目概览

**项目名称**: 智能日程助手  
**技术栈**: Flask + SQLite + JavaScript  
**部署地址**: http://${COZE_PROJECT_DOMAIN_DEFAULT}

## 快速开始

### 开发环境启动

```bash
cd backend && python app.py
```

服务将在 http://localhost:5000 启动

### 依赖安装

```bash
cd backend && pip install -r requirements.txt
```

## 目录结构

```
.
├── backend/
│   ├── app.py              # Flask应用入口
│   ├── config.py           # 配置文件
│   ├── extensions.py       # Flask扩展
│   ├── models/
│   │   └── task.py         # 数据模型 (User, Task, Tag, Reminder等)
│   ├── routes/
│   │   ├── auth_routes.py  # 用户认证API
│   │   ├── task_routes.py  # 任务管理API
│   │   ├── ai_routes.py    # AI功能API
│   │   ├── user_routes.py  # 用户管理API
│   │   └── ...
│   └── utils/
│       ├── ai_helper.py    # AI助手封装
│       ├── scheduler.py    # APScheduler定时任务
│       ├── auth.py         # JWT认证管理
│       └── ...
├── frontend/
│   ├── index.html          # 主页面 (包含登录/注册UI)
│   ├── app.js              # 前端逻辑
│   └── sw.js               # Service Worker
├── instance/
│   └── schedule.db         # SQLite数据库
└── scripts/
    └── ...
```

## 核心功能

### 1. 用户系统
- 用户注册/登录 (JWT Token认证)
- 匿名访问支持 (X-User-ID)
- 多用户数据隔离

### 2. 任务管理
- 任务CRUD操作
- 任务状态机 (pending → in_progress → completed)
- 任务分类和标签
- 重复任务

### 3. AI功能
- AI智能排序
- AI时长预估
- AI学习计划
- **每日免费额度10次**
- 支持用户自定义API Key

### 4. 定时提醒
- APScheduler定时任务
- 任务截止提醒
- 智能提醒生成
- Web Push推送通知

## API接口

### 认证接口
| 接口 | 方法 | 说明 |
|-----|------|------|
| /api/auth/register | POST | 用户注册 |
| /api/auth/login | POST | 用户登录 |
| /api/auth/logout | POST | 用户登出 |

### 任务接口
| 接口 | 方法 | 说明 |
|-----|------|------|
| /api/tasks | GET/POST | 任务列表/创建 |
| /api/tasks/:id | GET/PUT/DELETE | 任务详情/更新/删除 |
| /api/tasks/:id/status | PUT | 统一状态更新 |

### AI接口
| 接口 | 方法 | 说明 |
|-----|------|------|
| /api/ai/usage | GET | 获取AI使用额度 |
| /api/ai/api-key | POST | 设置用户API Key |
| /api/ai/check-quota | GET | 检查AI额度 |

### 用户接口
| 接口 | 方法 | 说明 |
|-----|------|------|
| /api/user/profile | GET/PUT | 用户信息 |
| /api/user/push/subscribe | POST | 订阅推送通知 |
| /api/user/push/vapid-key | GET | 获取VAPID公钥 |

## 数据模型

### User
```python
id: String (主键)
username: String (唯一)
password_hash: String
email: String
nickname: String
ai_api_key: String      # 用户自定义AI Key
ai_usage_count: Integer # 当日AI使用次数
ai_usage_date: Date     # AI使用日期
```

### Task
```python
id: Integer (主键)
user_id: String (外键)
title: String
category: String
is_completed: Integer
actual_start_time: DateTime
actual_end_time: DateTime
priority: Integer
```

## 环境变量

| 变量 | 说明 |
|-----|------|
| SECRET_KEY | Flask密钥 |
| JWT_SECRET_KEY | JWT签名密钥 |
| TONGYI_API_KEY | 通义千问API Key (系统默认) |
| VAPID_PUBLIC_KEY | Web Push公钥 |
| VAPID_PRIVATE_KEY | Web Push私钥 |

## 代码风格

- Python: 遵循PEP 8规范
- JavaScript: ES6+语法
- 使用有意义的变量名
- 添加必要的注释

## 常见问题

### 1. 数据库迁移
当添加新字段时，需要手动执行ALTER TABLE:
```python
from sqlalchemy import text
conn = db.engine.connect()
conn.execute(text('ALTER TABLE user ADD COLUMN new_field VARCHAR(256)'))
conn.commit()
```

### 2. 服务端口
服务必须运行在5000端口，由环境变量DEPLOY_RUN_PORT指定。

### 3. 缓存问题
前端使用版本号控制缓存 (?v=N)，修改前端代码后更新版本号。
