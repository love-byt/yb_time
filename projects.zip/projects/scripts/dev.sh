#!/bin/bash
# 开发环境启动脚本

cd /workspace/projects

# 安装依赖
pip install -r backend/requirements.txt > /app/work/logs/bypass/pip.log 2>&1

# 启动 Flask 应用
exec python backend/app.py
