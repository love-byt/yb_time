#!/bin/bash

# 智能日程助手 - 启动脚本
# 用于 Codeup 部署环境

echo "🚀 启动智能日程助手..."

# 设置环境变量
export COZE_PROJECT_ENV=PROD
export DEPLOY_RUN_PORT=${DEPLOY_RUN_PORT:-8080}
export PYTHONPATH=/app/backend

# 创建数据库目录（优先使用 /data 持久化存储）
if [ -d "/data" ]; then
    mkdir -p /data/smart_scheduler
    echo "✅ 使用持久化存储目录: /data/smart_scheduler"
else
    mkdir -p /tmp/smart_scheduler
    echo "⚠️ 警告：未找到持久化存储目录，使用 /tmp（数据将在容器重启后丢失）"
fi

echo "📦 环境配置:"
echo "  - 运行环境: $COZE_PROJECT_ENV"
echo "  - 服务端口: $DEPLOY_RUN_PORT"
echo "  - Python路径: $PYTHONPATH"

# 进入后端目录并启动
cd /app/backend
python app.py
