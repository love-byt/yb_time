/**
 * 智能日程助手 - 前端主逻辑
 * 滴答清单风格 - 简洁白色主题
 */

// ==================== XSS 防护工具 ====================

/**
 * HTML转义函数 - 防止XSS攻击
 * 将所有动态内容插入DOM前必须进行转义
 */
const XSSProtection = {
    /**
     * 转义HTML特殊字符
     * @param {string} text - 需要转义的文本
     * @returns {string} - 转义后的安全文本
     */
    escapeHtml(text) {
        if (text === null || text === undefined) {
            return '';
        }
        const str = String(text);
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    },

    /**
     * 转义HTML属性值
     * @param {string} text - 需要转义的属性值
     * @returns {string} - 转义后的安全属性值
     */
    escapeAttr(text) {
        if (text === null || text === undefined) {
            return '';
        }
        const str = String(text);
        return str
            .replace(/&/g, '&amp;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
    },

    /**
     * 安全地设置元素的innerHTML（仅用于可信内容）
     * @param {HTMLElement} element - 目标元素
     * @param {string} html - HTML内容（必须是可信的）
     */
    setTrustedHtml(element, html) {
        // 仅用于服务器渲染或硬编码的HTML
        element.innerHTML = html;
    },

    /**
     * 安全地设置元素的textContent（推荐用于用户输入）
     * @param {HTMLElement} element - 目标元素
     * @param {string} text - 文本内容
     */
    setText(element, text) {
        element.textContent = text;
    },

    /**
     * 创建安全的HTML片段（使用模板字符串）
     * @param {TemplateStringsArray} strings - 模板字符串数组
     * @param {...any} values - 插值
     * @returns {string} - 安全的HTML字符串
     */
    html(strings, ...values) {
        return strings.reduce((result, string, i) => {
            const value = values[i];
            if (value === undefined) {
                return result + string;
            }
            return result + string + this.escapeHtml(value);
        }, '');
    }
};

// 导出到全局，方便其他模块使用
window.XSSProtection = XSSProtection;

// ==================== 用户ID管理 ====================

/**
 * 用户ID管理模块
 * 为每个访问者生成唯一ID，实现多用户数据隔离
 * 
 * 优化点：
 * 1. 添加初始化锁，防止并发创建
 * 2. 使用Promise管理异步初始化
 * 3. 支持多标签页同步
 */
const UserManager = {
    STORAGE_KEY: 'smart_scheduler_user_id',
    // 内存备份，当localStorage不可用时使用
    _memoryUserId: null,
    // 标记localStorage是否可用
    _storageAvailable: null,
    // 初始化锁，防止竞态条件
    _initLock: null,
    // 缓存的用户ID
    _cachedUserId: null,
    
    /**
     * 检查localStorage是否可用
     */
    isStorageAvailable() {
        if (this._storageAvailable !== null) {
            return this._storageAvailable;
        }
        
        try {
            const testKey = '__storage_test__';
            localStorage.setItem(testKey, testKey);
            localStorage.removeItem(testKey);
            this._storageAvailable = true;
            return true;
        } catch (e) {
            console.warn('localStorage不可用，将使用内存存储用户ID');
            this._storageAvailable = false;
            return false;
        }
    },
    
    /**
     * 获取或创建用户ID（带锁机制）
     * 使用Promise解决竞态条件问题
     */
    async getUserIdAsync() {
        // 如果已经缓存，直接返回
        if (this._cachedUserId) {
            return this._cachedUserId;
        }
        
        // 如果正在初始化，等待完成
        if (this._initLock) {
            return this._initLock;
        }
        
        // 创建初始化Promise
        this._initLock = this._initializeUserId();
        
        try {
            const userId = await this._initLock;
            this._cachedUserId = userId;
            return userId;
        } finally {
            this._initLock = null;
        }
    },
    
    /**
     * 同步获取用户ID（兼容旧代码）
     * 如果已初始化则返回缓存值，否则返回null
     */
    getUserId() {
        // 优先返回缓存
        if (this._cachedUserId) {
            return this._cachedUserId;
        }
        
        // 尝试同步获取（可能存在竞态，但兼容旧代码）
        if (this.isStorageAvailable()) {
            try {
                let userId = localStorage.getItem(this.STORAGE_KEY);
                
                if (userId) {
                    this._cachedUserId = userId;
                    return userId;
                }
            } catch (e) {
                console.warn('访问localStorage失败');
            }
        }
        
        // 如果内存中有，返回内存值
        if (this._memoryUserId) {
            return this._memoryUserId;
        }
        
        // 生成新的（同步方式）
        return this._createUserId();
    },
    
    /**
     * 初始化用户ID
     * @private
     */
    async _initializeUserId() {
        // 如果localStorage可用，优先使用
        if (this.isStorageAvailable()) {
            try {
                let userId = localStorage.getItem(this.STORAGE_KEY);
                
                if (userId) {
                    return userId;
                }
                
                // 创建新ID
                userId = this.generateUUID();
                
                // 使用localStorage的原子操作尝试设置
                // 检查是否被其他标签页设置
                const existingId = localStorage.getItem(this.STORAGE_KEY);
                if (existingId) {
                    return existingId;
                }
                
                localStorage.setItem(this.STORAGE_KEY, userId);
                console.log('创建新用户ID:', userId);
                
                // 监听其他标签页的变化
                this._setupStorageListener();
                
                return userId;
            } catch (e) {
                console.warn('访问localStorage失败，使用内存存储');
            }
        }
        
        // localStorage不可用，使用内存存储
        if (!this._memoryUserId) {
            this._memoryUserId = this.generateUUID();
            console.log('使用内存存储创建用户ID:', this._memoryUserId);
        }
        
        return this._memoryUserId;
    },
    
    /**
     * 创建用户ID（同步方式，兼容旧代码）
     * @private
     */
    _createUserId() {
        const userId = this.generateUUID();
        
        if (this.isStorageAvailable()) {
            try {
                // 检查是否被其他标签页设置
                const existingId = localStorage.getItem(this.STORAGE_KEY);
                if (existingId) {
                    this._cachedUserId = existingId;
                    return existingId;
                }
                
                localStorage.setItem(this.STORAGE_KEY, userId);
                this._cachedUserId = userId;
                return userId;
            } catch (e) {
                // 忽略错误
            }
        }
        
        this._memoryUserId = userId;
        return userId;
    },
    
    /**
     * 设置storage事件监听，同步多标签页
     * @private
     */
    _setupStorageListener() {
        if (typeof window !== 'undefined') {
            window.addEventListener('storage', (e) => {
                if (e.key === this.STORAGE_KEY && e.newValue) {
                    this._cachedUserId = e.newValue;
                    console.log('同步用户ID:', e.newValue);
                }
            });
        }
    },
    
    /**
     * 生成UUID v4
     */
    generateUUID() {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
            const r = Math.random() * 16 | 0;
            const v = c === 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    },
    
    /**
     * 重置用户ID（用于测试或清除数据）
     */
    resetUserId() {
        if (this.isStorageAvailable()) {
            try {
                localStorage.removeItem(this.STORAGE_KEY);
            } catch (e) {
                // 忽略错误
            }
        }
        this._memoryUserId = null;
        this._cachedUserId = null;
        return this.getUserId();
    }
};

/**
 * 认证管理模块
 * 处理用户注册、登录、JWT Token管理
 */
const AuthManager = {
    TOKEN_KEY: 'smart_scheduler_token',
    USER_KEY: 'smart_scheduler_user',
    
    /**
     * 获取存储的Token
     */
    getToken() {
        try {
            return localStorage.getItem(this.TOKEN_KEY);
        } catch (e) {
            return null;
        }
    },
    
    /**
     * 保存Token
     */
    setToken(token) {
        try {
            localStorage.setItem(this.TOKEN_KEY, token);
        } catch (e) {
            console.warn('无法保存Token');
        }
    },
    
    /**
     * 移除Token
     */
    removeToken() {
        try {
            localStorage.removeItem(this.TOKEN_KEY);
            localStorage.removeItem(this.USER_KEY);
        } catch (e) {
            // 忽略错误
        }
    },
    
    /**
     * 获取当前登录用户
     */
    getCurrentUser() {
        try {
            const userStr = localStorage.getItem(this.USER_KEY);
            return userStr ? JSON.parse(userStr) : null;
        } catch (e) {
            return null;
        }
    },
    
    /**
     * 保存用户信息
     */
    setCurrentUser(user) {
        try {
            localStorage.setItem(this.USER_KEY, JSON.stringify(user));
        } catch (e) {
            console.warn('无法保存用户信息');
        }
    },
    
    /**
     * 检查是否已登录
     */
    isLoggedIn() {
        return !!this.getToken();
    },
    
    /**
     * 用户注册
     */
    async register(username, password, email, nickname) {
        try {
            const response = await fetch('/api/auth/register', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, password, email, nickname })
            });
            
            const result = await response.json();
            
            if (result.success) {
                this.setToken(result.token);
                this.setCurrentUser(result.user);
            }
            
            return result;
        } catch (error) {
            return { success: false, message: '注册失败，请检查网络连接' };
        }
    },
    
    /**
     * 用户登录
     */
    async login(username, password) {
        try {
            const response = await fetch('/api/auth/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, password })
            });
            
            const result = await response.json();
            
            if (result.success) {
                this.setToken(result.token);
                this.setCurrentUser(result.user);
            }
            
            return result;
        } catch (error) {
            return { success: false, message: '登录失败，请检查网络连接' };
        }
    },
    
    /**
     * 用户登出
     */
    logout() {
        this.removeToken();
        window.location.reload();
    }
};

/**
 * 请求管理器
 * 提供请求去重、缓存、超时控制等功能
 */
const RequestManager = {
    // 请求去重映射表
    _pendingRequests: new Map(),
    // 请求缓存
    _cache: new Map(),
    // 默认缓存时间（毫秒）
    DEFAULT_CACHE_TTL: 30000,
    // 默认请求超时（毫秒）
    DEFAULT_TIMEOUT: 30000,
    
    /**
     * 生成请求唯一键
     * @param {string} method - HTTP方法
     * @param {string} url - 请求URL
     * @param {object} data - 请求数据
     */
    _generateKey(method, url, data) {
        const dataStr = data ? JSON.stringify(data) : '';
        return `${method}:${url}:${dataStr}`;
    },
    
    /**
     * 发送请求（带去重和缓存）
     * @param {string} method - HTTP方法
     * @param {string} url - 请求URL
     * @param {object} options - 请求选项
     * @param {object} config - 配置
     *   - cache: 是否启用缓存（默认false）
     *   - cacheTTL: 缓存时间（毫秒）
     *   - dedupe: 是否去重（默认true）
     *   - timeout: 超时时间（毫秒）
     */
    async request(method, url, options = {}, config = {}) {
        const {
            cache = false,
            cacheTTL = this.DEFAULT_CACHE_TTL,
            dedupe = true,
            timeout = this.DEFAULT_TIMEOUT
        } = config;
        
        const key = this._generateKey(method, url, options.body);
        
        // 检查缓存
        if (cache && method === 'GET') {
            const cached = this._getCached(key);
            if (cached) {
                console.debug(`[RequestManager] 缓存命中: ${url}`);
                return cached;
            }
        }
        
        // 检查是否有相同的待处理请求
        if (dedupe && this._pendingRequests.has(key)) {
            console.debug(`[RequestManager] 请求去重: ${url}`);
            return this._pendingRequests.get(key);
        }
        
        // 创建请求Promise
        const requestPromise = this._executeRequest(url, options, timeout);
        
        // 如果启用去重，存储待处理请求
        if (dedupe) {
            this._pendingRequests.set(key, requestPromise);
        }
        
        try {
            const response = await requestPromise;
            
            // 缓存GET请求
            if (cache && method === 'GET' && response.ok) {
                const clonedResponse = response.clone();
                this._setCache(key, clonedResponse, cacheTTL);
            }
            
            return response;
        } finally {
            // 清理待处理请求
            if (dedupe) {
                this._pendingRequests.delete(key);
            }
        }
    },
    
    /**
     * 执行实际请求（带超时控制）
     */
    async _executeRequest(url, options, timeout) {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), timeout);
        
        try {
            const response = await fetch(url, {
                ...options,
                signal: controller.signal
            });
            return response;
        } finally {
            clearTimeout(timeoutId);
        }
    },
    
    /**
     * 获取缓存的响应
     */
    _getCached(key) {
        const cached = this._cache.get(key);
        if (!cached) return null;
        
        // 检查是否过期
        if (Date.now() > cached.expiry) {
            this._cache.delete(key);
            return null;
        }
        
        return cached.response;
    },
    
    /**
     * 设置缓存
     */
    _setCache(key, response, ttl) {
        this._cache.set(key, {
            response,
            expiry: Date.now() + ttl
        });
    },
    
    /**
     * 清除缓存
     * @param {string} pattern - 可选的URL模式匹配
     */
    clearCache(pattern = null) {
        if (!pattern) {
            this._cache.clear();
            console.debug('[RequestManager] 缓存已清空');
            return;
        }
        
        // 清除匹配的缓存
        for (const key of this._cache.keys()) {
            if (key.includes(pattern)) {
                this._cache.delete(key);
            }
        }
    },
    
    /**
     * 取消所有待处理请求
     */
    cancelAll() {
        this._pendingRequests.clear();
        console.debug('[RequestManager] 所有待处理请求已取消');
    },
    
    /**
     * 获取待处理请求数量
     */
    getPendingCount() {
        return this._pendingRequests.size;
    }
};

/**
 * API请求封装
 * 自动添加用户ID头部和JWT Token
 */
const API = {
    BASE: '/api',
    
    /**
     * 发送请求（自动添加用户ID头部和Token）
     */
    async request(url, options = {}) {
        const userId = UserManager.getUserId();
        const token = AuthManager.getToken();
        
        const headers = {
            ...options.headers,
            'X-User-ID': userId
        };
        
        // 如果有JWT Token，添加到Authorization头部
        if (token) {
            headers['Authorization'] = `Bearer ${token}`;
        }
        
        console.log('API Request:', url, 'UserId:', userId, 'Headers:', headers);
        
        return fetch(url, {
            ...options,
            headers
        });
    },
    
    /**
     * GET请求
     */
    async get(endpoint) {
        return this.request(`${this.BASE}${endpoint}`);
    },
    
    /**
     * POST请求
     */
    async post(endpoint, data) {
        return this.request(`${this.BASE}${endpoint}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
    },
    
    /**
     * PUT请求
     */
    async put(endpoint, data) {
        return this.request(`${this.BASE}${endpoint}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
    },
    
    /**
     * DELETE请求
     */
    async del(endpoint) {
        return this.request(`${this.BASE}${endpoint}`, {
            method: 'DELETE'
        });
    },
    
    // ==================== 任务状态管理 API ====================
    
    /**
     * 统一任务状态更新接口
     * @param {number} taskId - 任务ID
     * @param {string} action - 操作类型: start | complete | uncomplete | pause
     * @param {object} options - 可选参数
     */
    async updateTaskStatus(taskId, action, options = {}) {
        const response = await this.put(`/tasks/${taskId}/status`, {
            action: action,
            ...options
        });
        return response.json();
    },
    
    /**
     * 开始任务
     * @param {number} taskId - 任务ID
     */
    async startTask(taskId) {
        return this.updateTaskStatus(taskId, 'start');
    },
    
    /**
     * 完成任务
     * @param {number} taskId - 任务ID
     * @param {number} actualDuration - 可选，实际耗时（分钟）
     */
    async completeTask(taskId, actualDuration = null) {
        const options = actualDuration ? { actual_duration: actualDuration } : {};
        return this.updateTaskStatus(taskId, 'complete', options);
    },
    
    /**
     * 取消完成任务
     * @param {number} taskId - 任务ID
     */
    async uncompleteTask(taskId) {
        return this.updateTaskStatus(taskId, 'uncomplete');
    },
    
    /**
     * 暂停任务
     * @param {number} taskId - 任务ID
     */
    async pauseTask(taskId) {
        return this.updateTaskStatus(taskId, 'pause');
    },
    
    /**
     * 获取任务列表
     */
    async getTasks() {
        const response = await this.get('/tasks');
        return response.json();
    },
    
    // ==================== 动态排序 API ====================
    
    /**
     * 获取动态排序配置
     */
    async getSortConfig() {
        const response = await this.get('/sort/config');
        return response.json();
    },
    
    /**
     * 更新动态排序配置
     * @param {object} config - 配置对象
     */
    async updateSortConfig(config) {
        const response = await this.post('/sort/config', config);
        return response.json();
    },
    
    /**
     * 触发自动排序
     * @param {string} reason - 排序原因
     */
    async triggerAutoSort(reason = 'manual') {
        const response = await this.post('/sort/auto', { reason });
        return response.json();
    },
    
    /**
     * 获取排序历史
     * @param {number} limit - 限制数量
     */
    async getSortHistory(limit = 30) {
        const response = await this.get(`/sort/history?limit=${limit}`);
        return response.json();
    },
    
    /**
     * 自动调整权重
     */
    async autoAdjustWeights() {
        const response = await this.post('/sort/weights/auto-adjust', {});
        return response.json();
    },
    
    /**
     * 获取权重调整历史
     * @param {number} limit - 限制数量
     */
    async getWeightAdjustmentHistory(limit = 50) {
        const response = await this.get(`/sort/weights/adjustment-history?limit=${limit}`);
        return response.json();
    },
    
    /**
     * 提交排序反馈
     * @param {string} feedbackType - 反馈类型: positive | negative | reorder
     * @param {number} taskId - 任务ID（可选）
     * @param {string} details - 详细说明（可选）
     */
    async submitSortFeedback(feedbackType, taskId = null, details = null) {
        const data = { feedback_type: feedbackType };
        if (taskId) data.task_id = taskId;
        if (details) data.details = details;
        const response = await this.post('/sort/feedback', data);
        return response.json();
    },
    
    /**
     * 提交任务执行反馈
     * @param {object} feedback - 执行反馈数据
     */
    async submitExecutionFeedback(feedback) {
        const response = await this.post('/sort/execution-feedback', feedback);
        return response.json();
    },
    
    /**
     * 获取执行模式分析
     * @param {number} days - 分析天数
     */
    async getExecutionPatterns(days = 30) {
        const response = await this.get(`/sort/analysis/patterns?days=${days}`);
        return response.json();
    },
    
    /**
     * 获取排序分析汇总
     */
    async getSortAnalysisSummary() {
        const response = await this.get('/sort/analysis/summary');
        return response.json();
    },
    
    /**
     * 获取动态排序状态
     */
    async getDynamicSortStatus() {
        const response = await this.get('/sort/status');
        return response.json();
    },
    
    // ==================== 任务状态跟踪 API ====================
    
    /**
     * 获取任务状态历史
     * @param {number} taskId - 任务ID
     * @param {number} limit - 限制数量
     */
    async getTaskStatusHistory(taskId, limit = 50) {
        const response = await this.get(`/tracking/status-history/${taskId}?limit=${limit}`);
        return response.json();
    },
    
    /**
     * 记录状态变更
     * @param {object} data - 状态变更数据
     */
    async recordStatusChange(data) {
        const response = await this.post('/api/tracking/status-change', data);
        return response.json();
    },
    
    /**
     * 获取任务执行日志
     * @param {number} taskId - 任务ID
     */
    async getTaskExecutionLog(taskId) {
        const response = await this.get(`/api/tracking/execution-logs/${taskId}`);
        return response.json();
    },
    
    /**
     * 记录执行事件
     * @param {object} data - 事件数据
     */
    async logExecutionEvent(data) {
        const response = await this.post('/api/tracking/log-event', data);
        return response.json();
    },
    
    /**
     * 获取任务时间段记录
     * @param {number} taskId - 任务ID
     */
    async getTaskTimeSegments(taskId) {
        const response = await this.get(`/api/tracking/time-segments/${taskId}`);
        return response.json();
    },
    
    /**
     * 记录执行时间段
     * @param {object} data - 时间段数据
     */
    async recordTimeSegment(data) {
        const response = await this.post('/api/tracking/time-segment', data);
        return response.json();
    },
    
    /**
     * 获取任务执行档案
     * @param {number} taskId - 任务ID
     */
    async getTaskExecutionArchive(taskId) {
        const response = await this.get(`/tracking/archive/${taskId}`);
        return response.json();
    },
    
    /**
     * 获取执行统计
     */
    async getTrackingStatistics() {
        const response = await this.get('/tracking/tasks/summary');
        return response.json();
    },
    
    /**
     * 生成任务执行报告
     * @param {number} taskId - 任务ID
     */
    async generateTaskReport(taskId) {
        const response = await this.get(`/tracking/analytics/${taskId}`);
        return response.json();
    }
};

// ==================== 全局变量 ====================

// API基础URL（保留兼容性）
const API_BASE = '/api';

// 全局状态
let allTasks = [];
let allTags = [];
let currentView = 'all';
let currentTagFilter = null;
let selectedTags = [];
let categoryChart = null;
let trendChart = null;
let currentUser = null; // 当前用户信息

// ==================== 防重复点击工具 ====================

/**
 * 点击管理器 - 防止重复点击和弹窗堆叠
 */
const ClickManager = {
    // 点击计数器
    clickCounts: {},
    // 最近点击时间
    lastClickTime: {},
    // 当前打开的弹窗栈
    modalStack: [],
    // 最大点击次数阈值
    MAX_CLICK_THRESHOLD: 3,
    // 点击重置时间（毫秒）
    CLICK_RESET_TIME: 2000,
    // 防抖时间（毫秒）
    DEBOUNCE_TIME: 300,
    
    /**
     * 记录点击并检查是否需要提醒
     * @param {string} actionKey - 操作标识
     * @returns {Object} - { canProceed: boolean, shouldWarn: boolean, clickCount: number }
     */
    checkClick(actionKey) {
        const now = Date.now();
        const lastTime = this.lastClickTime[actionKey] || 0;
        
        // 如果超过重置时间，重置计数器
        if (now - lastTime > this.CLICK_RESET_TIME) {
            this.clickCounts[actionKey] = 0;
        }
        
        // 增加点击计数
        this.clickCounts[actionKey] = (this.clickCounts[actionKey] || 0) + 1;
        this.lastClickTime[actionKey] = now;
        
        const clickCount = this.clickCounts[actionKey];
        const shouldWarn = clickCount >= this.MAX_CLICK_THRESHOLD;
        
        // 如果达到阈值，重置计数器
        if (shouldWarn) {
            this.clickCounts[actionKey] = 0;
        }
        
        return {
            canProceed: !shouldWarn,
            shouldWarn,
            clickCount
        };
    },
    
    /**
     * 打开弹窗（堆叠式）
     * @param {string} modalId - 弹窗ID
     */
    openModal(modalId) {
        console.log('ClickManager.openModal:', modalId, '当前栈:', this.modalStack);
        
        // 如果弹窗已经在栈顶，直接返回（避免重复打开）
        if (this.modalStack.length > 0 && this.modalStack[this.modalStack.length - 1] === modalId) {
            console.log('弹窗已在栈顶，无需重复打开');
            return;
        }
        
        // 如果弹窗已在栈中但不在栈顶，先将其移到栈顶
        const existingIndex = this.modalStack.indexOf(modalId);
        if (existingIndex > -1) {
            this.modalStack.splice(existingIndex, 1);
        }
        
        // 先关闭当前打开的弹窗（如果不是同一个）
        if (this.modalStack.length > 0) {
            const currentModalId = this.modalStack[this.modalStack.length - 1];
            if (currentModalId !== modalId) {
                const currentModal = document.getElementById(currentModalId);
                if (currentModal) {
                    currentModal.classList.remove('active');
                    currentModal.style.opacity = '';
                    currentModal.style.visibility = '';
                    currentModal.style.display = '';
                }
            }
        }
        
        // 打开新弹窗并加入栈
        const modal = document.getElementById(modalId);
        console.log('Found modal element:', modal);
        if (modal) {
            // 先禁用过渡，避免动画干扰
            modal.style.setProperty('transition', 'none', 'important');
            const modalContent = modal.querySelector('.modal');
            if (modalContent) {
                modalContent.style.setProperty('transition', 'none', 'important');
            }
            
            // 先移除再添加 active 类
            modal.classList.remove('active');
            void modal.offsetWidth;
            modal.classList.add('active');
            
            // 强制设置样式确保弹窗显示
            modal.style.setProperty('position', 'fixed', 'important');
            modal.style.setProperty('top', '0', 'important');
            modal.style.setProperty('left', '0', 'important');
            modal.style.setProperty('right', '0', 'important');
            modal.style.setProperty('bottom', '0', 'important');
            modal.style.setProperty('z-index', '999999', 'important');
            modal.style.setProperty('opacity', '1', 'important');
            modal.style.setProperty('visibility', 'visible', 'important');
            modal.style.setProperty('display', 'flex', 'important');
            modal.style.setProperty('align-items', 'center', 'important');
            modal.style.setProperty('justify-content', 'center', 'important');
            modal.style.setProperty('background-color', 'rgba(0, 0, 0, 0.5)', 'important');
            modal.style.setProperty('pointer-events', 'auto', 'important');
            
            // 同时设置子 modal 元素的样式
            if (modalContent) {
                modalContent.style.cssText = 'background-color: #ffffff; border-radius: 12px; box-shadow: 0 4px 16px rgba(0, 0, 0, 0.12); width: 90%; max-width: 800px; max-height: 90vh; overflow: hidden; transform: scale(1); transition: none !important;';
            }
            
            this.modalStack.push(modalId);
            console.log('Modal activated with inline styles, stack:', this.modalStack);
            
            // 延迟恢复过渡效果
            setTimeout(() => {
                modal.style.removeProperty('transition');
                if (modalContent) {
                    modalContent.style.removeProperty('transition');
                }
            }, 50);
        }
    },
    
    /**
     * 关闭弹窗
     * @param {string} modalId - 弹窗ID
     */
    closeModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('active');
            // 清除内联样式
            modal.style.opacity = '';
            modal.style.visibility = '';
            modal.style.display = '';
            modal.style.zIndex = '';
            modal.style.pointerEvents = '';

            // 清除子 modal 元素的 transform
            const modalContent = modal.querySelector('.modal');
            if (modalContent) {
                modalContent.style.transform = '';
            }
        }
        
        // 从栈中移除
        const index = this.modalStack.indexOf(modalId);
        if (index > -1) {
            this.modalStack.splice(index, 1);
        }
        
        // 如果还有弹窗在栈中，恢复显示上一个
        if (this.modalStack.length > 0) {
            const prevModalId = this.modalStack[this.modalStack.length - 1];
            const prevModal = document.getElementById(prevModalId);
            if (prevModal) {
                prevModal.classList.add('active');
                prevModal.style.opacity = '1';
                prevModal.style.visibility = 'visible';
                prevModal.style.display = 'flex';
                
                const prevModalContent = prevModal.querySelector('.modal');
                if (prevModalContent) {
                    prevModalContent.style.transform = 'scale(1)';
                }
            }
        }
    },
    
    /**
     * 关闭所有弹窗
     */
    closeAllModals() {
        this.modalStack.forEach(modalId => {
            document.getElementById(modalId)?.classList.remove('active');
        });
        this.modalStack = [];
    },
    
    /**
     * 重置点击计数
     * @param {string} actionKey - 操作标识
     */
    resetClickCount(actionKey) {
        this.clickCounts[actionKey] = 0;
    }
};

// ==================== 初始化 ====================
document.addEventListener('DOMContentLoaded', () => {
    // 初始化UI（不依赖API）
    initTheme();
    initNavigation();
    initMobileMenu();
    initMobileFeatures();
    initRecurringPresets();
    initSortPresets();
    setDefaultStartTime();
    
    // 异步加载数据（不阻塞UI显示）
    initAppData();
});

// 初始化应用数据
async function initAppData() {
    // 显示加载状态
    const loadingIndicator = document.getElementById('loadingIndicator');
    if (loadingIndicator) {
        loadingIndicator.style.display = 'flex';
    }
    
    try {
        // 并行加载所有数据
        await Promise.allSettled([
            loadUserProfile(),
            loadTasks(),
            loadTags(),
            loadCategories(),
            loadTodayPlan()  // 添加今日计划加载
        ]);
    } catch (error) {
        console.error('初始化数据加载失败:', error);
    } finally {
        // 隐藏加载状态
        if (loadingIndicator) {
            loadingIndicator.style.display = 'none';
        }
    }
}

// 设置默认开始时间为当前时间
function setDefaultStartTime() {
    const startTimeInput = document.getElementById('newTaskStartTime');
    if (startTimeInput) {
        const now = new Date();
        // 格式化为 datetime-local 需要的格式: YYYY-MM-DDTHH:MM
        const year = now.getFullYear();
        const month = String(now.getMonth() + 1).padStart(2, '0');
        const day = String(now.getDate()).padStart(2, '0');
        const hours = String(now.getHours()).padStart(2, '0');
        const minutes = String(now.getMinutes()).padStart(2, '0');
        startTimeInput.value = `${year}-${month}-${day}T${hours}:${minutes}`;
        
        // 重置用户修改标记
        startTimeInput.dataset.userModified = 'false';
        
        // 添加变更监听器（只添加一次）
        if (!startTimeInput.dataset.hasListener) {
            startTimeInput.addEventListener('change', function() {
                this.dataset.userModified = 'true';
                console.log('[TimeInput] 用户手动修改了时间');
            });
            startTimeInput.dataset.hasListener = 'true';
        }
    }
}

// ==================== 导航 ====================

function initNavigation() {
    const navItems = document.querySelectorAll('.nav-item[data-view]');
    navItems.forEach(item => {
        item.addEventListener('click', () => {
            navItems.forEach(n => n.classList.remove('active'));
            item.classList.add('active');
            currentView = item.dataset.view;
            currentTagFilter = null; // 清除标签筛选
            resetCategoryFilter(); // 重置分类过滤器
            updatePageTitle();
            renderTasks();
            // 移动端自动关闭侧边栏
            if (window.innerWidth <= 768) {
                closeSidebar();
            }
        });
    });
}

function initMobileMenu() {
    const menuToggle = document.getElementById('menuToggle');
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    
    if (menuToggle) {
        menuToggle.addEventListener('click', () => {
            openSidebar();
        });
    }
}

function openSidebar() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    if (sidebar) {
        sidebar.classList.add('open');
    }
    if (overlay) {
        overlay.classList.add('active');
    }
    document.body.style.overflow = 'hidden';
}

function closeSidebar() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    if (sidebar) {
        sidebar.classList.remove('open');
    }
    if (overlay) {
        overlay.classList.remove('active');
    }
    document.body.style.overflow = '';
}

// ==================== 移动端导航和快速添加 ====================

let quickAddCategory = '';

/**
 * 切换移动端底部导航视图
 */
function switchMobileView(view) {
    currentView = view;
    
    // 更新底部导航激活状态
    document.querySelectorAll('.mobile-nav-item').forEach(item => {
        item.classList.remove('active');
        if (item.dataset.view === view) {
            item.classList.add('active');
        }
    });
    
    // 更新侧边栏激活状态
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
        if (item.dataset.view === view) {
            item.classList.add('active');
        }
    });
    
    updatePageTitle();
    renderTasks();
}

/**
 * 显示移动端更多菜单
 */
function showMobileMenu() {
    const modal = document.getElementById('mobileMenuModal');
    if (modal) {
        modal.classList.add('active');
    }
}

/**
 * 显示快速添加模态框
 */
function showQuickAddModal() {
    const modal = document.getElementById('quickAddModal');
    const input = document.getElementById('quickAddInput');
    
    if (modal) {
        modal.classList.add('active');
        // 重置状态
        quickAddCategory = '';
        document.querySelectorAll('.quick-add-option').forEach(btn => {
            btn.classList.remove('selected');
        });
        if (input) {
            input.value = '';
            input.focus();
        }
    }
}

/**
 * 隐藏快速添加模态框
 */
function hideQuickAddModal() {
    const modal = document.getElementById('quickAddModal');
    if (modal) {
        modal.classList.remove('active');
    }
}

/**
 * 选择快速添加的分类
 */
function selectQuickCategory(btn) {
    document.querySelectorAll('.quick-add-option').forEach(b => {
        b.classList.remove('selected');
    });
    btn.classList.add('selected');
    quickAddCategory = btn.dataset.category;
}

/**
 * 处理快速添加回车键
 */
function handleQuickAddKeypress(event) {
    if (event.key === 'Enter') {
        quickAddTask();
    }
}

/**
 * 智能时间解析器 - 支持开始时间和结束时间的完整解析
 * 支持格式：
 * - "今天中午12点打篮球" -> 今天12:00
 * - "明天下午3点开会" -> 明天15:00
 * - "下午2点到4点开会" -> 开始14:00，结束16:00
 * - "明天上午9点到11点做报告" -> 开始明天9:00，结束明天11:00
 * @param {string} title - 任务标题
 * @returns {Object|null} - {startTime: string, endTime: string|null, confidence: number, parsedText: string}
 */
function parseTimeFromTitle(title) {
    if (!title) return null;
    
    console.log('[TimeParser] 开始解析:', title);
    
    // 预处理：标准化中文时间表达
    let normalizedTitle = title
        .replace(/晚上/g, '下午')
        .replace(/傍晚/g, '下午')
        .replace(/清晨/g, '早上')
        .replace(/早晨/g, '早上')
        .replace(/礼拜/g, '星期')
        .replace(/週/g, '周');
    
    // 首先尝试解析时间段（开始+结束）
    const timeRange = parseTimeRange(normalizedTitle);
    if (timeRange) {
        console.log('[TimeParser] 解析到时间段:', timeRange);
        return timeRange;
    }
    
    // 使用 chrono-node 进行智能时间解析（单个时间点）
    if (typeof chrono !== 'undefined') {
        try {
            const results = chrono.parse(normalizedTitle, new Date(), { forwardDate: true });
            
            if (results && results.length > 0) {
                const result = results[0];
                let date = result.start.date();
                
                // 检查是否需要手动调整
                const chronoHour = result.start.get('hour');
                const manualTime = extractChineseTime(normalizedTitle);
                
                if (manualTime) {
                    date = manualTime.date;
                }
                
                const startTimeStr = formatLocalDateTime(date);
                console.log('[TimeParser] 解析到单个时间点:', startTimeStr);
                
                return {
                    startTime: startTimeStr,
                    endTime: null,
                    confidence: 0.8,
                    parsedText: result.text
                };
            }
        } catch (e) {
            console.warn('[TimeParser] chrono 解析失败:', e);
        }
    }
    
    // 降级方案
    console.log('[TimeParser] 使用降级方案');
    const fallbackTime = parseTimeFromTitleFallback(title);
    if (fallbackTime) {
        return {
            startTime: fallbackTime,
            endTime: null,
            confidence: 0.6,
            parsedText: null
        };
    }
    
    return null;
}

/**
 * 解析时间段（开始时间和结束时间）
 * 支持格式：
 * - "下午2点到4点开会"
 * - "明天上午9点到11点做报告"
 * - "14:00-16:00会议"
 * - "从上午9点开始到下午5点结束"
 * @param {string} title - 任务标题
 * @returns {Object|null} - {startTime, endTime, confidence, parsedText}
 */
function parseTimeRange(title) {
    // 时间段模式匹配
    const rangePatterns = [
        // 中文格式：X点到Y点
        {
            regex: /(明天|后天|大后天)?\s*(上午|下午|早上|中午|晚上)?\s*(\d{1,2})\s*点\s*(半)?\s*(?:到|至|~)\s*(明天|后天|大后天)?\s*(上午|下午|早上|中午|晚上)?\s*(\d{1,2})\s*点\s*(半)?/,
            type: 'chinese_range'
        },
        // 数字格式：XX:XX-YY:YY 或 XX:XX~YY:YY
        {
            regex: /(\d{1,2}):(\d{2})\s*(?:-|~|到|至)\s*(\d{1,2}):(\d{2})/,
            type: 'colon_range'
        },
        // 混合格式：上午X点到下午Y点
        {
            regex: /(上午|下午|早上|晚上)\s*(\d{1,2})\s*点\s*(?:到|至)\s*(上午|下午|早上|晚上)\s*(\d{1,2})\s*点/,
            type: 'mixed_range'
        },
        // 从...到...格式
        {
            regex: /从\s*(明天|后天)?\s*(上午|下午|早上|中午|晚上)?\s*(\d{1,2})\s*点\s*(?:开始)?\s*(?:到|至)\s*(明天|后天)?\s*(上午|下午|早上|中午|晚上)?\s*(\d{1,2})\s*点/,
            type: 'from_to'
        }
    ];
    
    for (const pattern of rangePatterns) {
        const match = title.match(pattern.regex);
        if (match) {
            console.log('[TimeRange] 匹配到模式:', pattern.type, match);
            
            let startDate = new Date();
            let endDate = new Date();
            let startHour, startMinute = 0, endHour, endMinute = 0;
            
            if (pattern.type === 'colon_range') {
                // XX:XX-YY:YY 格式
                startHour = parseInt(match[1]);
                startMinute = parseInt(match[2]);
                endHour = parseInt(match[3]);
                endMinute = parseInt(match[4]);
            } else {
                // 中文格式
                const startDayOffset = getDayOffset(match[1]);
                const startPeriod = match[2] || '';
                startHour = parseInt(match[3]);
                startMinute = match[4] === '半' ? 30 : 0;
                
                const endDayOffset = getDayOffset(match[5]) || startDayOffset;
                const endPeriod = match[6] || startPeriod;
                endHour = parseInt(match[7]);
                endMinute = match[8] === '半' ? 30 : 0;
                
                // 应用日期偏移
                startDate.setDate(startDate.getDate() + startDayOffset);
                endDate.setDate(endDate.getDate() + endDayOffset);
                
                // 应用时段转换
                startHour = applyPeriodOffset(startHour, startPeriod);
                endHour = applyPeriodOffset(endHour, endPeriod);
            }
            
            // 验证时间合理性
            if (startHour > 23 || endHour > 23 || startHour < 0 || endHour < 0) {
                continue;
            }
            
            startDate.setHours(startHour, startMinute, 0, 0);
            endDate.setHours(endHour, endMinute, 0, 0);
            
            // 如果结束时间早于开始时间，假设是跨天或24小时制问题
            if (endDate <= startDate) {
                // 如果结束小时小于开始小时，可能是下午/晚上时段
                if (endHour < startHour && endHour < 12) {
                    endDate.setDate(endDate.getDate() + 1);
                }
            }
            
            return {
                startTime: formatLocalDateTime(startDate),
                endTime: formatLocalDateTime(endDate),
                confidence: 0.9,
                parsedText: match[0]
            };
        }
    }
    
    return null;
}

/**
 * 获取日期偏移量
 */
function getDayOffset(dayWord) {
    if (!dayWord) return 0;
    if (dayWord.includes('明天')) return 1;
    if (dayWord.includes('后天')) return 2;
    if (dayWord.includes('大后天')) return 3;
    return 0;
}

/**
 * 应用时段偏移（上午/下午等转换为24小时制）
 */
function applyPeriodOffset(hour, period) {
    if (!period) return hour;
    
    if ((period === '下午' || period === '晚上') && hour < 12) {
        return hour + 12;
    } else if (period === '中午' && hour < 12) {
        return hour + 12;
    } else if (period === '上午' || period === '早上') {
        return hour; // 保持原值
    }
    return hour;
}

/**
 * 格式化为本地时间字符串 (YYYY-MM-DDTHH:mm)
 */
function formatLocalDateTime(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    return `${year}-${month}-${day}T${hours}:${minutes}`;
}

/**
 * 手动提取中文时间（辅助 chrono-node）
 */
function extractChineseTime(title) {
    const now = new Date();
    let targetDate = new Date(now);
    let hour = null;
    let minute = 0;
    
    // 解析日期关键词
    if (title.includes('明天')) {
        targetDate.setDate(targetDate.getDate() + 1);
    } else if (title.includes('后天')) {
        targetDate.setDate(targetDate.getDate() + 2);
    }
    
    // 匹配时段词 + 时间
    const patterns = [
        // 下午/晚上 X点
        { regex: /(下午|晚上)\s*(\d{1,2})\s*点?/, offset: 12 },
        // 中午 X点
        { regex: /中午\s*(\d{1,2})\s*点?/, offset: (h) => h < 12 ? 12 : 0 },
        // 上午/早上 X点
        { regex: /(上午|早上)\s*(\d{1,2})\s*点?/, offset: 0 },
        // 纯数字时间（24小时制）
        { regex: /(\d{1,2}):(\d{2})/, isColon: true },
        // X点X分
        { regex: /(\d{1,2})\s*点\s*(\d{1,2})\s*分?/, offset: 0 },
        // X点半
        { regex: /(\d{1,2})\s*点半/, offset: 0, minute: 30 },
        // X点
        { regex: /(\d{1,2})\s*点/, offset: 0 }
    ];
    
    for (const pattern of patterns) {
        const match = title.match(pattern.regex);
        if (match) {
            if (pattern.isColon) {
                // XX:XX 格式
                hour = parseInt(match[1]);
                minute = parseInt(match[2]);
            } else {
                hour = parseInt(match[2] || match[1]);
                if (pattern.minute !== undefined) {
                    minute = pattern.minute;
                } else if (match[3]) {
                    minute = parseInt(match[3]);
                }
                
                // 应用时段偏移
                if (typeof pattern.offset === 'function') {
                    hour = hour + pattern.offset(hour);
                } else if (pattern.offset && hour < 12) {
                    hour = hour + pattern.offset;
                }
            }
            
            targetDate.setHours(hour, minute, 0, 0);
            console.log('[extractChineseTime] 匹配成功:', {
                pattern: pattern.regex.source,
                match: match[0],
                hour: hour,
                minute: minute,
                result: targetDate.toISOString()
            });
            return { date: targetDate, hour, minute };
        }
    }
    
    return null;
}

/**
 * 时间解析降级方案（正则表达式）
 */
function parseTimeFromTitleFallback(title) {
    const now = new Date();
    let targetDate = new Date(now);
    let hour = null;
    let minute = 0;
    
    console.log('[Fallback] 开始解析:', title, '当前时间:', now.toISOString());
    
    // 解析日期关键词
    if (title.includes('明天')) {
        targetDate.setDate(targetDate.getDate() + 1);
    } else if (title.includes('后天')) {
        targetDate.setDate(targetDate.getDate() + 2);
    }
    
    // 解析时间 - 优先匹配带时段词的模式
    const timePatterns = [
        // 上午/下午/晚上 X点（优先匹配）
        { regex: /(上午|下午|晚上|早晨|早上|中午)\s*(\d{1,2})\s*点?/, hasPeriod: true },
        // 几点、几点半、几点几分
        { regex: /(\d{1,2})\s*点\s*(半|(\d{1,2})\s*分?)?/, hasPeriod: false },
        // XX:XX 格式
        { regex: /(\d{1,2}):(\d{2})/, hasPeriod: false, isColon: true }
    ];
    
    // 尝试匹配时间（按优先级顺序）
    for (const pattern of timePatterns) {
        const match = title.match(pattern.regex);
        if (match) {
            console.log('[Fallback] 匹配到模式:', pattern.regex.source, '匹配内容:', match[0]);
            
            if (pattern.isColon) {
                // XX:XX 格式
                hour = parseInt(match[1]);
                minute = parseInt(match[2]);
            } else if (pattern.hasPeriod) {
                // 带时段词的模式
                const period = match[1];
                hour = parseInt(match[2]);
                
                // 转换12小时制到24小时制
                if ((period === '下午' || period === '晚上') && hour < 12) {
                    hour += 12;
                } else if (period === '中午' && hour < 12) {
                    hour += 12;
                }
                // 上午、早晨、早上保持原值
            } else {
                // 纯数字+点 模式
                hour = parseInt(match[1]);
                if (match[2] === '半') {
                    minute = 30;
                } else if (match[3]) {
                    minute = parseInt(match[3]);
                }
            }
            break; // 匹配成功就退出
        }
    }
    
    // 如果没有解析到小时，返回null
    if (hour === null || hour < 0 || hour > 23) {
        return null;
    }
    
    // 设置时间
    targetDate.setHours(hour, minute, 0, 0);
    
    console.log('[Fallback] 解析结果:', {
        hour: hour,
        minute: minute,
        targetDate: targetDate.toISOString(),
        localString: targetDate.toString()
    });
    
    // 转换为本地时间字符串 (YYYY-MM-DDTHH:mm)
    const year = targetDate.getFullYear();
    const month = String(targetDate.getMonth() + 1).padStart(2, '0');
    const day = String(targetDate.getDate()).padStart(2, '0');
    const hours = String(targetDate.getHours()).padStart(2, '0');
    const minutes = String(targetDate.getMinutes()).padStart(2, '0');
    
    return `${year}-${month}-${day}T${hours}:${minutes}`;
}

/**
 * 快速添加任务 - 使用智能时间解析
 */
async function quickAddTask() {
    const input = document.getElementById('quickAddInput');
    const title = input ? input.value.trim() : '';
    
    if (!title) {
        showToast('请输入任务内容', 'error');
        return;
    }
    
    const category = quickAddCategory || '未分类';
    
    // 使用智能时间解析
    const timeParseResult = await resolveTaskTime(title, category);
    const difficultyInfo = assessTaskDifficulty(title, category);
    
    try {
        const taskData = {
            title: title,
            category: category,
            priority: 3,
            start_time: timeParseResult.startTime,
            end_time: timeParseResult.endTime,
            estimated_duration: timeParseResult.estimatedDuration,
            difficulty_level: difficultyInfo.level
        };
        
        const response = await API.post('/tasks', taskData);
        
        if (response.ok) {
            const result = await response.json();
            
            // 显示智能推荐信息（如果后端使用了智能推荐）
            if (result.recommendation && result.recommendation.used_smart_recommendation) {
                showSmartRecommendationNotification(result.recommendation, result.task);
            } else {
                showSmartTaskNotification(timeParseResult, difficultyInfo);
            }
            
            showToast('任务添加成功', 'success');
            hideQuickAddModal();
            input.value = '';
            await loadTasks();
            clearAICache();
        } else {
            const error = await response.json();
            showToast(error.message || '添加失败', 'error');
        }
    } catch (error) {
        console.error('添加任务失败:', error);
        showToast('添加失败，请重试', 'error');
    }
}

/**
 * 更新移动端底部导航徽章
 */
function updateMobileNavBadges() {
    const allCount = allTasks.filter(t => !t.is_completed).length;
    const todayCount = allTasks.filter(t => {
        if (t.is_completed) return false;
        if (!t.end_time) return false;
        const today = new Date().toDateString();
        const taskDate = new Date(t.end_time).toDateString();
        return today === taskDate;
    }).length;
    
    // 更新底部导航徽章（如果有的话）
    const allBadge = document.querySelector('.mobile-nav-item[data-view="all"] .nav-badge-mobile');
    const todayBadge = document.querySelector('.mobile-nav-item[data-view="today"] .nav-badge-mobile');
    
    if (allBadge) {
        allBadge.textContent = allCount;
        allBadge.style.display = allCount > 0 ? 'flex' : 'none';
    }
    
    if (todayBadge) {
        todayBadge.textContent = todayCount;
        todayBadge.style.display = todayCount > 0 ? 'flex' : 'none';
    }
}

/**
 * 检测是否为移动设备
 */
function isMobileDevice() {
    return window.innerWidth <= 768 || 
           /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
}

/**
 * 初始化移动端特性
 */
function initMobileFeatures() {
    // 点击快速添加模态框背景关闭
    const quickAddModal = document.getElementById('quickAddModal');
    if (quickAddModal) {
        quickAddModal.addEventListener('click', (e) => {
            if (e.target === quickAddModal) {
                hideQuickAddModal();
            }
        });
    }
    
    // 监听窗口大小变化
    window.addEventListener('resize', () => {
        if (window.innerWidth > 768) {
            hideQuickAddModal();
        }
    });
    
    // 更新移动端导航徽章
    updateMobileNavBadges();
}

function updatePageTitle() {
    const titles = {
        'all': '所有任务',
        'today': '今天',
        'completed': '已完成',
        'tag': '标签筛选'
    };
    
    let title = titles[currentView] || '所有任务';
    
    // 如果是标签筛选，显示标签名称
    if (currentView === 'tag' && currentTagFilter) {
        const tag = allTags.find(t => t.id === parseInt(currentTagFilter));
        if (tag) {
            title = tag.name;
        }
    }
    
    document.getElementById('pageTitle').textContent = title;
}

// ==================== 任务管理 ====================

async function loadTasks() {
    try {
        const userId = UserManager.getUserId();
        console.log('loadTasks: userId =', userId);
        
        const response = await API.get('/tasks');
        console.log('loadTasks: response status =', response.status);
        
        if (response.ok) {
            allTasks = await response.json();
            updateStats();
            renderTasks();
            updateNavBadges();
        } else {
            const errorText = await response.text();
            console.error('加载任务失败: HTTP', response.status, errorText);
        }
    } catch (error) {
        console.error('加载任务失败:', error);
        // 不显示toast，避免页面一打开就报错
    }
}

function renderTasks() {
    const taskList = document.getElementById('taskList');
    const emptyState = document.getElementById('emptyState');
    const categoryFilter = document.getElementById('categoryFilter').value;
    const sortFilter = document.getElementById('sortFilter').value;
    
    let filteredTasks = filterTasksByView(allTasks, currentView);
    
    if (categoryFilter) {
        filteredTasks = filteredTasks.filter(t => t.category === categoryFilter);
    }
    
    filteredTasks = sortTasks(filteredTasks, sortFilter);
    
    if (filteredTasks.length === 0) {
        taskList.innerHTML = '';
        emptyState.style.display = 'block';
        return;
    }
    
    emptyState.style.display = 'none';
    taskList.innerHTML = filteredTasks.map(task => createTaskHTML(task)).join('');
}

function filterTasksByView(tasks, view) {
    const today = new Date().toDateString();
    
    switch (view) {
        case 'today':
            return tasks.filter(t => {
                if (!t.start_time) return false;
                const taskDate = new Date(t.start_time).toDateString();
                return taskDate === today && !t.is_completed;
            });
        case 'completed':
            return tasks.filter(t => t.is_completed);
        case 'tag':
            // 按标签筛选，只显示未完成的任务
            if (currentTagFilter) {
                return tasks.filter(t => {
                    if (t.is_completed) return false; // 过滤已完成任务
                    const taskTags = t.tags || [];
                    return taskTags.some(tag => tag.id === currentTagFilter || tag.id === parseInt(currentTagFilter));
                });
            }
            return tasks.filter(t => !t.is_completed);
        default:
            return tasks.filter(t => !t.is_completed);
    }
}

function sortTasks(tasks, sortType) {
    const sorted = [...tasks];
    switch (sortType) {
        case 'priority':
            return sorted.sort((a, b) => (b.priority || 0) - (a.priority || 0));
        case 'time':
            return sorted.sort((a, b) => {
                if (!a.start_time) return 1;
                if (!b.start_time) return -1;
                return new Date(a.start_time) - new Date(b.start_time);
            });
        case 'ai_sort':
            return sorted.sort((a, b) => (b.ai_sort_score || 0) - (a.ai_sort_score || 0));
        default:
            return sorted.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
    }
}

function createTaskHTML(task) {
    const isCompleted = task.is_completed;
    const priorityClass = getPriorityClass(task.priority);
    const priorityText = getPriorityText(task.priority);
    const statusBadge = getStatusBadgeHTML(task.status);
    
    let dimensionScoresHTML = '';
    if (task.ai_sort_score > 0) {
        // 检查是否是优化算法的分数详情
        if (task.ai_score_details && task.ai_score_details.dimensions) {
            // 使用优化算法的展示方式
            dimensionScoresHTML = renderOptimizedAIScore(task.ai_score_details);
        } else {
            // 使用经典算法的展示方式
            const dims = [
                { key: 'time', label: '时', score: task.time_score },
                { key: 'importance', label: '重', score: task.importance_score },
                { key: 'impact', label: '效', score: task.impact_score },
                { key: 'money', label: '钱', score: task.money_score },
                { key: 'relation', label: '人', score: task.relation_score },
                { key: 'skill', label: '技', score: task.skill_score }
            ];
            
            dimensionScoresHTML = `
                <div class="dimension-scores">
                    ${dims.map(d => `
                        <span class="dimension-score ${d.key}" title="${getDimensionName(d.key)}">
                            ${d.label}:${d.score?.toFixed(1) || '0'}
                        </span>
                    `).join('')}
                    <span style="font-weight: 600; color: var(--accent-primary);">
                        综合: ${task.ai_sort_score?.toFixed(2) || '0'}
                    </span>
                </div>
            `;
        }
    }
    
    return `
        <li class="task-item ${isCompleted ? 'completed' : ''}" data-id="${task.id}">
            <div class="task-checkbox ${isCompleted ? 'completed' : ''}" onclick="toggleTask(${task.id})">
                ${isCompleted ? '<i class="fas fa-check"></i>' : ''}
            </div>
            <div class="task-content" onclick="showEditModal(${task.id})">
                <div class="task-title ${isCompleted ? 'completed' : ''}">${escapeHtml(task.title)}</div>
                <div class="task-meta">
                    ${statusBadge}
                    <span class="task-tag category">${task.category}</span>
                    ${task.priority > 0 ? `<span class="task-tag ${priorityClass}"><i class="fas fa-flag"></i> ${priorityText}</span>` : ''}
                    ${task.start_time ? `<span class="task-tag"><i class="fas fa-clock"></i> ${formatDate(task.start_time)}</span>` : ''}
                    ${task.ai_sort_score > 0 ? `<span class="task-tag ai-tag"><i class="fas fa-robot"></i> AI已评分</span>` : ''}
                </div>
                ${dimensionScoresHTML}
            </div>
            <div class="task-actions">
                <div class="priority-dropdown" style="position: relative;">
                    <button class="task-action-btn" onclick="event.stopPropagation(); togglePriorityDropdown(${task.id})" title="调整优先级" style="${task.priority > 0 ? 'color: var(--danger-color);' : ''}">
                        <i class="fas fa-flag"></i>
                    </button>
                    <div class="priority-menu" id="priorityMenu_${task.id}" style="display: none; position: fixed; background: var(--bg-primary); border: 1px solid var(--border-color); border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.15); z-index: 1000; min-width: 100px; padding: 4px 0;">
                        <div class="priority-option" onclick="event.stopPropagation(); updateTaskPriority(${task.id}, 5)" style="padding: 8px 12px; cursor: pointer; display: flex; align-items: center; gap: 8px;">
                            <i class="fas fa-flag" style="color: #EF4444;"></i> 最高
                        </div>
                        <div class="priority-option" onclick="event.stopPropagation(); updateTaskPriority(${task.id}, 4)" style="padding: 8px 12px; cursor: pointer; display: flex; align-items: center; gap: 8px;">
                            <i class="fas fa-flag" style="color: #F97316;"></i> 高
                        </div>
                        <div class="priority-option" onclick="event.stopPropagation(); updateTaskPriority(${task.id}, 3)" style="padding: 8px 12px; cursor: pointer; display: flex; align-items: center; gap: 8px;">
                            <i class="fas fa-flag" style="color: #EAB308;"></i> 中
                        </div>
                        <div class="priority-option" onclick="event.stopPropagation(); updateTaskPriority(${task.id}, 2)" style="padding: 8px 12px; cursor: pointer; display: flex; align-items: center; gap: 8px;">
                            <i class="fas fa-flag" style="color: #3B82F6;"></i> 低
                        </div>
                        <div class="priority-option" onclick="event.stopPropagation(); updateTaskPriority(${task.id}, 0)" style="padding: 8px 12px; cursor: pointer; display: flex; align-items: center; gap: 8px;">
                            <i class="fas fa-flag" style="color: #9CA3AF;"></i> 无
                        </div>
                    </div>
                </div>
                ${task.status === 'in_progress' 
                    ? `<button class="task-action-btn" onclick="event.stopPropagation(); pauseTask(${task.id})" title="暂停任务"><i class="fas fa-pause"></i></button>`
                    : `<button class="task-action-btn" onclick="event.stopPropagation(); startTask(${task.id})" title="开始任务"><i class="fas fa-play"></i></button>`
                }
                <button class="task-action-btn" onclick="event.stopPropagation(); showEditModal(${task.id})" title="编辑">
                    <i class="fas fa-edit"></i>
                </button>

                <button class="task-action-btn delete" onclick="event.stopPropagation(); deleteTask(${task.id})" title="删除">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </li>
    `;
}

function getPriorityClass(priority) {
    if (priority >= 4) return 'priority-high';
    if (priority >= 3) return 'priority-medium';
    return 'priority-low';
}

function getPriorityText(priority) {
    const texts = { 5: '最高', 4: '高', 3: '中', 2: '低', 1: '最低' };
    return texts[priority] || '';
}

/**
 * 获取状态徽章HTML
 * @param {string} status - 任务状态
 * @returns {string} 状态徽章HTML
 */
function getStatusBadgeHTML(status) {
    const statusConfig = {
        'pending': { label: '待处理', class: 'status-pending', icon: 'fa-clock' },
        'in_progress': { label: '进行中', class: 'status-in_progress', icon: 'fa-play-circle' },
        'paused': { label: '已暂停', class: 'status-paused', icon: 'fa-pause-circle' },
        'completed': { label: '已完成', class: 'status-completed', icon: 'fa-check-circle' },
        'cancelled': { label: '已取消', class: 'status-cancelled', icon: 'fa-times-circle' }
    };
    
    const config = statusConfig[status] || statusConfig['pending'];
    return `<span class="status-badge ${config.class}"><i class="fas ${config.icon}"></i> ${config.label}</span>`;
}

function getDimensionName(key) {
    const names = {
        time: '时间紧迫度',
        importance: '重要性',
        impact: '影响力',
        money: '金钱价值',
        relation: '关系价值',
        skill: '技能成长'
    };
    return names[key] || key;
}

/**
 * 获取优化算法维度名称
 * @param {string} key - 维度键名
 * @returns {string} 维度中文名称
 */
function getOptimizedDimensionName(key) {
    const names = {
        time_pressure: '时间压力',
        priority: '优先级',
        energy_match: '精力匹配',
        user_preference: '用户偏好',
        semantic_importance: '语义重要性',
        context_fit: '上下文适配'
    };
    return names[key] || key;
}

/**
 * 获取优化算法维度图标
 * @param {string} key - 维度键名
 * @returns {string} FontAwesome图标类名
 */
function getOptimizedDimensionIcon(key) {
    const icons = {
        time_pressure: 'fa-clock',
        priority: 'fa-flag',
        energy_match: 'fa-battery-three-quarters',
        user_preference: 'fa-user-cog',
        semantic_importance: 'fa-language',
        context_fit: 'fa-compass'
    };
    return icons[key] || 'fa-star';
}

/**
 * 渲染优化算法的AI分数详情组件
 * @param {Object} scoreDetails - AI分数详情对象
 * @returns {string} HTML字符串
 */
function renderOptimizedAIScore(scoreDetails) {
    if (!scoreDetails || !scoreDetails.dimensions) {
        return '';
    }
    
    const { total_score, dimensions, factors, explanation } = scoreDetails;
    
    const dimensionItems = Object.entries(dimensions).map(([key, value]) => {
        const name = getOptimizedDimensionName(key);
        const icon = getOptimizedDimensionIcon(key);
        const percentage = Math.min(Math.max(value, 0), 100);
        const cssClass = key.replace(/_/g, '-');
        
        return `
            <div class="dimension-item">
                <div class="dimension-info">
                    <i class="fas ${icon}"></i>
                    <span>${name}</span>
                </div>
                <div class="dimension-bar">
                    <div class="dimension-fill ${cssClass}" style="width: ${percentage}%"></div>
                </div>
                <span class="dimension-value">${value.toFixed(1)}</span>
            </div>
        `;
    }).join('');
    
    const factorsHTML = factors ? `
        <div class="score-factors">
            <span class="score-factor"><i class="fas fa-user"></i> 个性化: ${factors.personalization?.toFixed(2) || 1.0}</span>
            <span class="score-factor"><i class="fas fa-clock"></i> 时间上下文: ${factors.time_context?.toFixed(2) || 1.0}</span>
        </div>
    ` : '';
    
    return `
        <div class="ai-score-breakdown">
            <div class="score-header">
                <span class="total-score">${total_score?.toFixed(1) || '0'}</span>
                <span class="score-label">AI排序分</span>
            </div>
            
            <div class="score-dimensions">
                ${dimensionItems}
            </div>
            
            ${factorsHTML}
            
            ${explanation ? `<div class="score-explanation">${explanation}</div>` : ''}
        </div>
    `;
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function formatDate(dateStr) {
    if (!dateStr) return '';
    const date = new Date(dateStr);
    return date.toLocaleDateString('zh-CN', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
}

// ==================== 任务操作 ====================

/**
 * 智能任务创建 - 集成时间解析、用户行为习惯和任务难度评估
 */
async function addTask() {
    const title = document.getElementById('newTaskInput').value.trim();
    if (!title) {
        showToast('请输入任务标题', 'error');
        return;
    }
    
    const category = document.getElementById('newTaskCategory').value || '未分类';
    const priority = parseInt(document.getElementById('newTaskPriority').value) || 0;
    
    // ========== 第一步：智能时间解析 ==========
    const timeParseResult = await resolveTaskTime(title, category);
    
    // ========== 第二步：任务难度评估 ==========
    const difficultyInfo = assessTaskDifficulty(title, category);
    
    console.log('[addTask] 智能解析结果:', {
        time: timeParseResult,
        difficulty: difficultyInfo
    });
    
    const task = {
        title: title,
        category: category,
        priority: priority,
        start_time: timeParseResult.startTime,
        end_time: timeParseResult.endTime,
        estimated_duration: timeParseResult.estimatedDuration,
        difficulty_level: difficultyInfo.level,
        difficulty_factors: difficultyInfo.factors
    };
    
    try {
        const response = await API.post('/tasks', task);
        const result = await response.json();
        
        if (result.success) {
            document.getElementById('newTaskInput').value = '';
            setDefaultStartTime();
            
            // 显示智能提示
            showSmartTaskNotification(timeParseResult, difficultyInfo);
            
            showToast('任务创建成功', 'success');
            loadTasks();
            
            // 清除AI分析缓存
            clearAICache();
        } else {
            showToast(result.message || '创建失败', 'error');
        }
    } catch (error) {
        console.error('[addTask] 创建任务失败:', error);
        showToast('创建任务失败', 'error');
    }
}

/**
 * 解析任务时间 - 结合标题解析、用户行为习惯推荐
 * @returns {Object} - {startTime, endTime, estimatedDuration, source}
 */
async function resolveTaskTime(title, category) {
    const startTimeInput = document.getElementById('newTaskStartTime');
    const endTimeInput = document.getElementById('newTaskEndTime');
    const isUserModified = startTimeInput?.dataset.userModified === 'true';
    
    let startTime = null;
    let endTime = null;
    let estimatedDuration = null;
    let source = 'default';
    
    // 1. 首先尝试从标题解析时间（包括时间段）
    const parsedTime = parseTimeFromTitle(title);
    
    if (parsedTime) {
        startTime = parsedTime.startTime;
        endTime = parsedTime.endTime;
        source = parsedTime.confidence >= 0.9 ? 'parsed_range' : 'parsed_single';
        console.log('[resolveTaskTime] 从标题解析到时间:', parsedTime);
    }
    
    // 2. 如果用户手动修改了时间，优先使用用户设置
    if (isUserModified && startTimeInput.value) {
        startTime = startTimeInput.value;
        if (endTimeInput?.value) {
            endTime = endTimeInput.value;
        }
        source = 'user_manual';
        console.log('[resolveTaskTime] 使用用户手动设置的时间');
    }
    
    // 3. 如果没有解析到时间，根据用户行为习惯推荐
    if (!startTime) {
        const recommendedTime = await getRecommendedStartTime(category);
        startTime = recommendedTime.time;
        source = recommendedTime.source;
        console.log('[resolveTaskTime] 根据用户习惯推荐时间:', recommendedTime);
    }
    
    // 4. 如果没有结束时间，预估任务时长
    if (!endTime) {
        const durationEstimate = await estimateDurationByDifficulty(title, category);
        estimatedDuration = durationEstimate.duration;
        
        const startDate = new Date(startTime);
        const endDate = new Date(startDate.getTime() + estimatedDuration * 60000);
        endTime = formatLocalDateTime(endDate);
        
        console.log('[resolveTaskTime] 预估时长:', {
            duration: estimatedDuration,
            endTime: endTime,
            method: durationEstimate.method
        });
    } else {
        // 计算已解析的时长
        const startDate = new Date(startTime);
        const endDate = new Date(endTime);
        estimatedDuration = Math.round((endDate - startDate) / 60000);
    }
    
    return {
        startTime,
        endTime,
        estimatedDuration,
        source
    };
}

/**
 * 根据用户行为习惯推荐开始时间
 */
async function getRecommendedStartTime(category) {
    const now = new Date();
    const currentHour = now.getHours();
    
    try {
        // 尝试获取用户行为数据
        const response = await API.get('/user/behavior/pattern');
        if (response.ok) {
            const result = await response.json();
            if (result.success && result.pattern) {
                const pattern = result.pattern;
                
                // 获取该分类的最佳时段
                const categoryPrefs = result.preferences?.find(p => p.category === category);
                const bestHours = categoryPrefs?.best_hours || pattern.peak_hours || [9, 10, 14, 15];
                
                // 找到当前时间之后的最佳时段
                const futureHours = bestHours.filter(h => h > currentHour);
                let recommendedHour;
                let isTomorrow = false;
                
                if (futureHours.length > 0) {
                    recommendedHour = futureHours[0];
                } else {
                    // 如果今天没有合适时段，使用明天的第一个最佳时段
                    recommendedHour = bestHours[0] || 9;
                    isTomorrow = true;
                }
                
                const recommendedDate = new Date(now);
                if (isTomorrow) {
                    recommendedDate.setDate(recommendedDate.getDate() + 1);
                }
                recommendedDate.setHours(recommendedHour, 0, 0, 0);
                
                return {
                    time: formatLocalDateTime(recommendedDate),
                    source: 'behavior_recommended',
                    reason: `根据您的习惯，${category}类任务在${recommendedHour}:00效率最高`
                };
            }
        }
    } catch (error) {
        console.log('[getRecommendedStartTime] 获取用户行为数据失败:', error);
    }
    
    // 默认：当前时间或下一个整点
    const nextHour = new Date(now);
    nextHour.setHours(currentHour + 1, 0, 0, 0);
    
    return {
        time: formatLocalDateTime(nextHour),
        source: 'default_next_hour'
    };
}

/**
 * 任务难度评估
 * @returns {Object} - {level: 'easy'|'medium'|'hard', score: number, factors: Object}
 */
function assessTaskDifficulty(title, category) {
    const titleLower = title.toLowerCase();
    let score = 0;
    const factors = {
        keywords: [],
        categoryWeight: 0,
        complexity: 0
    };
    
    // 1. 关键词难度评分
    const difficultyKeywords = {
        hard: ['困难', '复杂', '重要', '紧急', '关键', '核心', '深度', '研究', '分析', '设计', '开发', '论文', '考试', '面试', '汇报'],
        medium: ['准备', '整理', '复习', '练习', '修改', '优化', '测试', '文档', '报告', '作业'],
        easy: ['简单', '快速', '查看', '阅读', '浏览', '回复', '打电话', '买', '取', '送']
    };
    
    difficultyKeywords.hard.forEach(kw => {
        if (titleLower.includes(kw)) {
            score += 3;
            factors.keywords.push({ word: kw, weight: 3 });
        }
    });
    
    difficultyKeywords.medium.forEach(kw => {
        if (titleLower.includes(kw)) {
            score += 2;
            factors.keywords.push({ word: kw, weight: 2 });
        }
    });
    
    difficultyKeywords.easy.forEach(kw => {
        if (titleLower.includes(kw)) {
            score -= 1;
            factors.keywords.push({ word: kw, weight: -1 });
        }
    });
    
    // 2. 分类难度权重
    const categoryWeights = {
        '考试': 3,
        '项目': 2.5,
        '学习': 2,
        '工作': 2,
        '健康': 1,
        '生活': 0.5,
        '社交': 0.5
    };
    
    factors.categoryWeight = categoryWeights[category] || 1;
    score += factors.categoryWeight;
    
    // 3. 复杂度评估（标题长度、包含的任务数量等）
    const taskCount = (title.match(/[、,，和与及]/g) || []).length + 1;
    factors.complexity = Math.min(taskCount * 0.5, 2);
    score += factors.complexity;
    
    // 确定难度等级
    let level;
    if (score >= 5) {
        level = 'hard';
    } else if (score >= 2.5) {
        level = 'medium';
    } else {
        level = 'easy';
    }
    
    return {
        level,
        score: Math.round(score * 10) / 10,
        factors
    };
}

/**
 * 根据难度预估任务时长
 */
async function estimateDurationByDifficulty(title, category) {
    const difficulty = assessTaskDifficulty(title, category);
    
    // 基础时长根据难度
    const baseDurations = {
        easy: 30,
        medium: 60,
        hard: 120
    };
    
    let duration = baseDurations[difficulty.level];
    
    // 尝试获取历史数据
    try {
        const response = await API.post('/ai/estimate-duration', { 
            title, 
            category,
            difficulty: difficulty.level 
        });
        
        if (response.ok) {
            const result = await response.json();
            if (result.success && result.estimated_duration) {
                // 结合难度和历史数据
                duration = Math.round((duration * 0.3 + result.estimated_duration * 0.7));
                return {
                    duration,
                    method: 'hybrid',
                    difficulty: difficulty.level
                };
            }
        }
    } catch (error) {
        console.log('[estimateDurationByDifficulty] 获取AI预估失败:', error);
    }
    
    return {
        duration,
        method: 'difficulty_based',
        difficulty: difficulty.level
    };
}

/**
 * 显示智能任务创建通知
 */
function showSmartTaskNotification(timeInfo, difficultyInfo) {
    const sourceMap = {
        'parsed_range': '从标题解析到时间段',
        'parsed_single': '从标题解析到时间',
        'user_manual': '使用您设置的时间',
        'behavior_recommended': '根据您的习惯推荐',
        'default_next_hour': '默认下一小时'
    };
    
    const difficultyMap = {
        easy: { text: '简单', color: '#52c41a' },
        medium: { text: '中等', color: '#faad14' },
        hard: { text: '困难', color: '#f5222d' }
    };
    
    const diff = difficultyMap[difficultyInfo.level];
    const hours = Math.floor(timeInfo.estimatedDuration / 60);
    const mins = timeInfo.estimatedDuration % 60;
    const durationText = hours > 0 ? `${hours}小时${mins}分钟` : `${mins}分钟`;
    
    console.log(`[SmartTask] ${sourceMap[timeInfo.source]} | 难度:${diff.text} | 预估:${durationText}`);
}

/**
 * 显示智能时间推荐通知
 * @param {Object} recommendation - 后端返回的推荐信息
 * @param {Object} task - 创建的任务对象
 */
function showSmartRecommendationNotification(recommendation, task) {
    const difficultyMap = {
        easy: { text: '简单', color: '#52c41a', icon: '🟢' },
        medium: { text: '中等', color: '#faad14', icon: '🟡' },
        hard: { text: '困难', color: '#f5222d', icon: '🔴' },
        very_hard: { text: '非常困难', color: '#722ed1', icon: '⚫' }
    };
    
    const diff = difficultyMap[recommendation.difficulty_level] || difficultyMap.medium;
    
    // 格式化预估时长
    const duration = recommendation.estimated_duration;
    let durationText = '';
    if (duration) {
        const hours = Math.floor(duration / 60);
        const mins = duration % 60;
        durationText = hours > 0 ? `${hours}小时${mins}分钟` : `${mins}分钟`;
    }
    
    // 格式化时间
    const formatTime = (timeStr) => {
        if (!timeStr) return '未设置';
        const date = new Date(timeStr);
        return `${date.getMonth() + 1}月${date.getDate()}日 ${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`;
    };
    
    // 构建通知内容
    let message = `🤖 AI智能推荐`;
    let details = [];
    
    if (task.start_time) {
        details.push(`开始时间: ${formatTime(task.start_time)}`);
    }
    if (task.end_time) {
        details.push(`截止时间: ${formatTime(task.end_time)}`);
    }
    details.push(`难度评估: ${diff.icon} ${diff.text}`);
    if (durationText) {
        details.push(`预估时长: ⏱️ ${durationText}`);
    }
    
    console.log(`[SmartRecommendation] ${message}`);
    console.log(`[SmartRecommendation] ${details.join(' | ')}`);
    
    // 显示Toast通知
    const detailText = details.slice(0, 2).join(' · ');
    showToast(`${message}: ${detailText}`, 'info', 4000);
}

/**
 * 清除AI缓存
 */
function clearAICache() {
    if (typeof AICache !== 'undefined') {
        AICache.clear();
        console.log('[AI缓存] 已清除');
    } else if (typeof AIAnalysisCache !== 'undefined') {
        AIAnalysisCache.clearAll();
        console.log('[AI缓存] 已清除');
    }
}

// AI预估任务时长
async function estimateTaskDuration(taskId, title, category) {
    try {
        const response = await API.post('/ai/estimate-duration', { task_id: taskId, title, category });
        
        const result = await response.json();
        if (result.success && result.estimated_duration) {
            // 更新任务的结束时间
            const task = allTasks.find(t => t.id === taskId);
            if (task && task.start_time) {
                const startDate = new Date(task.start_time);
                const endDate = new Date(startDate.getTime() + result.estimated_duration * 60000); // 分钟转毫秒
                
                await API.put(`/tasks/${taskId}`, {
                    end_time: endDate.toISOString().slice(0, 16)
                });
                
                loadTasks();
            }
        }
    } catch (error) {
        console.log('AI预估时长失败:', error);
    }
}

function handleNewTaskKeypress(event) {
    if (event.key === 'Enter') {
        addTask();
    }
}

async function toggleTask(taskId) {
    const task = allTasks.find(t => t.id === taskId);
    if (!task) return;
    
    const endpoint = task.is_completed ? 'uncomplete' : 'complete';
    const newStatus = task.is_completed ? 'in_progress' : 'completed';
    
    try {
        const response = await API.put(`/tasks/${taskId}/${endpoint}`);
        
        const result = await response.json();
        if (result.success) {
            // 执行历史功能已禁用，不记录状态变更和执行事件
            
            loadTasks();
            loadCategories(); // 刷新分类小红点
            loadTags(); // 刷新标签小红点
            // 任务状态变更，清除AI分析缓存
            if (typeof AICache !== 'undefined') {
                AICache.clear();
                console.log('[AI缓存] 任务状态变更，已清除分析缓存');
            } else if (typeof AIAnalysisCache !== 'undefined') {
                AIAnalysisCache.clearAll();
                console.log('[AI缓存] 任务状态变更，已清除分析缓存');
            }
            showToast(task.is_completed ? '任务已恢复' : '任务已完成', 'success');
        }
    } catch (error) {
        showToast('操作失败', 'error');
    }
}

async function startTask(taskId) {
    try {
        const response = await API.put(`/tasks/${taskId}/start`);
        
        const result = await response.json();
        if (result.success) {
            showToast('任务已开始计时', 'success');
            // 执行历史功能已禁用，不记录状态变更和执行事件
            loadTasks();
        }
    } catch (error) {
        showToast('操作失败', 'error');
    }
}

/**
 * 暂停任务
 * @param {number} taskId - 任务ID
 */
async function pauseTask(taskId) {
    try {
        const task = allTasks.find(t => t.id === taskId);
        if (!task) return;
        
        // 调用API暂停任务
        const result = await API.pauseTask(taskId);
        
        if (result.success) {
            showToast('任务已暂停', 'warning');
            // 执行历史功能已禁用，不记录状态变更和执行事件
            loadTasks();
        }
    } catch (error) {
        console.error('暂停任务失败:', error);
        showToast('暂停任务失败', 'error');
    }
}

async function deleteTask(taskId) {
    if (!confirm('确定要删除这个任务吗？')) return;
    
    try {
        const response = await API.del(`/tasks/${taskId}`);
        
        const result = await response.json();
        if (result.success) {
            showToast('任务已删除', 'success');
            loadTasks();
            // 任务删除，清除AI分析缓存
            if (typeof AICache !== 'undefined') {
                AICache.clear();
                console.log('[AI缓存] 任务删除，已清除分析缓存');
            } else if (typeof AIAnalysisCache !== 'undefined') {
                AIAnalysisCache.clearAll();
                console.log('[AI缓存] 任务删除，已清除分析缓存');
            }
        }
    } catch (error) {
        showToast('删除失败', 'error');
    }
}

// 切换优先级下拉菜单
function togglePriorityDropdown(taskId) {
    const menu = document.getElementById(`priorityMenu_${taskId}`);
    const btn = event.target.closest('.task-action-btn');
    if (!menu || !btn) return;
    
    // 关闭其他优先级菜单
    document.querySelectorAll('.priority-menu').forEach(m => {
        if (m.id !== `priorityMenu_${taskId}`) {
            m.style.display = 'none';
        }
    });
    
    if (menu.style.display === 'block') {
        menu.style.display = 'none';
    } else {
        // 计算按钮位置，使用 fixed 定位
        const rect = btn.getBoundingClientRect();
        menu.style.left = `${rect.right - 100}px`; // 100px 是菜单宽度
        menu.style.top = `${rect.bottom + 5}px`;
        menu.style.display = 'block';
    }
}

// 更新任务优先级
async function updateTaskPriority(taskId, priority) {
    // 关闭菜单
    const menu = document.getElementById(`priorityMenu_${taskId}`);
    if (menu) menu.style.display = 'none';
    
    try {
        const response = await API.put(`/tasks/${taskId}`, { priority });
        
        const result = await response.json();
        if (result.success) {
            showToast('优先级已更新', 'success');
            loadTasks();
        }
    } catch (error) {
        showToast('更新失败', 'error');
    }
}

// 点击其他地方关闭优先级菜单
document.addEventListener('click', () => {
    document.querySelectorAll('.priority-menu').forEach(m => {
        m.style.display = 'none';
    });
});

async function refreshTasks() {
    await Promise.all([
        loadTasks(),
        loadTags(),
        loadCategories()
    ]);
    showToast('已刷新', 'success');
}

// ==================== 编辑任务 ====================

async function showEditModal(taskId) {
    const task = allTasks.find(t => t.id === taskId);
    if (!task) return;
    
    // 确保标签已加载
    if (allTags.length === 0) {
        await loadTags();
    }
    
    document.getElementById('editTaskId').value = taskId;
    document.getElementById('editTaskTitle').value = task.title;
    document.getElementById('editTaskDesc').value = task.description || '';
    document.getElementById('editTaskCategory').value = task.category;
    document.getElementById('editTaskPriority').value = task.priority;
    document.getElementById('editTaskStartTime').value = task.start_time || '';
    document.getElementById('editTaskEndTime').value = task.end_time || '';
    
    selectedTags = task.tag_ids || [];
    renderTagSelector();
    
    openModal('editModal');
}

/**
 * 加载任务执行历史预览（用于编辑弹窗）
 * @param {number} taskId - 任务ID
 * 功能已禁用
 */
async function loadTaskHistoryPreview(taskId) {
    // 执行历史功能已禁用
    console.log('执行历史功能已禁用');
}

async function saveTask() {
    const taskId = document.getElementById('editTaskId').value;
    
    const task = {
        title: document.getElementById('editTaskTitle').value.trim(),
        description: document.getElementById('editTaskDesc').value,
        category: document.getElementById('editTaskCategory').value,
        priority: parseInt(document.getElementById('editTaskPriority').value),
        start_time: document.getElementById('editTaskStartTime').value || null,
        end_time: document.getElementById('editTaskEndTime').value || null
    };
    
    try {
        const response = await API.put(`/tasks/${taskId}`, task);
        
        const result = await response.json();
        if (result.success) {
            // 更新标签
            await API.put(`/tasks/${taskId}/tags`, { tag_ids: selectedTags });
            
            closeModal('editModal');
            showToast('任务已保存', 'success');
            loadTasks();
            loadTags(); // 刷新标签列表
            // 任务更新，清除AI分析缓存
            if (typeof AICache !== 'undefined') {
                AICache.clear();
                console.log('[AI缓存] 任务更新，已清除分析缓存');
            } else if (typeof AIAnalysisCache !== 'undefined') {
                AIAnalysisCache.clearAll();
                console.log('[AI缓存] 任务更新，已清除分析缓存');
            }
        }
    } catch (error) {
        showToast('保存失败', 'error');
    }
}

// ==================== 标签管理 ====================

async function loadTags() {
    try {
        const response = await API.get('/tags');
        const result = await response.json();
        allTags = result.tags || [];
        renderTagNav();
    } catch (error) {
        console.error('加载标签失败:', error);
    }
}

function renderTagNav() {
    const tagNav = document.getElementById('tagNav');
    if (!tagNav) return;
    
    tagNav.innerHTML = allTags.map(tag => `
        <div class="nav-item" onclick="filterByTag('${tag.id}')">
            <span class="tag-color-dot" style="background-color: ${tag.color}"></span>
            <span>${tag.name}</span>
            ${tag.task_count > 0 ? `<span class="nav-badge">${tag.task_count}</span>` : ''}
        </div>
    `).join('');
}

function renderTagSelector() {
    const selector = document.getElementById('editTagSelector');
    if (!selector) return;
    
    selector.innerHTML = allTags.map(tag => `
        <div class="tag-option ${selectedTags.some(id => id === tag.id || id === String(tag.id)) ? 'selected' : ''}" 
             onclick="toggleTagSelection(${tag.id})">
            <span class="tag-dot" style="background-color: ${tag.color}"></span>
            <span>${tag.name}</span>
        </div>
    `).join('');
}

function toggleTagSelection(tagId) {
    // 统一转换为数字类型进行比较
    const numTagId = parseInt(tagId);
    const index = selectedTags.findIndex(id => parseInt(id) === numTagId);
    
    if (index > -1) {
        selectedTags.splice(index, 1);
    } else {
        selectedTags.push(numTagId);
    }
    renderTagSelector();
}

function filterByTag(tagId) {
    // 按标签筛选任务
    currentView = 'tag';
    currentTagFilter = tagId;
    resetCategoryFilter(); // 重置分类过滤器
    clearNavActive(); // 清除导航项激活状态
    updatePageTitle(); // 更新页面标题
    renderTasks();
    // 移动端自动关闭侧边栏
    if (window.innerWidth <= 768) {
        closeSidebar();
    }
}

function resetCategoryFilter() {
    const categoryFilter = document.getElementById('categoryFilter');
    if (categoryFilter) {
        categoryFilter.value = '';
    }
}

function clearNavActive() {
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
}

// 标签管理功能
function showTagManageModal() {
    openModal('tagManageModal');
    loadTagsForManage();
}

async function loadTagsForManage() {
    try {
        const response = await API.get('/tags');
        const result = await response.json();
        const tags = result.tags || [];
        renderTagManageList(tags);
    } catch (error) {
        console.error('加载标签失败:', error);
        showToast('加载标签失败', 'error');
    }
}

function renderTagManageList(tags) {
    const list = document.getElementById('tagManageList');
    if (!list) return;
    
    if (tags.length === 0) {
        list.innerHTML = '<p style="text-align: center; color: var(--text-tertiary); padding: 20px;">暂无标签</p>';
        return;
    }
    
    list.innerHTML = tags.map(tag => `
        <div class="tag-manage-item" data-id="${tag.id}">
            <div style="display: flex; align-items: center; gap: 8px; flex: 1;">
                <span class="tag-color-dot" style="background-color: ${tag.color}; width: 12px; height: 12px; border-radius: 50%;"></span>
                <span style="font-weight: 500;">${tag.name}</span>
                <span style="font-size: 12px; color: var(--text-tertiary);">${tag.task_count || 0} 个任务</span>
            </div>
            <div style="display: flex; gap: 8px;">
                <button class="btn-icon" onclick="editTag(${tag.id}, '${tag.name}', '${tag.color}')" title="编辑">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="btn-icon btn-icon-danger" onclick="deleteTag(${tag.id})" title="删除">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </div>
    `).join('');
    
    // 添加样式
    if (!document.getElementById('tagManageStyles')) {
        const style = document.createElement('style');
        style.id = 'tagManageStyles';
        style.textContent = `
            .tag-manage-item {
                display: flex;
                align-items: center;
                justify-content: space-between;
                padding: 12px;
                background: var(--bg-secondary);
                border-radius: 8px;
                margin-bottom: 8px;
            }
            .tag-manage-item:hover {
                background: var(--bg-hover);
            }
            .btn-icon {
                padding: 6px 10px;
                border: none;
                background: transparent;
                color: var(--text-secondary);
                cursor: pointer;
                border-radius: 4px;
                transition: all 0.2s;
            }
            .btn-icon:hover {
                background: var(--bg-active);
                color: var(--primary-color);
            }
            .btn-icon-danger:hover {
                background: #fee2e2;
                color: #dc2626;
            }
        `;
        document.head.appendChild(style);
    }
}

async function createTag() {
    const nameInput = document.getElementById('newTagName');
    const colorInput = document.getElementById('newTagColor');
    
    const name = nameInput.value.trim();
    const color = colorInput.value;
    
    if (!name) {
        showToast('请输入标签名称', 'error');
        return;
    }
    
    try {
        const response = await API.post('/tags', { name, color });
        
        const result = await response.json();
        if (response.ok) {
            showToast('标签创建成功', 'success');
            nameInput.value = '';
            colorInput.value = '#3B82F6';
            loadTagsForManage();
            loadTags(); // 更新侧边栏
        } else {
            showToast(result.error || '创建失败', 'error');
        }
    } catch (error) {
        console.error('创建标签失败:', error);
        showToast('创建标签失败', 'error');
    }
}

function editTag(tagId, currentName, currentColor) {
    // 使用prompt简化编辑，也可以创建专门的编辑模态框
    const name = prompt('编辑标签名称:', currentName);
    if (name === null) return; // 用户取消
    
    const color = prompt('编辑标签颜色 (十六进制, 如 #3B82F6):', currentColor);
    if (color === null) return;
    
    updateTag(tagId, name.trim(), color.trim() || currentColor);
}

async function updateTag(tagId, name, color) {
    if (!name) {
        showToast('标签名称不能为空', 'error');
        return;
    }
    
    try {
        const response = await API.put(`/tags/${tagId}`, { name, color });
        
        const result = await response.json();
        if (response.ok) {
            showToast('标签更新成功', 'success');
            loadTagsForManage();
            loadTags();
        } else {
            showToast(result.error || '更新失败', 'error');
        }
    } catch (error) {
        console.error('更新标签失败:', error);
        showToast('更新标签失败', 'error');
    }
}

async function deleteTag(tagId) {
    if (!confirm('确定要删除这个标签吗?')) return;
    
    try {
        const response = await API.del(`/tags/${tagId}`);
        
        if (response.ok) {
            showToast('标签已删除', 'success');
            loadTagsForManage();
            loadTags();
        } else {
            const result = await response.json();
            showToast(result.error || '删除失败', 'error');
        }
    } catch (error) {
        console.error('删除标签失败:', error);
        showToast('删除标签失败', 'error');
    }
}

// ==================== 分类管理 ====================

async function loadCategories() {
    try {
        const response = await API.get('/categories');
        const result = await response.json();
        const categories = result.categories || [];
        
        // 更新分类过滤器
        const categoryFilter = document.getElementById('categoryFilter');
        if (categoryFilter) {
            categoryFilter.innerHTML = '<option value="">全部分类</option>' +
                categories.filter(c => !c.hidden).map(c => `<option value="${c.name}">${c.name}</option>`).join('');
        }
        
        // 更新任务添加区域的分类选择框
        const newTaskCategory = document.getElementById('newTaskCategory');
        if (newTaskCategory) {
            newTaskCategory.innerHTML = '<option value="">选择分类</option>' +
                categories.filter(c => !c.hidden).map(c => `<option value="${c.name}">${c.name}</option>`).join('') +
                '<option value="other">其他</option>';
        }
        
        // 更新任务编辑模态框的分类选择框
        const editTaskCategory = document.getElementById('editTaskCategory');
        if (editTaskCategory) {
            editTaskCategory.innerHTML = '<option value="">选择分类</option>' +
                categories.filter(c => !c.hidden).map(c => `<option value="${c.name}">${c.name}</option>`).join('') +
                '<option value="other">其他</option>';
        }
        
        // 更新侧边栏分类导航
        const categoryNav = document.getElementById('categoryNav');
        if (categoryNav) {
            const categoriesHtml = categories.filter(c => !c.hidden).map(c => `
                <div class="nav-item" data-category="${c.name}">
                    <i class="fas ${c.icon || 'fa-folder'}" style="color: ${c.color || 'inherit'}"></i>
                    <span>${c.name}</span>
                    ${c.count > 0 ? `<span class="nav-badge">${c.count}</span>` : ''}
                </div>
            `).join('');

            const manageBtnHtml = `<div class="nav-item" onclick="openCategoryManage()" style="margin-top: 8px; border-top: 1px solid var(--border-color); padding-top: 8px;">
                <i class="fas fa-cog" style="color: var(--accent-primary);"></i>
                <span>管理分类</span>
            </div>`;

            categoryNav.innerHTML = categoriesHtml + manageBtnHtml;
            
            // 添加点击事件
            categoryNav.querySelectorAll('.nav-item[data-category]').forEach(item => {
                item.addEventListener('click', () => {
                    const category = item.dataset.category;
                    currentTagFilter = null; // 清除标签筛选
                    document.getElementById('categoryFilter').value = category;
                    renderTasks();
                    // 移动端自动关闭侧边栏
                    if (window.innerWidth <= 768) {
                        closeSidebar();
                    }
                });
            });
        }
    } catch (error) {
        console.error('加载分类失败:', error);
        // 即使加载失败，也显示管理分类按钮
        const categoryNav = document.getElementById('categoryNav');
        if (categoryNav) {
            categoryNav.innerHTML = `<div class="nav-item" onclick="openCategoryManage()" style="margin-top: 8px;">
                <i class="fas fa-cog" style="color: var(--accent-primary);"></i>
                <span>管理分类</span>
            </div>`;
        }
    }
}

// ==================== 分类管理功能（全新简化版）====================

// 打开分类管理弹窗
function openCategoryManage() {
    console.log('openCategoryManage 被调用');
    const dialog = document.getElementById('categoryManageDialog');
    if (!dialog) {
        showToast('分类管理功能加载失败', 'error');
        return;
    }
    
    // 如果元素被嵌套在隐藏的modal中，将其移动到body下
    if (dialog.parentElement && dialog.parentElement.id === 'settingsModal') {
        console.log('检测到元素嵌套在settingsModal中，移动到body');
        document.body.appendChild(dialog);
    }
    
    dialog.style.display = 'flex';
    renderCategoryList();
}

// 关闭分类管理弹窗
function closeCategoryManage() {
    const dialog = document.getElementById('categoryManageDialog');
    if (dialog) {
        dialog.style.display = 'none';
    }
}

// 渲染分类列表
async function renderCategoryList() {
    const container = document.getElementById('categoryListContainer');
    if (!container) return;
    
    try {
        const response = await API.get('/categories');
        const result = await response.json();
        const categories = result.categories || [];
        
        if (categories.length === 0) {
            container.innerHTML = '<div style="text-align: center; color: #999; padding: 40px;">暂无分类</div>';
            return;
        }
        
        container.innerHTML = categories.map(c => `
            <div style="display: flex; align-items: center; padding: 12px; background: #f5f5f5; border-radius: 8px;">
                <div style="width: 12px; height: 12px; border-radius: 50%; background: ${c.color || '#999'}; margin-right: 10px;"></div>
                <i class="fas ${c.icon || 'fa-folder'}" style="margin-right: 8px; color: ${c.color || '#666'};"></i>
                <span style="flex: 1; ${c.hidden ? 'text-decoration: line-through; opacity: 0.5;' : ''}">${escapeHtml(c.name)}</span>
                <span style="color: #999; font-size: 12px; margin-right: 12px;">${c.count || 0} 个任务</span>
                <button onclick="toggleCatVisibility('${encodeURIComponent(c.name)}', ${!c.hidden})" 
                        style="background: ${c.hidden ? '#4caf50' : '#ff9800'}; color: white; border: none; padding: 6px 12px; border-radius: 4px; cursor: pointer; font-size: 12px; margin-right: 8px;">
                    ${c.hidden ? '显示' : '隐藏'}
                </button>
                ${c.is_custom ? `<button onclick="deleteCat('${encodeURIComponent(c.name)}')" 
                        style="background: #f44336; color: white; border: none; padding: 6px 12px; border-radius: 4px; cursor: pointer; font-size: 12px;">
                    删除
                </button>` : '<span style="color: #999; font-size: 12px;">预设</span>'}
            </div>
        `).join('');
    } catch (error) {
        container.innerHTML = '<div style="text-align: center; color: #f44336; padding: 40px;">加载失败</div>';
    }
}

// 添加新分类
async function addNewCategory() {
    const nameInput = document.getElementById('catNameInput');
    const colorInput = document.getElementById('catColorInput');
    
    const name = nameInput.value.trim();
    const color = colorInput.value;
    
    if (!name) {
        showToast('请输入分类名称', 'error');
        return;
    }
    
    try {
        const response = await API.post('/categories', { name, color, icon: 'fa-folder' });
        const result = await response.json();
        
        if (result.success) {
            showToast('分类创建成功', 'success');
            nameInput.value = '';
            renderCategoryList();
            loadCategories();
        } else {
            showToast(result.message || '创建失败', 'error');
        }
    } catch (error) {
        showToast('创建失败', 'error');
    }
}

// 切换分类可见性
async function toggleCatVisibility(encodedName, hidden) {
    const name = decodeURIComponent(encodedName);
    try {
        const response = await API.put(`/categories/${encodeURIComponent(name)}`, { hidden });
        const result = await response.json();
        
        if (result.success) {
            showToast(hidden ? '分类已隐藏' : '分类已显示', 'success');
            renderCategoryList();
            loadCategories();
        }
    } catch (error) {
        showToast('操作失败', 'error');
    }
}

// 删除分类
async function deleteCat(encodedName) {
    const name = decodeURIComponent(encodedName);
    if (!confirm(`确定删除分类"${name}"?`)) return;
    
    try {
        const response = await API.del(`/categories/${encodeURIComponent(name)}`);
        const result = await response.json();
        
        if (result.success) {
            showToast('分类已删除', 'success');
            renderCategoryList();
            loadCategories();
        }
    } catch (error) {
        showToast('删除失败', 'error');
    }
}

// ==================== AI智能排序 ====================

// 当前选择的排序模式: local / smart / optimized
let currentSortMode = 'local';

// 当前使用的算法版本: classic / optimized
let currentAlgorithmVersion = 'classic';

function showAISortModal() {
    // 检查点击频率
    const clickCheck = ClickManager.checkClick('showAISortModal');
    if (clickCheck.shouldWarn) {
        showToast('请稍候再试，不要重复点击哦~', 'warning');
        return;
    }
    
    openModal('aiSortModal');
    // 检查AI配置状态
    checkAIConfigStatus();
    // 初始化权重总和显示
    updateWeightTotal();
    // 根据当前算法版本更新UI
    updateAlgorithmUI();
}

/**
 * 选择算法版本（经典或优化）
 * @param {string} version - 'classic' 或 'optimized'
 */
function selectAlgorithmVersion(version) {
    currentAlgorithmVersion = version;
    
    // 更新UI选中状态
    const options = document.querySelectorAll('.algorithm-version-option');
    options.forEach(opt => {
        opt.classList.toggle('selected', opt.dataset.version === version);
    });
    
    // 更新UI显示
    updateAlgorithmUI();
    
    // 加载对应版本的预设
    loadSortPresets(version);
}

/**
 * 更新算法相关UI
 */
function updateAlgorithmUI() {
    const isOptimized = currentAlgorithmVersion === 'optimized';
    
    // 显示/隐藏优化算法特有的说明
    const optimizedHint = document.getElementById('optimizedAlgorithmHint');
    if (optimizedHint) {
        optimizedHint.style.display = isOptimized ? 'block' : 'none';
    }
    
    // 更新权重滑块标签
    updateWeightLabels(isOptimized);
}

/**
 * 更新权重滑块标签
 * @param {boolean} isOptimized - 是否使用优化算法
 */
function updateWeightLabels(isOptimized) {
    const labels = isOptimized ? {
        weightTime: '时间压力',
        weightImportance: '任务优先级',
        weightImpact: '精力匹配',
        weightMoney: '用户偏好',
        weightRelation: '语义重要性',
        weightSkill: '上下文适配'
    } : {
        weightTime: '时间紧迫度',
        weightImportance: '重要性',
        weightImpact: '影响力',
        weightMoney: '金钱价值',
        weightRelation: '关系价值',
        weightSkill: '技能成长'
    };
    
    Object.entries(labels).forEach(([id, label]) => {
        const labelEl = document.querySelector(`label[for="${id}"]`);
        if (labelEl) {
            labelEl.textContent = label;
        }
    });
}

function checkAIConfigStatus() {
    const aiApiKey = localStorage.getItem('aiApiKey') || '';
    const hintEl = document.getElementById('aiKeyHint');
    
    if (hintEl) {
        hintEl.style.display = (!aiApiKey && currentSortMode === 'smart') ? 'block' : 'none';
    }
}

function selectSortMode(mode) {
    currentSortMode = mode;
    
    // 更新UI选中状态
    const options = document.querySelectorAll('.sort-mode-option');
    options.forEach(opt => {
        opt.classList.toggle('selected', opt.dataset.mode === mode);
    });
    
    // 检查AI配置
    checkAIConfigStatus();
}

function initSortPresets() {
    const presets = document.querySelectorAll('#sortPresets .recurring-preset');
    presets.forEach(preset => {
        preset.addEventListener('click', () => {
            presets.forEach(p => p.classList.remove('selected'));
            preset.classList.add('selected');
            applySortPreset(preset.dataset.preset);
        });
    });
}

function applySortPreset(presetId) {
    // 经典算法预设
    const classicPresets = {
        balanced: { time: 25, importance: 20, impact: 20, money: 15, relation: 10, skill: 10 },
        deadline_first: { time: 50, importance: 20, impact: 10, money: 10, relation: 5, skill: 5 },
        exam_prep: { time: 30, importance: 20, impact: 10, money: 5, relation: 5, skill: 30 },
        freelancer: { time: 20, importance: 15, impact: 15, money: 25, relation: 15, skill: 10 }
    };
    
    // 优化算法预设
    const optimizedPresets = {
        balanced: { time: 25, importance: 20, impact: 15, money: 20, relation: 15, skill: 5 },
        deadline_first: { time: 45, importance: 20, impact: 10, money: 10, relation: 10, skill: 5 },
        energy_aware: { time: 20, importance: 15, impact: 30, money: 15, relation: 10, skill: 10 },
        preference_learned: { time: 20, importance: 15, impact: 10, money: 35, relation: 10, skill: 10 }
    };
    
    const presets = currentAlgorithmVersion === 'optimized' ? optimizedPresets : classicPresets;
    const weights = presets[presetId];
    if (!weights) return;
    
    document.getElementById('weightTime').value = weights.time;
    document.getElementById('weightImportance').value = weights.importance;
    document.getElementById('weightImpact').value = weights.impact;
    document.getElementById('weightMoney').value = weights.money;
    document.getElementById('weightRelation').value = weights.relation;
    document.getElementById('weightSkill').value = weights.skill;
    
    updateWeightDisplay();
}

/**
 * 加载排序预设（根据算法版本）
 * @param {string} version - 'classic' 或 'optimized'
 */
function loadSortPresets(version) {
    const container = document.getElementById('sortPresets');
    if (!container) return;
    
    const isOptimized = version === 'optimized';
    
    const presets = isOptimized ? [
        { id: 'balanced', name: '均衡模式', icon: 'fa-balance-scale', desc: '六个维度均衡考虑，适合日常使用' },
        { id: 'deadline_first', name: '截止优先', icon: 'fa-clock', desc: '优先处理时间压力大的任务' },
        { id: 'energy_aware', name: '精力感知', icon: 'fa-battery-three-quarters', desc: '根据精力状态匹配任务' },
        { id: 'preference_learned', name: '偏好学习', icon: 'fa-user-cog', desc: '重视用户历史行为数据' }
    ] : [
        { id: 'balanced', name: '均衡模式', icon: 'fa-balance-scale', desc: '六个维度均衡考虑' },
        { id: 'deadline_first', name: '截止优先', icon: 'fa-clock', desc: '优先处理临近截止的任务' },
        { id: 'exam_prep', name: '备考模式', icon: 'fa-graduation-cap', desc: '适合备考人员' },
        { id: 'freelancer', name: '自由职业', icon: 'fa-briefcase', desc: '适合自由职业者' }
    ];
    
    container.innerHTML = presets.map(p => `
        <div class="recurring-preset" data-preset="${p.id}" onclick="applySortPreset('${p.id}')">
            <i class="fas ${p.icon}"></i>
            <div class="preset-info">
                <span class="preset-name">${p.name}</span>
                <span class="preset-desc">${p.desc}</span>
            </div>
        </div>
    `).join('');
}

function updateWeightDisplay(changedSliderId = null) {
    const sliders = ['weightTime', 'weightImportance', 'weightImpact', 'weightMoney', 'weightRelation', 'weightSkill'];
    
    // 获取所有当前值
    const values = {};
    sliders.forEach(id => {
        values[id] = parseInt(document.getElementById(id).value);
    });
    
    // 计算当前总和
    const total = Object.values(values).reduce((sum, v) => sum + v, 0);
    
    // 如果总和不为100且有滑块被改变，自动调整其他滑块
    if (changedSliderId && total !== 100) {
        const otherSliders = sliders.filter(id => id !== changedSliderId);
        const otherTotal = total - values[changedSliderId];
        
        if (otherTotal > 0) {
            // 按比例调整其他滑块
            const targetOtherTotal = 100 - values[changedSliderId];
            const ratio = targetOtherTotal / otherTotal;
            
            otherSliders.forEach(id => {
                const newValue = Math.round(values[id] * ratio);
                document.getElementById(id).value = Math.max(0, Math.min(100, newValue));
            });
        } else {
            // 其他滑块都为0，平均分配剩余值
            const remaining = 100 - values[changedSliderId];
            const perSlider = Math.round(remaining / otherSliders.length);
            
            otherSliders.forEach((id, index) => {
                // 最后一个滑块取余数，确保总和为100
                const value = index === otherSliders.length - 1 
                    ? remaining - perSlider * (otherSliders.length - 1)
                    : perSlider;
                document.getElementById(id).value = Math.max(0, value);
            });
        }
    }
    
    // 确保总和为100（边界情况处理）
    const finalValues = {};
    sliders.forEach(id => {
        finalValues[id] = parseInt(document.getElementById(id).value);
    });
    const finalTotal = Object.values(finalValues).reduce((sum, v) => sum + v, 0);
    
    if (finalTotal !== 100 && changedSliderId) {
        // 微调最后一个滑块
        const lastSlider = sliders[sliders.length - 1];
        const adjustment = 100 - finalTotal + finalValues[lastSlider];
        document.getElementById(lastSlider).value = Math.max(0, adjustment);
    }
    
    // 更新显示值
    document.getElementById('weightTimeValue').textContent = document.getElementById('weightTime').value + '%';
    document.getElementById('weightImportanceValue').textContent = document.getElementById('weightImportance').value + '%';
    document.getElementById('weightImpactValue').textContent = document.getElementById('weightImpact').value + '%';
    document.getElementById('weightMoneyValue').textContent = document.getElementById('weightMoney').value + '%';
    document.getElementById('weightRelationValue').textContent = document.getElementById('weightRelation').value + '%';
    document.getElementById('weightSkillValue').textContent = document.getElementById('weightSkill').value + '%';
    
    // 更新总和显示
    updateWeightTotal();
}

/**
 * 更新权重总和显示
 */
function updateWeightTotal() {
    const sliders = ['weightTime', 'weightImportance', 'weightImpact', 'weightMoney', 'weightRelation', 'weightSkill'];
    const total = sliders.reduce((sum, id) => sum + parseInt(document.getElementById(id).value), 0);
    
    // 更新或创建总和显示元素
    let totalEl = document.getElementById('weightTotalValue');
    if (!totalEl) {
        const weightSliders = document.querySelector('.weight-sliders');
        if (weightSliders) {
            const totalDiv = document.createElement('div');
            totalDiv.className = 'weight-item weight-total';
            totalDiv.style.cssText = 'margin-top: 12px; padding-top: 12px; border-top: 1px solid var(--border-light);';
            totalDiv.innerHTML = `
                <span class="weight-label" style="font-weight: 600;">总和</span>
                <div style="flex: 1;"></div>
                <span class="weight-value" id="weightTotalValue" style="font-weight: 600; color: var(--accent-primary);">100%</span>
            `;
            weightSliders.appendChild(totalDiv);
            totalEl = document.getElementById('weightTotalValue');
        }
    }
    
    if (totalEl) {
        totalEl.textContent = total + '%';
        totalEl.style.color = total === 100 ? 'var(--accent-primary)' : 'var(--accent-danger)';
    }
    
    return total;
}

async function executeAISort() {
    // 检查点击频率
    const clickCheck = ClickManager.checkClick('executeAISort');
    if (clickCheck.shouldWarn) {
        showToast('请稍候再试，不要重复点击哦~', 'warning');
        return;
    }
    
    // 智能模式下检查API Key
    if (currentSortMode === 'smart' && !hasAIConfig()) {
        showAIConfigReminder();
        return;
    }
    
    // 验证权重总和
    const total = updateWeightTotal();
    if (total !== 100) {
        showToast(`权重总和必须为100%，当前为${total}%`, 'error');
        return;
    }
    
    const aiProvider = localStorage.getItem('aiProvider') || '';
    const aiApiKey = localStorage.getItem('aiApiKey') || '';
    const aiModel = localStorage.getItem('aiModel') || 'qwen-turbo';
    
    // 根据算法版本构建权重对象
    let weights;
    if (currentAlgorithmVersion === 'optimized') {
        weights = {
            time_pressure: parseInt(document.getElementById('weightTime').value) / 100,
            priority: parseInt(document.getElementById('weightImportance').value) / 100,
            energy_match: parseInt(document.getElementById('weightImpact').value) / 100,
            user_preference: parseInt(document.getElementById('weightMoney').value) / 100,
            semantic_importance: parseInt(document.getElementById('weightRelation').value) / 100,
            context_fit: parseInt(document.getElementById('weightSkill').value) / 100
        };
    } else {
        weights = {
            time: parseInt(document.getElementById('weightTime').value) / 100,
            importance: parseInt(document.getElementById('weightImportance').value) / 100,
            impact: parseInt(document.getElementById('weightImpact').value) / 100,
            money: parseInt(document.getElementById('weightMoney').value) / 100,
            relation: parseInt(document.getElementById('weightRelation').value) / 100,
            skill: parseInt(document.getElementById('weightSkill').value) / 100
        };
    }
    
    // 构建用户上下文（用于优化算法）
    const userContext = {
        current_energy: 5,  // 默认中等精力
        focus_mode: false   // 默认非专注模式
    };
    
    // 构建请求头
    const headers = {
        'Content-Type': 'application/json'
    };
    
    if (currentSortMode === 'smart' && aiApiKey) {
        headers['X-AI-Provider'] = aiProvider;
        headers['X-AI-API-Key'] = aiApiKey;
        headers['X-AI-Model'] = aiModel;
    }
    
    // 确定排序模式
    let sortMode = currentSortMode;
    if (currentAlgorithmVersion === 'optimized') {
        sortMode = 'optimized';
    }
    
    try {
        const response = await API.request(`${API_BASE}/ai/sort/batch-update`, {
            method: 'POST',
            headers: headers,
            body: JSON.stringify({ 
                weights, 
                mode: sortMode,
                save_scores: true,
                user_context: userContext,
                behavior_data: {}  // 可从本地存储加载用户行为数据
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            closeModal('aiSortModal');
            
            // 重置点击计数
            ClickManager.resetClickCount('executeAISort');
            
            // 根据模式显示不同的提示
            if (result.mode === 'optimized') {
                showToast(`优化算法分析完成，已更新${result.updated_count}个任务`, 'success');
            } else if (result.mode === 'smart') {
                showToast(`AI智能分析完成，已更新${result.updated_count}个任务`, 'success');
            } else if (result.fallback) {
                showToast(`AI分析失败，已使用本地分析更新${result.updated_count}个任务`, 'warning');
            } else {
                showToast(`本地分析完成，已更新${result.updated_count}个任务`, 'success');
            }
            
            document.getElementById('sortFilter').value = 'ai_sort';
            loadTasks();
        } else {
            showToast(result.message || '排序失败', 'error');
        }
    } catch (error) {
        console.error('AI排序失败:', error);
        showToast('排序失败', 'error');
    }
}

async function batchAISort() {
    // 检查点击频率
    const clickCheck = ClickManager.checkClick('batchAISort');
    if (clickCheck.shouldWarn) {
        showToast('请稍候再试，不要重复点击哦~', 'warning');
        return;
    }
    
    // 获取保存的AI配置
    const aiProvider = localStorage.getItem('aiProvider') || '';
    const aiApiKey = localStorage.getItem('aiApiKey') || '';
    const aiModel = localStorage.getItem('aiModel') || 'qwen-turbo';
    
    // 根据是否配置AI Key决定使用智能模式还是本地模式
    const mode = aiApiKey ? 'smart' : 'local';
    
    // 使用默认的均衡权重（与模态框的均衡预设一致）
    const weights = {
        time: 0.20,
        importance: 0.20,
        impact: 0.15,
        money: 0.15,
        relation: 0.15,
        skill: 0.15
    };
    
    // 构建请求头
    const headers = {
        'Content-Type': 'application/json'
    };
    
    // 智能模式添加AI配置
    if (mode === 'smart' && aiApiKey) {
        headers['X-AI-Provider'] = aiProvider;
        headers['X-AI-API-Key'] = aiApiKey;
        headers['X-AI-Model'] = aiModel;
    }
    
    try {
        const response = await API.request(`${API_BASE}/ai/sort/batch-update`, {
            method: 'POST',
            headers: headers,
            body: JSON.stringify({ 
                weights, 
                mode: mode,
                save_scores: true 
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            // 重置点击计数
            ClickManager.resetClickCount('batchAISort');
            
            // 根据模式显示不同的提示
            if (result.mode === 'smart') {
                showToast(`AI智能分析完成，已更新${result.updated_count}个任务`, 'success');
            } else if (result.fallback) {
                showToast(`AI分析失败，已使用本地分析更新${result.updated_count}个任务`, 'warning');
            } else {
                showToast(`本地分析完成，已更新${result.updated_count}个任务`, 'success');
            }
            
            document.getElementById('sortFilter').value = 'ai_sort';
            loadTasks();
        } else {
            showToast(result.message || '排序失败', 'error');
        }
    } catch (error) {
        console.error('AI排序失败:', error);
        showToast('排序失败', 'error');
    }
}

// ==================== 重复任务 ====================

function showRecurringModal() {
    // 检查点击频率
    const clickCheck = ClickManager.checkClick('showRecurringModal');
    if (clickCheck.shouldWarn) {
        showToast('请稍候再试，不要重复点击哦~', 'warning');
        return;
    }
    
    document.getElementById('recurringStartDate').value = new Date().toISOString().split('T')[0];
    openModal('recurringModal');
}

function initRecurringPresets() {
    const presets = document.querySelectorAll('#recurringPresets .recurring-preset');
    presets.forEach(preset => {
        preset.addEventListener('click', () => {
            presets.forEach(p => p.classList.remove('selected'));
            preset.classList.add('selected');
        });
    });
}

async function createRecurringTask() {
    const selectedPreset = document.querySelector('#recurringPresets .recurring-preset.selected');
    const recurringType = selectedPreset?.dataset.type || 'daily';
    
    const rule = {
        name: document.getElementById('recurringName').value.trim(),
        recurring_type: recurringType,
        category: document.getElementById('recurringCategory').value,
        priority: parseInt(document.getElementById('recurringPriority').value),
        start_date: document.getElementById('recurringStartDate').value
    };
    
    if (!rule.name) {
        showToast('请输入任务名称', 'error');
        return;
    }
    
    try {
        const response = await API.post('/recurring', rule);
        
        const result = await response.json();
        if (result.success) {
            closeModal('recurringModal');
            showToast('重复任务创建成功', 'success');
            
            // 生成实例
            await API.post(`/recurring/${result.rule.id}/generate`, { days_ahead: 7 });
            
            loadTasks();
        }
    } catch (error) {
        showToast('创建失败', 'error');
    }
}

// ==================== 重复任务管理 ====================

function showRecurringManageModal() {
    // 检查点击频率
    const clickCheck = ClickManager.checkClick('showRecurringManageModal');
    if (clickCheck.shouldWarn) {
        showToast('请稍候再试，不要重复点击哦~', 'warning');
        return;
    }
    
    openModal('recurringManageModal');
    loadRecurringRules();
}

async function loadRecurringRules() {
    const container = document.getElementById('recurringRulesList');
    if (!container) return;
    
    try {
        const response = await API.get('/recurring');
        const result = await response.json();
        
        if (!result.success || !result.rules || result.rules.length === 0) {
            container.innerHTML = `
                <div style="text-align: center; color: var(--text-tertiary); padding: 40px;">
                    <i class="fas fa-redo" style="font-size: 48px; margin-bottom: 16px; opacity: 0.3;"></i>
                    <p>暂无重复任务规则</p>
                    <button class="btn-primary" onclick="closeModal('recurringManageModal'); showRecurringModal();" style="margin-top: 16px;">
                        <i class="fas fa-plus"></i> 创建第一个规则
                    </button>
                </div>
            `;
            return;
        }
        
        const typeLabels = {
            'daily': '每天',
            'weekly': '每周',
            'monthly': '每月',
            'custom': '自定义'
        };
        
        const html = result.rules.map(rule => {
            const template = rule.task_template || {};
            const isActive = rule.is_active !== 0;
            return `
                <div class="recurring-rule-item" style="
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                    padding: 16px;
                    background: var(--bg-secondary);
                    border-radius: 8px;
                    margin-bottom: 12px;
                    border: 1px solid var(--border-color);
                    opacity: ${isActive ? 1 : 0.6};
                ">
                    <div style="flex: 1;">
                        <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 4px;">
                            <span style="font-weight: 500; color: var(--text-primary);">${XSSProtection.escapeHtml(rule.name)}</span>
                            ${!isActive ? '<span style="font-size: 11px; background: var(--text-tertiary); color: white; padding: 2px 6px; border-radius: 4px;">已暂停</span>' : ''}
                        </div>
                        <div style="font-size: 12px; color: var(--text-tertiary);">
                            <span style="margin-right: 12px;"><i class="fas fa-calendar"></i> ${typeLabels[rule.recurring_type] || rule.recurring_type}</span>
                            <span style="margin-right: 12px;"><i class="fas fa-folder"></i> ${template.category || '学习'}</span>
                            <span><i class="fas fa-flag"></i> 优先级 ${template.priority || 0}</span>
                        </div>
                    </div>
                    <div style="display: flex; gap: 8px;">
                        <button class="btn-icon" onclick="toggleRecurringRule(${rule.id}, ${!isActive})" title="${isActive ? '暂停' : '启用'}">
                            <i class="fas ${isActive ? 'fa-pause' : 'fa-play'}"></i>
                        </button>
                        <button class="btn-icon" onclick="generateRecurringTasks(${rule.id})" title="立即生成">
                            <i class="fas fa-magic"></i>
                        </button>
                        <button class="btn-icon" onclick="deleteRecurringRule(${rule.id})" title="删除">
                            <i class="fas fa-trash" style="color: var(--accent-error);"></i>
                        </button>
                    </div>
                </div>
            `;
        }).join('');
        
        container.innerHTML = html;
    } catch (error) {
        console.error('加载重复任务规则失败:', error);
        container.innerHTML = `
            <div style="text-align: center; color: var(--accent-error); padding: 40px;">
                <i class="fas fa-exclamation-circle" style="font-size: 24px; margin-bottom: 12px;"></i>
                <p>加载失败，请重试</p>
                <button class="btn-secondary" onclick="loadRecurringRules()" style="margin-top: 12px;">
                    <i class="fas fa-refresh"></i> 重试
                </button>
            </div>
        `;
    }
}

async function toggleRecurringRule(ruleId, isActive) {
    try {
        const response = await API.put(`/recurring/${ruleId}`, { is_active: isActive ? 1 : 0 });
        const result = await response.json();
        
        if (result.success) {
            showToast(isActive ? '规则已启用' : '规则已暂停', 'success');
            loadRecurringRules();
        } else {
            showToast(result.message || '操作失败', 'error');
        }
    } catch (error) {
        console.error('切换规则状态失败:', error);
        showToast('操作失败', 'error');
    }
}

async function generateRecurringTasks(ruleId) {
    try {
        showToast('正在生成任务...', 'info');
        const response = await API.post(`/recurring/${ruleId}/generate`, { days_ahead: 7 });
        const result = await response.json();
        
        if (result.success) {
            showToast(`成功生成 ${result.generated_count} 个任务`, 'success');
            loadTasks();
        } else {
            showToast(result.message || '生成失败', 'error');
        }
    } catch (error) {
        console.error('生成任务失败:', error);
        showToast('生成失败', 'error');
    }
}

async function deleteRecurringRule(ruleId) {
    if (!confirm('确定要删除这个重复任务规则吗？相关的未完成任务也会被删除。')) {
        return;
    }
    
    try {
        const response = await API.delete(`/recurring/${ruleId}?delete_instances=true`);
        const result = await response.json();
        
        if (result.success) {
            showToast('规则已删除', 'success');
            loadRecurringRules();
            loadTasks();
        } else {
            showToast(result.message || '删除失败', 'error');
        }
    } catch (error) {
        console.error('删除规则失败:', error);
        showToast('删除失败', 'error');
    }
}

// ==================== AI分析 ====================

function showAnalysisModal() {
    // 检查点击频率
    const clickCheck = ClickManager.checkClick('showAnalysisModal');
    if (clickCheck.shouldWarn) {
        showToast('请稍候再试，不要重复点击哦~', 'warning');
        return;
    }
    
    openModal('analysisModal');
    loadAnalysisData();
}

/**
 * AI分析结果缓存管理器
 */
const AIAnalysisCache = {
    // localStorage 键名
    CACHE_PREFIX: 'ai_analysis_',
    EFFICIENCY_KEY: 'ai_analysis_efficiency',
    COMPLETION_KEY: 'ai_analysis_completion',
    HABIT_KEY: 'ai_analysis_habit',
    // 缓存有效期（24小时，单位：毫秒）
    CACHE_TTL: 24 * 60 * 60 * 1000,
    
    /**
     * 保存效率分析数据到本地缓存
     * @param {object} data - 效率分析数据
     */
    saveEfficiency(data) {
        try {
            const cacheData = {
                timestamp: Date.now(),
                data: data
            };
            localStorage.setItem(this.EFFICIENCY_KEY, JSON.stringify(cacheData));
        } catch (e) {
            console.warn('保存效率分析缓存失败:', e);
        }
    },
    
    /**
     * 从本地缓存读取效率分析数据
     * @returns {object|null} 缓存数据或null
     */
    loadEfficiency() {
        try {
            const cached = localStorage.getItem(this.EFFICIENCY_KEY);
            if (!cached) return null;
            
            const cacheData = JSON.parse(cached);
            // 检查是否过期
            if (Date.now() - cacheData.timestamp > this.CACHE_TTL) {
                localStorage.removeItem(this.EFFICIENCY_KEY);
                return null;
            }
            return cacheData.data;
        } catch (e) {
            console.warn('读取效率分析缓存失败:', e);
            return null;
        }
    },
    
    /**
     * 保存AI完成分析结果到本地缓存
     * @param {string} analysis - 分析文本
     */
    saveCompletion(analysis) {
        try {
            const cacheData = {
                timestamp: Date.now(),
                analysis: analysis
            };
            localStorage.setItem(this.COMPLETION_KEY, JSON.stringify(cacheData));
        } catch (e) {
            console.warn('保存AI分析缓存失败:', e);
        }
    },
    
    /**
     * 从本地缓存读取AI完成分析结果
     * @returns {object|null} 缓存数据或null
     */
    loadCompletion() {
        try {
            const cached = localStorage.getItem(this.COMPLETION_KEY);
            if (!cached) return null;
            
            const cacheData = JSON.parse(cached);
            // 检查是否过期
            if (Date.now() - cacheData.timestamp > this.CACHE_TTL) {
                localStorage.removeItem(this.COMPLETION_KEY);
                return null;
            }
            return cacheData;
        } catch (e) {
            console.warn('读取AI分析缓存失败:', e);
            return null;
        }
    },
    
    /**
     * 保存习惯分析结果到本地缓存
     * @param {object} data - 习惯分析数据
     */
    saveHabit(data) {
        try {
            const cacheData = {
                timestamp: Date.now(),
                data: data
            };
            localStorage.setItem(this.HABIT_KEY, JSON.stringify(cacheData));
        } catch (e) {
            console.warn('保存习惯分析缓存失败:', e);
        }
    },
    
    /**
     * 从本地缓存读取习惯分析结果
     * @returns {object|null} 缓存数据或null
     */
    loadHabit() {
        try {
            const cached = localStorage.getItem(this.HABIT_KEY);
            if (!cached) return null;
            
            const cacheData = JSON.parse(cached);
            // 检查是否过期
            if (Date.now() - cacheData.timestamp > this.CACHE_TTL) {
                localStorage.removeItem(this.HABIT_KEY);
                return null;
            }
            return cacheData.data;
        } catch (e) {
            console.warn('读取习惯分析缓存失败:', e);
            return null;
        }
    },
    
    /**
     * 清除所有分析缓存
     */
    clearAll() {
        try {
            localStorage.removeItem(this.EFFICIENCY_KEY);
            localStorage.removeItem(this.COMPLETION_KEY);
            localStorage.removeItem(this.HABIT_KEY);
        } catch (e) {
            console.warn('清除分析缓存失败:', e);
        }
    },
    
    /**
     * 获取缓存剩余有效时间（秒）
     * @param {string} type - 'efficiency'、'completion' 或 'habit'
     * @returns {number} 剩余秒数，0表示已过期或不存在
     */
    getRemainingTime(type) {
        try {
            let key;
            if (type === 'efficiency') key = this.EFFICIENCY_KEY;
            else if (type === 'completion') key = this.COMPLETION_KEY;
            else if (type === 'habit') key = this.HABIT_KEY;
            else return 0;
            
            const cached = localStorage.getItem(key);
            if (!cached) return 0;
            
            const cacheData = JSON.parse(cached);
            const elapsed = Date.now() - cacheData.timestamp;
            const remaining = Math.max(0, this.CACHE_TTL - elapsed);
            return Math.floor(remaining / 1000);
        } catch (e) {
            return 0;
        }
    },
    
    /**
     * 根据键名获取缓存（通用方法）
     * @param {string} key - 缓存键名（不含前缀）
     * @returns {object|null} 缓存数据或null
     */
    get(key) {
        try {
            const item = localStorage.getItem(this.CACHE_PREFIX + key);
            if (!item) return null;
            const { data, timestamp } = JSON.parse(item);
            if (Date.now() - timestamp > this.CACHE_TTL) {
                localStorage.removeItem(this.CACHE_PREFIX + key);
                return null;
            }
            return data;
        } catch (e) {
            return null;
        }
    },
    
    /**
     * 设置缓存（通用方法）
     * @param {string} key - 缓存键名（不含前缀）
     * @param {object} data - 缓存数据
     */
    set(key, data) {
        try {
            localStorage.setItem(this.CACHE_PREFIX + key, JSON.stringify({
                data,
                timestamp: Date.now()
            }));
        } catch (e) {
            console.warn('设置缓存失败:', e);
        }
    },
    
    /**
     * 清除指定类型的缓存
     * @param {string} type - 'efficiency'、'completion'、'habit' 或 'all'
     */
    clear(type = 'all') {
        try {
            if (type === 'all' || type === 'efficiency') {
                localStorage.removeItem(this.EFFICIENCY_KEY);
            }
            if (type === 'all' || type === 'completion') {
                localStorage.removeItem(this.COMPLETION_KEY);
            }
            if (type === 'all' || type === 'habit') {
                localStorage.removeItem(this.HABIT_KEY);
            }
        } catch (e) {
            console.warn('清除缓存失败:', e);
        }
    }
};

/**
 * 渲染AI分析结果到UI
 * @param {string} type - 分析类型（habit/weekly/completion）
 * @param {string} analysis - 分析文本
 * @param {boolean} fromCache - 是否来自缓存
 */
function renderAnalysisResult(type, analysis, fromCache = false) {
    console.log(`[AI分析] 渲染${type}分析结果${fromCache ? '（来自缓存）' : ''}`);
    
    // 根据类型渲染到对应UI
    switch(type) {
        case 'completion':
        case 'habit':
            const analysisEmpty = document.getElementById('analysisEmpty');
            const analysisContent = document.getElementById('analysisContent');
            const analysisResult = document.getElementById('analysisResult');
            
            if (analysisEmpty && analysisContent && analysisResult) {
                analysisEmpty.style.display = 'none';
                analysisContent.style.display = 'block';
                analysisResult.textContent = analysis;
                
                if (fromCache) {
                    // 添加缓存标记
                    const cacheBadge = document.createElement('span');
                    cacheBadge.className = 'cache-badge';
                    cacheBadge.textContent = '来自缓存';
                    cacheBadge.style.cssText = 'font-size: 12px; color: #888; margin-left: 8px;';
                    
                    // 检查是否已存在缓存标记
                    const existingBadge = analysisContent.querySelector('.cache-badge');
                    if (!existingBadge && analysisResult.parentElement) {
                        analysisResult.parentElement.appendChild(cacheBadge);
                    }
                }
            }
            break;
            
        case 'weekly':
            // 每周报告渲染逻辑
            const reportContent = document.getElementById('weeklyReportContent');
            if (reportContent) {
                reportContent.innerHTML = `<pre>${analysis}</pre>`;
                if (fromCache) {
                    showToast('已加载缓存的每周报告', 'info');
                }
            }
            break;
            
        default:
            console.warn(`[AI分析] 未知的分析类型: ${type}`);
    }
}

async function loadAnalysisData(forceRefresh = false) {
    // 首先尝试从本地缓存加载（快速显示）
    const cachedEfficiency = AIAnalysisCache.loadEfficiency();
    if (cachedEfficiency) {
        document.getElementById('analysisTotalTasks').textContent = cachedEfficiency.total_tasks || 0;
        document.getElementById('analysisTotalDuration').textContent = cachedEfficiency.total_duration || 0;
        document.getElementById('analysisAvgDuration').textContent = cachedEfficiency.avg_duration || 0;
        console.log('[AI分析缓存] 效率数据已从本地缓存加载');
    }
    
    // 尝试加载AI分析文本缓存
    const cachedCompletion = AIAnalysisCache.loadCompletion();
    if (cachedCompletion) {
        document.getElementById('analysisEmpty').style.display = 'none';
        document.getElementById('analysisContent').style.display = 'block';
        document.getElementById('analysisResult').textContent = cachedCompletion.analysis;
        
        // 显示缓存时间提示
        const remainingTime = AIAnalysisCache.getRemainingTime('completion');
        const hours = Math.floor(remainingTime / 3600);
        console.log(`[AI分析缓存] 分析文本缓存剩余有效期: ${hours}小时`);
    }
    
    // 同时异步从服务器获取最新数据
    try {
        const url = forceRefresh ? '/analysis/efficiency?days=7&force_refresh=true' : '/analysis/efficiency?days=7';
        const response = await API.get(url);
        const result = await response.json();
        
        if (result.success) {
            document.getElementById('analysisTotalTasks').textContent = result.efficiency.total_tasks;
            document.getElementById('analysisTotalDuration').textContent = result.efficiency.total_duration;
            document.getElementById('analysisAvgDuration').textContent = result.efficiency.avg_duration;
            
            // 保存到本地缓存
            AIAnalysisCache.saveEfficiency(result.efficiency);
            
            // 如果服务器返回的是缓存数据，显示提示
            if (result.cached) {
                console.log(`[AI分析缓存] 服务器返回缓存数据，缓存时间: ${result.cached_at}`);
            }
        }
    } catch (error) {
        console.error('加载分析数据失败:', error);
        // 如果服务器请求失败但本地有缓存，显示提示
        if (cachedEfficiency) {
            showToast('已显示本地缓存数据，联网后可获取最新分析', 'info');
        }
    }
}

async function runAIAnalysis() {
    // 检查点击频率
    const clickCheck = ClickManager.checkClick('runAIAnalysis');
    if (clickCheck.shouldWarn) {
        showToast('请稍候再试，不要重复点击哦~', 'warning');
        return;
    }
    
    // 检查是否配置了AI API Key
    if (!hasAIConfig()) {
        showAIConfigReminder();
        return;
    }
    
    try {
        const aiProvider = localStorage.getItem('aiProvider') || '';
        const aiApiKey = localStorage.getItem('aiApiKey') || '';
        const aiModel = localStorage.getItem('aiModel') || 'qwen-turbo';
        
        const headers = {
            'Content-Type': 'application/json',
            'X-AI-Provider': aiProvider,
            'X-AI-API-Key': aiApiKey,
            'X-AI-Model': aiModel
        };
        
        const response = await API.request(`${API_BASE}/analysis/completion`, {
            method: 'POST',
            headers: headers,
            body: JSON.stringify({ days: 7 })
        });
        
        const result = await response.json();
        if (result.success) {
            document.getElementById('analysisEmpty').style.display = 'none';
            document.getElementById('analysisContent').style.display = 'block';
            document.getElementById('analysisResult').textContent = result.analysis;
            
            // 保存分析结果到本地缓存
            AIAnalysisCache.saveCompletion(result.analysis);
            
            // 显示缓存状态提示
            if (result.cached) {
                showToast(`已显示缓存分析结果（缓存时间: ${result.cached_at}）`, 'info');
            } else {
                showToast('AI分析完成并已缓存', 'success');
            }
            
            // 成功后重置点击计数
            ClickManager.resetClickCount('runAIAnalysis');
        } else {
            showToast(result.message || '分析失败', 'error');
        }
    } catch (error) {
        showToast('AI分析失败', 'error');
    }
}

// ==================== 统计 ====================

function showStatsModal() {
    // 检查点击频率
    const clickCheck = ClickManager.checkClick('showStatsModal');
    if (clickCheck.shouldWarn) {
        showToast('请稍候再试，不要重复点击哦~', 'warning');
        return;
    }
    
    openModal('statsModal');
    loadStats();
}

// 每周报告模态框
async function showWeeklyReportModal() {
    openModal('weeklyReportModal');
    await loadWeeklyReport();
}

async function loadWeeklyReport() {
    try {
        const report = await WeeklyReportManager.loadReport();
        
        if (report) {
            WeeklyReportManager.renderReport(report);
            
            // 渲染图表
            if (report.category_stats) {
                WeeklyReportManager.renderCategoryChart(report.category_stats);
            }
            if (report.efficiency_trend) {
                WeeklyReportManager.renderTrendChart(report.efficiency_trend);
            }
        } else {
            showToast('加载报告失败，请稍后重试', 'error');
        }
    } catch (error) {
        console.error('加载每周报告失败:', error);
        showToast('加载报告失败', 'error');
    }
}

async function loadStats() {
    try {
        // 使用新的图表API获取数据（包含热力图、雷达图、生产力统计）
        const [overviewRes, categoryBarRes, completionLineRes, timePieRes, radarRes, heatmapRes, productivityRes] = await Promise.all([
            API.get('/stats/overview'),
            API.get('/stats/chart/category-bar'),
            API.get('/stats/chart/completion-line?days=7'),
            API.get('/stats/chart/time-pie'),
            API.get('/stats/chart/radar'),
            API.get('/stats/heatmap'),
            API.get('/stats/productivity')
        ]);
        
        const overview = await overviewRes.json();
        const categoryBar = await categoryBarRes.json();
        const completionLine = await completionLineRes.json();
        const timePie = await timePieRes.json();
        const radar = await radarRes.json();
        const heatmap = await heatmapRes.json();
        const productivity = await productivityRes.json();
        
        if (overview.success) {
            document.getElementById('statTotal').textContent = overview.overview.total_tasks;
            document.getElementById('statCompleted').textContent = overview.overview.completed_tasks;
            document.getElementById('statPending').textContent = overview.overview.pending_tasks;
            document.getElementById('statRate').textContent = overview.overview.completion_rate + '%';
        }
        
        if (categoryBar.success) {
            renderCategoryBarChart(categoryBar.chart);
        }
        
        if (completionLine.success) {
            renderCompletionLineChart(completionLine.chart);
        }
        
        if (timePie.success) {
            renderTimePieChart(timePie.chart);
        }
        
        // 渲染新增的图表
        if (radar.success) {
            renderRadarChart(radar.chart);
        }
        
        if (heatmap.success) {
            renderHeatmap(heatmap.heatmap);
        }
        
        if (productivity.success) {
            renderProductivityStats(productivity.productivity);
        }
    } catch (error) {
        console.error('加载统计失败:', error);
    }
}

function renderCategoryBarChart(chartData) {
    const ctx = document.getElementById('categoryChart');
    if (!ctx) return;
    
    // 检查 Chart.js 是否可用
    if (typeof Chart === 'undefined') {
        console.warn('Chart.js 不可用，图表渲染已跳过');
        return;
    }
    
    // 安全销毁旧图表实例
    if (categoryChart && typeof categoryChart.destroy === 'function') {
        try {
            categoryChart.destroy();
        } catch (e) {
            console.warn('销毁旧图表失败:', e);
        }
    }
    categoryChart = null;
    
    categoryChart = new Chart(ctx, chartData);
}

function renderCompletionLineChart(chartData) {
    const ctx = document.getElementById('trendChart');
    if (!ctx) return;
    
    // 检查 Chart.js 是否可用
    if (typeof Chart === 'undefined') {
        console.warn('Chart.js 不可用，图表渲染已跳过');
        return;
    }
    
    // 安全销毁旧图表实例
    if (trendChart && typeof trendChart.destroy === 'function') {
        try {
            trendChart.destroy();
        } catch (e) {
            console.warn('销毁旧图表失败:', e);
        }
    }
    trendChart = null;
    
    trendChart = new Chart(ctx, chartData);
}

function renderTimePieChart(chartData) {
    const ctx = document.getElementById('timePieChart');
    if (!ctx) return;
    
    // 检查 Chart.js 是否可用
    if (typeof Chart === 'undefined') {
        console.warn('Chart.js 不可用，图表渲染已跳过');
        return;
    }
    
    // 安全销毁旧图表实例
    if (window.timePieChart && typeof window.timePieChart.destroy === 'function') {
        try {
            window.timePieChart.destroy();
        } catch (e) {
            console.warn('销毁旧图表失败:', e);
        }
    }
    window.timePieChart = null;
    
    window.timePieChart = new Chart(ctx, chartData);
}

function renderTrendChart(trend) {
    const ctx = document.getElementById('trendChart');
    if (!ctx) return;
    
    // 检查 Chart.js 是否可用
    if (typeof Chart === 'undefined') {
        console.warn('Chart.js 不可用，图表渲染已跳过');
        return;
    }
    
    // 安全销毁旧图表实例
    if (trendChart && typeof trendChart.destroy === 'function') {
        try {
            trendChart.destroy();
        } catch (e) {
            console.warn('销毁旧图表失败:', e);
        }
    }
    trendChart = null;
    
    trendChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: trend.map(t => t.date),
            datasets: [
                {
                    label: '创建',
                    data: trend.map(t => t.created),
                    borderColor: '#2196F3',
                    tension: 0.3
                },
                {
                    label: '完成',
                    data: trend.map(t => t.completed),
                    borderColor: '#4CAF50',
                    tension: 0.3
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}

// ==================== 高级统计图表渲染 ====================

let radarChart = null;
let heatmapChart = null;

function renderRadarChart(chartData) {
    const ctx = document.getElementById('radarChart');
    if (!ctx) return;
    
    // 检查 Chart.js 是否可用
    if (typeof Chart === 'undefined') {
        console.warn('Chart.js 不可用，图表渲染已跳过');
        return;
    }
    
    // 安全销毁旧图表实例
    if (radarChart && typeof radarChart.destroy === 'function') {
        try {
            radarChart.destroy();
        } catch (e) {
            console.warn('销毁雷达图失败:', e);
        }
    }
    radarChart = null;
    
    radarChart = new Chart(ctx, chartData);
}

function renderHeatmap(heatmapData) {
    const container = document.getElementById('heatmapContainer');
    if (!container) return;
    
    // 清空容器
    container.innerHTML = '';
    
    if (!heatmapData || heatmapData.length === 0) {
        container.innerHTML = '<div style="text-align: center; color: var(--text-tertiary); padding: 20px;">暂无数据</div>';
        return;
    }
    
    // 创建热力图网格
    const grid = document.createElement('div');
    grid.style.cssText = 'display: grid; grid-template-columns: repeat(7, 1fr); gap: 4px;';
    
    // 颜色映射
    const colors = ['#ebedf0', '#9be9a8', '#40c463', '#30a14e', '#216e39'];
    
    heatmapData.forEach(item => {
        const cell = document.createElement('div');
        cell.style.cssText = `
            aspect-ratio: 1;
            border-radius: 2px;
            background-color: ${colors[item.level] || colors[0]};
            cursor: pointer;
            transition: transform 0.2s;
        `;
        cell.title = `${item.date}: ${item.count} 个任务`;
        cell.addEventListener('mouseenter', () => {
            cell.style.transform = 'scale(1.2)';
        });
        cell.addEventListener('mouseleave', () => {
            cell.style.transform = 'scale(1)';
        });
        grid.appendChild(cell);
    });
    
    container.appendChild(grid);
    
    // 添加图例
    const legend = document.createElement('div');
    legend.style.cssText = 'display: flex; align-items: center; justify-content: center; gap: 8px; margin-top: 12px; font-size: 12px; color: var(--text-tertiary);';
    legend.innerHTML = `
        <span>少</span>
        ${colors.map(c => `<div style="width: 12px; height: 12px; border-radius: 2px; background: ${c};"></div>`).join('')}
        <span>多</span>
    `;
    container.appendChild(legend);
}

function renderProductivityStats(productivity) {
    const container = document.getElementById('productivityContainer');
    if (!container) return;
    
    if (!productivity || productivity.total_completed === 0) {
        container.innerHTML = '<div style="text-align: center; color: var(--text-tertiary); padding: 20px;">暂无足够数据</div>';
        return;
    }
    
    const html = `
        <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 16px;">
            <div class="stat-card" style="padding: 16px; background: var(--bg-secondary); border-radius: 8px;">
                <div style="font-size: 12px; color: var(--text-tertiary); margin-bottom: 4px;">平均完成时长</div>
                <div style="font-size: 24px; font-weight: 600; color: var(--text-primary);">${productivity.avg_completion_time_minutes ? Math.round(productivity.avg_completion_time_minutes) : '-'}</div>
                <div style="font-size: 12px; color: var(--text-tertiary);">分钟</div>
            </div>
            <div class="stat-card" style="padding: 16px; background: var(--bg-secondary); border-radius: 8px;">
                <div style="font-size: 12px; color: var(--text-tertiary); margin-bottom: 4px;">最佳工作时段</div>
                <div style="font-size: 24px; font-weight: 600; color: var(--text-primary);">${productivity.best_hour !== null ? productivity.best_hour + ':00' : '-'}</div>
                <div style="font-size: 12px; color: var(--text-tertiary);">${productivity.best_hour_display || ''}</div>
            </div>
            <div class="stat-card" style="padding: 16px; background: var(--bg-secondary); border-radius: 8px;">
                <div style="font-size: 12px; color: var(--text-tertiary); margin-bottom: 4px;">最高效分类</div>
                <div style="font-size: 18px; font-weight: 600; color: var(--text-primary);">${productivity.most_productive_category || '-'}</div>
            </div>
            <div class="stat-card" style="padding: 16px; background: var(--bg-secondary); border-radius: 8px;">
                <div style="font-size: 12px; color: var(--text-tertiary); margin-bottom: 4px;">已完成任务</div>
                <div style="font-size: 24px; font-weight: 600; color: var(--text-primary);">${productivity.total_completed}</div>
            </div>
        </div>
    `;
    
    container.innerHTML = html;
}

// ==================== 设置 ====================

// 用户配置文件管理
async function loadUserProfile() {
    try {
        const response = await API.get('/user/profile');
        const result = await response.json();
        if (result.success) {
            currentUser = result.user;
            updateUserDisplay();
        }
    } catch (error) {
        console.error('加载用户信息失败:', error);
    }
}

function updateUserDisplay() {
    if (!currentUser) return;

    // 判断是否为已登录用户
    const isLoggedIn = AuthManager.isLoggedIn();

    // 更新侧边栏用户显示
    const userDisplayEl = document.getElementById('userDisplay');
    if (userDisplayEl) {
        if (isLoggedIn) {
            // 已登录用户：显示用户名和用户ID
            userDisplayEl.innerHTML = `
                <div style="padding: 12px 16px; border-top: 1px solid var(--border-color);">
                    <div style="display: flex; align-items: center; gap: 10px;">
                        <div style="width: 32px; height: 32px; border-radius: 50%; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); display: flex; align-items: center; justify-content: center; color: white; font-weight: 600; font-size: 14px;">
                            ${(currentUser.nickname || '用')[0]}
                        </div>
                        <div style="flex: 1; min-width: 0;">
                            <div style="font-weight: 500; font-size: 14px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${currentUser.nickname || '用户'}</div>
                            <div style="font-size: 11px; color: var(--text-tertiary);">ID: ${currentUser.id.substring(0, 8)}...</div>
                        </div>
                    </div>
                </div>
            `;
        } else {
            // 匿名用户：显示"匿名用户"，不显示用户ID
            userDisplayEl.innerHTML = `
                <div style="padding: 12px 16px; border-top: 1px solid var(--border-color);">
                    <div style="display: flex; align-items: center; gap: 10px;">
                        <div style="width: 32px; height: 32px; border-radius: 50%; background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); display: flex; align-items: center; justify-content: center; color: white; font-weight: 600; font-size: 14px;">
                            <i class="fas fa-user"></i>
                        </div>
                        <div style="flex: 1; min-width: 0;">
                            <div style="font-weight: 500; font-size: 14px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">匿名用户</div>
                        </div>
                    </div>
                </div>
            `;
        }
    }

    // 更新设置界面用户显示（仅在已登录时显示）
    const settingsUserAvatarEl = document.getElementById('settingsUserAvatar');
    const settingsUserNameEl = document.getElementById('settingsUserName');
    const userNicknameEl = document.getElementById('userNickname');
    const userIdDisplayEl = document.getElementById('userIdDisplay');

    if (settingsUserAvatarEl) {
        settingsUserAvatarEl.textContent = (currentUser.nickname || '用')[0];
    }
    if (settingsUserNameEl) {
        settingsUserNameEl.textContent = currentUser.nickname || '用户';
    }
    if (userNicknameEl) {
        userNicknameEl.value = currentUser.nickname || '';
    }
    if (userIdDisplayEl) {
        userIdDisplayEl.textContent = currentUser.id;
    }
}

async function updateUserNickname() {
    const nicknameInput = document.getElementById('userNickname');
    if (!nicknameInput) return;
    
    const nickname = nicknameInput.value.trim();
    
    try {
        const response = await API.put('/user/profile', { nickname });
        const result = await response.json();
        if (result.success) {
            currentUser = result.user;
            updateUserDisplay();
            showToast('昵称已更新', 'success');
        }
    } catch (error) {
        showToast('更新失败', 'error');
    }
}

// AI服务商配置
const AI_PROVIDERS = {
    tongyi: {
        name: '通义千问',
        hint: '通义千问API密钥，可在阿里云控制台获取',
        models: [
            { value: 'qwen-turbo', label: 'qwen-turbo（快速）' },
            { value: 'qwen-plus', label: 'qwen-plus（均衡）' },
            { value: 'qwen-max', label: 'qwen-max（强大）' }
        ]
    },
    wenxin: {
        name: '文心一言',
        hint: '文心一言API Key，可在百度智能云获取',
        models: [
            { value: 'ernie-speed', label: 'ERNIE-Speed（快速）' },
            { value: 'ernie-4.0', label: 'ERNIE-4.0（强大）' },
            { value: 'ernie-3.5', label: 'ERNIE-3.5（均衡）' }
        ]
    },
    zhipu: {
        name: '智谱AI',
        hint: '智谱AI API Key，可在智谱开放平台获取',
        models: [
            { value: 'glm-4-flash', label: 'GLM-4-Flash（快速）' },
            { value: 'glm-4', label: 'GLM-4（强大）' },
            { value: 'glm-3-turbo', label: 'GLM-3-Turbo（均衡）' }
        ]
    },
    spark: {
        name: '讯飞星火',
        hint: '讯飞星火API Key，可在讯飞开放平台获取',
        models: [
            { value: 'spark-lite', label: 'Spark Lite（轻量）' },
            { value: 'spark-pro', label: 'Spark Pro（均衡）' },
            { value: 'spark-max', label: 'Spark Max（强大）' }
        ]
    },
    baichuan: {
        name: '百川智能',
        hint: '百川API Key，可在百川智能官网获取',
        models: [
            { value: 'baichuan2-turbo', label: 'Baichuan2-Turbo（快速）' },
            { value: 'baichuan2-53b', label: 'Baichuan2-53B（强大）' }
        ]
    },
    moonshot: {
        name: '月之暗面',
        hint: 'Kimi API Key，可在月之暗面开放平台获取',
        models: [
            { value: 'moonshot-v1-8k', label: 'Moonshot V1 8K' },
            { value: 'moonshot-v1-32k', label: 'Moonshot V1 32K' },
            { value: 'moonshot-v1-128k', label: 'Moonshot V1 128K' }
        ]
    },
    deepseek: {
        name: 'DeepSeek',
        hint: 'DeepSeek API Key，可在DeepSeek官网获取',
        models: [
            { value: 'deepseek-chat', label: 'DeepSeek Chat' },
            { value: 'deepseek-coder', label: 'DeepSeek Coder' }
        ]
    },
    custom: {
        name: '自定义API',
        hint: '请输入您的API Key和自定义API地址',
        models: [
            { value: 'custom', label: '自定义模型' }
        ]
    }
};

// 当前选中的主题
let currentTheme = localStorage.getItem('theme') || 'light';

// 检查AI配置
function hasAIConfig() {
    const aiApiKey = localStorage.getItem('aiApiKey') || '';
    return aiApiKey.trim() !== '';
}

// 显示AI配置提醒
function showAIConfigReminder() {
    openModal('aiConfigReminderModal');
}

function goToSettingsFromReminder() {
    // 关闭提醒弹窗并打开设置弹窗
    closeModal('aiConfigReminderModal');
    // 由于是堆叠式弹窗，需要延迟打开新弹窗
    setTimeout(() => {
        showSettingsModal();
    }, 100);
}

function showSettingsModal() {
    // 检查点击频率
    const clickCheck = ClickManager.checkClick('showSettingsModal');
    if (clickCheck.shouldWarn) {
        showToast('请稍候再试，不要重复点击哦~', 'warning');
        return;
    }
    
    // 加载已保存的设置
    loadSettings();
    openModal('settingsModal');
}

function loadSettings() {
    // 更新登录状态显示
    updateSettingsLoginState();

    // 加载主题设置
    const savedTheme = localStorage.getItem('theme') || 'light';
    selectTheme(savedTheme, false);

    // 加载用户信息显示
    const userNicknameEl = document.getElementById('userNickname');
    const userIdDisplayEl = document.getElementById('userIdDisplay');
    const settingsUserAvatarEl = document.getElementById('settingsUserAvatar');
    const settingsUserNameEl = document.getElementById('settingsUserName');

    if (currentUser) {
        if (userNicknameEl) {
            userNicknameEl.value = currentUser.nickname || '';
        }
        if (userIdDisplayEl) {
            userIdDisplayEl.textContent = currentUser.id;
        }
        if (settingsUserAvatarEl) {
            settingsUserAvatarEl.textContent = (currentUser.nickname || '用')[0];
        }
        if (settingsUserNameEl) {
            settingsUserNameEl.textContent = currentUser.nickname || '用户';
        }
    }

    // 加载AI使用额度
    loadAIUsage();

    // 加载AI设置
    const provider = localStorage.getItem('aiProvider') || 'tongyi';
    const apiKey = localStorage.getItem('aiApiKey') || '';
    const model = localStorage.getItem('aiModel') || 'qwen-turbo';
    const customUrl = localStorage.getItem('customApiUrl') || '';

    document.getElementById('aiProvider').value = provider;
    document.getElementById('aiApiKey').value = apiKey;
    document.getElementById('customApiUrl').value = customUrl;

    // 更新API Key状态显示
    updateAPIKeyStatus(apiKey);

    updateProviderConfig();

    // 设置模型
    setTimeout(() => {
        document.getElementById('aiModel').value = model;
    }, 0);
}

/**
 * 更新设置界面的登录状态
 */
function updateSettingsLoginState() {
    const loginEntrySection = document.getElementById('loginEntrySection');
    const userInfoSection = document.getElementById('userInfoSection');

    if (AuthManager.isLoggedIn()) {
        // 已登录状态
        if (loginEntrySection) {
            loginEntrySection.style.display = 'none';
        }
        if (userInfoSection) {
            userInfoSection.style.display = 'block';
        }
    } else {
        // 未登录状态（匿名用户）
        if (loginEntrySection) {
            loginEntrySection.style.display = 'block';
        }
        if (userInfoSection) {
            userInfoSection.style.display = 'none';
        }
    }
}

/**
 * 从设置界面打开登录模态框
 */
function showAuthModalFromSettings() {
    closeModal('settingsModal');
    setTimeout(() => {
        showLoginForm();
        openModal('authModal');
    }, 100);
}

/**
 * 从设置界面登出
 */
async function logoutFromSettings() {
    if (!confirm('确定要退出登录吗？退出后将继续使用匿名账户。')) {
        return;
    }

    try {
        const response = await API.post('/auth/logout');
        if (response.ok) {
            // 清除本地认证信息
            AuthManager.removeToken();

            // 清空当前用户
            currentUser = null;

            // 重新初始化应用
            await initApp();

            // 重新打开设置界面
            closeModal('settingsModal');
            setTimeout(() => {
                showSettingsModal();
            }, 100);

            showToast('已退出登录', 'success');
        } else {
            showToast('退出登录失败', 'error');
        }
    } catch (error) {
        console.error('退出登录失败:', error);
        showToast('退出登录失败', 'error');
    }
}

/**
 * 加载AI使用额度
 */
async function loadAIUsage() {
    try {
        const response = await API.get('/ai/usage');
        if (response.ok) {
            const result = await response.json();
            if (result.success) {
                updateAIUsageDisplay(result.usage);
            }
        }
    } catch (error) {
        console.error('加载AI使用额度失败:', error);
    }
}

/**
 * 更新AI使用额度显示
 */
function updateAIUsageDisplay(usage) {
    const countEl = document.getElementById('aiUsageCount');
    const barEl = document.getElementById('aiUsageBar');
    const hintEl = document.getElementById('aiUsageHint');
    
    if (!usage) return;
    
    // 如果有自定义Key，显示无限
    if (usage.has_custom_key) {
        if (countEl) countEl.textContent = '无限制';
        if (barEl) barEl.style.width = '100%';
        if (barEl) barEl.style.background = 'var(--accent-success)';
        if (hintEl) hintEl.textContent = '已配置个人API Key，可无限使用AI功能';
        return;
    }
    
    const used = usage.used || 0;
    const quota = usage.quota || 10;
    const remaining = usage.remaining || quota - used;
    const percentage = Math.min(100, (used / quota) * 100);
    
    if (countEl) countEl.textContent = `${used}/${quota} 次`;
    if (barEl) barEl.style.width = `${percentage}%`;
    
    // 根据使用量改变颜色
    if (percentage >= 80) {
        if (barEl) barEl.style.background = 'var(--accent-danger)';
    } else if (percentage >= 50) {
        if (barEl) barEl.style.background = 'var(--accent-warning)';
    } else {
        if (barEl) barEl.style.background = 'var(--accent-primary)';
    }
    
    if (remaining <= 0) {
        if (hintEl) {
            hintEl.innerHTML = '今日免费额度已用完，<a href="javascript:void(0)" onclick="showAPIKeyGuide()" style="color: var(--accent-primary);">配置个人API Key</a>继续使用';
        }
    } else {
        if (hintEl) hintEl.textContent = `剩余${remaining}次免费额度，配置个人API Key可无限使用`;
    }
}

/**
 * 更新API Key状态显示
 */
function updateAPIKeyStatus(apiKey) {
    const badgeEl = document.getElementById('apiKeyBadge');
    if (badgeEl) {
        if (apiKey) {
            badgeEl.textContent = '已配置';
            badgeEl.style.background = 'var(--accent-success)';
        } else {
            badgeEl.textContent = '使用本地存储';
            badgeEl.style.background = 'var(--accent-warning)';
        }
    }
}

/**
 * 显示API Key配置引导
 */
function showAPIKeyGuide() {
    showToast('请在设置中配置您的API Key', 'info');
    openModal('settingsModal');
    // 滚动到AI设置区域
    setTimeout(() => {
        const aiSettings = document.getElementById('aiProvider');
        if (aiSettings) {
            aiSettings.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
    }, 300);
}

// 复制用户ID
function copyUserId() {
    const userId = document.getElementById('userIdDisplay').textContent;
    navigator.clipboard.writeText(userId).then(() => {
        showToast('ID已复制', 'success');
    }).catch(() => {
        showToast('复制失败', 'error');
    });
}

function selectTheme(theme, save = true) {
    currentTheme = theme;
    
    // 更新UI选中状态
    document.querySelectorAll('.theme-option').forEach(opt => {
        opt.classList.remove('selected');
        if (opt.dataset.theme === theme) {
            opt.classList.add('selected');
        }
    });
    
    // 应用主题
    applyTheme(theme);
    
    // 保存设置
    if (save) {
        localStorage.setItem('theme', theme);
    }
}

function applyTheme(theme) {
    const root = document.documentElement;
    
    if (theme === 'system') {
        // 跟随系统
        const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        root.setAttribute('data-theme', prefersDark ? 'dark' : 'light');
    } else {
        root.setAttribute('data-theme', theme);
    }
}

function updateProviderConfig() {
    const provider = document.getElementById('aiProvider').value;
    const config = AI_PROVIDERS[provider];
    
    // 更新提示信息
    const hintEl = document.getElementById('apiHint');
    if (hintEl) {
        hintEl.textContent = config.hint;
    }
    
    // 更新模型选择
    const modelSelect = document.getElementById('aiModel');
    if (modelSelect) {
        modelSelect.innerHTML = config.models.map(m => 
            `<option value="${m.value}">${m.label}</option>`
        ).join('');
    }
    
    // 显示/隐藏自定义API地址
    const customUrlGroup = document.getElementById('customApiUrlGroup');
    if (customUrlGroup) {
        customUrlGroup.style.display = provider === 'custom' ? 'block' : 'none';
    }
}

async function saveSettings() {
    const provider = document.getElementById('aiProvider').value;
    const apiKey = document.getElementById('aiApiKey').value;
    const model = document.getElementById('aiModel').value;
    const customUrl = document.getElementById('customApiUrl').value;
    
    // 保存到localStorage
    localStorage.setItem('theme', currentTheme);
    localStorage.setItem('aiProvider', provider);
    localStorage.setItem('aiApiKey', apiKey);
    localStorage.setItem('aiModel', model);
    localStorage.setItem('customApiUrl', customUrl);
    
    // 保存用户昵称
    const nicknameInput = document.getElementById('userNickname');
    if (nicknameInput) {
        const nickname = nicknameInput.value.trim();
        try {
            const response = await API.put('/user/profile', { nickname });
            const result = await response.json();
            if (result.success) {
                currentUser = result.user;
                updateUserDisplay();
            }
        } catch (error) {
            console.error('保存昵称失败:', error);
        }
    }
    
    showToast('设置已保存', 'success');
    closeModal('settingsModal');
}

function initTheme() {
    const savedTheme = localStorage.getItem('theme') || 'light';
    applyTheme(savedTheme);
    currentTheme = savedTheme;
    
    // 监听系统主题变化
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
        if (localStorage.getItem('theme') === 'system') {
            applyTheme('system');
        }
    });
}

// ==================== 工具函数 ====================

function updateStats() {
    const total = allTasks.length;
    const completed = allTasks.filter(t => t.is_completed).length;
    const pending = total - completed;
    
    // 更新侧边栏计数 - 所有任务
    const allTaskCountEl = document.getElementById('allTaskCount');
    if (allTaskCountEl) {
        allTaskCountEl.textContent = pending;
        allTaskCountEl.style.display = pending > 0 ? 'inline-flex' : 'none';
    }
    
    // 今天任务计数
    const today = new Date().toDateString();
    const todayCount = allTasks.filter(t => {
        if (!t.start_time) return false;
        return new Date(t.start_time).toDateString() === today && !t.is_completed;
    }).length;
    
    const todayTaskCountEl = document.getElementById('todayTaskCount');
    if (todayTaskCountEl) {
        todayTaskCountEl.textContent = todayCount;
        todayTaskCountEl.style.display = todayCount > 0 ? 'inline-flex' : 'none';
    }
    
    // 更新移动端底部导航徽章
    updateMobileNavBadges();
}

function updateNavBadges() {
    // 更新各视图的任务数量
}

function openModal(modalId) {
    console.log('openModal called:', modalId);
    ClickManager.openModal(modalId);
}

function closeModal(modalId) {
    ClickManager.closeModal(modalId);
}

function closeAllModals() {
    ClickManager.closeAllModals();
}

/**
 * 显示全局加载状态
 * @param {string} message - 加载提示文字
 */
function showLoading(message = '加载中...') {
    // 检查是否已存在loading遮罩
    let loadingOverlay = document.getElementById('globalLoadingOverlay');
    
    if (!loadingOverlay) {
        loadingOverlay = document.createElement('div');
        loadingOverlay.id = 'globalLoadingOverlay';
        loadingOverlay.className = 'loading-overlay';
        loadingOverlay.innerHTML = `
            <div class="loading-content">
                <div class="loading-spinner"></div>
                <div class="loading-text">${message}</div>
            </div>
        `;
        document.body.appendChild(loadingOverlay);
    } else {
        // 更新提示文字
        const textEl = loadingOverlay.querySelector('.loading-text');
        if (textEl) textEl.textContent = message;
        loadingOverlay.style.display = 'flex';
    }
}

/**
 * 隐藏全局加载状态
 */
function hideLoading() {
    const loadingOverlay = document.getElementById('globalLoadingOverlay');
    if (loadingOverlay) {
        loadingOverlay.style.display = 'none';
    }
}

function showToast(message, type = 'success') {
    const container = document.getElementById('toastContainer');
    
    // 防重复机制：检查是否已有相同消息的toast正在显示
    const existingToasts = container.querySelectorAll('.toast span');
    for (const span of existingToasts) {
        if (span.textContent === message) {
            // 已存在相同消息，不再重复添加
            return;
        }
    }
    
    // 限制最多显示3条toast
    const currentToasts = container.querySelectorAll('.toast');
    if (currentToasts.length >= 3) {
        // 移除最旧的toast
        currentToasts[0].remove();
    }
    
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    
    // 根据类型选择图标
    let icon = 'check-circle';
    if (type === 'error') icon = 'exclamation-circle';
    else if (type === 'warning') icon = 'exclamation-triangle';
    else if (type === 'info') icon = 'info-circle';
    
    toast.innerHTML = `
        <i class="fas fa-${icon}"></i>
        <span>${message}</span>
    `;
    
    container.appendChild(toast);
    
    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(100%)';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// 点击模态框外部关闭
document.querySelectorAll('.modal-overlay').forEach(overlay => {
    overlay.addEventListener('click', (e) => {
        if (e.target === overlay) {
            overlay.classList.remove('active');
        }
    });
});

// ==================== 推送通知管理 ====================

/**
 * 推送通知管理模块
 */
const PushNotificationManager = {
    _registration: null,
    _isSubscribed: false,
    
    /**
     * 初始化推送通知
     */
    async init() {
        // 检查浏览器是否支持推送
        if (!('serviceWorker' in navigator)) {
            console.log('浏览器不支持 Service Worker');
            return false;
        }
        
        if (!('PushManager' in window)) {
            console.log('浏览器不支持推送通知');
            return false;
        }
        
        try {
            // 注册 Service Worker
            this._registration = await this.registerServiceWorker();
            if (!this._registration) {
                console.log('Service Worker 注册失败');
                return false;
            }
            
            // 请求通知权限
            const permission = await Notification.requestPermission();
            if (permission !== 'granted') {
                console.log('用户拒绝了通知权限');
                return false;
            }
            
            console.log('推送通知已启用');
            
            // 监听 Service Worker 消息
            navigator.serviceWorker.addEventListener('message', this.handleMessage.bind(this));
            
            return true;
        } catch (error) {
            console.error('初始化推送通知失败:', error);
            return false;
        }
    },
    
    /**
     * 注册 Service Worker
     */
    async registerServiceWorker() {
        try {
            const registration = await navigator.serviceWorker.register('sw.js', {
                scope: './'
            });
            console.log('Service Worker 注册成功:', registration.scope);
            
            // 等待 Service Worker 激活
            if (registration.installing) {
                await new Promise(resolve => {
                    registration.installing.addEventListener('statechange', e => {
                        if (e.target.state === 'activated') {
                            resolve();
                        }
                    });
                });
            }
            
            return registration;
        } catch (error) {
            console.error('Service Worker 注册失败:', error);
            return null;
        }
    },
    
    /**
     * 处理 Service Worker 消息
     */
    handleMessage(event) {
        console.log('收到 Service Worker 消息:', event.data);
        
        if (event.data && event.data.type === 'TASK_COMPLETED') {
            // 刷新任务列表
            if (typeof loadTasks === 'function') {
                loadTasks();
            }
            showToast('任务已标记完成', 'success');
        }
    },
    
    /**
     * 订阅推送通知
     */
    async subscribe() {
        // 如果 Service Worker 未注册，先尝试初始化
        if (!this._registration) {
            console.log('Service Worker 未注册，尝试初始化...');
            const initialized = await this.init();
            if (!initialized || !this._registration) {
                console.log('Service Worker 初始化失败');
                return null;
            }
        }
        
        try {
            // 获取现有订阅
            let subscription = await this._registration.pushManager.getSubscription();
            
            if (!subscription) {
                // 尝试使用 VAPID 公钥创建订阅
                // 注意：需要从服务器获取 VAPID 公钥
                const vapidPublicKey = await this.getVapidPublicKey();
                
                if (vapidPublicKey) {
                    subscription = await this._registration.pushManager.subscribe({
                        userVisibleOnly: true,
                        applicationServerKey: this.urlBase64ToUint8Array(vapidPublicKey)
                    });
                } else {
                    console.log('服务器未配置 VAPID 公钥，使用本地通知模式');
                    this._isSubscribed = true;
                    return { local: true };
                }
            }
            
            if (subscription) {
                // 发送订阅信息到服务器
                const response = await API.post('/push/subscribe', { 
                    subscription: subscription.toJSON() 
                });
                
                if (response.ok) {
                    this._isSubscribed = true;
                    console.log('推送订阅成功');
                    return subscription;
                }
            }
            
            return null;
        } catch (error) {
            console.error('推送订阅失败:', error);
            return null;
        }
    },
    
    /**
     * 取消订阅
     */
    async unsubscribe() {
        try {
            if (this._registration) {
                const subscription = await this._registration.pushManager.getSubscription();
                if (subscription) {
                    await subscription.unsubscribe();
                }
            }
            
            await API.post('/push/unsubscribe', {});
            this._isSubscribed = false;
            console.log('已取消推送订阅');
            return true;
        } catch (error) {
            console.error('取消订阅失败:', error);
            return false;
        }
    },
    
    /**
     * 获取推送状态
     */
    async getPushStatus() {
        try {
            const response = await API.get('/push/status');
            const data = await response.json();
            return data.push_enabled || false;
        } catch (error) {
            return false;
        }
    },
    
    /**
     * 获取 VAPID 公钥
     */
    async getVapidPublicKey() {
        try {
            // 优先使用新接口
            const response = await API.get('/config/vapid-public-key');
            const data = await response.json();
            
            if (data.success && data.public_key) {
                console.log('已获取 VAPID 公钥');
                return data.public_key;
            }
            
            // 兼容旧接口
            const fallbackResponse = await API.get('/push/vapid-key');
            const fallbackData = await fallbackResponse.json();
            return fallbackData.public_key || null;
        } catch (error) {
            console.error('获取 VAPID 公钥失败:', error);
            return null;
        }
    },
    
    /**
     * 显示本地通知（不需要推送服务）
     */
    async showLocalNotification(title, options = {}) {
        // 检查权限
        if (Notification.permission !== 'granted') {
            const permission = await Notification.requestPermission();
            if (permission !== 'granted') {
                console.log('通知权限未授予');
                return false;
            }
        }
        
        // 如果 Service Worker 可用，使用它显示通知
        if (this._registration) {
            await this._registration.showNotification(title, {
                body: options.body || '',
                icon: options.icon || '/static/icon.png',
                badge: options.badge || '/static/badge.png',
                tag: options.tag || 'local-notification',
                requireInteraction: options.requireInteraction !== false,
                data: options.data || {},
                actions: options.actions || []
            });
        } else {
            // 直接使用 Notification API
            new Notification(title, {
                body: options.body || '',
                icon: options.icon || '/static/icon.png',
                tag: options.tag || 'local-notification'
            });
        }
        
        return true;
    },
    
    /**
     * Base64 URL 转换为 Uint8Array
     */
    urlBase64ToUint8Array(base64String) {
        const padding = '='.repeat((4 - base64String.length % 4) % 4);
        const base64 = (base64String + padding)
            .replace(/\-/g, '+')
            .replace(/_/g, '/');
        
        const rawData = window.atob(base64);
        const outputArray = new Uint8Array(rawData.length);
        
        for (let i = 0; i < rawData.length; ++i) {
            outputArray[i] = rawData.charCodeAt(i);
        }
        return outputArray;
    },
    
    /**
     * 检查是否已订阅
     */
    isSubscribed() {
        return this._isSubscribed;
    }
};

// ==================== 每周报告管理 ====================

/**
 * 每周报告管理模块
 */
const WeeklyReportManager = {
    async loadReport() {
        try {
            const response = await API.get('/analysis/weekly-report');
            const data = await response.json();
            
            if (data.success) {
                return data.report;
            }
            return null;
        } catch (error) {
            console.error('加载每周报告失败:', error);
            return null;
        }
    },
    
    async loadMonthlyReport() {
        try {
            const response = await API.get('/analysis/monthly-report');
            const data = await response.json();
            
            if (data.success) {
                return data.report;
            }
            return null;
        } catch (error) {
            console.error('加载月报失败:', error);
            return null;
        }
    },
    
    async loadLearningInsights() {
        try {
            const response = await API.get('/analysis/learning-insights');
            const data = await response.json();
            
            if (data.success) {
                return data.insights;
            }
            return null;
        } catch (error) {
            console.error('加载学习洞察失败:', error);
            return null;
        }
    },
    
    renderReport(report) {
        // 更新报告卡片数据
        const completedEl = document.getElementById('report-completed');
        const durationEl = document.getElementById('report-duration');
        const rateEl = document.getElementById('report-rate');
        
        if (completedEl) completedEl.textContent = report.total_tasks || 0;
        if (durationEl) durationEl.textContent = report.total_duration || 0;
        if (rateEl && report.efficiency_trend && report.efficiency_trend.length > 0) {
            rateEl.textContent = report.efficiency_trend[0].rate + '%';
        }
        
        // 显示AI建议
        const suggestionsEl = document.getElementById('report-suggestions');
        if (suggestionsEl && report.ai_suggestions) {
            suggestionsEl.innerHTML = `
                <h4><i class="fas fa-lightbulb"></i> 个性化建议</h4>
                <div class="suggestion-content" style="white-space: pre-line;">${report.ai_suggestions}</div>
            `;
        }
    },
    
    renderCategoryChart(categoryStats) {
        const ctx = document.getElementById('report-category-chart');
        if (!ctx) return;
        
        // 检查 Chart.js 是否可用
        if (typeof Chart === 'undefined') {
            console.error('Chart.js 未加载，无法渲染图表');
            ctx.parentElement.innerHTML = '<p style="text-align:center;color:var(--text-secondary);padding:20px;">图表加载失败，请刷新页面重试</p>';
            return;
        }

        const labels = Object.keys(categoryStats);
        const data = labels.map(cat => categoryStats[cat].count);

        // 安全销毁旧图表实例
        if (window.reportCategoryChart && typeof window.reportCategoryChart.destroy === 'function') {
            try {
                window.reportCategoryChart.destroy();
            } catch (e) {
                console.warn('销毁旧图表失败:', e);
            }
        }
        window.reportCategoryChart = null;

        window.reportCategoryChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: labels,
                datasets: [{
                    data: data,
                    backgroundColor: [
                        '#4CAF50', '#2196F3', '#FF9800', '#F44336', 
                        '#9C27B0', '#00BCD4', '#795548', '#607D8B'
                    ]
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    },
    
    renderTrendChart(trendData) {
        const ctx = document.getElementById('report-trend-chart');
        if (!ctx) return;
        
        // 检查 Chart.js 是否可用
        if (typeof Chart === 'undefined') {
            console.error('Chart.js 未加载，无法渲染图表');
            ctx.parentElement.innerHTML = '<p style="text-align:center;color:var(--text-secondary);padding:20px;">图表加载失败，请刷新页面重试</p>';
            return;
        }

        const labels = trendData.map(t => t.week);
        const completedData = trendData.map(t => t.total);
        const rateData = trendData.map(t => t.rate);

        // 安全销毁旧图表实例
        if (window.reportTrendChart && typeof window.reportTrendChart.destroy === 'function') {
            try {
                window.reportTrendChart.destroy();
            } catch (e) {
                console.warn('销毁旧图表失败:', e);
            }
        }
        window.reportTrendChart = null;
        
        window.reportTrendChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [
                    {
                        label: '完成任务',
                        data: completedData,
                        borderColor: '#4CAF50',
                        backgroundColor: '#4CAF5020',
                        yAxisID: 'y'
                    },
                    {
                        label: '按时完成率(%)',
                        data: rateData,
                        borderColor: '#FF9800',
                        backgroundColor: '#FF980020',
                        yAxisID: 'y1'
                    }
                ]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true,
                        title: { display: true, text: '任务数' }
                    },
                    y1: {
                        beginAtZero: true,
                        position: 'right',
                        max: 100,
                        title: { display: true, text: '完成率(%)' }
                    }
                }
            }
        });
    }
};

// ==================== 智能提醒管理 ====================

/**
 * 智能提醒管理模块
 */
const SmartReminderManager = {
    async getSmartReminders() {
        try {
            const response = await API.get('/reminders/smart');
            const data = await response.json();
            
            if (data.success) {
                return data.reminders;
            }
            return [];
        } catch (error) {
            console.error('获取智能提醒失败:', error);
            return [];
        }
    },
    
    renderSmartReminders(reminders) {
        const container = document.getElementById('smart-reminders-list');
        if (!container) return;
        
        if (!reminders || reminders.length === 0) {
            container.innerHTML = '<div class="empty-state">暂无紧急提醒</div>';
            return;
        }
        
        container.innerHTML = reminders.map(r => `
            <div class="reminder-item urgency-${r.urgency}">
                <div class="reminder-icon">
                    <i class="fas fa-${r.urgency === 'critical' ? 'exclamation-triangle' : r.urgency === 'high' ? 'clock' : 'bell'}"></i>
                </div>
                <div class="reminder-content">
                    <div class="reminder-title">${r.task_title}</div>
                    <div class="reminder-meta">
                        <span class="reminder-category">${r.category}</span>
                        <span class="reminder-time">${this.formatTimeLeft(r.time_left_minutes)}</span>
                    </div>
                </div>
                <div class="reminder-priority priority-${r.priority}">P${r.priority}</div>
            </div>
        `).join('');
    },
    
    formatTimeLeft(minutes) {
        if (minutes <= 0) return '已过期';
        if (minutes < 60) return `${minutes}分钟后`;
        const hours = Math.floor(minutes / 60);
        const mins = minutes % 60;
        if (hours < 24) return `${hours}小时${mins > 0 ? mins + '分钟' : ''}后`;
        const days = Math.floor(hours / 24);
        return `${days}天后`;
    },
    
    /**
     * 更新提醒徽章
     */
    updateBadge(count) {
        const badge = document.getElementById('smartReminderBadge');
        if (badge) {
            if (count > 0) {
                badge.textContent = count > 99 ? '99+' : count;
                badge.style.display = 'inline-flex';
            } else {
                badge.style.display = 'none';
            }
        }
    }
};

/**
 * 显示智能提醒模态框
 */
async function showSmartReminderModal() {
    openModal('smartReminderModal');
    await loadSmartReminders();
}

/**
 * 加载智能提醒数据
 */
async function loadSmartReminders() {
    const container = document.getElementById('smart-reminders-list');
    if (container) {
        container.innerHTML = '<div class="loading-state">加载中...</div>';
    }
    
    const reminders = await SmartReminderManager.getSmartReminders();
    SmartReminderManager.renderSmartReminders(reminders);
    
    // 更新统计
    updateReminderStats(reminders);
    
    // 更新徽章
    const urgentCount = reminders ? reminders.filter(r => r.urgency === 'high' || r.urgency === 'critical').length : 0;
    SmartReminderManager.updateBadge(urgentCount);
}

/**
 * 刷新智能提醒
 */
async function refreshSmartReminders() {
    const btn = document.querySelector('.smart-reminders-section .btn-text');
    if (btn) {
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 刷新中...';
        btn.disabled = true;
    }
    
    await loadSmartReminders();
    
    if (btn) {
        btn.innerHTML = '<i class="fas fa-sync-alt"></i> 刷新';
        btn.disabled = false;
    }
    showToast('提醒列表已刷新', 'success');
}

/**
 * 更新提醒统计
 */
function updateReminderStats(reminders) {
    if (!reminders) {
        document.getElementById('reminderTotal').textContent = '0';
        document.getElementById('reminderUrgent').textContent = '0';
        document.getElementById('reminderOverdue').textContent = '0';
        document.getElementById('reminderToday').textContent = '0';
        return;
    }
    
    const total = reminders.length;
    const urgent = reminders.filter(r => r.urgency === 'high' || r.urgency === 'critical').length;
    const overdue = reminders.filter(r => r.status === 'overdue').length;
    const today = reminders.filter(r => r.time_left_minutes > 0 && r.time_left_minutes <= 24 * 60).length;
    
    document.getElementById('reminderTotal').textContent = total;
    document.getElementById('reminderUrgent').textContent = urgent;
    document.getElementById('reminderOverdue').textContent = overdue;
    document.getElementById('reminderToday').textContent = today;
}

/**
 * 切换推送通知
 */
async function togglePushNotification() {
    const toggle = document.getElementById('pushNotificationToggle');
    if (!toggle) return;
    
    try {
        if (toggle.checked) {
            const result = await PushNotificationManager.subscribe();
            if (result) {
                showToast('推送通知已启用', 'success');
            } else {
                toggle.checked = false;
                showToast('启用推送通知失败', 'error');
            }
        } else {
            await PushNotificationManager.unsubscribe();
            showToast('推送通知已关闭', 'success');
        }
    } catch (error) {
        console.error('切换推送通知失败:', error);
        toggle.checked = !toggle.checked;
        showToast('操作失败，请重试', 'error');
    }
}

/**
 * 测试推送通知
 */
async function testPushNotification() {
    try {
        const result = await PushNotificationManager.showLocalNotification(
            '测试通知',
            {
                body: '这是一条测试推送通知，如果您看到此消息，说明推送功能正常工作！',
                icon: '/icon-192x192.png',
                tag: 'test-notification'
            }
        );
        
        if (result) {
            showToast('测试通知已发送', 'success');
        } else {
            showToast('请先启用推送通知', 'warning');
        }
    } catch (error) {
        console.error('发送测试通知失败:', error);
        showToast('发送失败，请检查浏览器权限设置', 'error');
    }
}

// ==================== 登录/注册UI管理 ====================

/**
 * 显示登录表单
 */
function showLoginForm() {
    // 隐藏所有表单
    document.getElementById('loginForm').style.display = 'block';
    document.getElementById('registerForm').style.display = 'none';
    document.getElementById('forgotPasswordForm').style.display = 'none';
    document.getElementById('resetPasswordForm').style.display = 'none';

    // 更新标题
    document.getElementById('authModalTitle').textContent = '登录';

    // 清空忘记密码表单的输入（避免残留）
    const forgotInput = document.getElementById('forgotPasswordUsername');
    if (forgotInput) {
        forgotInput.value = '';
    }

    // 自动聚焦到用户名输入框
    setTimeout(() => {
        const usernameInput = document.getElementById('loginUsername');
        if (usernameInput) {
            usernameInput.focus();
        }
    }, 100);
}

/**
 * 显示注册表单
 */
function showRegisterForm() {
    // 隐藏所有表单
    document.getElementById('loginForm').style.display = 'none';
    document.getElementById('registerForm').style.display = 'block';
    document.getElementById('forgotPasswordForm').style.display = 'none';
    document.getElementById('resetPasswordForm').style.display = 'none';

    // 更新标题
    document.getElementById('authModalTitle').textContent = '注册';

    // 自动聚焦到用户名输入框
    setTimeout(() => {
        const usernameInput = document.getElementById('registerUsername');
        if (usernameInput) {
            usernameInput.focus();
        }
    }, 100);
}

/**
 * 处理登录
 */
async function handleLogin() {
    const username = document.getElementById('loginUsername').value.trim();
    const password = document.getElementById('loginPassword').value;
    
    if (!username) {
        showToast('请输入用户名', 'error');
        return;
    }
    if (!password) {
        showToast('请输入密码', 'error');
        return;
    }
    
    try {
        showToast('登录中...', 'info');
        const result = await AuthManager.login(username, password);
        
        if (result.success) {
            showToast('登录成功', 'success');
            closeModal('authModal');
            currentUser = result.user;
            await initApp();
        } else {
            showToast(result.message || '登录失败', 'error');
        }
    } catch (error) {
        showToast('登录失败，请检查网络', 'error');
    }
}

/**
 * 处理注册
 */
async function handleRegister() {
    const username = document.getElementById('registerUsername').value.trim();
    const password = document.getElementById('registerPassword').value;
    const passwordConfirm = document.getElementById('registerPasswordConfirm').value;
    const nickname = document.getElementById('registerNickname').value.trim();
    const email = document.getElementById('registerEmail').value.trim();
    
    // 验证
    if (!username || username.length < 3) {
        showToast('用户名至少3个字符', 'error');
        return;
    }
    if (!password || password.length < 6) {
        showToast('密码至少6个字符', 'error');
        return;
    }
    if (password !== passwordConfirm) {
        showToast('两次密码不一致', 'error');
        return;
    }
    
    try {
        showToast('注册中...', 'info');
        const result = await AuthManager.register(username, password, email || null, nickname || null);
        
        if (result.success) {
            showToast('注册成功', 'success');
            closeModal('authModal');
            currentUser = result.user;
            await initApp();
        } else {
            showToast(result.message || '注册失败', 'error');
        }
    } catch (error) {
        showToast('注册失败，请检查网络', 'error');
    }
}

/**
 * 游客模式继续
 */
function continueAsGuest() {
    closeModal('authModal');
    initApp();
}

/**
 * 显示忘记密码表单
 */
function showForgotPasswordForm() {
    // 隐藏所有表单
    document.getElementById('loginForm').style.display = 'none';
    document.getElementById('registerForm').style.display = 'none';
    document.getElementById('forgotPasswordForm').style.display = 'block';
    document.getElementById('resetPasswordForm').style.display = 'none';

    // 更新标题
    document.getElementById('authModalTitle').textContent = '找回密码';

    // 清空输入框
    const forgotInput = document.getElementById('forgotPasswordUsername');
    if (forgotInput) {
        forgotInput.value = '';
    }

    // 自动聚焦到输入框
    setTimeout(() => {
        if (forgotInput) {
            forgotInput.focus();
        }
    }, 100);
}

/**
 * 显示重置密码表单
 */
function showResetPasswordForm(token) {
    // 隐藏所有表单
    document.getElementById('loginForm').style.display = 'none';
    document.getElementById('registerForm').style.display = 'none';
    document.getElementById('forgotPasswordForm').style.display = 'none';
    document.getElementById('resetPasswordForm').style.display = 'block';

    // 更新标题
    document.getElementById('authModalTitle').textContent = '重置密码';

    // 设置token
    document.getElementById('resetPasswordToken').value = token;

    // 清空密码输入框
    const newPassInput = document.getElementById('newPassword');
    const confirmPassInput = document.getElementById('newPasswordConfirm');
    if (newPassInput) newPassInput.value = '';
    if (confirmPassInput) confirmPassInput.value = '';

    // 自动聚焦到新密码输入框
    setTimeout(() => {
        if (newPassInput) {
            newPassInput.focus();
        }
    }, 100);
}

/**
 * 处理忘记密码
 */
async function handleForgotPassword() {
    const usernameOrEmail = document.getElementById('forgotPasswordUsername').value.trim();
    
    if (!usernameOrEmail) {
        showToast('请输入用户名或邮箱', 'error');
        return;
    }
    
    try {
        showToast('正在处理...', 'info');
        const response = await fetch('/api/auth/forgot-password', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username_or_email: usernameOrEmail })
        });
        
        const result = await response.json();
        
        if (result.success) {
            if (result.reset_token) {
                // 开发环境：直接显示重置密码表单
                showToast('验证成功，请设置新密码', 'success');
                showResetPasswordForm(result.reset_token);
            } else {
                showToast('重置链接已发送到您的邮箱', 'success');
            }
        } else {
            showToast(result.message || '操作失败', 'error');
        }
    } catch (error) {
        showToast('操作失败，请检查网络', 'error');
    }
}

/**
 * 处理重置密码
 */
async function handleResetPassword() {
    const token = document.getElementById('resetPasswordToken').value;
    const newPassword = document.getElementById('newPassword').value;
    const newPasswordConfirm = document.getElementById('newPasswordConfirm').value;
    
    if (!newPassword || newPassword.length < 6) {
        showToast('密码至少6个字符', 'error');
        return;
    }
    if (newPassword !== newPasswordConfirm) {
        showToast('两次密码不一致', 'error');
        return;
    }
    
    try {
        showToast('正在重置...', 'info');
        const response = await fetch('/api/auth/reset-password', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ token, new_password: newPassword })
        });
        
        const result = await response.json();
        
        if (result.success) {
            showToast('密码重置成功，请登录', 'success');
            showLoginForm();
            // 清空表单
            document.getElementById('newPassword').value = '';
            document.getElementById('newPasswordConfirm').value = '';
        } else {
            showToast(result.message || '重置失败', 'error');
        }
    } catch (error) {
        showToast('重置失败，请检查网络', 'error');
    }
}

/**
 * 用户登出
 */
function handleLogout() {
    if (confirm('确定要退出登录吗？')) {
        AuthManager.logout();
    }
}

/**
 * 初始化应用
 */
async function initApp() {
    // 加载用户信息
    await loadUserInfo();
    
    // 加载任务
    await loadTasks();
    
    // 加载标签
    await loadTags();
    
    // 加载分类
    await loadCategories();
    
    // 初始化推送通知（如果用户已登录）
    if (AuthManager.isLoggedIn()) {
        await PushNotificationManager.init();
    }
    
    // 更新用户显示
    updateUserDisplay();
    
    // 更新设置界面用户信息
    updateSettingsUserInfo();
}

/**
 * 加载用户信息
 */
async function loadUserInfo() {
    // 优先使用已登录用户
    const loggedUser = AuthManager.getCurrentUser();
    if (loggedUser) {
        currentUser = loggedUser;
        return;
    }
    
    // 如果是游客模式（未登录），不调用 /user/profile 接口
    // 因为该接口需要认证，会导致 401 错误
    const token = AuthManager.getToken();
    const userId = UserManager.getUserId();
    
    // 只有有 token 或有效的 user_id 时才调用
    if (!token && !userId) {
        console.log('游客模式，跳过加载用户信息');
        return;
    }
    
    try {
        const response = await API.get('/user/profile');
        if (response.ok) {
            const result = await response.json();
            if (result.success) {
                currentUser = result.user;
            }
        } else if (response.status === 401) {
            console.log('未登录，跳过加载用户信息');
        }
    } catch (error) {
        console.error('加载用户信息失败:', error);
    }
}

/**
 * 更新设置界面用户信息
 */
function updateSettingsUserInfo() {
    if (!currentUser) return;
    
    const avatarEl = document.getElementById('settingsUserAvatar');
    const nameEl = document.getElementById('settingsUserName');
    const idEl = document.getElementById('userIdDisplay');
    const nicknameInput = document.getElementById('userNickname');
    
    if (avatarEl) {
        avatarEl.textContent = (currentUser.nickname || currentUser.username || '用')[0];
    }
    if (nameEl) {
        nameEl.textContent = currentUser.nickname || currentUser.username || '用户';
    }
    if (idEl) {
        idEl.textContent = currentUser.id;
    }
    if (nicknameInput) {
        nicknameInput.value = currentUser.nickname || '';
    }
}

// ==================== 应用初始化 ====================

// 初始化时自动请求通知权限
document.addEventListener('DOMContentLoaded', async () => {
    // 检查登录状态
    const isLoggedIn = AuthManager.isLoggedIn();
    
    if (isLoggedIn) {
        // 已登录，直接初始化应用
        await initApp();
        // 页面加载完成后恢复AI分析缓存
        loadCachedAnalysis();
    } else {
        // 未登录，显示登录界面
        // 先加载基础数据（使用匿名用户ID）
        await UserManager.getUserIdAsync();
        
        // 显示登录模态框
        setTimeout(() => {
            openModal('authModal');
        }, 500);
        
        // 同时初始化应用（游客模式）
        await initApp();
        // 页面加载完成后恢复AI分析缓存
        loadCachedAnalysis();
    }
    
    // 学习计划弹窗点击背景关闭
    const studyPlanModal = document.getElementById('studyPlanModal');
    if (studyPlanModal) {
        studyPlanModal.addEventListener('click', (e) => {
            if (e.target === studyPlanModal) {
                closeStudyPlanModal();
            }
        });
    }
});

// ==================== 学习计划功能 ====================

/**
 * 显示学习计划弹窗
 */
function showStudyPlanModal() {
    const modal = document.getElementById('studyPlanModal');
    if (modal) {
        openModal('studyPlanModal');
        // 加载用户个性化设置
        loadPersonalizedSettings();
    }
}

/**
 * 关闭学习计划弹窗
 */
function closeStudyPlanModal() {
    closeModal('studyPlanModal');
}

/**
 * 加载用户个性化设置
 */
async function loadPersonalizedSettings() {
    try {
        const response = await API.get('/user/behavior/settings');
        const result = await response.json();
        
        if (result.success && result.settings) {
            const settings = result.settings;
            
            // 填充配置项
            const pomodoroInput = document.getElementById('pomodoroMinutes');
            const breakInput = document.getElementById('breakMinutes');
            
            if (pomodoroInput && settings.pomodoro_minutes) {
                pomodoroInput.value = settings.pomodoro_minutes;
            }
            if (breakInput && settings.break_minutes) {
                breakInput.value = settings.break_minutes;
            }
            
            // 如果有个性化数据，默认开启个性化
            const usePersonalized = document.getElementById('usePersonalized');
            if (usePersonalized) {
                usePersonalized.checked = settings.is_personalized || false;
            }
        }
    } catch (error) {
        console.error('加载个性化设置失败:', error);
    }
}

/**
 * 生成学习计划
 */
async function generateStudyPlan() {
    const availableHours = parseInt(document.getElementById('availableHours').value) || 8;
    const usePersonalized = document.getElementById('usePersonalized').checked;
    const pomodoroMinutes = parseInt(document.getElementById('pomodoroMinutes').value) || 25;
    const breakMinutes = parseInt(document.getElementById('breakMinutes').value) || 5;
    
    // 显示加载状态
    showToast('正在生成学习计划...', 'info');
    
    try {
        const response = await API.post('/ai/study-plan', {
            available_hours: availableHours,
            use_personalized: usePersonalized,
            preferences: {
                pomodoro_minutes: pomodoroMinutes,
                break_minutes: breakMinutes,
                long_break_minutes: 15,
                pomodoros_before_long_break: 4
            }
        });
        
        const result = await response.json();
        
        if (result.success) {
            renderStudyPlan(result);
            showToast('学习计划生成成功', 'success');
        } else {
            showToast(result.message || '生成计划失败', 'error');
        }
    } catch (error) {
        console.error('生成学习计划失败:', error);
        showToast('生成计划失败，请重试', 'error');
    }
}

/**
 * 渲染学习计划
 */
function renderStudyPlan(data) {
    const { plan, stats, ai_recommendations, personalized_settings } = data;
    
    // 显示结果区域
    const planResult = document.getElementById('planResult');
    if (planResult) {
        planResult.style.display = 'block';
    }
    
    // 渲染统计信息
    renderPlanStats(stats, personalized_settings);
    
    // 渲染时间线
    renderPlanTimeline(plan);
    
    // 渲染AI建议
    renderAIRecommendations(ai_recommendations);
}

/**
 * 渲染计划统计
 */
function renderPlanStats(stats, personalizedSettings) {
    const container = document.getElementById('planStats');
    if (!container) return;
    
    const isPersonalized = stats.is_personalized;
    const personalizedBadge = isPersonalized ? 
        '<span class="badge badge-primary"><i class="fas fa-user-check"></i> 个性化推荐</span>' : 
        '<span class="badge badge-secondary">标准排序</span>';
    
    container.innerHTML = `
        <div class="stats-grid">
            <div class="stat-item">
                <span class="stat-value">${stats.total_tasks}</span>
                <span class="stat-label">待办任务</span>
            </div>
            <div class="stat-item">
                <span class="stat-value">${stats.scheduled_tasks}</span>
                <span class="stat-label">已安排</span>
            </div>
            <div class="stat-item">
                <span class="stat-value">${Math.round(stats.scheduled_minutes / 60 * 10) / 10}h</span>
                <span class="stat-label">学习时长</span>
            </div>
            <div class="stat-item">
                <span class="stat-value">${stats.utilization_rate}%</span>
                <span class="stat-label">时间利用率</span>
            </div>
        </div>
        <div class="personalized-badge">
            ${personalizedBadge}
            ${isPersonalized && personalizedSettings ? `
                <span class="peak-hours">
                    <i class="fas fa-clock"></i> 
                    最佳时段: ${personalizedSettings.peak_hours?.join(', ')}点
                </span>
            ` : ''}
        </div>
    `;
}

/**
 * 渲染计划时间线
 */
function renderPlanTimeline(plan) {
    const container = document.getElementById('planTimeline');
    if (!container) return;
    
    const timeSlots = plan.time_slots || [];
    const pomodoroSettings = plan.pomodoro_settings || {};
    
    let timelineHTML = '<div class="timeline">';
    
    timeSlots.forEach((slot, index) => {
        const isPeakHour = slot.in_peak_hour ? 'peak-hour' : '';
        const categoryIcon = getCategoryIcon(slot.category);
        
        timelineHTML += `
            <div class="timeline-item ${isPeakHour}">
                <div class="timeline-marker">
                    <span class="time">${slot.start_time}</span>
                    <span class="duration">${slot.duration_minutes}分钟</span>
                </div>
                <div class="timeline-content">
                    <div class="task-title">
                        <i class="${categoryIcon}"></i>
                        ${XSSProtection.escapeHtml(slot.title)}
                    </div>
                    <div class="task-meta">
                        <span><i class="fas fa-hourglass-half"></i> ${slot.duration_minutes}分钟</span>
                        <span><i class="fas fa-coffee"></i> 休息${slot.break_minutes}分钟</span>
                        ${slot.in_peak_hour ? '<span class="peak-badge"><i class="fas fa-star"></i> 最佳时段</span>' : ''}
                    </div>
                </div>
            </div>
        `;
    });
    
    timelineHTML += '</div>';
    
    // 添加番茄钟设置说明
    timelineHTML += `
        <div class="pomodoro-info">
            <i class="fas fa-info-circle"></i>
            番茄钟设置: ${pomodoroSettings.work_minutes || 25}分钟专注 + ${pomodoroSettings.break_minutes || 5}分钟休息
        </div>
    `;
    
    container.innerHTML = timelineHTML;
}

/**
 * 渲染AI建议
 */
function renderAIRecommendations(recommendations) {
    const container = document.getElementById('planRecommendations');
    if (!container) return;
    
    if (!recommendations || !recommendations.suggestions) {
        container.innerHTML = '';
        return;
    }
    
    container.innerHTML = `
        <div class="ai-recommendations">
            <h4><i class="fas fa-robot"></i> AI学习建议</h4>
            <div class="recommendation-content">
                ${XSSProtection.escapeHtml(recommendations.suggestions)}
            </div>
            <div class="recommendation-time">
                生成时间: ${new Date(recommendations.generated_at).toLocaleString()}
            </div>
        </div>
    `;
}

/**
 * 获取今日学习计划
 */
async function loadTodayPlan() {
    try {
        const response = await API.get('/ai/study-plan/daily');
        const result = await response.json();
        
        if (result.success && result.plan) {
            renderTodayPlanCard(result);
        } else {
            hideTodayPlanCard();
        }
    } catch (error) {
        console.error('加载今日计划失败:', error);
        hideTodayPlanCard();
    }
}

/**
 * 渲染今日计划卡片
 */
function renderTodayPlanCard(data) {
    const card = document.getElementById('todayPlanCard');
    const summary = document.getElementById('todayPlanSummary');
    
    if (!card || !summary) return;
    
    const { plan, total_tasks, available_hours } = data;
    const timeSlots = plan.time_slots || [];
    const firstTask = timeSlots[0];
    const nextTask = timeSlots.find(slot => {
        const startTime = new Date();
        const [hours, minutes] = slot.start_time.split(':').map(Number);
        startTime.setHours(hours, minutes, 0, 0);
        return startTime > new Date();
    });
    
    summary.innerHTML = `
        <div class="plan-summary">
            <div class="summary-item">
                <span class="summary-value">${total_tasks}</span>
                <span class="summary-label">个任务待完成</span>
            </div>
            <div class="summary-item">
                <span class="summary-value">${available_hours}h</span>
                <span class="summary-label">可用学习时间</span>
            </div>
            ${nextTask ? `
                <div class="next-task">
                    <i class="fas fa-play-circle"></i>
                    下一个任务: ${XSSProtection.escapeHtml(nextTask.title)} (${nextTask.start_time})
                </div>
            ` : ''}
        </div>
    `;
    
    card.style.display = 'block';
}

/**
 * 隐藏今日计划卡片
 */
function hideTodayPlanCard() {
    const card = document.getElementById('todayPlanCard');
    if (card) {
        card.style.display = 'none';
    }
}

/**
 * 获取分类图标
 */
function getCategoryIcon(category) {
    const iconMap = {
        '工作': 'fas fa-briefcase',
        '学习': 'fas fa-book',
        '生活': 'fas fa-home',
        '健康': 'fas fa-heartbeat',
        '娱乐': 'fas fa-gamepad',
        '未分类': 'fas fa-inbox'
    };
    return iconMap[category] || 'fas fa-tasks';
}

// ==================== 动态排序功能 ====================

/**
 * 切换自动排序开关
 */
function toggleAutoSort() {
    const checkbox = document.getElementById('autoSortEnabled');
    const configSection = document.getElementById('autoSortConfig');
    
    if (checkbox && configSection) {
        configSection.style.display = checkbox.checked ? 'block' : 'none';
    }
}

/**
 * 加载排序配置
 */
async function loadSortConfig() {
    try {
        const response = await API.getSortConfig();
        const result = await response.json();
        
        if (result.success && result.config) {
            const config = result.config;
            
            // 填充配置项
            const autoSortEnabled = document.getElementById('autoSortEnabled');
            const autoSortTime = document.getElementById('autoSortTime');
            const maxSortPerDay = document.getElementById('maxSortPerDay');
            const autoSortConfig = document.getElementById('autoSortConfig');
            
            if (autoSortEnabled) {
                autoSortEnabled.checked = config.auto_sort_enabled || false;
            }
            if (autoSortTime) {
                autoSortTime.value = config.auto_sort_time || '08:00';
            }
            if (maxSortPerDay) {
                maxSortPerDay.value = config.max_sort_per_day || 3;
            }
            if (autoSortConfig) {
                autoSortConfig.style.display = config.auto_sort_enabled ? 'block' : 'none';
            }
        }
    } catch (error) {
        console.error('加载排序配置失败:', error);
    }
}

/**
 * 保存排序配置
 */
async function saveSortConfig() {
    const autoSortEnabled = document.getElementById('autoSortEnabled').checked;
    const autoSortTime = document.getElementById('autoSortTime').value;
    const maxSortPerDay = parseInt(document.getElementById('maxSortPerDay').value) || 3;
    
    try {
        const response = await API.updateSortConfig({
            auto_sort_enabled: autoSortEnabled,
            auto_sort_time: autoSortTime,
            max_sort_per_day: maxSortPerDay
        });
        
        const result = await response.json();
        
        if (result.success) {
            showToast('排序配置已保存', 'success');
        } else {
            showToast(result.message || '保存配置失败', 'error');
        }
    } catch (error) {
        console.error('保存排序配置失败:', error);
        showToast('保存配置失败', 'error');
    }
}

/**
 * 立即触发自动排序
 */
async function triggerAutoSortNow() {
    const btn = document.getElementById('triggerAutoSortBtn');
    if (btn) {
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 排序中...';
    }
    
    try {
        const result = await API.triggerAutoSort('manual');
        
        if (result.success) {
            showToast('自动排序完成', 'success');
            // 刷新任务列表
            await loadTasks();
            // 更新动态排序状态
            await loadDynamicSortStatus();
        } else {
            showToast(result.message || '排序失败', 'error');
        }
    } catch (error) {
        console.error('触发自动排序失败:', error);
        showToast('排序失败，请重试', 'error');
    } finally {
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-magic"></i> 立即排序';
        }
    }
}

/**
 * 自动调整权重
 */
async function autoAdjustWeights() {
    const btn = document.getElementById('autoAdjustWeightsBtn');
    if (btn) {
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 调整中...';
    }
    
    try {
        const result = await API.autoAdjustWeights();
        
        if (result.success) {
            showToast(`权重已自动调整，共调整 ${result.adjustments_count || 0} 个维度`, 'success');
            // 更新动态排序状态
            await loadDynamicSortStatus();
        } else {
            showToast(result.message || '调整权重失败', 'error');
        }
    } catch (error) {
        console.error('自动调整权重失败:', error);
        showToast('调整权重失败，请重试', 'error');
    } finally {
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-brain"></i> 自动调整权重';
        }
    }
}

/**
 * 加载动态排序状态
 */
async function loadDynamicSortStatus() {
    try {
        const response = await API.getDynamicSortStatus();
        const result = await response.json();
        
        if (result.success) {
            renderDynamicSortStatus(result.status);
        }
    } catch (error) {
        console.error('加载动态排序状态失败:', error);
    }
}

/**
 * 渲染动态排序状态
 */
function renderDynamicSortStatus(status) {
    const container = document.getElementById('dynamicSortStatus');
    if (!container) return;
    
    const lastSortTime = status.last_auto_sort ? 
        new Date(status.last_auto_sort).toLocaleString() : '从未';
    const nextSortTime = status.next_scheduled_sort ? 
        new Date(status.next_scheduled_sort).toLocaleString() : '未安排';
    
    container.innerHTML = `
        <div class="sort-status-card">
            <div class="status-header">
                <i class="fas fa-robot"></i>
                <span>动态排序状态</span>
            </div>
            <div class="status-body">
                <div class="status-item">
                    <span class="status-label">自动排序:</span>
                    <span class="status-value ${status.auto_sort_enabled ? 'enabled' : 'disabled'}">
                        ${status.auto_sort_enabled ? '已启用' : '已禁用'}
                    </span>
                </div>
                <div class="status-item">
                    <span class="status-label">上次排序:</span>
                    <span class="status-value">${lastSortTime}</span>
                </div>
                <div class="status-item">
                    <span class="status-label">下次排序:</span>
                    <span class="status-value">${nextSortTime}</span>
                </div>
                <div class="status-item">
                    <span class="status-label">今日剩余次数:</span>
                    <span class="status-value">${status.remaining_sorts_today || 0} / ${status.max_sorts_per_day || 3}</span>
                </div>
                ${status.total_adjustments > 0 ? `
                    <div class="status-item">
                        <span class="status-label">累计调整:</span>
                        <span class="status-value">${status.total_adjustments} 次</span>
                    </div>
                ` : ''}
            </div>
        </div>
    `;
}

/**
 * 显示排序反馈弹窗
 */
function showSortFeedbackModal() {
    // 加载任务列表到反馈表单
    loadFeedbackTaskOptions();
    // 重置表单
    resetSortFeedbackForm();
    // 显示弹窗
    openModal('sortFeedbackModal');
}

/**
 * 关闭排序反馈弹窗
 */
function closeSortFeedbackModal() {
    closeModal('sortFeedbackModal');
}

/**
 * 加载反馈任务选项
 */
function loadFeedbackTaskOptions() {
    const select = document.getElementById('feedbackTaskId');
    if (!select) return;
    
    // 清空现有选项
    select.innerHTML = '<option value="">-- 选择任务（可选）--</option>';
    
    // 添加未完成任务选项
    const pendingTasks = allTasks.filter(t => !t.is_completed);
    pendingTasks.forEach(task => {
        const option = document.createElement('option');
        option.value = task.id;
        option.textContent = task.title;
        select.appendChild(option);
    });
}

/**
 * 选择反馈类型
 */
function selectFeedbackType(type) {
    // 更新选中状态
    document.querySelectorAll('.feedback-type-option').forEach(el => {
        el.classList.remove('selected');
    });
    
    const selectedEl = document.querySelector(`[data-feedback-type="${type}"]`);
    if (selectedEl) {
        selectedEl.classList.add('selected');
    }
    
    // 保存到隐藏字段
    const hiddenInput = document.getElementById('selectedFeedbackType');
    if (hiddenInput) {
        hiddenInput.value = type;
    }
}

/**
 * 提交排序反馈表单
 */
async function submitSortFeedbackForm() {
    const feedbackType = document.getElementById('selectedFeedbackType').value;
    const taskId = document.getElementById('feedbackTaskId').value;
    const details = document.getElementById('feedbackDetails').value.trim();
    
    if (!feedbackType) {
        showToast('请选择反馈类型', 'warning');
        return;
    }
    
    try {
        const result = await API.submitSortFeedback(feedbackType, taskId || null, details);
        
        if (result.success) {
            showToast('感谢您的反馈，系统将根据您的反馈优化排序', 'success');
            closeSortFeedbackModal();
            
            // 如果反馈建议调整权重，自动触发权重调整
            if (result.suggest_weight_adjustment) {
                setTimeout(() => {
                    autoAdjustWeights();
                }, 1000);
            }
        } else {
            showToast(result.message || '提交反馈失败', 'error');
        }
    } catch (error) {
        console.error('提交排序反馈失败:', error);
        showToast('提交反馈失败，请重试', 'error');
    }
}

/**
 * 重置排序反馈表单
 */
function resetSortFeedbackForm() {
    const hiddenInput = document.getElementById('selectedFeedbackType');
    const taskSelect = document.getElementById('feedbackTaskId');
    const detailsTextarea = document.getElementById('feedbackDetails');
    
    if (hiddenInput) hiddenInput.value = '';
    if (taskSelect) taskSelect.value = '';
    if (detailsTextarea) detailsTextarea.value = '';
    
    // 清除选中状态
    document.querySelectorAll('.feedback-type-option').forEach(el => {
        el.classList.remove('selected');
    });
}

/**
 * 查看排序历史
 */
async function viewSortHistory() {
    try {
        const response = await API.getSortHistory(10);
        const result = await response.json();
        
        if (result.success) {
            renderSortHistory(result.history);
        }
    } catch (error) {
        console.error('加载排序历史失败:', error);
        showToast('加载历史失败', 'error');
    }
}

/**
 * 渲染排序历史
 */
function renderSortHistory(history) {
    // 创建历史弹窗内容
    const modalContent = `
        <div class="modal-overlay" id="sortHistoryModal">
            <div class="modal-container" style="max-width: 600px;">
                <div class="modal-header">
                    <h3><i class="fas fa-history"></i> 排序历史</h3>
                    <button class="btn-close" onclick="closeModal('sortHistoryModal')">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="modal-body">
                    ${history && history.length > 0 ? `
                        <div class="sort-history-list">
                            ${history.map(h => `
                                <div class="sort-history-item">
                                    <div class="history-time">
                                        <i class="fas fa-clock"></i>
                                        ${new Date(h.created_at).toLocaleString()}
                                    </div>
                                    <div class="history-type">
                                        <span class="badge badge-${h.sort_type === 'auto' ? 'primary' : 'secondary'}">
                                            ${h.sort_type === 'auto' ? '自动' : '手动'}
                                        </span>
                                    </div>
                                    <div class="history-details">
                                        调整了 ${h.tasks_affected || 0} 个任务
                                    </div>
                                </div>
                            `).join('')}
                        </div>
                    ` : '<div class="empty-state">暂无排序历史</div>'}
                </div>
            </div>
        </div>
    `;
    
    // 添加到DOM并显示
    const existingModal = document.getElementById('sortHistoryModal');
    if (existingModal) {
        existingModal.remove();
    }
    
    const tempDiv = document.createElement('div');
    tempDiv.innerHTML = modalContent;
    document.body.appendChild(tempDiv.firstElementChild);
    
    openModal('sortHistoryModal');
}

/**
 * 查看权重调整历史
 */
async function viewWeightAdjustmentHistory() {
    try {
        const response = await API.getWeightAdjustmentHistory(10);
        const result = await response.json();
        
        if (result.success) {
            renderWeightAdjustmentHistory(result.adjustments);
        }
    } catch (error) {
        console.error('加载权重调整历史失败:', error);
        showToast('加载历史失败', 'error');
    }
}

/**
 * 渲染权重调整历史
 */
function renderWeightAdjustmentHistory(adjustments) {
    // 创建历史弹窗内容
    const modalContent = `
        <div class="modal-overlay" id="weightHistoryModal">
            <div class="modal-container" style="max-width: 600px;">
                <div class="modal-header">
                    <h3><i class="fas fa-sliders-h"></i> 权重调整历史</h3>
                    <button class="btn-close" onclick="closeModal('weightHistoryModal')">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="modal-body">
                    ${adjustments && adjustments.length > 0 ? `
                        <div class="weight-history-list">
                            ${adjustments.map(a => `
                                <div class="weight-history-item">
                                    <div class="history-time">
                                        <i class="fas fa-clock"></i>
                                        ${new Date(a.created_at).toLocaleString()}
                                    </div>
                                    <div class="history-dimension">
                                        <span class="dimension-name">${a.dimension_name}</span>
                                        <span class="weight-change">
                                            ${a.old_weight.toFixed(1)} 
                                            <i class="fas fa-arrow-right"></i> 
                                            ${a.new_weight.toFixed(1)}
                                        </span>
                                    </div>
                                    <div class="history-reason">${a.adjustment_reason}</div>
                                </div>
                            `).join('')}
                        </div>
                    ` : '<div class="empty-state">暂无权重调整历史</div>'}
                </div>
            </div>
        </div>
    `;
    
    // 添加到DOM并显示
    const existingModal = document.getElementById('weightHistoryModal');
    if (existingModal) {
        existingModal.remove();
    }
    
    const tempDiv = document.createElement('div');
    tempDiv.innerHTML = modalContent;
    document.body.appendChild(tempDiv.firstElementChild);
    
    openModal('weightHistoryModal');
}

// ==================== 任务状态跟踪功能 ====================

// 当前查看的任务ID
let currentTrackingTaskId = null;

/**
 * 显示任务执行历史弹窗
 * @param {number} taskId - 任务ID（可选，不传则显示任务选择器）
 * 功能已禁用
 */
async function showTaskHistoryModal(taskId = null) {
    // 执行历史功能已禁用
    console.log('执行历史功能已禁用');
    showToast('执行历史功能已暂时禁用', 'info');
}

/**
 * 关闭任务执行历史弹窗
 * 功能已禁用
 */
function closeTaskHistoryModal() {
    // 执行历史功能已禁用
    console.log('执行历史功能已禁用');
}

/**
 * 加载任务选择器选项
 * 功能已禁用
 */
async function loadTaskSelectorOptions() {
    // 执行历史功能已禁用
    console.log('执行历史功能已禁用');
}

/**
 * 加载任务执行数据
 * @param {number} taskId - 任务ID
 * 功能已禁用
 */
async function loadTaskExecutionData(taskId) {
    if (!taskId) return;
    // 执行历史功能已禁用
    console.log('执行历史功能已禁用');
    hideLoading();
}

/**
 * 渲染执行统计
 * @param {Object} statistics - 统计数据
 * 功能已禁用
 */
function renderExecutionStats(statistics) {
    // 执行历史功能已禁用
}

/**
 * 渲染执行时间轴
 * @param {Object} archive - 执行档案数据
 * 功能已禁用
 */
function renderExecutionTimeline(archive) {
    // 执行历史功能已禁用
}

/**
 * 渲染时间段列表
 * @param {Array} segments - 时间段数组
 * 功能已禁用
 */
function renderTimeSegments(segments) {
    // 执行历史功能已禁用
}

/**
 * 渲染状态变更历史
 * @param {Array} history - 状态历史数组
 * 功能已禁用
 */
function renderStatusHistory(history) {
    // 执行历史功能已禁用
}

/**
 * 记录状态变更
 * @param {number} taskId - 任务ID
 * @param {string} oldStatus - 原状态
 * @param {string} newStatus - 新状态
 * @param {string} reason - 变更原因
 * 功能已禁用
 */
async function recordStatusChange(taskId, oldStatus, newStatus, reason = '') {
    // 执行历史功能已禁用，不记录状态变更
    return true;
}

/**
 * 记录执行事件
 * @param {number} taskId - 任务ID
 * @param {string} eventType - 事件类型
 * @param {Object} eventData - 事件数据
 * 功能已禁用
 */
async function logExecutionEvent(taskId, eventType, eventData = {}) {
    // 执行历史功能已禁用，不记录执行事件
    return true;
}

/**
 * 记录执行时间段
 * @param {number} taskId - 任务ID
 * @param {Date} startTime - 开始时间
 * @param {Date} endTime - 结束时间
 * @param {string} interruptReason - 中断原因
 * 功能已禁用
 */
async function recordTimeSegment(taskId, startTime, endTime = null, interruptReason = null) {
    // 执行历史功能已禁用，不记录时间段
    return true;
}

/**
 * 导出任务执行报告
 * 功能已禁用
 */
async function exportTaskReport() {
    // 执行历史功能已禁用
    showToast('执行历史功能已暂时禁用', 'info');
}

/**
 * 下载报告
 * @param {Object} report - 报告数据
 * 功能已禁用
 */
function downloadReport(report) {
    // 执行历史功能已禁用
    console.log('执行历史功能已禁用');
}

/**
 * 生成报告文本
 * @param {Object} report - 报告数据
 * @returns {string} 报告文本
 * 功能已禁用
 */
function generateReportText(report) {
    // 执行历史功能已禁用
    return '';
}

// ==================== 辅助函数 ====================

/**
 * 获取状态标签
 * @param {string} status - 状态代码
 * @returns {string} 状态标签
 */
function getStatusLabel(status) {
    const labels = {
        'pending': '待处理',
        'in_progress': '进行中',
        'paused': '已暂停',
        'completed': '已完成',
        'cancelled': '已取消'
    };
    return labels[status] || status || '未知';
}

/**
 * 获取事件配置
 * @param {string} eventType - 事件类型
 * @returns {Object} 事件配置
 */
function getEventConfig(eventType) {
    const configs = {
        'start': { title: '开始执行', icon: 'fa-play', color: 'green' },
        'pause': { title: '暂停执行', icon: 'fa-pause', color: 'orange' },
        'resume': { title: '恢复执行', icon: 'fa-play-circle', color: 'blue' },
        'complete': { title: '任务完成', icon: 'fa-check', color: 'green' },
        'cancel': { title: '任务取消', icon: 'fa-times', color: 'red' },
        'modify': { title: '任务修改', icon: 'fa-edit', color: 'purple' },
        'reminder': { title: '提醒触发', icon: 'fa-bell', color: 'yellow' },
        'ai_sort': { title: 'AI排序影响', icon: 'fa-magic', color: 'cyan' },
        'status_change': { title: '状态变更', icon: 'fa-exchange-alt', color: 'blue' }
    };
    return configs[eventType] || { title: eventType, icon: 'fa-circle', color: 'gray' };
}

/**
 * 格式化时长
 * @param {number} seconds - 秒数
 * @returns {string} 格式化后的时长
 */
function formatDuration(seconds) {
    if (!seconds || seconds <= 0) return '0秒';
    
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    
    const parts = [];
    if (hours > 0) parts.push(`${hours}小时`);
    if (minutes > 0) parts.push(`${minutes}分钟`);
    if (secs > 0 && hours === 0) parts.push(`${secs}秒`);
    
    return parts.join(' ') || '0秒';
}

/**
 * 获取效率等级样式
 * @param {number} score - 效率评分
 * @returns {string} CSS类名
 */
function getEfficiencyClass(score) {
    if (score >= 80) return 'excellent';
    if (score >= 60) return 'good';
    if (score >= 40) return 'average';
    return 'poor';
}

// ==================== 校园场景功能（已重构） ====================
// 新实现位于 campus-new.js 模块中

// ==================== 批量添加任务功能 ====================

/**
 * 显示批量添加任务模态框
 */
function showBatchAddModal() {
    const modal = document.getElementById('batchAddModal');
    modal.classList.add('active');
    
    // 清空输入
    document.getElementById('batchTaskInput').value = '';
    document.getElementById('batchTaskCount').textContent = '0 个任务';
    document.getElementById('batchPreviewSection').style.display = 'none';
    document.getElementById('batchPreviewList').innerHTML = '';
    
    // 聚焦输入框
    setTimeout(() => {
        document.getElementById('batchTaskInput').focus();
    }, 100);
    
    // 添加输入监听
    const input = document.getElementById('batchTaskInput');
    input.removeEventListener('input', updateBatchTaskCount);
    input.addEventListener('input', updateBatchTaskCount);
}

/**
 * 关闭批量添加任务模态框
 */
function closeBatchAddModal() {
    const modal = document.getElementById('batchAddModal');
    modal.classList.remove('active');
}

/**
 * 更新任务计数
 */
function updateBatchTaskCount() {
    const input = document.getElementById('batchTaskInput').value;
    const lines = input.split('\n').filter(line => line.trim());
    document.getElementById('batchTaskCount').textContent = `${lines.length} 个任务`;
}

/**
 * 解析单行任务文本
 * @param {string} line - 任务文本行
 * @returns {Object} 解析后的任务对象
 */
function parseBatchTaskLine(line) {
    const text = line.trim();
    if (!text) return null;
    
    const task = {
        title: text,
        category: null,
        priority: 0,
        deadline: null,
        estimated_duration: null
    };
    
    // 提取分类关键词
    const categoryKeywords = {
        '数学': '学习', '英语': '学习', '语文': '学习', '物理': '学习', 
        '化学': '学习', '生物': '学习', '历史': '学习', '地理': '学习',
        '作业': '作业', '练习': '作业', '习题': '作业',
        '考试': '考试', '测验': '考试', '期中': '考试', '期末': '考试',
        '项目': '项目', '实验': '项目', '报告': '项目',
        '工作': '工作', '会议': '工作', '汇报': '工作'
    };
    
    for (const [keyword, category] of Object.entries(categoryKeywords)) {
        if (text.includes(keyword)) {
            task.category = category;
            break;
        }
    }
    
    // 提取优先级
    if (text.includes('高优先级') || text.includes('非常重要') || text.includes('紧急')) {
        task.priority = 4;
    } else if (text.includes('中优先级') || text.includes('重要')) {
        task.priority = 3;
    } else if (text.includes('低优先级')) {
        task.priority = 1;
    }
    
    // 提取预计耗时
    const durationPatterns = [
        { regex: /(\d+)\s*小时/, multiplier: 60 },
        { regex: /(\d+)\s*分钟/, multiplier: 1 },
        { regex: /(\d+)\s*min/i, multiplier: 1 },
        { regex: /(\d+)\s*h/i, multiplier: 60 },
        { regex: /预计\s*(\d+)/, multiplier: 60 },
        { regex: /耗时\s*(\d+)/, multiplier: 60 }
    ];
    
    for (const pattern of durationPatterns) {
        const match = text.match(pattern.regex);
        if (match) {
            task.estimated_duration = parseInt(match[1]) * pattern.multiplier;
            break;
        }
    }
    
    // 清理标题中的元信息
    let cleanTitle = text
        .replace(/高优先级|中优先级|低优先级|非常重要|重要|紧急/g, '')
        .replace(/\d+\s*小时|\d+\s*分钟|\d+\s*min|\d+\s*h/gi, '')
        .replace(/预计\s*\d+|耗时\s*\d+/g, '')
        .replace(/\s+/g, ' ')
        .trim();
    
    task.title = cleanTitle || text;
    
    return task;
}

/**
 * 预览批量任务解析结果
 */
function previewBatchTasks() {
    const input = document.getElementById('batchTaskInput').value;
    const lines = input.split('\n').filter(line => line.trim());
    
    if (lines.length === 0) {
        showToast('请输入至少一个任务', 'warning');
        return;
    }
    
    const previewList = document.getElementById('batchPreviewList');
    const previewSection = document.getElementById('batchPreviewSection');
    
    const parsedTasks = lines.map((line, index) => {
        const task = parseBatchTaskLine(line);
        return { ...task, originalIndex: index + 1 };
    }).filter(t => t !== null);
    
    if (parsedTasks.length === 0) {
        showToast('未能解析到有效任务', 'error');
        return;
    }
    
    previewList.innerHTML = parsedTasks.map((task, index) => `
        <div style="padding: 10px; border-bottom: 1px solid var(--border-color); ${index === parsedTasks.length - 1 ? 'border-bottom: none;' : ''}">
            <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 10px;">
                <div style="flex: 1;">
                    <div style="font-weight: 500; color: var(--text-primary); margin-bottom: 4px;">
                        ${index + 1}. ${XSSProtection.escapeHtml(task.title)}
                    </div>
                    <div style="font-size: 12px; color: var(--text-secondary); display: flex; gap: 12px; flex-wrap: wrap;">
                        ${task.category ? `<span><i class="fas fa-tag"></i> ${task.category}</span>` : ''}
                        ${task.priority > 0 ? `<span style="color: ${getPriorityColor(task.priority)}"><i class="fas fa-flag"></i> 优先级 ${task.priority}</span>` : ''}
                        ${task.estimated_duration ? `<span><i class="fas fa-clock"></i> ${formatDuration(task.estimated_duration)}</span>` : ''}
                    </div>
                </div>
            </div>
        </div>
    `).join('');
    
    previewSection.style.display = 'block';
    previewList.scrollTop = 0;
    
    showToast(`成功解析 ${parsedTasks.length} 个任务`, 'success');
}

/**
 * 获取优先级颜色
 */
function getPriorityColor(priority) {
    const colors = {
        5: '#ef4444', // 最高 - 红色
        4: '#f97316', // 高 - 橙色
        3: '#eab308', // 中 - 黄色
        2: '#22c55e', // 低 - 绿色
        1: '#6b7280'  // 最低 - 灰色
    };
    return colors[priority] || '#6b7280';
}

/**
 * 格式化时长
 */
function formatDuration(minutes) {
    if (minutes >= 60) {
        const hours = Math.floor(minutes / 60);
        const mins = minutes % 60;
        return mins > 0 ? `${hours}小时${mins}分钟` : `${hours}小时`;
    }
    return `${minutes}分钟`;
}

/**
 * 提交批量任务
 */
async function submitBatchTasks() {
    const input = document.getElementById('batchTaskInput').value;
    const defaultCategory = document.getElementById('batchDefaultCategory').value;
    const autoDeadline = document.getElementById('batchAutoDeadline').value === 'true';
    
    const lines = input.split('\n').filter(line => line.trim());
    
    if (lines.length === 0) {
        showToast('请输入至少一个任务', 'warning');
        return;
    }
    
    // 解析所有任务
    const tasks = lines.map(line => {
        const parsed = parseBatchTaskLine(line);
        if (!parsed) return null;
        
        return {
            title: parsed.title,
            category: parsed.category || defaultCategory,
            priority: parsed.priority,
            estimated_duration: parsed.estimated_duration,
            description: ''
        };
    }).filter(t => t !== null);
    
    if (tasks.length === 0) {
        showToast('未能解析到有效任务', 'error');
        return;
    }
    
    // 显示加载状态
    const submitBtn = document.querySelector('#batchAddModal .btn-primary');
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 添加中...';
    submitBtn.disabled = true;
    
    try {
        const response = await API.post('/tasks/batch', {
            tasks: tasks,
            options: {
                auto_deadline: autoDeadline,
                default_category: defaultCategory
            }
        });
        
        const result = await response.json();
        
        if (result.success) {
            showToast(`成功创建 ${result.created} 个任务！`, 'success');
            closeBatchAddModal();
            loadTasks(); // 刷新任务列表
            
            // 如果有AI排序功能，询问是否排序
            if (result.created > 1) {
                setTimeout(() => {
                    if (confirm(`已创建 ${result.created} 个任务，是否使用AI智能排序？`)) {
                        batchAISort();
                    }
                }, 500);
            }
        } else {
            showToast(result.message || '批量创建失败', 'error');
        }
    } catch (error) {
        console.error('[submitBatchTasks] 批量创建任务失败:', error);
        showToast('批量创建任务失败，请检查网络连接', 'error');
    } finally {
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
    }
}

// 批量添加模态框点击背景关闭
document.addEventListener('DOMContentLoaded', () => {
    const batchModal = document.getElementById('batchAddModal');
    if (batchModal) {
        batchModal.addEventListener('click', (e) => {
            if (e.target === batchModal) {
                closeBatchAddModal();
            }
        });
    }
});
