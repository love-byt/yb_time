# Frontend - 智能日程助手前端界面

基于原生 HTML5 + CSS3 + JavaScript 构建的用户界面，采用滴答清单风格的简洁白色主题。

## 技术栈

| 技术 | 版本 | 用途 |
|------|------|------|
| HTML5 | - | 页面结构 |
| CSS3 | - | 样式布局 |
| JavaScript | ES6+ | 交互逻辑 |
| Chart.js | 4.4+ | 数据可视化 |
| Font Awesome | 6.0+ | 图标库 |

## 目录结构

```
frontend/
├── index.html              # 应用主页面
├── login.html              # 登录/注册页面
├── app.js                  # 前端主逻辑
├── sw.js                   # Service Worker (PWA)
├── package.json            # npm 配置
├── css/                    # 样式文件
│   └── auth.css           # 认证页面样式
├── js/                     # JavaScript 模块
│   ├── auth-manager.js    # 认证管理模块
│   └── smart-scheduler.js # 智能日程模块
└── readme.txt             # 文本版本说明
```

## 核心文件说明

### index.html

应用主页面，包含：
- 侧边栏导航
- 任务列表展示
- 任务创建/编辑表单
- 标签管理
- 统计图表
- AI 排序结果展示

**主要区域**:
1. **侧边栏** - 用户信息、任务筛选、标签列表
2. **主内容区** - 任务列表、快速添加输入框
3. **模态框** - 任务编辑、AI 分析结果

### login.html

认证页面，包含：
- 登录表单
- 注册表单
- 忘记密码功能
- 响应式布局

### app.js

前端主逻辑文件 (~6000+ 行)，主要功能：

#### 任务管理
- `loadTasks()` - 加载任务列表
- `createTask()` - 创建任务
- `updateTask()` - 更新任务
- `deleteTask()` - 删除任务
- `completeTask()` - 完成任务

#### AI 功能
- `aiSortTasks()` - AI 智能排序
- `analyzeTaskDuration()` - 耗时分析
- `analyzeTaskDeadline()` - 截止分析
- `loadTodayPlan()` - 加载学习计划

#### 批量任务
- `showBatchAddModal()` - 显示批量添加弹窗
- `parseBatchText()` - 解析批量文本
- `submitBatchTasks()` - 提交批量任务

#### 辅助功能
- `initApp()` - 应用初始化
- `initEventListeners()` - 事件监听
- `showToast()` - 消息提示
- `formatDate()` - 日期格式化

### sw.js

Service Worker 文件，实现 PWA 功能：
- 静态资源缓存
- 离线访问支持
- 缓存策略管理

### css/auth.css

认证页面样式：
- 登录/注册表单样式
- 响应式布局 (移动端适配)
- 动画效果
- 主题色彩

### js/auth-manager.js

认证管理模块：
- Token 存储管理 (localStorage)
- 登录/注册/登出
- API 请求封装
- 认证状态管理

### js/smart-scheduler.js

智能日程管理模块：
- 任务管理逻辑
- 时间解析辅助
- 与后端 API 交互

## 页面结构

### index.html 布局

```
┌─────────────────────────────────────────────────────┐
│  侧边栏 (25%)        │  主内容区 (75%)              │
│                      │                              │
│  ┌────────────────┐  │  ┌────────────────────────┐  │
│  │ 用户信息        │  │  │ 顶部栏 (筛选/排序)      │  │
│  └────────────────┘  │  └────────────────────────┘  │
│                      │                              │
│  ┌────────────────┐  │  ┌────────────────────────┐  │
│  │ 任务筛选        │  │  │                        │  │
│  │ - 全部任务      │  │  │     任务列表            │  │
│  │ - 今天          │  │  │                        │  │
│  │ - 即将到来      │  │  │  ┌──────────────────┐  │  │
│  └────────────────┘  │  │  │ 任务卡片          │  │  │
│                      │  │  │ - 复选框          │  │  │
│  ┌────────────────┐  │  │  │ - 标题            │  │  │
│  │ 标签列表        │  │  │  │ - 时间            │  │  │
│  └────────────────┘  │  │  │ - 优先级标签       │  │  │
│                      │  │  └──────────────────┘  │  │
│  ┌────────────────┐  │  │                        │  │
│  │ 统计概览        │  │  └────────────────────────┘  │
│  └────────────────┘  │                              │
│                      │  ┌────────────────────────┐  │
│                      │  │ 快速添加输入框          │  │
│                      │  └────────────────────────┘  │
└──────────────────────┴──────────────────────────────┘
```

### 模态框组件

1. **任务编辑模态框**
   - 标题输入
   - 描述文本框
   - 时间选择器
   - 优先级选择
   - 标签选择

2. **批量添加模态框**
   - 文本输入区域
   - 解析预览
   - 确认创建

3. **AI 排序结果模态框**
   - 排序后任务列表
   - 维度评分展示
   - 应用排序按钮

4. **统计分析模态框**
   - 完成率图表
   - 时间分布图表
   - 效率趋势

## 交互特性

### 响应式设计

- **桌面端** (>1024px): 侧边栏 + 主内容区
- **平板端** (768-1024px): 可折叠侧边栏
- **移动端** (<768px): 底部导航栏

### 离线支持

Service Worker 缓存策略：
- 静态资源 (CSS/JS/HTML): Cache First
- API 请求: Network First with Cache Fallback
- 图片资源: Stale While Revalidate

### 动画效果

- 任务完成: 划线动画 + 淡出
- 模态框: 淡入 + 缩放
- 列表加载: 渐显动画
- Toast 提示: 滑入滑出

### 键盘快捷键

| 快捷键 | 功能 |
|--------|------|
| `Ctrl/Cmd + N` | 新建任务 |
| `Ctrl/Cmd + Enter` | 保存任务 |
| `Esc` | 关闭模态框 |
| `?` | 显示快捷键帮助 |

## API 交互

### 请求封装

```javascript
const API = {
  baseUrl: '/api',
  
  async request(endpoint, options = {}) {
    const response = await fetch(`${this.baseUrl}${endpoint}`, {
      headers: {
        'Content-Type': 'application/json',
        'X-User-ID': getUserId()
      },
      ...options
    });
    return response.json();
  },
  
  get(endpoint) { return this.request(endpoint); },
  post(endpoint, data) { return this.request(endpoint, { method: 'POST', body: JSON.stringify(data) }); },
  put(endpoint, data) { return this.request(endpoint, { method: 'PUT', body: JSON.stringify(data) }); },
  delete(endpoint) { return this.request(endpoint, { method: 'DELETE' }); }
};
```

### 主要 API 调用

```javascript
// 任务管理
API.get('/tasks');
API.post('/tasks', taskData);
API.put(`/tasks/${id}`, taskData);
API.delete(`/tasks/${id}`);

// AI 功能
API.post('/ai/sort', { task_ids: [...] });
API.get('/ai/study-plan/daily');

// 批量任务
API.post('/tasks/parse-text', { text: '...' });
API.post('/tasks/batch', { tasks: [...] });
```

## 开发指南

### 添加新页面

1. 创建 HTML 文件
2. 添加路由处理 (app.js)
3. 添加导航链接

### 添加新组件

1. 在 index.html 添加 HTML 结构
2. 在 app.js 添加交互逻辑
3. 如需新样式，添加到 css/

### 添加新 API 调用

1. 在 app.js 添加请求函数
2. 处理响应和错误
3. 更新 UI

### 调试技巧

```javascript
// 开启调试日志
localStorage.setItem('debug', 'true');

// 查看 API 请求
console.log('[API]', endpoint, data);

// 模拟数据
window.mockData = { ... };
```

## 性能优化

### 已实施

- Service Worker 缓存静态资源
- 图片懒加载
- 虚拟滚动 (长列表)
- 防抖/节流 (搜索输入)

### 建议

- 代码分割 (动态导入)
- 预加载关键资源
- 使用 Intersection Observer

## 浏览器支持

| 浏览器 | 最低版本 |
|--------|----------|
| Chrome | 90+ |
| Firefox | 88+ |
| Safari | 14+ |
| Edge | 90+ |

## 常见问题

### 页面白屏

检查：
1. 后端服务是否运行
2. 浏览器控制台错误
3. Service Worker 是否更新

### API 请求失败

检查：
1. 网络连接
2. 用户是否登录
3. Token 是否过期

### 样式错乱

检查：
1. CSS 文件是否正确加载
2. 浏览器缓存 (Ctrl+F5 刷新)

## 构建部署

前端为纯静态文件，直接部署即可：

```bash
# 复制到 Web 服务器
cp -r frontend/* /var/www/html/

# 或使用 Nginx
cp -r frontend/* /usr/share/nginx/html/
```

## 许可证

MIT License
