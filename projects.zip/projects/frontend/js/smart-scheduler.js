/**
 * 智能日程助手 - 命名空间封装模块
 * 
 * 功能：
 * 1. 将全局变量封装到 SmartScheduler 命名空间
 * 2. 提供统一的错误边界处理
 * 3. 保持向后兼容性
 */

(function(global) {
    'use strict';
    
    // ==================== 错误边界类 ====================
    
    class ErrorBoundary {
        constructor() {
            this.errors = [];
            this.maxErrors = 100;
            this.errorHandlers = new Map();
        }
        
        /**
         * 捕获并处理错误
         */
        catch(error, context = 'unknown') {
            const errorInfo = {
                message: error.message || String(error),
                stack: error.stack,
                context: context,
                timestamp: new Date().toISOString()
            };
            
            // 存储错误
            this.errors.push(errorInfo);
            if (this.errors.length > this.maxErrors) {
                this.errors.shift();
            }
            
            // 调用特定上下文的错误处理器
            const handler = this.errorHandlers.get(context);
            if (handler) {
                try {
                    handler(error, errorInfo);
                } catch (handlerError) {
                    console.error('错误处理器执行失败:', handlerError);
                }
            }
            
            // 默认处理：记录到控制台
            console.error(`[${context}] 错误:`, error);
            
            // 显示用户友好的错误提示
            this.showUserError(error, context);
            
            return errorInfo;
        }
        
        /**
         * 注册错误处理器
         */
        registerHandler(context, handler) {
            this.errorHandlers.set(context, handler);
        }
        
        /**
         * 显示用户友好的错误提示
         */
        showUserError(error, context) {
            // 检查是否有全局toast函数
            if (typeof window.showToast === 'function') {
                window.showToast(this.getUserFriendlyMessage(error, context), 'error');
                return;
            }
            
            // 创建简单的错误提示
            const toast = document.createElement('div');
            toast.className = 'error-boundary-toast';
            toast.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                background: #ff4d4f;
                color: white;
                padding: 12px 20px;
                border-radius: 8px;
                z-index: 10000;
                font-size: 14px;
                box-shadow: 0 4px 12px rgba(0,0,0,0.15);
                animation: slideIn 0.3s ease;
            `;
            toast.textContent = this.getUserFriendlyMessage(error, context);
            
            document.body.appendChild(toast);
            
            // 3秒后自动移除
            setTimeout(() => {
                toast.style.animation = 'slideOut 0.3s ease';
                setTimeout(() => toast.remove(), 300);
            }, 3000);
        }
        
        /**
         * 获取用户友好的错误消息
         */
        getUserFriendlyMessage(error, context) {
            const contextMessages = {
                'api': '网络请求失败，请稍后重试',
                'auth': '认证失败，请重新登录',
                'task': '任务操作失败，请刷新页面重试',
                'storage': '存储空间不足或不可用',
                'render': '页面渲染出错，请刷新页面',
                'ai': 'AI分析暂时不可用，请稍后重试'
            };
            
            return contextMessages[context] || '操作失败，请稍后重试';
        }
        
        /**
         * 包装异步函数，自动捕获错误
         */
        wrapAsync(fn, context = 'unknown') {
            return async (...args) => {
                try {
                    return await fn(...args);
                } catch (error) {
                    this.catch(error, context);
                    throw error;
                }
            };
        }
        
        /**
         * 包装同步函数，自动捕获错误
         */
        wrapSync(fn, context = 'unknown') {
            return (...args) => {
                try {
                    return fn(...args);
                } catch (error) {
                    this.catch(error, context);
                    throw error;
                }
            };
        }
        
        /**
         * 获取错误历史
         */
        getErrors() {
            return [...this.errors];
        }
        
        /**
         * 清除错误历史
         */
        clearErrors() {
            this.errors = [];
        }
    }
    
    // ==================== 命名空间定义 ====================
    
    const SmartScheduler = {
        // 版本信息
        version: '2.0.0',
        
        // 错误边界实例
        errorBoundary: new ErrorBoundary(),
        
        // 模块容器（将在app.js加载后填充引用）
        modules: {
            UserManager: null,
            AuthManager: null,
            RequestManager: null,
            API: null,
            ClickManager: null,
            AI_PROVIDERS: null,
            PushNotificationManager: null,
            WeeklyReportManager: null,
            SmartReminderManager: null
        },
        
        // 工具函数
        utils: {
            /**
             * 安全执行函数
             */
            safeExecute(fn, context = 'unknown', ...args) {
                try {
                    const result = fn(...args);
                    if (result instanceof Promise) {
                        return result.catch(error => {
                            SmartScheduler.errorBoundary.catch(error, context);
                            return null;
                        });
                    }
                    return result;
                } catch (error) {
                    SmartScheduler.errorBoundary.catch(error, context);
                    return null;
                }
            },
            
            /**
             * 安全执行异步函数
             */
            async safeAsync(fn, context = 'unknown', ...args) {
                try {
                    return await fn(...args);
                } catch (error) {
                    SmartScheduler.errorBoundary.catch(error, context);
                    return null;
                }
            },
            
            /**
             * 防抖函数
             */
            debounce(fn, delay = 300) {
                let timer = null;
                return function(...args) {
                    if (timer) clearTimeout(timer);
                    timer = setTimeout(() => fn.apply(this, args), delay);
                };
            },
            
            /**
             * 节流函数
             */
            throttle(fn, limit = 300) {
                let inThrottle = false;
                return function(...args) {
                    if (!inThrottle) {
                        fn.apply(this, args);
                        inThrottle = true;
                        setTimeout(() => inThrottle = false, limit);
                    }
                };
            },
            
            /**
             * 深拷贝
             */
            deepClone(obj) {
                if (obj === null || typeof obj !== 'object') {
                    return obj;
                }
                
                if (obj instanceof Date) {
                    return new Date(obj.getTime());
                }
                
                if (Array.isArray(obj)) {
                    return obj.map(item => this.deepClone(item));
                }
                
                const cloned = {};
                for (const key in obj) {
                    if (obj.hasOwnProperty(key)) {
                        cloned[key] = this.deepClone(obj[key]);
                    }
                }
                return cloned;
            },
            
            /**
             * 格式化日期
             */
            formatDate(date, format = 'YYYY-MM-DD HH:mm') {
                const d = new Date(date);
                const year = d.getFullYear();
                const month = String(d.getMonth() + 1).padStart(2, '0');
                const day = String(d.getDate()).padStart(2, '0');
                const hours = String(d.getHours()).padStart(2, '0');
                const minutes = String(d.getMinutes()).padStart(2, '0');
                
                return format
                    .replace('YYYY', year)
                    .replace('MM', month)
                    .replace('DD', day)
                    .replace('HH', hours)
                    .replace('mm', minutes);
            }
        },
        
        // 配置
        config: {
            apiBase: '/api',
            toastDuration: 3000,
            debounceDelay: 300,
            throttleLimit: 300
        },
        
        /**
         * 初始化命名空间
         * 在app.js加载后调用
         */
        init() {
            // 将全局模块引用保存到命名空间
            if (typeof UserManager !== 'undefined') {
                this.modules.UserManager = UserManager;
            }
            if (typeof AuthManager !== 'undefined') {
                this.modules.AuthManager = AuthManager;
            }
            if (typeof RequestManager !== 'undefined') {
                this.modules.RequestManager = RequestManager;
            }
            if (typeof API !== 'undefined') {
                this.modules.API = API;
            }
            if (typeof ClickManager !== 'undefined') {
                this.modules.ClickManager = ClickManager;
            }
            if (typeof AI_PROVIDERS !== 'undefined') {
                this.modules.AI_PROVIDERS = AI_PROVIDERS;
            }
            if (typeof PushNotificationManager !== 'undefined') {
                this.modules.PushNotificationManager = PushNotificationManager;
            }
            if (typeof WeeklyReportManager !== 'undefined') {
                this.modules.WeeklyReportManager = WeeklyReportManager;
            }
            if (typeof SmartReminderManager !== 'undefined') {
                this.modules.SmartReminderManager = SmartReminderManager;
            }
            
            console.log('SmartScheduler 命名空间已初始化');
        }
    };
    
    // ==================== 全局错误处理 ====================
    
    // 捕获未处理的Promise错误
    global.addEventListener('unhandledrejection', (event) => {
        SmartScheduler.errorBoundary.catch(event.reason, 'promise');
    });
    
    // 捕获全局错误
    global.addEventListener('error', (event) => {
        SmartScheduler.errorBoundary.catch(event.error, 'global');
    });
    
    // 添加CSS动画
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        @keyframes slideOut {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(100%); opacity: 0; }
        }
    `;
    document.head.appendChild(style);
    
    // 导出到全局
    global.SmartScheduler = SmartScheduler;
    global.ErrorBoundary = ErrorBoundary;
    
    // 页面加载完成后初始化
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => SmartScheduler.init());
    } else {
        // DOM已加载，延迟初始化以确保app.js已执行
        setTimeout(() => SmartScheduler.init(), 100);
    }
    
})(typeof window !== 'undefined' ? window : global);
