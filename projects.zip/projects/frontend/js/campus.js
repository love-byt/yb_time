/**
 * 校园场景功能模块 - 已禁用
 * 课程表、考试安排等功能的独立模块已暂时禁用
 */

(function(global) {
    'use strict';

    console.log('[Campus] 校园场景模块已禁用');

    // ==================== 已禁用的导出 ====================
    global.CampusModule = {
        // 课程表功能已禁用
        showSchedule() {
            console.log('[Campus] 课程表功能已禁用');
            if (typeof showToast === 'function') {
                showToast('课程表功能已暂时禁用', 'info');
            }
        },
        
        // 考试周功能已禁用
        showExams() {
            console.log('[Campus] 考试周功能已禁用');
            if (typeof showToast === 'function') {
                showToast('考试周功能已暂时禁用', 'info');
            }
        },
        
        // 添加课程功能已禁用
        showCourseForm(course) {
            console.log('[Campus] 添加课程功能已禁用');
            if (typeof showToast === 'function') {
                showToast('课程表功能已暂时禁用', 'info');
            }
        },
        
        // 添加考试功能已禁用
        showExamForm(exam) {
            console.log('[Campus] 添加考试功能已禁用');
            if (typeof showToast === 'function') {
                showToast('考试周功能已暂时禁用', 'info');
            }
        },
        
        // 保存课程功能已禁用
        saveCourse() {
            console.log('[Campus] 保存课程功能已禁用');
            if (typeof showToast === 'function') {
                showToast('课程表功能已暂时禁用', 'info');
            }
        },
        
        // 保存考试功能已禁用
        saveExam() {
            console.log('[Campus] 保存考试功能已禁用');
            if (typeof showToast === 'function') {
                showToast('考试周功能已暂时禁用', 'info');
            }
        }
    };

})(window);
