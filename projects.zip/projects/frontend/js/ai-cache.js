/**
 * AI分析结果缓存管理器
 * 支持localStorage本地持久化
 */
const AICache = {
    CACHE_PREFIX: 'ai_analysis_',
    CACHE_TTL: 24 * 60 * 60 * 1000, // 24小时（毫秒）
    
    /**
     * 获取缓存键
     * @param {string} type - 分析类型（habit/weekly/completion）
     * @param {string} params - 参数标识
     * @returns {string} 完整缓存键
     */
    _getKey(type, params = '') {
        const user = JSON.parse(localStorage.getItem('user') || '{}');
        const userId = user.id || 'anonymous';
        return `${this.CACHE_PREFIX}${userId}_${type}${params ? '_' + params : ''}`;
    },
    
    /**
     * 获取缓存
     * @param {string} type - 分析类型
     * @param {string} params - 参数标识
     * @returns {Object|null} 缓存数据或null
     */
    get(type, params = '') {
        try {
            const key = this._getKey(type, params);
            const item = localStorage.getItem(key);
            if (!item) return null;
            
            const { data, timestamp } = JSON.parse(item);
            
            // 检查是否过期
            if (Date.now() - timestamp > this.CACHE_TTL) {
                localStorage.removeItem(key);
                return null;
            }
            
            console.log(`[AICache] 命中缓存: ${type}`);
            return data;
        } catch (e) {
            console.error('[AICache] 读取缓存失败:', e);
            return null;
        }
    },
    
    /**
     * 设置缓存
     * @param {string} type - 分析类型
     * @param {Object} data - 缓存数据
     * @param {string} params - 参数标识
     */
    set(type, data, params = '') {
        try {
            const key = this._getKey(type, params);
            const cacheItem = {
                data,
                timestamp: Date.now()
            };
            localStorage.setItem(key, JSON.stringify(cacheItem));
            console.log(`[AICache] 缓存已保存: ${type}`);
        } catch (e) {
            console.error('[AICache] 保存缓存失败:', e);
            // localStorage空间不足时清除旧缓存
            if (e.name === 'QuotaExceededError') {
                this.clearExpired();
            }
        }
    },
    
    /**
     * 清除过期缓存
     */
    clearExpired() {
        const keys = Object.keys(localStorage);
        let cleared = 0;
        
        keys.forEach(key => {
            if (key.startsWith(this.CACHE_PREFIX)) {
                try {
                    const item = JSON.parse(localStorage.getItem(key));
                    if (Date.now() - item.timestamp > this.CACHE_TTL) {
                        localStorage.removeItem(key);
                        cleared++;
                    }
                } catch (e) {
                    localStorage.removeItem(key);
                    cleared++;
                }
            }
        });
        
        console.log(`[AICache] 清除过期缓存: ${cleared} 条`);
    },
    
    /**
     * 清除所有AI缓存
     */
    clear() {
        const keys = Object.keys(localStorage);
        keys.forEach(key => {
            if (key.startsWith(this.CACHE_PREFIX)) {
                localStorage.removeItem(key);
            }
        });
        console.log('[AICache] 所有缓存已清除');
    },
    
    /**
     * 检查缓存是否存在且有效
     * @param {string} type - 分析类型
     * @param {string} params - 参数标识
     * @returns {boolean}
     */
    has(type, params = '') {
        return this.get(type, params) !== null;
    }
};

// ==================== 与API层集成 ====================

/**
 * 带缓存的AI分析请求
 * @param {string} type - 分析类型（habit/weekly/completion）
 * @param {Object} options - 请求选项
 * @returns {Promise<Object>} 分析结果
 */
async function fetchAIAnalysis(type, options = {}) {
    const { days = 7, forceRefresh = false } = options;
    const params = days ? `days${days}` : '';
    
    // 1. 检查缓存（非强制刷新时）
    if (!forceRefresh) {
        const cached = AICache.get(type, params);
        if (cached) {
            return { ...cached, fromCache: true };
        }
    }
    
    // 2. 发起API请求
    const response = await fetch(`/api/analysis/${type}?days=${days}${forceRefresh ? '&force_refresh=true' : ''}`);
    const result = await response.json();
    
    // 3. 缓存成功响应
    if (result.success && !result.cached) {
        AICache.set(type, result, params);
    }
    
    return result;
}

// ==================== 页面加载时恢复缓存 ====================

/**
 * 页面初始化时加载缓存的分析结果
 */
function loadCachedAnalysis() {
    const types = ['habit', 'weekly', 'completion'];
    
    types.forEach(type => {
        const cached = AICache.get(type);
        if (cached && cached.analysis) {
            // 根据类型渲染到对应UI
            renderAnalysisResult(type, cached.analysis, true);
        }
    });
}

// 导出模块
window.AICache = AICache;
window.fetchAIAnalysis = fetchAIAnalysis;
window.loadCachedAnalysis = loadCachedAnalysis;
