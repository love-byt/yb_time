/**
 * 认证管理模块（合并版）
 * 统一处理登录、注册、忘记密码、Token管理、API请求
 * 
 * 功能：
 * 1. 用户登录/注册/忘记密码/重置密码
 * 2. Token存储管理（统一使用localStorage/sessionStorage）
 * 3. 认证状态管理
 * 4. API请求封装
 */

class AuthManager {
    constructor() {
        this.token = null;
        this.user = null;
        this.API_BASE_URL = ''; // 同域部署，使用相对路径
        this._initialized = false;
        this.init();
    }
    
    // ==================== 初始化 ====================
    
    init() {
        // Token现在存储在httpOnly Cookie中，无法通过JS读取
        // 只从存储中恢复用户信息
        const userStr = localStorage.getItem('user') || sessionStorage.getItem('user');
        
        if (userStr) {
            try {
                this.user = JSON.parse(userStr);
            } catch (e) {
                console.error('用户数据解析失败');
                this.clearAuth();
            }
        }
        
        this._initialized = true;
    }
    
    // ==================== 状态检查 ====================
    
    /**
     * 检查登录状态
     * 注意：Token 存储在 httpOnly Cookie 中，无法通过 JS 读取
     * 通过检查 user 对象和发送验证请求来确认登录状态
     */
    isLoggedIn() {
        // 如果本地有用户信息，认为已登录
        // 实际验证由后端通过 Cookie 完成
        return !!this.user;
    }
    
    /**
     * 获取 Token
     * 注意：由于使用 httpOnly Cookie，前端无法直接获取 Token
     * 此方法返回 null，Token 会自动随请求发送到后端
     */
    getToken() {
        console.warn('Token 存储在 httpOnly Cookie 中，前端无法直接访问');
        return null;
    }
    
    getUser() {
        return this.user;
    }
    
    getUserId() {
        return this.user ? this.user.id : null;
    }
    
    // ==================== 存储管理 ====================
    
    _getStorage(rememberMe = false) {
        return rememberMe ? localStorage : sessionStorage;
    }
    
    /**
     * 保存认证信息
     * 注意：Token 现在由后端通过 httpOnly Cookie 设置，前端只保存用户信息
     */
    saveAuth(token, user, rememberMe = false) {
        const storage = this._getStorage(rememberMe);
        // 不再存储 token 到 localStorage（由后端 Cookie 管理）
        storage.setItem('user', JSON.stringify(user));
        
        this.user = user;
        // token 参数保留用于兼容性，但实际不使用
        this.token = 'stored_in_cookie';
    }
    
    /**
     * 清除认证信息
     * 发送请求到后端清除 httpOnly Cookie
     */
    async clearAuth() {
        this.token = null;
        this.user = null;
        
        // 清除本地存储
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        sessionStorage.removeItem('token');
        sessionStorage.removeItem('user');
        
        // 通知后端清除 Cookie
        try {
            await fetch(`${this.API_BASE_URL}/api/auth/logout`, {
                method: 'POST',
                credentials: 'include'  // 包含 Cookie
            });
        } catch (e) {
            console.warn('清除后端 Cookie 失败:', e);
        }
    }
    
    // ==================== 登出 ====================
    
    async logout() {
        await this.clearAuth();
        window.location.href = 'login.html';
    }
    
    // ==================== API请求封装 ====================
    
    async apiRequest(url, options = {}) {
        const headers = {
            'Content-Type': 'application/json',
            ...options.headers
        };
        
        // Token 现在通过 httpOnly Cookie 自动发送，不需要手动设置 Authorization 头
        // 但保留向后兼容：如果本地有 token（旧版本），仍然使用
        if (this.token && this.token !== 'stored_in_cookie') {
            headers['Authorization'] = `Bearer ${this.token}`;
        }
        
        const response = await fetch(`${this.API_BASE_URL}${url}`, {
            ...options,
            headers,
            credentials: 'include'  // 关键：包含 httpOnly Cookie
        });
        
        // Token过期处理
        if (response.status === 401) {
            await this.logout();
            throw new Error('登录已过期，请重新登录');
        }
        
        return response;
    }
    
    // ==================== 登录/注册API ====================
    
    async login(username, password, rememberMe = false) {
        const response = await fetch(`${this.API_BASE_URL}/api/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password }),
            credentials: 'include'  // 关键：接收 httpOnly Cookie
        });
        
        const data = await response.json();
        
        if (data.success) {
            // Token 现在存储在 httpOnly Cookie 中，由后端设置
            // 只保存用户信息到本地
            this.saveAuth(null, data.user, rememberMe);
        }
        
        return data;
    }
    
    async register(userData) {
        const response = await fetch(`${this.API_BASE_URL}/api/auth/register`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(userData),
            credentials: 'include'  // 关键：接收 httpOnly Cookie
        });
        
        return response.json();
    }
    
    async forgotPassword(usernameOrEmail) {
        const response = await fetch(`${this.API_BASE_URL}/api/auth/forgot-password`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username_or_email: usernameOrEmail })
        });
        
        return response.json();
    }
    
    async resetPassword(token, newPassword) {
        const response = await fetch(`${this.API_BASE_URL}/api/auth/reset-password`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ token, new_password: newPassword })
        });
        
        return response.json();
    }
    
    async getProfile() {
        if (!this.isLoggedIn()) {
            return null;
        }
        
        try {
            const response = await this.apiRequest('/api/auth/profile');
            const data = await response.json();
            
            if (data.success) {
                this.user = data.user;
                return this.user;
            }
        } catch (error) {
            console.error('获取用户信息失败:', error);
        }
        
        return null;
    }
    
    async getAIQuota() {
        try {
            const response = await this.apiRequest('/api/user/quota');
            const data = await response.json();
            
            if (data.success) {
                return data.data;
            }
        } catch (error) {
            console.error('获取AI额度失败:', error);
        }
        
        return { used: 0, quota: 10, remaining: 10 };
    }
    
    async saveApiKey(apiKey) {
        try {
            const response = await this.apiRequest('/api/user/apikey', {
                method: 'POST',
                body: JSON.stringify({ api_key: apiKey })
            });
            
            return response.json();
        } catch (error) {
            console.error('保存API Key失败:', error);
            return { success: false, message: '保存失败' };
        }
    }
    
    // ==================== 表单辅助方法 ====================
    
    static showMessage(message, type, form = null) {
        // 移除已有的消息
        const existingMsg = document.querySelector('.error-message, .success-message, .info-message');
        if (existingMsg) {
            existingMsg.remove();
        }
        
        const msgDiv = document.createElement('div');
        msgDiv.className = type === 'error' ? 'error-message' : 
                           type === 'success' ? 'success-message' : 'info-message';
        msgDiv.textContent = message;
        
        if (form) {
            form.insertBefore(msgDiv, form.firstChild);
        }
        
        // 5秒后自动移除
        setTimeout(() => {
            msgDiv.remove();
        }, 5000);
    }
    
    static setButtonLoading(button, loading, text = null) {
        if (loading) {
            button.dataset.originalText = button.textContent;
            button.classList.add('loading');
            button.disabled = true;
            button.textContent = text || '处理中...';
        } else {
            button.classList.remove('loading');
            button.disabled = false;
            button.textContent = button.dataset.originalText || button.textContent;
        }
    }
}

// ==================== 登录页面表单处理 ====================

/**
 * 初始化登录页面表单
 * 在login.html页面加载时调用
 */
function initAuthForms() {
    // DOM元素
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    const forgotPasswordForm = document.getElementById('forgotPasswordForm');
    const resetPasswordForm = document.getElementById('resetPasswordForm');
    const showRegisterLink = document.getElementById('showRegister');
    const showLoginLink = document.getElementById('showLogin');
    const forgotPasswordLink = document.getElementById('forgotPasswordLink');
    const backToLoginLink = document.getElementById('backToLogin');
    
    // 表单切换
    function showForm(formId) {
        [loginForm, registerForm, forgotPasswordForm, resetPasswordForm].forEach(form => {
            if (form) form.style.display = 'none';
        });
        const targetForm = document.getElementById(formId);
        if (targetForm) targetForm.style.display = 'block';
    }
    
    // 绑定切换事件
    if (showRegisterLink) {
        showRegisterLink.addEventListener('click', (e) => {
            e.preventDefault();
            showForm('registerForm');
        });
    }
    
    if (showLoginLink) {
        showLoginLink.addEventListener('click', (e) => {
            e.preventDefault();
            showForm('loginForm');
        });
    }
    
    if (forgotPasswordLink) {
        forgotPasswordLink.addEventListener('click', (e) => {
            e.preventDefault();
            showForm('forgotPasswordForm');
        });
    }
    
    if (backToLoginLink) {
        backToLoginLink.addEventListener('click', (e) => {
            e.preventDefault();
            showForm('loginForm');
        });
    }
    
    // 登录处理
    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const username = document.getElementById('loginUsername').value.trim();
            const password = document.getElementById('loginPassword').value;
            const rememberMe = document.getElementById('rememberMe').checked;
            
            const submitBtn = loginForm.querySelector('button[type="submit"]');
            AuthManager.setButtonLoading(submitBtn, true, '登录中...');
            
            try {
                const data = await authManager.login(username, password, rememberMe);
                
                if (data.success) {
                    AuthManager.showMessage('登录成功！正在跳转...', 'success');
                    setTimeout(() => {
                        window.location.href = 'index.html';
                    }, 1000);
                } else {
                    AuthManager.showMessage(data.message || '登录失败', 'error');
                }
            } catch (error) {
                AuthManager.showMessage('网络错误，请稍后重试', 'error');
                console.error('登录错误:', error);
            } finally {
                AuthManager.setButtonLoading(submitBtn, false);
            }
        });
    }
    
    // 注册处理
    if (registerForm) {
        registerForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const username = document.getElementById('regUsername').value.trim();
            const email = document.getElementById('regEmail').value.trim();
            const nickname = document.getElementById('regNickname').value.trim();
            const password = document.getElementById('regPassword').value;
            const confirmPassword = document.getElementById('regConfirmPassword').value;
            
            // 验证密码
            if (password !== confirmPassword) {
                AuthManager.showMessage('两次输入的密码不一致', 'error', registerForm);
                return;
            }
            
            if (password.length < 6) {
                AuthManager.showMessage('密码长度至少6个字符', 'error', registerForm);
                return;
            }
            
            const submitBtn = registerForm.querySelector('button[type="submit"]');
            AuthManager.setButtonLoading(submitBtn, true, '注册中...');
            
            try {
                const data = await authManager.register({
                    username,
                    password,
                    email: email || null,
                    nickname: nickname || username
                });
                
                if (data.success) {
                    AuthManager.showMessage('注册成功！请登录', 'success', registerForm);
                    
                    setTimeout(() => {
                        showForm('loginForm');
                        document.getElementById('loginUsername').value = username;
                    }, 1500);
                } else {
                    AuthManager.showMessage(data.message || '注册失败', 'error', registerForm);
                }
            } catch (error) {
                AuthManager.showMessage('网络错误，请稍后重试', 'error', registerForm);
                console.error('注册错误:', error);
            } finally {
                AuthManager.setButtonLoading(submitBtn, false);
            }
        });
    }
    
    // 忘记密码处理
    if (forgotPasswordForm) {
        forgotPasswordForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const usernameOrEmail = document.getElementById('forgotEmail').value.trim();
            
            const submitBtn = forgotPasswordForm.querySelector('button[type="submit"]');
            AuthManager.setButtonLoading(submitBtn, true, '发送中...');
            
            try {
                const data = await authManager.forgotPassword(usernameOrEmail);
                
                if (data.success) {
                    if (data.reset_token) {
                        AuthManager.showMessage('验证成功（开发模式）', 'success', forgotPasswordForm);
                        
                        setTimeout(() => {
                            document.getElementById('resetToken').value = data.reset_token;
                            showForm('resetPasswordForm');
                        }, 1000);
                    } else {
                        AuthManager.showMessage('重置链接已发送到您的邮箱', 'success', forgotPasswordForm);
                    }
                } else {
                    AuthManager.showMessage(data.message || '发送失败', 'error', forgotPasswordForm);
                }
            } catch (error) {
                AuthManager.showMessage('网络错误，请稍后重试', 'error', forgotPasswordForm);
                console.error('忘记密码错误:', error);
            } finally {
                AuthManager.setButtonLoading(submitBtn, false);
            }
        });
    }
    
    // 重置密码处理
    if (resetPasswordForm) {
        resetPasswordForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const token = document.getElementById('resetToken').value;
            const newPassword = document.getElementById('newPassword').value;
            const confirmPassword = document.getElementById('confirmNewPassword').value;
            
            // 验证密码
            if (newPassword !== confirmPassword) {
                AuthManager.showMessage('两次输入的密码不一致', 'error', resetPasswordForm);
                return;
            }
            
            if (newPassword.length < 6) {
                AuthManager.showMessage('密码长度至少6个字符', 'error', resetPasswordForm);
                return;
            }
            
            const submitBtn = resetPasswordForm.querySelector('button[type="submit"]');
            AuthManager.setButtonLoading(submitBtn, true, '重置中...');
            
            try {
                const data = await authManager.resetPassword(token, newPassword);
                
                if (data.success) {
                    AuthManager.showMessage('密码重置成功！请登录', 'success', resetPasswordForm);
                    
                    setTimeout(() => {
                        showForm('loginForm');
                    }, 1500);
                } else {
                    AuthManager.showMessage(data.message || '重置失败', 'error', resetPasswordForm);
                }
            } catch (error) {
                AuthManager.showMessage('网络错误，请稍后重试', 'error', resetPasswordForm);
                console.error('重置密码错误:', error);
            } finally {
                AuthManager.setButtonLoading(submitBtn, false);
            }
        });
    }
    
    // 检查URL参数
    const urlParams = new URLSearchParams(window.location.search);
    const resetToken = urlParams.get('reset_token');
    
    if (resetToken) {
        document.getElementById('resetToken').value = resetToken;
        showForm('resetPasswordForm');
    }
}

// 创建全局实例
const authManager = new AuthManager();

// 导出
window.AuthManager = AuthManager;
window.authManager = authManager;
window.initAuthForms = initAuthForms;

// 检查是否已登录（在登录页面时）
if (window.location.pathname.includes('login.html')) {
    if (authManager.isLoggedIn()) {
        window.location.href = 'index.html';
    }
}
