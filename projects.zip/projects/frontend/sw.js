/**
 * Service Worker - 智能日程助手
 * 处理推送通知和离线缓存
 */

const CACHE_NAME = 'smart-scheduler-v1';
const STATIC_ASSETS = [
    '/',
    '/index.html',
    '/app.js',
    'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap',
    'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css',
    'https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js'
];

// 安装事件 - 缓存静态资源
self.addEventListener('install', event => {
    console.log('[Service Worker] 安装中...');
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then(cache => {
                console.log('[Service Worker] 缓存静态资源');
                return cache.addAll(STATIC_ASSETS);
            })
            .then(() => self.skipWaiting())
            .catch(err => console.error('[Service Worker] 缓存失败:', err))
    );
});

// 激活事件 - 清理旧缓存
self.addEventListener('activate', event => {
    console.log('[Service Worker] 激活');
    event.waitUntil(
        caches.keys().then(cacheNames => {
            return Promise.all(
                cacheNames
                    .filter(name => name !== CACHE_NAME)
                    .map(name => {
                        console.log('[Service Worker] 删除旧缓存:', name);
                        return caches.delete(name);
                    })
            );
        }).then(() => self.clients.claim())
    );
});

// 推送事件 - 处理推送通知
self.addEventListener('push', event => {
    console.log('[Service Worker] 收到推送消息');
    
    let data = {
        title: '⏰ 任务提醒',
        body: '您有一个任务需要处理',
        icon: '/static/icon.png',
        badge: '/static/badge.png',
        tag: 'task-reminder',
        requireInteraction: true,
        actions: [
            { action: 'complete', title: '✅ 标记完成' },
            { action: 'delay', title: '⏰ 稍后提醒' },
            { action: 'view', title: '👁️ 查看详情' }
        ]
    };
    
    // 解析推送数据
    if (event.data) {
        try {
            const pushData = event.data.json();
            data = { ...data, ...pushData };
        } catch (e) {
            data.body = event.data.text() || data.body;
        }
    }
    
    const options = {
        body: data.body,
        icon: data.icon || '/static/icon.png',
        badge: data.badge || '/static/badge.png',
        tag: data.tag || 'task-reminder',
        requireInteraction: data.requireInteraction !== false,
        actions: data.actions || [
            { action: 'complete', title: '✅ 标记完成' },
            { action: 'delay', title: '⏰ 稍后提醒' }
        ],
        data: data.data || {},
        vibrate: [200, 100, 200],
        timestamp: Date.now()
    };
    
    event.waitUntil(
        self.registration.showNotification(data.title, options)
            .then(() => {
                // 通知显示成功
                console.log('[Service Worker] 通知显示成功');
            })
            .catch(err => {
                console.error('[Service Worker] 通知显示失败:', err);
            })
    );
});

// 通知点击事件
self.addEventListener('notificationclick', event => {
    console.log('[Service Worker] 通知被点击:', event.action);
    
    event.notification.close();
    
    const taskId = event.notification.data?.taskId;
    const action = event.action;
    
    // 根据用户操作执行不同动作
    if (action === 'complete' && taskId) {
        // 标记任务完成
        event.waitUntil(
            fetch(`/api/tasks/${taskId}/complete`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                }
            })
            .then(response => {
                if (response.ok) {
                    console.log('[Service Worker] 任务已标记完成');
                    // 通知所有客户端刷新
                    self.clients.matchAll().then(clients => {
                        clients.forEach(client => {
                            client.postMessage({
                                type: 'TASK_COMPLETED',
                                taskId: taskId
                            });
                        });
                    });
                }
            })
            .catch(err => console.error('[Service Worker] 完成任务失败:', err))
        );
    } else if (action === 'delay' && taskId) {
        // 延后提醒 (30分钟后)
        event.waitUntil(
            fetch(`/api/reminders/delay`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    task_id: taskId,
                    delay_minutes: 30
                })
            })
            .then(response => {
                if (response.ok) {
                    console.log('[Service Worker] 提醒已延后');
                }
            })
            .catch(err => console.error('[Service Worker] 延后提醒失败:', err))
        );
    } else {
        // 默认：打开应用
        event.waitUntil(
            self.clients.matchAll({ type: 'window', includeUncontrolled: true })
                .then(clientList => {
                    // 如果已有窗口打开，则聚焦
                    for (const client of clientList) {
                        if (client.url === '/' || client.url.includes(self.location.origin)) {
                            return client.focus();
                        }
                    }
                    // 否则打开新窗口
                    return self.clients.openWindow('/');
                })
        );
    }
});

// 通知关闭事件
self.addEventListener('notificationclose', event => {
    console.log('[Service Worker] 通知被关闭');
});

// 消息事件 - 接收来自主页面的消息
self.addEventListener('message', event => {
    console.log('[Service Worker] 收到消息:', event.data);
    
    if (event.data && event.data.type === 'SKIP_WAITING') {
        self.skipWaiting();
    }
    
    if (event.data && event.data.type === 'SHOW_NOTIFICATION') {
        const { title, options } = event.data;
        self.registration.showNotification(title, options);
    }
});

// 后台同步事件
self.addEventListener('sync', event => {
    console.log('[Service Worker] 后台同步:', event.tag);
    
    if (event.tag === 'sync-tasks') {
        event.waitUntil(
            // 同步任务数据
            fetch('/api/tasks')
                .then(response => response.json())
                .then(data => {
                    console.log('[Service Worker] 任务同步成功');
                })
                .catch(err => console.error('[Service Worker] 任务同步失败:', err))
        );
    }
});

// 定期同步事件 (Periodic Background Sync)
self.addEventListener('periodicsync', event => {
    console.log('[Service Worker] 定期同步:', event.tag);
    
    if (event.tag === 'check-reminders') {
        event.waitUntil(
            fetch('/api/reminders/pending')
                .then(response => response.json())
                .then(data => {
                    if (data.reminders && data.reminders.length > 0) {
                        // 显示通知
                        data.reminders.forEach(reminder => {
                            self.registration.showNotification('⏰ 任务提醒', {
                                body: `任务即将到期: ${reminder.task_title || '未知任务'}`,
                                tag: `reminder-${reminder.id}`
                            });
                        });
                    }
                })
        );
    }
});

console.log('[Service Worker] 已加载');
