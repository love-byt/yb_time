# Projects - 智能日程助手项目代码

本文件夹是智能日程助手项目的根目录，包含完整的项目代码和配置。

## 项目架构

项目采用**前后端分离**架构：

- **后端**: Flask + Python 3.12 + SQLite
- **前端**: HTML5 + CSS3 + JavaScript (ES6+)

## 目录结构

```
projects/
├── backend/          # 后端代码
├── frontend/         # 前端代码
├── instance/         # 实例数据 (数据库等)
├── scripts/          # 脚本工具
├── .env.example      # 环境变量示例
├── AGENTS.md         # AI Agent 配置
├── app.yaml          # 应用配置
├── Dockerfile        # Docker 构建文件
└── readme.txt        # 本说明的文本版本
```

## 配置文件

### .env.example

环境变量示例文件，包含所有需要配置的环境变量：

| 变量 | 说明 | 示例 |
|------|------|------|
| `SECRET_KEY` | Flask 密钥 | `your-secret-key` |
| `DATABASE_URL` | 数据库连接 | `sqlite:///instance/schedule.db` |
| `AI_API_KEY` | AI 服务密钥 | `sk-...` |
| `REDIS_URL` | Redis 连接（可选）| `redis://localhost:6379/0` |

复制并编辑：
```bash
cp .env.example .env
# 编辑 .env 文件
```

### .gitignore

Git 版本控制忽略配置：
- `__pycache__/` - Python 缓存
- `.env` - 环境变量
- `instance/` - 实例数据
- `*.db` - 数据库文件
- `node_modules/` - Node 模块

## 子项目说明

### [backend/](./backend/) - 后端服务

基于 Flask 框架的 RESTful API 服务。

**主要功能**:
- RESTful API 服务
- 数据持久化 (SQLAlchemy)
- AI 算法执行
- 用户认证 (JWT)
- 定时任务调度

**技术栈**:
- Flask 3.1
- SQLAlchemy + SQLite
- Alembic (数据库迁移)
- pytest (测试)
- Redis / 内存缓存

### [frontend/](./frontend/) - 前端界面

基于原生 Web 技术的用户界面。

**主要功能**:
- 任务管理界面
- 标签/分类管理
- AI 排序展示
- 统计图表 (Chart.js)
- PWA 离线支持

**技术栈**:
- HTML5 语义化标签
- CSS3 (Flexbox/Grid)
- JavaScript ES6+
- Chart.js 图表库
- Font Awesome 图标
- Service Worker

## 快速开始

### 环境要求

- Python 3.12+
- pip
- 现代浏览器

### 安装步骤

1. **配置环境**
   ```bash
   cp .env.example .env
   # 编辑 .env 文件
   ```

2. **安装后端依赖**
   ```bash
   cd backend
   pip install -r requirements.txt
   ```

3. **初始化数据库**
   ```bash
   python migrate.py upgrade
   ```

4. **启动服务**
   ```bash
   python app.py
   ```

5. **访问应用**
   
   打开 http://localhost:5000

## 开发指南

### 后端开发

```bash
cd backend

# 启动开发服务器
python app.py

# 运行测试
pytest

# 运行测试（带覆盖率）
pytest --cov=./ --cov-report=html

# 数据库迁移
python migrate.py migrate -m "描述"
python migrate.py upgrade
```

### 前端开发

前端为静态文件，直接编辑后刷新浏览器即可。

```bash
cd frontend

# 如需使用 npm 包
npm install
```

## 部署说明

### Docker 部署

```bash
# 构建镜像
docker build -t smart-schedule .

# 运行容器
docker run -p 5000:5000 smart-schedule
```

### 手动部署

1. 配置生产环境变量
2. 初始化数据库
3. 使用 Gunicorn 启动:
   ```bash
   gunicorn -w 4 -b 0.0.0.0:5000 "app:create_app()"
   ```

## 版本信息

- **当前版本**: 3.2.0
- **发布日期**: 2026-04-01

### 版本历史

| 版本 | 日期 | 更新内容 |
|------|------|----------|
| 3.2.0 | 2026-04-01 | AI排序优化、时间解析、前端认证合并 |
| 3.0.1 | 2026-03-15 | 基础功能、认证模块 |

## 贡献规范

### 代码规范

- **Python**: PEP 8
- **JavaScript**: ESLint
- **提交信息**: 语义化版本

### 提交类型

```
feat: 新功能
fix: 修复
docs: 文档
test: 测试
refactor: 重构
style: 格式
chore: 构建/工具
```

## 许可证

MIT License

Copyright (c) 2026 智能日程助手团队
