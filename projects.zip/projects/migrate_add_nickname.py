#!/usr/bin/env python3
"""数据库迁移脚本：添加nickname字段到User表"""

import sqlite3
import os

def migrate():
    db_path = os.path.join(os.path.dirname(__file__), 'instance', 'schedule.db')
    
    if not os.path.exists(db_path):
        print("数据库文件不存在，将在首次运行时自动创建")
        return
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        # 检查nickname字段是否已存在
        cursor.execute("PRAGMA table_info(user)")
        columns = [column[1] for column in cursor.fetchall()]
        
        if 'nickname' not in columns:
            print("添加nickname字段到user表...")
            cursor.execute("ALTER TABLE user ADD COLUMN nickname VARCHAR(50)")
            conn.commit()
            print("✅ nickname字段添加成功")
        else:
            print("✅ nickname字段已存在，无需迁移")
            
    except Exception as e:
        print(f"❌ 迁移失败: {e}")
        conn.rollback()
    finally:
        conn.close()

if __name__ == "__main__":
    migrate()
