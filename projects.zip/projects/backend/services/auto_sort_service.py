"""
自动排序服务
定时重新排序任务，基于最新状态动态调整
"""
import asyncio
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Callable
import json

from utils.ai_sorter import ai_sorter
from utils.dynamic_weight_adjuster import DynamicWeightAdjuster, get_weight_adjuster
from database.db_manager import get_db

logger = logging.getLogger(__name__)


class AutoSortService:
    """
    自动排序服务
    
    功能：
    1. 定时自动重新排序任务
    2. 任务状态变化时触发重排序
    3. 每天早上根据最新状态生成新排序
    4. 检测紧急任务插入并调整排序
    """
    
    def __init__(self):
        self.db = None
        self.ai_sorter = None
        self.weight_adjuster: Optional[DynamicWeightAdjuster] = None
        self._running = False
        self._callbacks: List[Callable] = []
        
        # 默认配置
        self.config = {
            'auto_sort_enabled': True,
            'daily_sort_time': '08:00',  # 每天早上8点自动排序
            'urgency_threshold_minutes': 30,  # 紧急任务阈值
            'state_change_delay_seconds': 5,  # 状态变化后延迟排序
            'max_sort_per_day': 10  # 每天最大自动排序次数
        }
    
    def initialize(self, db_connection=None):
        """初始化服务"""
        self.db = db_connection or get_db()
        self.ai_sorter = ai_sorter
        self.weight_adjuster = get_weight_adjuster(self.db)
        logger.info("自动排序服务已初始化")
    
    def register_callback(self, callback: Callable):
        """注册排序完成回调"""
        self._callbacks.append(callback)
    
    def unregister_callback(self, callback: Callable):
        """注销回调"""
        if callback in self._callbacks:
            self._callbacks.remove(callback)
    
    def _notify_callbacks(self, user_id: int, result: Dict):
        """通知所有回调"""
        for callback in self._callbacks:
            try:
                callback(user_id, result)
            except Exception as e:
                logger.error(f"回调执行失败: {e}")
    
    # ==================== 定时排序 ====================
    
    async def start_scheduler(self):
        """启动定时调度器"""
        if self._running:
            logger.warning("调度器已在运行")
            return
        
        self._running = True
        logger.info("自动排序调度器已启动")
        
        while self._running:
            try:
                now = datetime.now()
                target_time = datetime.strptime(
                    self.config['daily_sort_time'], 
                    '%H:%M'
                ).replace(year=now.year, month=now.month, day=now.day)
                
                # 如果今天的时间已过，设置为明天
                if target_time <= now:
                    target_time += timedelta(days=1)
                
                # 计算等待时间
                wait_seconds = (target_time - now).total_seconds()
                
                logger.info(f"下次自动排序时间: {target_time}, 等待 {wait_seconds/60:.1f} 分钟")
                
                # 等待到目标时间
                await asyncio.sleep(wait_seconds)
                
                # 执行每日自动排序
                if self.config['auto_sort_enabled']:
                    await self.daily_auto_sort()
                    
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"调度器错误: {e}")
                await asyncio.sleep(60)  # 出错后等待1分钟重试
    
    def stop_scheduler(self):
        """停止调度器"""
        self._running = False
        logger.info("自动排序调度器已停止")
    
    async def daily_auto_sort(self) -> Dict:
        """
        每日自动排序所有用户的任务
        
        Returns:
            排序结果统计
        """
        logger.info("开始每日自动排序...")
        
        stats = {
            'total_users': 0,
            'sorted_users': 0,
            'failed_users': 0,
            'total_tasks': 0,
            'details': []
        }
        
        try:
            cursor = self.db.cursor()
            
            # 获取所有活跃用户（最近7天有任务的用户）
            cursor.execute("""
                SELECT DISTINCT t.user_id, u.username
                FROM tasks t
                JOIN users u ON t.user_id = u.id
                WHERE t.status IN ('pending', 'in_progress')
                    AND t.deleted = 0
                    AND (t.updated_at >= datetime('now', '-7 days')
                         OR t.created_at >= datetime('now', '-7 days'))
            """)
            
            users = cursor.fetchall()
            stats['total_users'] = len(users)
            
            for user_id, username in users:
                try:
                    result = await self.sort_user_tasks(user_id)
                    
                    if result.get('success'):
                        stats['sorted_users'] += 1
                        stats['total_tasks'] += result.get('task_count', 0)
                        stats['details'].append({
                            'user_id': user_id,
                            'username': username,
                            'status': 'success',
                            'task_count': result.get('task_count', 0),
                            'ai_mode': result.get('ai_mode', False)
                        })
                    else:
                        stats['failed_users'] += 1
                        stats['details'].append({
                            'user_id': user_id,
                            'username': username,
                            'status': 'failed',
                            'message': result.get('message')
                        })
                        
                except Exception as e:
                    logger.error(f"为用户 {user_id} 排序失败: {e}")
                    stats['failed_users'] += 1
            
            logger.info(f"每日自动排序完成: {stats['sorted_users']}/{stats['total_users']} 用户成功")
            
        except Exception as e:
            logger.error(f"每日自动排序失败: {e}")
        
        return stats
    
    async def sort_user_tasks(self, user_id: int, reason: str = 'daily') -> Dict:
        """
        为指定用户排序任务
        
        Args:
            user_id: 用户ID
            reason: 排序原因 (daily, urgent, state_change, manual)
            
        Returns:
            排序结果
        """
        try:
            # 检查今日排序次数
            if not self._check_sort_limit(user_id):
                return {'success': False, 'message': '今日自动排序次数已达上限'}
            
            # 先尝试自动调整权重
            weight_result = self.weight_adjuster.auto_adjust_weights(user_id)
            if weight_result.get('success') and weight_result.get('adjustments'):
                logger.info(f"用户 {user_id} 权重已自动调整: {len(weight_result['adjustments'])} 项")
            
            # 执行排序
            result = self.ai_sorter.sort_tasks_for_user(user_id)
            
            if result.get('success'):
                # 记录排序历史
                self._record_sort_history(user_id, result, reason)
                
                # 通知回调
                self._notify_callbacks(user_id, result)
                
                return {
                    'success': True,
                    'task_count': len(result.get('sorted_tasks', [])),
                    'ai_mode': result.get('ai_mode', False),
                    'weights_adjusted': len(weight_result.get('adjustments', [])),
                    'reason': reason
                }
            else:
                return {'success': False, 'message': result.get('message')}
                
        except Exception as e:
            logger.error(f"排序用户 {user_id} 任务失败: {e}")
            return {'success': False, 'message': str(e)}
    
    def _check_sort_limit(self, user_id: int) -> bool:
        """检查用户今日排序次数是否超限"""
        try:
            cursor = self.db.cursor()
            cursor.execute("""
                SELECT COUNT(*) FROM auto_sort_history
                WHERE user_id = ? 
                    AND created_at >= date('now')
                    AND reason != 'manual'
            """, (user_id,))
            
            count = cursor.fetchone()[0]
            return count < self.config['max_sort_per_day']
            
        except Exception as e:
            logger.error(f"检查排序限制失败: {e}")
            return True
    
    def _record_sort_history(self, user_id: int, result: Dict, reason: str):
        """记录排序历史"""
        try:
            cursor = self.db.cursor()
            cursor.execute("""
                INSERT INTO auto_sort_history 
                (user_id, reason, task_count, ai_mode, weights_used, created_at)
                VALUES (?, ?, ?, ?, ?, datetime('now'))
            """, (
                user_id,
                reason,
                len(result.get('sorted_tasks', [])),
                result.get('ai_mode', False),
                json.dumps(result.get('weights', {}))
            ))
            self.db.commit()
        except Exception as e:
            logger.error(f"记录排序历史失败: {e}")
    
    # ==================== 事件驱动排序 ====================
    
    async def on_task_state_change(self, user_id: int, task_id: int, new_state: str):
        """
        任务状态变化时触发
        
        Args:
            user_id: 用户ID
            task_id: 任务ID
            new_state: 新状态
        """
        if not self.config['auto_sort_enabled']:
            return
        
        # 延迟执行，避免频繁排序
        await asyncio.sleep(self.config['state_change_delay_seconds'])
        
        # 检查是否还有其他待处理的状态变化
        if self._has_pending_changes(user_id):
            return
        
        logger.info(f"任务 {task_id} 状态变为 {new_state}，触发自动排序")
        
        result = await self.sort_user_tasks(user_id, reason='state_change')
        
        if result.get('success'):
            logger.info(f"状态变化触发的排序完成: {result['task_count']} 个任务")
    
    async def on_urgent_task_added(self, user_id: int, task_id: int):
        """
        紧急任务添加时触发
        
        Args:
            user_id: 用户ID
            task_id: 任务ID
        """
        if not self.config['auto_sort_enabled']:
            return
        
        logger.info(f"紧急任务 {task_id} 添加，触发自动排序")
        
        result = await self.sort_user_tasks(user_id, reason='urgent')
        
        if result.get('success'):
            logger.info(f"紧急任务触发的排序完成: {result['task_count']} 个任务")
    
    async def on_task_completed(self, user_id: int, task_id: int, execution_feedback: Dict):
        """
        任务完成时触发
        
        Args:
            user_id: 用户ID
            task_id: 任务ID
            execution_feedback: 执行反馈数据
        """
        # 保存执行反馈
        self._save_execution_feedback(user_id, task_id, execution_feedback)
        
        # 检查是否需要立即重新排序
        if execution_feedback.get('significantly_delayed'):
            logger.info(f"任务 {task_id} 严重延迟，触发重新排序")
            await self.sort_user_tasks(user_id, reason='state_change')
    
    def _has_pending_changes(self, user_id: int) -> bool:
        """检查是否有待处理的状态变化"""
        # 简化实现，实际可以使用队列或缓存
        return False
    
    def _save_execution_feedback(self, user_id: int, task_id: int, feedback: Dict):
        """保存任务执行反馈"""
        try:
            cursor = self.db.cursor()
            cursor.execute("""
                INSERT OR REPLACE INTO sort_execution_feedback 
                (task_id, user_id, dimension_scores, actual_duration, estimated_duration,
                 execution_order, ai_recommended_order, on_time, completed_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
            """, (
                task_id,
                user_id,
                json.dumps(feedback.get('dimension_scores', {})),
                feedback.get('actual_duration'),
                feedback.get('estimated_duration'),
                feedback.get('execution_order'),
                feedback.get('ai_recommended_order'),
                feedback.get('on_time', False)
            ))
            self.db.commit()
        except Exception as e:
            logger.error(f"保存执行反馈失败: {e}")
    
    # ==================== 配置管理 ====================
    
    def get_config(self, user_id: int) -> Dict:
        """获取用户配置"""
        try:
            cursor = self.db.cursor()
            cursor.execute("""
                SELECT config FROM auto_sort_config WHERE user_id = ?
            """, (user_id,))
            
            row = cursor.fetchone()
            if row:
                return {**self.config, **json.loads(row[0])}
            else:
                return self.config.copy()
                
        except Exception as e:
            logger.error(f"获取配置失败: {e}")
            return self.config.copy()
    
    def update_config(self, user_id: int, new_config: Dict) -> Dict:
        """更新用户配置"""
        try:
            # 合并配置
            config = self.get_config(user_id)
            config.update(new_config)
            
            cursor = self.db.cursor()
            cursor.execute("""
                INSERT OR REPLACE INTO auto_sort_config 
                (user_id, config, updated_at)
                VALUES (?, ?, datetime('now'))
            """, (user_id, json.dumps(config)))
            self.db.commit()
            
            return {'success': True, 'config': config}
            
        except Exception as e:
            logger.error(f"更新配置失败: {e}")
            return {'success': False, 'message': str(e)}
    
    def get_sort_history(self, user_id: int, limit: int = 30) -> List[Dict]:
        """获取排序历史"""
        try:
            cursor = self.db.cursor()
            cursor.execute("""
                SELECT reason, task_count, ai_mode, created_at
                FROM auto_sort_history
                WHERE user_id = ?
                ORDER BY created_at DESC
                LIMIT ?
            """, (user_id, limit))
            
            return [
                {
                    'reason': row[0],
                    'reason_name': self._get_reason_name(row[0]),
                    'task_count': row[1],
                    'ai_mode': row[2],
                    'created_at': row[3]
                }
                for row in cursor.fetchall()
            ]
            
        except Exception as e:
            logger.error(f"获取排序历史失败: {e}")
            return []
    
    def _get_reason_name(self, reason: str) -> str:
        """获取原因名称"""
        names = {
            'daily': '每日自动排序',
            'urgent': '紧急任务触发',
            'state_change': '状态变化触发',
            'manual': '手动触发'
        }
        return names.get(reason, reason)


# 全局服务实例
_auto_sort_service: Optional[AutoSortService] = None


def get_auto_sort_service(db_connection=None) -> AutoSortService:
    """获取自动排序服务实例"""
    global _auto_sort_service
    if _auto_sort_service is None:
        _auto_sort_service = AutoSortService()
        _auto_sort_service.initialize(db_connection)
    return _auto_sort_service
