"""
任务状态跟踪服务
全程记录任务执行轨迹，形成完整的历史数据档案
"""

from datetime import datetime
from typing import Dict, List, Optional, Any
import json
import logging

from database.db_manager import get_db
from models.task_history import TaskStatusHistory, TaskExecutionLog, TaskTimeSegment, TaskAnalyticsSummary

logger = logging.getLogger(__name__)


class TaskTrackingService:
    """任务跟踪服务 - 记录和管理任务执行历史"""
    
    def __init__(self, db_connection=None):
        self.db = db_connection or get_db()
    
    # ==================== 状态变更记录 ====================
    
    def record_status_change(self, task_id: int, user_id: str,
                            old_status: Optional[str], new_status: str,
                            reason: str = None, changed_by: str = 'user') -> bool:
        """
        记录任务状态变更
        
        Args:
            task_id: 任务ID
            user_id: 用户ID
            old_status: 原状态
            new_status: 新状态
            reason: 变更原因
            changed_by: 变更者 (user/system/auto)
        """
        try:
            cursor = self.db.cursor()
            cursor.execute("""
                INSERT INTO task_status_history
                (task_id, user_id, old_status, new_status, change_reason, changed_by, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (task_id, user_id, old_status, new_status, reason, changed_by, datetime.now()))
            
            self.db.commit()
            
            # 同时记录执行日志
            self.log_event(task_id, user_id, 'status_change', {
                'old_status': old_status,
                'new_status': new_status,
                'reason': reason
            })
            
            logger.info(f"任务 {task_id} 状态变更记录: {old_status} -> {new_status}")
            return True
            
        except Exception as e:
            logger.error(f"记录状态变更失败: {e}")
            return False
    
    def get_status_history(self, task_id: int, limit: int = 50) -> List[Dict]:
        """获取任务状态变更历史"""
        try:
            cursor = self.db.cursor()
            cursor.execute("""
                SELECT * FROM task_status_history
                WHERE task_id = ?
                ORDER BY created_at DESC
                LIMIT ?
            """, (task_id, limit))
            
            rows = cursor.fetchall()
            columns = [description[0] for description in cursor.description]
            
            history = []
            for row in rows:
                record = dict(zip(columns, row))
                # 转换时间格式
                if record.get('created_at'):
                    record['created_at'] = record['created_at'].isoformat() if hasattr(record['created_at'], 'isoformat') else str(record['created_at'])
                history.append(record)
            
            return history
            
        except Exception as e:
            logger.error(f"获取状态历史失败: {e}")
            return []
    
    # ==================== 执行日志记录 ====================
    
    def log_event(self, task_id: int, user_id: str, event_type: str,
                 event_data: Dict = None, ip_address: str = None,
                 user_agent: str = None) -> bool:
        """
        记录任务执行事件
        
        Args:
            task_id: 任务ID
            user_id: 用户ID
            event_type: 事件类型 (start, pause, resume, complete, cancel, modify, reminder, ai_sort, manual_sort)
            event_data: 事件详细数据
            ip_address: IP地址
            user_agent: 用户代理
        """
        try:
            cursor = self.db.cursor()
            cursor.execute("""
                INSERT INTO task_execution_log
                (task_id, user_id, event_type, event_data, ip_address, user_agent, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (task_id, user_id, event_type, json.dumps(event_data) if event_data else None,
                  ip_address, user_agent, datetime.now()))
            
            self.db.commit()
            return True
            
        except Exception as e:
            logger.error(f"记录执行日志失败: {e}")
            return False
    
    def get_execution_logs(self, task_id: int, event_types: List[str] = None,
                          limit: int = 100) -> List[Dict]:
        """获取任务执行日志"""
        try:
            cursor = self.db.cursor()
            
            if event_types:
                placeholders = ','.join(['?' for _ in event_types])
                query = f"""
                    SELECT * FROM task_execution_log
                    WHERE task_id = ? AND event_type IN ({placeholders})
                    ORDER BY created_at DESC
                    LIMIT ?
                """
                params = [task_id] + event_types + [limit]
            else:
                query = """
                    SELECT * FROM task_execution_log
                    WHERE task_id = ?
                    ORDER BY created_at DESC
                    LIMIT ?
                """
                params = [task_id, limit]
            
            cursor.execute(query, params)
            rows = cursor.fetchall()
            columns = [description[0] for description in cursor.description]
            
            logs = []
            for row in rows:
                record = dict(zip(columns, row))
                # 解析JSON数据
                if record.get('event_data'):
                    try:
                        record['event_data'] = json.loads(record['event_data'])
                    except:
                        pass
                # 转换时间格式
                if record.get('created_at'):
                    record['created_at'] = record['created_at'].isoformat() if hasattr(record['created_at'], 'isoformat') else str(record['created_at'])
                logs.append(record)
            
            return logs
            
        except Exception as e:
            logger.error(f"获取执行日志失败: {e}")
            return []
    
    # ==================== 时间段记录 ====================
    
    def start_time_segment(self, task_id: int, user_id: str,
                          status: str = 'in_progress') -> Optional[int]:
        """
        开始一个新的执行时间段
        
        Returns:
            segment_id: 时间段ID
        """
        try:
            cursor = self.db.cursor()
            cursor.execute("""
                INSERT INTO task_time_segments
                (task_id, user_id, start_time, status, created_at)
                VALUES (?, ?, ?, ?, ?)
            """, (task_id, user_id, datetime.now(), status, datetime.now()))
            
            self.db.commit()
            segment_id = cursor.lastrowid
            
            logger.info(f"任务 {task_id} 开始执行时间段: {segment_id}")
            return segment_id
            
        except Exception as e:
            logger.error(f"开始时间段记录失败: {e}")
            return None
    
    def end_time_segment(self, segment_id: int, interrupt_reason: str = None) -> bool:
        """结束当前执行时间段"""
        try:
            end_time = datetime.now()
            
            cursor = self.db.cursor()
            
            # 获取开始时间
            cursor.execute("""
                SELECT start_time FROM task_time_segments WHERE id = ?
            """, (segment_id,))
            row = cursor.fetchone()
            
            if not row:
                return False
            
            start_time = row[0]
            duration = int((end_time - start_time).total_seconds() / 60)
            
            cursor.execute("""
                UPDATE task_time_segments
                SET end_time = ?, duration_minutes = ?, interrupt_reason = ?, updated_at = ?
                WHERE id = ?
            """, (end_time, duration, interrupt_reason, datetime.now(), segment_id))
            
            self.db.commit()
            logger.info(f"时间段 {segment_id} 结束，持续 {duration} 分钟")
            return True
            
        except Exception as e:
            logger.error(f"结束时间段记录失败: {e}")
            return False
    
    def get_time_segments(self, task_id: int) -> List[Dict]:
        """获取任务的所有执行时间段"""
        try:
            cursor = self.db.cursor()
            cursor.execute("""
                SELECT * FROM task_time_segments
                WHERE task_id = ?
                ORDER BY start_time ASC
            """, (task_id,))
            
            rows = cursor.fetchall()
            columns = [description[0] for description in cursor.description]
            
            segments = []
            for row in rows:
                record = dict(zip(columns, row))
                # 转换时间格式
                for field in ['start_time', 'end_time', 'created_at', 'updated_at']:
                    if record.get(field):
                        record[field] = record[field].isoformat() if hasattr(record[field], 'isoformat') else str(record[field])
                segments.append(record)
            
            return segments
            
        except Exception as e:
            logger.error(f"获取时间段失败: {e}")
            return []
    
    def calculate_total_execution_time(self, task_id: int) -> int:
        """计算任务总执行时间（分钟）"""
        try:
            cursor = self.db.cursor()
            cursor.execute("""
                SELECT COALESCE(SUM(duration_minutes), 0)
                FROM task_time_segments
                WHERE task_id = ? AND status = 'in_progress'
            """, (task_id,))
            
            row = cursor.fetchone()
            return row[0] if row else 0
            
        except Exception as e:
            logger.error(f"计算执行时间失败: {e}")
            return 0
    
    # ==================== 分析汇总 ====================
    
    def update_analytics_summary(self, task_id: int, user_id: str) -> bool:
        """更新任务分析汇总"""
        try:
            # 获取执行统计数据
            cursor = self.db.cursor()
            
            # 总执行时间
            total_duration = self.calculate_total_execution_time(task_id)
            
            # 执行次数和暂停次数
            cursor.execute("""
                SELECT 
                    COUNT(CASE WHEN status = 'in_progress' THEN 1 END) as exec_count,
                    COUNT(CASE WHEN status = 'paused' THEN 1 END) as pause_count
                FROM task_time_segments
                WHERE task_id = ?
            """, (task_id,))
            row = cursor.fetchone()
            exec_count = row[0] if row else 0
            pause_count = row[1] if row else 0
            
            # 平均执行时长
            avg_duration = total_duration // exec_count if exec_count > 0 else 0
            
            # 获取计划时长
            cursor.execute("""
                SELECT estimated_duration, expected_duration
                FROM task WHERE id = ?
            """, (task_id,))
            row = cursor.fetchone()
            planned_duration = row[0] or row[1] or 0
            
            # 完成率
            completion_rate = min(100, (total_duration / planned_duration * 100)) if planned_duration > 0 else 0
            
            # 保存或更新汇总
            cursor.execute("""
                INSERT OR REPLACE INTO task_analytics_summary
                (task_id, user_id, total_planned_duration, total_actual_duration,
                 execution_count, pause_count, completion_rate, avg_session_duration,
                 updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (task_id, user_id, planned_duration, total_duration,
                  exec_count, pause_count, completion_rate, avg_duration,
                  datetime.now()))
            
            self.db.commit()
            return True
            
        except Exception as e:
            logger.error(f"更新分析汇总失败: {e}")
            return False
    
    def get_analytics_summary(self, task_id: int) -> Optional[Dict]:
        """获取任务分析汇总"""
        try:
            cursor = self.db.cursor()
            cursor.execute("""
                SELECT * FROM task_analytics_summary WHERE task_id = ?
            """, (task_id,))
            
            row = cursor.fetchone()
            if not row:
                return None
            
            columns = [description[0] for description in cursor.description]
            record = dict(zip(columns, row))
            
            # 解析JSON字段
            for field in ['common_interrupt_reasons', 'related_task_ids']:
                if record.get(field):
                    try:
                        record[field] = json.loads(record[field])
                    except:
                        pass
            
            # 转换时间格式
            for field in ['created_at', 'updated_at']:
                if record.get(field):
                    record[field] = record[field].isoformat() if hasattr(record[field], 'isoformat') else str(record[field])
            
            return record
            
        except Exception as e:
            logger.error(f"获取分析汇总失败: {e}")
            return None
    
    # ==================== 完整执行档案 ====================
    
    def get_task_execution_archive(self, task_id: int) -> Dict:
        """
        获取任务的完整执行档案
        
        Returns:
            包含状态历史、执行日志、时间段和分析汇总的完整档案
        """
        try:
            cursor = self.db.cursor()
            
            # 获取任务基本信息
            cursor.execute("""
                SELECT id, title, status, is_completed, 
                       actual_start_time, actual_end_time, actual_duration,
                       created_at, completed_at
                FROM task WHERE id = ?
            """, (task_id,))
            
            row = cursor.fetchone()
            if not row:
                return {'error': '任务不存在'}
            
            task_info = {
                'id': row[0],
                'title': row[1],
                'status': row[2],
                'is_completed': row[3],
                'actual_start_time': row[4].isoformat() if row[4] else None,
                'actual_end_time': row[5].isoformat() if row[5] else None,
                'actual_duration': row[6],
                'created_at': row[7].isoformat() if row[7] else None,
                'completed_at': row[8].isoformat() if row[8] else None
            }
            
            # 组装完整档案
            archive = {
                'task_info': task_info,
                'status_history': self.get_status_history(task_id),
                'execution_logs': self.get_execution_logs(task_id),
                'time_segments': self.get_time_segments(task_id),
                'analytics_summary': self.get_analytics_summary(task_id),
                'total_execution_time': self.calculate_total_execution_time(task_id),
                'generated_at': datetime.now().isoformat()
            }
            
            return archive
            
        except Exception as e:
            logger.error(f"获取执行档案失败: {e}")
            return {'error': str(e)}


# 全局服务实例
_tracking_service = None


def get_task_tracking_service(db_connection=None):
    """获取任务跟踪服务实例"""
    global _tracking_service
    if _tracking_service is None:
        _tracking_service = TaskTrackingService(db_connection)
    return _tracking_service
