"""
数据库管理模块
提供数据库连接获取功能
"""
import os
import sqlite3
from flask import current_app, g


def get_db():
    """
    获取数据库连接
    优先使用 Flask 应用上下文中的数据库 URI
    否则使用默认路径
    """
    # 如果在 Flask 应用上下文中，使用应用配置的数据库
    if current_app:
        db_path = current_app.config.get('SQLALCHEMY_DATABASE_URI', '').replace('sqlite:///', '')
        if db_path:
            return sqlite3.connect(db_path)
    
    # 否则使用默认路径
    backend_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    db_path = os.path.join(backend_dir, '..', 'instance', 'schedule.db')
    db_path = os.path.abspath(db_path)
    
    return sqlite3.connect(db_path)


def get_db_connection():
    """获取原始 SQLite 数据库连接（用于直接 SQL 操作）"""
    return get_db()
