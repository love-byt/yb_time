-- 任务状态跟踪功能数据库迁移
-- 创建任务状态历史、执行日志、时间段和分析汇总表

-- 任务状态变更历史表
CREATE TABLE IF NOT EXISTS task_status_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id INTEGER NOT NULL,
    user_id VARCHAR(50) NOT NULL,
    old_status VARCHAR(20),
    new_status VARCHAR(20) NOT NULL,
    change_reason TEXT,
    changed_by VARCHAR(50),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (task_id) REFERENCES task(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES user(id) ON DELETE CASCADE
);

-- 状态历史表索引
CREATE INDEX IF NOT EXISTS idx_status_history_task ON task_status_history(task_id);
CREATE INDEX IF NOT EXISTS idx_status_history_user ON task_status_history(user_id);
CREATE INDEX IF NOT EXISTS idx_status_history_created ON task_status_history(created_at);

-- 任务执行日志表
CREATE TABLE IF NOT EXISTS task_execution_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id INTEGER NOT NULL,
    user_id VARCHAR(50) NOT NULL,
    event_type VARCHAR(50) NOT NULL,
    event_data JSON,
    ip_address VARCHAR(50),
    user_agent VARCHAR(500),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (task_id) REFERENCES task(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES user(id) ON DELETE CASCADE
);

-- 执行日志表索引
CREATE INDEX IF NOT EXISTS idx_execution_log_task ON task_execution_log(task_id);
CREATE INDEX IF NOT EXISTS idx_execution_log_user ON task_execution_log(user_id);
CREATE INDEX IF NOT EXISTS idx_execution_log_type ON task_execution_log(event_type);
CREATE INDEX IF NOT EXISTS idx_execution_log_created ON task_execution_log(created_at);

-- 任务时间段表
CREATE TABLE IF NOT EXISTS task_time_segments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id INTEGER NOT NULL,
    user_id VARCHAR(50) NOT NULL,
    start_time DATETIME NOT NULL,
    end_time DATETIME,
    status VARCHAR(20) NOT NULL,
    duration_minutes INTEGER,
    interrupt_reason VARCHAR(200),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (task_id) REFERENCES task(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES user(id) ON DELETE CASCADE
);

-- 时间段表索引
CREATE INDEX IF NOT EXISTS idx_time_segments_task ON task_time_segments(task_id);
CREATE INDEX IF NOT EXISTS idx_time_segments_user ON task_time_segments(user_id);
CREATE INDEX IF NOT EXISTS idx_time_segments_start ON task_time_segments(start_time);

-- 任务分析汇总表
CREATE TABLE IF NOT EXISTS task_analytics_summary (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id INTEGER NOT NULL UNIQUE,
    user_id VARCHAR(50) NOT NULL,
    total_planned_duration INTEGER,
    total_actual_duration INTEGER,
    execution_count INTEGER DEFAULT 0,
    pause_count INTEGER DEFAULT 0,
    completion_rate REAL,
    on_time_rate REAL,
    peak_hour_start INTEGER,
    avg_session_duration INTEGER,
    common_interrupt_reasons JSON,
    related_task_ids JSON,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (task_id) REFERENCES task(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES user(id) ON DELETE CASCADE
);

-- 分析汇总表索引
CREATE INDEX IF NOT EXISTS idx_analytics_task ON task_analytics_summary(task_id);
CREATE INDEX IF NOT EXISTS idx_analytics_user ON task_analytics_summary(user_id);

-- 迁移完成标记
INSERT OR REPLACE INTO migration_history (version, description, applied_at)
VALUES (9, 'Add task tracking tables (status history, execution log, time segments, analytics)', datetime('now'));
