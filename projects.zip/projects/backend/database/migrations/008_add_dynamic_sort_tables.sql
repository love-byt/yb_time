-- 动态排序相关表
-- 创建时间: 2026-05-04

-- 任务执行反馈表：记录任务实际执行情况
CREATE TABLE IF NOT EXISTS sort_execution_feedback (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    dimension_scores TEXT, -- JSON格式，各维度分数
    actual_duration INTEGER, -- 实际耗时（分钟）
    estimated_duration INTEGER, -- 预估耗时（分钟）
    execution_order INTEGER, -- 实际执行顺序
    ai_recommended_order INTEGER, -- AI推荐的顺序
    on_time BOOLEAN DEFAULT 0, -- 是否按时完成
    completed_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_feedback_user_id ON sort_execution_feedback(user_id);
CREATE INDEX IF NOT EXISTS idx_feedback_completed_at ON sort_execution_feedback(completed_at);
CREATE INDEX IF NOT EXISTS idx_feedback_task_id ON sort_execution_feedback(task_id);

-- 用户反馈表：记录用户对排序的显式反馈
CREATE TABLE IF NOT EXISTS sort_user_feedback (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    feedback_type VARCHAR(20) NOT NULL, -- 'positive', 'negative', 'reorder'
    task_id INTEGER,
    details TEXT,
    adjustments TEXT, -- JSON格式，触发的权重调整
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_user_feedback_user_id ON sort_user_feedback(user_id);
CREATE INDEX IF NOT EXISTS idx_user_feedback_type ON sort_user_feedback(feedback_type);

-- 权重调整历史表：记录权重的自动调整历史
CREATE TABLE IF NOT EXISTS weight_adjustment_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    dimension VARCHAR(20) NOT NULL, -- 调整的维度
    old_value REAL NOT NULL,
    new_value REAL NOT NULL,
    reason TEXT,
    confidence REAL, -- 调整置信度
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_weight_adj_user_id ON weight_adjustment_history(user_id);
CREATE INDEX IF NOT EXISTS idx_weight_adj_created ON weight_adjustment_history(created_at);

-- 自动排序配置表：用户自动排序设置
CREATE TABLE IF NOT EXISTS auto_sort_config (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER UNIQUE NOT NULL,
    config TEXT NOT NULL, -- JSON格式配置
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- 自动排序历史表：记录自动排序的执行历史
CREATE TABLE IF NOT EXISTS auto_sort_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    reason VARCHAR(20) NOT NULL, -- 'daily', 'urgent', 'state_change', 'manual'
    task_count INTEGER DEFAULT 0,
    ai_mode BOOLEAN DEFAULT 0,
    weights_used TEXT, -- JSON格式，使用的权重
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_auto_sort_user_id ON auto_sort_history(user_id);
CREATE INDEX IF NOT EXISTS idx_auto_sort_created ON auto_sort_history(created_at);

-- 任务排序缓存表：缓存排序结果
CREATE TABLE IF NOT EXISTS task_sort_cache (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    task_order TEXT NOT NULL, -- JSON格式，任务ID顺序
    weights_used TEXT, -- 使用的权重
    ai_mode BOOLEAN DEFAULT 0,
    expires_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_sort_cache_user_id ON task_sort_cache(user_id);
CREATE INDEX IF NOT EXISTS idx_sort_cache_expires ON task_sort_cache(expires_at);

-- 插入默认配置
INSERT OR IGNORE INTO auto_sort_config (user_id, config)
SELECT id, '{"auto_sort_enabled": true, "daily_sort_time": "08:00", "urgency_threshold_minutes": 30}'
FROM users;
