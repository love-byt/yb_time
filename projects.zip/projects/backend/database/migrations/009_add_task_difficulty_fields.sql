-- 添加任务难度和预估时长字段
-- Migration: 009_add_task_difficulty_fields
-- Created: 2026-05-06

-- 添加 estimated_duration 字段（预估时长，分钟）
ALTER TABLE task ADD COLUMN estimated_duration INTEGER;

-- 添加 difficulty_level 字段（难度等级：easy, medium, hard）
ALTER TABLE task ADD COLUMN difficulty_level VARCHAR(10) DEFAULT 'medium';

-- 添加 difficulty_factors 字段（难度评估因素，JSON格式）
ALTER TABLE task ADD COLUMN difficulty_factors TEXT;

-- 创建索引优化查询
CREATE INDEX idx_task_difficulty ON task(user_id, difficulty_level);
CREATE INDEX idx_task_estimated_duration ON task(user_id, estimated_duration);

-- 更新注释
COMMENT ON COLUMN task.estimated_duration IS '预估任务时长（分钟），由智能时间解析系统生成';
COMMENT ON COLUMN task.difficulty_level IS '任务难度等级：easy(简单), medium(中等), hard(困难)';
COMMENT ON COLUMN task.difficulty_factors IS '难度评估因素（JSON格式），包含关键词、分类权重等';
