#!/usr/bin/env python
"""
执行任务跟踪表迁移
直接执行SQL脚本创建必要的表
"""
import sqlite3
import os

# 获取数据库路径
backend_dir = os.path.dirname(os.path.abspath(__file__))
db_path = os.path.join(backend_dir, '..', 'instance', 'schedule.db')
db_path = os.path.abspath(db_path)

print(f'数据库路径: {db_path}')

# 确保数据库目录存在
os.makedirs(os.path.dirname(db_path), exist_ok=True)

# 连接数据库
conn = sqlite3.connect(db_path)
cursor = conn.cursor()

# 读取并执行SQL迁移脚本
sql_path = os.path.join(backend_dir, 'database', 'migrations', '009_add_task_tracking_tables.sql')
with open(sql_path, 'r', encoding='utf-8') as f:
    sql_script = f.read()

# 分割并执行每个SQL语句
statements = [s.strip() for s in sql_script.split(';') if s.strip()]
success_count = 0
skip_count = 0
error_count = 0

for stmt in statements:
    if stmt and not stmt.startswith('--'):
        try:
            cursor.execute(stmt)
            success_count += 1
            print('[OK] 执行成功')
        except sqlite3.OperationalError as e:
            if 'already exists' in str(e):
                skip_count += 1
                print('[SKIP] 已存在，跳过')
            else:
                error_count += 1
                print(f'[ERR] 错误: {e}')
        except Exception as e:
            error_count += 1
            print(f'[ERR] 错误: {e}')

conn.commit()
conn.close()

print(f'\n迁移完成！')
print(f'  成功: {success_count}')
print(f'  跳过: {skip_count}')
print(f'  错误: {error_count}')
