"""
任务状态历史跟踪模型
全程记录任务执行轨迹，形成完整的历史数据档案
"""

from datetime import datetime
from extensions import db


class TaskStatusHistory(db.Model):
    """任务状态变更历史 - 记录每次状态变化"""
    __tablename__ = 'task_status_history'
    
    id = db.Column(db.Integer, primary_key=True)
    task_id = db.Column(db.Integer, db.ForeignKey('task.id'), nullable=False, index=True)
    user_id = db.Column(db.String(50), db.ForeignKey('user.id'), nullable=False, index=True)
    
    # 状态变更信息
    old_status = db.Column(db.String(20))  # 原状态: pending, in_progress, paused, completed
    new_status = db.Column(db.String(20), nullable=False)  # 新状态
    
    # 变更原因/备注
    change_reason = db.Column(db.Text)
    changed_by = db.Column(db.String(50))  # 变更者: user, system, auto
    
    # 时间戳
    created_at = db.Column(db.DateTime, default=datetime.now, index=True)
    
    # 关联关系
    task = db.relationship('Task', backref='status_history')
    
    def to_dict(self):
        """转换为字典"""
        return {
            'id': self.id,
            'task_id': self.task_id,
            'user_id': self.user_id,
            'old_status': self.old_status,
            'new_status': self.new_status,
            'change_reason': self.change_reason,
            'changed_by': self.changed_by,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


class TaskExecutionLog(db.Model):
    """任务执行日志 - 详细记录执行过程中的关键事件"""
    __tablename__ = 'task_execution_log'
    
    id = db.Column(db.Integer, primary_key=True)
    task_id = db.Column(db.Integer, db.ForeignKey('task.id'), nullable=False, index=True)
    user_id = db.Column(db.String(50), db.ForeignKey('user.id'), nullable=False, index=True)
    
    # 事件类型
    event_type = db.Column(db.String(50), nullable=False, index=True)
    # 事件类型包括:
    # - start: 开始执行
    # - pause: 暂停
    # - resume: 恢复
    # - complete: 完成
    # - cancel: 取消
    # - modify: 修改任务
    # - reminder: 提醒触发
    # - ai_sort: AI排序调整
    # - manual_sort: 手动排序调整
    
    # 事件详情
    event_data = db.Column(db.JSON)  # 存储事件相关的详细数据
    
    # 执行上下文
    ip_address = db.Column(db.String(50))
    user_agent = db.Column(db.String(500))
    
    # 时间戳
    created_at = db.Column(db.DateTime, default=datetime.now, index=True)
    
    # 关联关系
    task = db.relationship('Task', backref='execution_logs')
    
    def to_dict(self):
        """转换为字典"""
        return {
            'id': self.id,
            'task_id': self.task_id,
            'user_id': self.user_id,
            'event_type': self.event_type,
            'event_data': self.event_data,
            'ip_address': self.ip_address,
            'user_agent': self.user_agent,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


class TaskTimeSegment(db.Model):
    """任务时间段 - 记录任务实际执行的各个时间段"""
    __tablename__ = 'task_time_segments'
    
    id = db.Column(db.Integer, primary_key=True)
    task_id = db.Column(db.Integer, db.ForeignKey('task.id'), nullable=False, index=True)
    user_id = db.Column(db.String(50), db.ForeignKey('user.id'), nullable=False, index=True)
    
    # 时间段
    start_time = db.Column(db.DateTime, nullable=False)
    end_time = db.Column(db.DateTime)
    
    # 该段时间内的状态
    status = db.Column(db.String(20), nullable=False)  # in_progress, paused
    
    # 持续时间（分钟）- 自动计算
    duration_minutes = db.Column(db.Integer)
    
    # 中断原因（如果是暂停）
    interrupt_reason = db.Column(db.String(200))
    
    # 时间戳
    created_at = db.Column(db.DateTime, default=datetime.now)
    updated_at = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now)
    
    # 关联关系
    task = db.relationship('Task', backref='time_segments')
    
    def calculate_duration(self):
        """计算持续时间"""
        if self.start_time and self.end_time:
            delta = self.end_time - self.start_time
            self.duration_minutes = int(delta.total_seconds() / 60)
        return self.duration_minutes
    
    def to_dict(self):
        """转换为字典"""
        return {
            'id': self.id,
            'task_id': self.task_id,
            'user_id': self.user_id,
            'start_time': self.start_time.isoformat() if self.start_time else None,
            'end_time': self.end_time.isoformat() if self.end_time else None,
            'status': self.status,
            'duration_minutes': self.duration_minutes,
            'interrupt_reason': self.interrupt_reason,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


class TaskAnalyticsSummary(db.Model):
    """任务分析汇总 - 记录任务的执行统计和分析结果"""
    __tablename__ = 'task_analytics_summary'
    
    id = db.Column(db.Integer, primary_key=True)
    task_id = db.Column(db.Integer, db.ForeignKey('task.id'), nullable=False, unique=True)
    user_id = db.Column(db.String(50), db.ForeignKey('user.id'), nullable=False, index=True)
    
    # 执行统计
    total_planned_duration = db.Column(db.Integer)  # 计划总时长（分钟）
    total_actual_duration = db.Column(db.Integer)   # 实际总时长（分钟）
    execution_count = db.Column(db.Integer, default=0)  # 执行次数
    pause_count = db.Column(db.Integer, default=0)      # 暂停次数
    
    # 效率指标
    completion_rate = db.Column(db.Float)  # 完成率（实际/计划）
    on_time_rate = db.Column(db.Float)     # 按时完成率
    
    # 时间分布
    peak_hour_start = db.Column(db.Integer)  # 最佳开始时段
    avg_session_duration = db.Column(db.Integer)  # 平均单次执行时长
    
    # 中断分析
    common_interrupt_reasons = db.Column(db.JSON)  # 常见中断原因
    
    # 关联任务
    related_task_ids = db.Column(db.JSON)  # 关联的任务ID列表
    
    # 时间戳
    created_at = db.Column(db.DateTime, default=datetime.now)
    updated_at = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now)
    
    # 关联关系
    task = db.relationship('Task', backref='analytics_summary')
    
    def to_dict(self):
        """转换为字典"""
        return {
            'id': self.id,
            'task_id': self.task_id,
            'user_id': self.user_id,
            'total_planned_duration': self.total_planned_duration,
            'total_actual_duration': self.total_actual_duration,
            'execution_count': self.execution_count,
            'pause_count': self.pause_count,
            'completion_rate': self.completion_rate,
            'on_time_rate': self.on_time_rate,
            'peak_hour_start': self.peak_hour_start,
            'avg_session_duration': self.avg_session_duration,
            'common_interrupt_reasons': self.common_interrupt_reasons,
            'related_task_ids': self.related_task_ids,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
