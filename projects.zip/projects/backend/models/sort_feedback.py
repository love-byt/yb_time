"""
智能排序反馈模型 - 记录任务执行反馈，支持动态权重调整
"""

from datetime import datetime, timedelta
from extensions import db


class TaskExecutionFeedback(db.Model):
    """任务执行反馈 - 记录实际执行与计划的差异"""
    __tablename__ = 'task_execution_feedback'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.String(50), db.ForeignKey('user.id'), nullable=False, index=True)
    task_id = db.Column(db.Integer, db.ForeignKey('task.id'), nullable=False, index=True)
    
    # 计划信息
    planned_start_time = db.Column(db.DateTime)
    planned_end_time = db.Column(db.DateTime)
    planned_duration = db.Column(db.Integer)  # 计划时长（分钟）
    planned_priority = db.Column(db.Integer)
    planned_ai_sort_score = db.Column(db.Float)
    
    # 实际执行信息
    actual_start_time = db.Column(db.DateTime)
    actual_end_time = db.Column(db.DateTime)
    actual_duration = db.Column(db.Integer)  # 实际时长（分钟）
    
    # 执行偏差分析
    duration_deviation_ratio = db.Column(db.Float)  # 时长偏差比例 (实际-计划)/计划
    start_delay_minutes = db.Column(db.Integer, default=0)  # 开始延迟（分钟）
    
    # 执行质量
    completion_quality = db.Column(db.Integer)  # 完成质量 1-5
    interruptions_count = db.Column(db.Integer, default=0)  # 中断次数
    
    # 用户反馈
    user_satisfaction = db.Column(db.Integer)  # 用户满意度 1-5
    user_feedback_text = db.Column(db.Text)  # 用户文字反馈
    is_sort_reasonable = db.Column(db.Boolean)  # 排序是否合理
    
    # 执行时的权重配置（快照）
    weights_snapshot = db.Column(db.Text)  # JSON格式
    
    # 执行时的时段
    day_of_week = db.Column(db.Integer)  # 0-6
    hour_of_day = db.Column(db.Integer)  # 0-23
    
    created_at = db.Column(db.DateTime, default=datetime.now)
    
    user = db.relationship('User', backref='execution_feedbacks')
    task = db.relationship('Task', backref='execution_feedbacks')
    
    __table_args__ = (
        db.Index('idx_feedback_user_time', 'user_id', 'created_at'),
        db.Index('idx_feedback_task', 'task_id'),
    )
    
    def to_dict(self):
        import json
        return {
            'id': self.id,
            'user_id': self.user_id,
            'task_id': self.task_id,
            'planned_start_time': self.planned_start_time.isoformat() if self.planned_start_time else None,
            'planned_end_time': self.planned_end_time.isoformat() if self.planned_end_time else None,
            'planned_duration': self.planned_duration,
            'planned_priority': self.planned_priority,
            'planned_ai_sort_score': self.planned_ai_sort_score,
            'actual_start_time': self.actual_start_time.isoformat() if self.actual_start_time else None,
            'actual_end_time': self.actual_end_time.isoformat() if self.actual_end_time else None,
            'actual_duration': self.actual_duration,
            'duration_deviation_ratio': self.duration_deviation_ratio,
            'start_delay_minutes': self.start_delay_minutes,
            'completion_quality': self.completion_quality,
            'interruptions_count': self.interruptions_count,
            'user_satisfaction': self.user_satisfaction,
            'user_feedback_text': self.user_feedback_text,
            'is_sort_reasonable': self.is_sort_reasonable,
            'weights_snapshot': json.loads(self.weights_snapshot) if self.weights_snapshot else None,
            'day_of_week': self.day_of_week,
            'hour_of_day': self.hour_of_day,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


class SortFeedbackSummary(db.Model):
    """排序反馈汇总 - 用于权重动态调整"""
    __tablename__ = 'sort_feedback_summary'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.String(50), db.ForeignKey('user.id'), nullable=False, index=True)
    
    # 统计周期
    period_start = db.Column(db.DateTime, nullable=False)
    period_end = db.Column(db.DateTime, nullable=False)
    period_days = db.Column(db.Integer, default=7)
    
    # 整体统计
    total_tasks = db.Column(db.Integer, default=0)
    completed_tasks = db.Column(db.Integer, default=0)
    avg_completion_rate = db.Column(db.Float, default=0.0)
    avg_user_satisfaction = db.Column(db.Float, default=0.0)
    
    # 各维度效果评估
    time_dimension_effectiveness = db.Column(db.Float, default=0.5)  # 时间维度有效性 0-1
    importance_dimension_effectiveness = db.Column(db.Float, default=0.5)
    impact_dimension_effectiveness = db.Column(db.Float, default=0.5)
    money_dimension_effectiveness = db.Column(db.Float, default=0.5)
    relation_dimension_effectiveness = db.Column(db.Float, default=0.5)
    skill_dimension_effectiveness = db.Column(db.Float, default=0.5)
    
    # 建议的权重调整
    recommended_weight_adjustments = db.Column(db.Text)  # JSON格式
    
    # 是否需要调整
    needs_adjustment = db.Column(db.Boolean, default=False)
    adjustment_confidence = db.Column(db.Float, default=0.0)  # 调整信心度 0-1
    
    created_at = db.Column(db.DateTime, default=datetime.now)
    updated_at = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now)
    
    user = db.relationship('User', backref='sort_feedback_summaries')
    
    __table_args__ = (
        db.Index('idx_summary_user_period', 'user_id', 'period_start', 'period_end'),
    )
    
    def to_dict(self):
        import json
        return {
            'id': self.id,
            'user_id': self.user_id,
            'period_start': self.period_start.isoformat() if self.period_start else None,
            'period_end': self.period_end.isoformat() if self.period_end else None,
            'period_days': self.period_days,
            'total_tasks': self.total_tasks,
            'completed_tasks': self.completed_tasks,
            'avg_completion_rate': self.avg_completion_rate,
            'avg_user_satisfaction': self.avg_user_satisfaction,
            'dimension_effectiveness': {
                'time': self.time_dimension_effectiveness,
                'importance': self.importance_dimension_effectiveness,
                'impact': self.impact_dimension_effectiveness,
                'money': self.money_dimension_effectiveness,
                'relation': self.relation_dimension_effectiveness,
                'skill': self.skill_dimension_effectiveness
            },
            'recommended_weight_adjustments': json.loads(self.recommended_weight_adjustments) if self.recommended_weight_adjustments else None,
            'needs_adjustment': self.needs_adjustment,
            'adjustment_confidence': self.adjustment_confidence,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }


class DynamicWeightHistory(db.Model):
    """动态权重历史 - 记录权重的自动调整历史"""
    __tablename__ = 'dynamic_weight_history'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.String(50), db.ForeignKey('user.id'), nullable=False, index=True)
    
    # 调整前后的权重
    previous_weights = db.Column(db.Text, nullable=False)  # JSON
    new_weights = db.Column(db.Text, nullable=False)  # JSON
    
    # 调整原因
    adjustment_reason = db.Column(db.Text)  # 调整原因说明
    trigger_type = db.Column(db.String(50))  # 触发类型: feedback(用户反馈), auto(自动分析), schedule(定时调整)
    
    # 调整依据的数据
    feedback_summary_id = db.Column(db.Integer, db.ForeignKey('sort_feedback_summary.id'), nullable=True)
    
    # 调整效果评估（后续填充）
    effectiveness_score = db.Column(db.Float, nullable=True)  # 效果评分 0-1
    
    created_at = db.Column(db.DateTime, default=datetime.now)
    
    user = db.relationship('User', backref='weight_history')
    feedback_summary = db.relationship('SortFeedbackSummary', backref='weight_adjustments')
    
    def to_dict(self):
        import json
        return {
            'id': self.id,
            'user_id': self.user_id,
            'previous_weights': json.loads(self.previous_weights),
            'new_weights': json.loads(self.new_weights),
            'adjustment_reason': self.adjustment_reason,
            'trigger_type': self.trigger_type,
            'feedback_summary_id': self.feedback_summary_id,
            'effectiveness_score': self.effectiveness_score,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }
