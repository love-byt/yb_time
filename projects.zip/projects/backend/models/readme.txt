================================================================================
                          Models 文件夹说明
================================================================================

【文件夹作用】
本文件夹包含 SQLAlchemy 数据模型定义，实现对象关系映射（ORM）。
定义了智能日程助手的核心数据结构和数据库表结构。

================================================================================
                              文件说明
================================================================================

1. __init__.py
   - 模型包初始化文件
   - 导出所有模型类供外部使用
   - 统一模型接口

2. task.py
   - 核心数据模型定义文件
   - 包含所有数据库模型类

   【模型类说明】

   a) User (用户模型)
      - 表名: user
      - 字段:
        * id: 用户唯一标识（主键）
        * username: 用户名（唯一，可选）
        * password_hash: 密码哈希（可选）
        * email: 邮箱（唯一，可选）
        * nickname: 昵称
        * avatar: 头像 URL
        * push_subscription: 推送订阅信息（JSON）
        * created_at: 创建时间
        * last_visit: 最后访问时间
        * settings: 用户设置（JSON）
        * ai_api_key: 自定义 AI API Key
        * ai_usage_count: 当日 AI 使用次数
        * ai_usage_date: AI 使用日期
      - 方法:
        * set_password(): 设置密码（哈希加密）
        * check_password(): 验证密码
        * can_use_ai(): 检查是否可使用 AI
        * increment_ai_usage(): 增加 AI 使用计数
        * reset_ai_quota(): 重置 AI 额度

   b) Task (任务模型)
      - 表名: task
      - 字段:
        * id: 任务唯一标识（主键）
        * user_id: 所属用户 ID（外键）
        * title: 任务标题
        * description: 任务描述
        * category: 分类
        * priority: 优先级（1-5）
        * status: 状态（pending/completed）
        * start_time: 开始时间
        * end_time: 截止时间
        * estimated_duration: 预计时长（分钟）
        * completed_at: 完成时间
        * created_at: 创建时间
        * updated_at: 更新时间
      - 关系:
        * tags: 多对多关联标签
        * recurring_rule: 一对一关联重复规则
      - 方法:
        * to_dict(): 转换为字典
        * complete(): 标记完成
        * start(): 开始任务

   c) Tag (标签模型)
      - 表名: tag
      - 字段:
        * id: 标签唯一标识（主键）
        * user_id: 所属用户 ID
        * name: 标签名称
        * color: 标签颜色
        * created_at: 创建时间
      - 关系:
        * tasks: 多对多关联任务

   d) TaskTag (任务标签关联模型)
      - 表名: task_tag
      - 作用: 实现任务和标签的多对多关系
      - 字段:
        * task_id: 任务 ID（外键）
        * tag_id: 标签 ID（外键）

   e) Category (分类模型)
      - 表名: category
      - 字段:
        * id: 分类唯一标识（主键）
        * user_id: 所属用户 ID
        * name: 分类名称
        * color: 分类颜色
        * icon: 分类图标
        * created_at: 创建时间

   f) RecurringRule (重复任务规则模型)
      - 表名: recurring_rule
      - 字段:
        * id: 规则唯一标识（主键）
        * task_id: 关联任务 ID
        * frequency: 频率（daily/weekly/monthly）
        * interval: 间隔
        * days_of_week: 周几（JSON）
        * end_date: 结束日期
        * created_at: 创建时间
      - 方法:
        * generate_next(): 生成下一次任务

   g) Reminder (提醒模型)
      - 表名: reminder
      - 字段:
        * id: 提醒唯一标识（主键）
        * task_id: 关联任务 ID
        * remind_at: 提醒时间
        * type: 提醒类型
        * is_sent: 是否已发送
        * created_at: 创建时间

   h) AIAnalysis (AI 分析结果模型)
      - 表名: ai_analysis
      - 字段:
        * id: 分析唯一标识（主键）
        * user_id: 所属用户 ID
        * analysis_type: 分析类型
        * content: 分析内容（JSON）
        * created_at: 创建时间

================================================================================

【辅助类/函数】

1. PriorityLevel (枚举类)
   - 优先级等级枚举
   - 值: LOWEST(1), LOW(2), MEDIUM(3), HIGH(4), HIGHEST(5)

2. format_datetime() (工具函数)
   - 格式化日期时间为字符串
   - 格式: YYYY-MM-DD HH:MM:SS

================================================================================
                              数据库关系
================================================================================

【关系图】

User (1) ----< (*) Task
   |
   |----< (*) Tag
   |
   |----< (*) Category
   |
   |----< (*) AIAnalysis

Task (1) ----< (*) TaskTag >---- (*) Tag
   |
   |---- (1) RecurringRule
   |
   |----< (*) Reminder

================================================================================
                              设计特点
================================================================================

1. 多用户隔离
   - 所有模型都包含 user_id 字段
   - 实现用户数据完全隔离

2. 软删除支持
   - 使用 status 字段标记删除状态
   - 保留历史数据

3. JSON 字段扩展
   - settings、push_subscription 等使用 JSON 存储
   - 支持灵活的扩展配置

4. 时间戳自动管理
   - created_at、updated_at 自动填充
   - 使用 SQLAlchemy 事件监听

5. 关联关系完整
   - 一对多、多对多关系完整定义
   - 级联操作配置

================================================================================
