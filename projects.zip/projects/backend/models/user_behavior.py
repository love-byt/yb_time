"""
用户行为模型 - 用于学习用户习惯，支持个性化推荐
"""

from datetime import datetime, timedelta
from extensions import db


class UserStudyPattern(db.Model):
    """用户学习模式模型 - 记录用户的学习习惯"""
    __tablename__ = 'user_study_pattern'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.String(50), db.ForeignKey('user.id'), nullable=False, index=True)
    
    # 学习时段偏好（24小时制，记录每小时的学习频率）
    hourly_distribution = db.Column(db.Text, default='{}')  # JSON格式 {0: 0.1, 1: 0.05, ...}
    
    # 最佳学习时段（系统自动计算）
    peak_hours = db.Column(db.String(50), default='')  # 逗号分隔，如 "9,10,14,15"
    
    # 平均专注时长（分钟）
    avg_focus_duration = db.Column(db.Integer, default=25)
    
    # 平均休息间隔（分钟）
    avg_break_interval = db.Column(db.Integer, default=5)
    
    # 长休息间隔（番茄钟数量）
    pomodoros_before_long_break = db.Column(db.Integer, default=4)
    
    # 偏好的学习分类（JSON格式）
    preferred_categories = db.Column(db.Text, default='[]')
    
    # 任务完成率统计
    completion_rate = db.Column(db.Float, default=0.0)  # 0-1
    
    # 平均任务完成时长（相对于预估时长的比例）
    avg_completion_ratio = db.Column(db.Float, default=1.0)
    
    # 学习频率（每周学习天数）
    weekly_study_days = db.Column(db.Integer, default=5)
    
    # 数据更新时间
    updated_at = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now)
    created_at = db.Column(db.DateTime, default=datetime.now)
    
    user = db.relationship('User', backref='study_pattern')
    
    def to_dict(self):
        import json
        return {
            'id': self.id,
            'user_id': self.user_id,
            'hourly_distribution': json.loads(self.hourly_distribution) if self.hourly_distribution else {},
            'peak_hours': [int(h) for h in self.peak_hours.split(',') if h] if self.peak_hours else [],
            'avg_focus_duration': self.avg_focus_duration,
            'avg_break_interval': self.avg_break_interval,
            'pomodoros_before_long_break': self.pomodoros_before_long_break,
            'preferred_categories': json.loads(self.preferred_categories) if self.preferred_categories else [],
            'completion_rate': self.completion_rate,
            'avg_completion_ratio': self.avg_completion_ratio,
            'weekly_study_days': self.weekly_study_days,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


class UserStudySession(db.Model):
    """用户学习会话记录 - 记录每次学习的详细数据"""
    __tablename__ = 'user_study_session'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.String(50), db.ForeignKey('user.id'), nullable=False, index=True)
    task_id = db.Column(db.Integer, db.ForeignKey('task.id'), nullable=True)
    
    # 会话时间
    start_time = db.Column(db.DateTime, nullable=False)
    end_time = db.Column(db.DateTime, nullable=True)
    
    # 学习时长（分钟）
    duration_minutes = db.Column(db.Integer, default=0)
    
    # 会话类型：focus(专注), break(休息), long_break(长休息)
    session_type = db.Column(db.String(20), default='focus')
    
    # 中断次数
    interruptions = db.Column(db.Integer, default=0)
    
    # 效率自评（1-5）
    efficiency_rating = db.Column(db.Integer, nullable=True)
    
    # 任务分类
    category = db.Column(db.String(50), default='')
    
    # 星期几（0-6）
    day_of_week = db.Column(db.Integer, default=0)
    
    # 小时（0-23）
    hour_of_day = db.Column(db.Integer, default=0)
    
    created_at = db.Column(db.DateTime, default=datetime.now)
    
    user = db.relationship('User', backref='study_sessions')
    task = db.relationship('Task', backref='study_sessions')
    
    __table_args__ = (
        db.Index('idx_study_session_user_time', 'user_id', 'start_time'),
        db.Index('idx_study_session_hour', 'hour_of_day'),
    )
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'task_id': self.task_id,
            'start_time': self.start_time.isoformat() if self.start_time else None,
            'end_time': self.end_time.isoformat() if self.end_time else None,
            'duration_minutes': self.duration_minutes,
            'session_type': self.session_type,
            'interruptions': self.interruptions,
            'efficiency_rating': self.efficiency_rating,
            'category': self.category,
            'day_of_week': self.day_of_week,
            'hour_of_day': self.hour_of_day,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


class UserTaskPreference(db.Model):
    """用户任务偏好 - 记录用户对不同任务类型的偏好"""
    __tablename__ = 'user_task_preference'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.String(50), db.ForeignKey('user.id'), nullable=False, index=True)
    
    # 任务分类
    category = db.Column(db.String(50), nullable=False)
    
    # 该分类的平均完成时长（分钟）
    avg_duration = db.Column(db.Integer, default=0)
    
    # 完成次数
    completion_count = db.Column(db.Integer, default=0)
    
    # 平均效率（1-5）
    avg_efficiency = db.Column(db.Float, default=3.0)
    
    # 偏好权重（0-1，基于完成频率和效率计算）
    preference_weight = db.Column(db.Float, default=0.5)
    
    # 最佳完成时段（JSON格式 [9, 10, 14]）
    best_hours = db.Column(db.Text, default='[]')
    
    updated_at = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now)
    created_at = db.Column(db.DateTime, default=datetime.now)
    
    user = db.relationship('User', backref='task_preferences')
    
    __table_args__ = (
        db.UniqueConstraint('user_id', 'category', name='uix_user_category_preference'),
    )
    
    def to_dict(self):
        import json
        return {
            'id': self.id,
            'user_id': self.user_id,
            'category': self.category,
            'avg_duration': self.avg_duration,
            'completion_count': self.completion_count,
            'avg_efficiency': self.avg_efficiency,
            'preference_weight': self.preference_weight,
            'best_hours': json.loads(self.best_hours) if self.best_hours else [],
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
