"""
校园场景数据模型 - 重构版
包含课程表、考试安排等核心模型
"""

from datetime import datetime, time, date
from extensions import db


class Course(db.Model):
    """课程模型"""
    __tablename__ = 'courses'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.String(50), db.ForeignKey('user.id'), nullable=False, index=True)

    # 基本信息
    name = db.Column(db.String(100), nullable=False)
    code = db.Column(db.String(20))
    teacher = db.Column(db.String(50))
    location = db.Column(db.String(100))

    # 时间安排
    day_of_week = db.Column(db.Integer, nullable=False)  # 1-7 周一到周日
    start_time = db.Column(db.Time, nullable=False)
    end_time = db.Column(db.Time, nullable=False)
    start_week = db.Column(db.Integer, default=1)
    end_week = db.Column(db.Integer, default=16)

    # 属性
    course_type = db.Column(db.String(20), default='必修')  # 必修/选修/通识
    credit = db.Column(db.Float, default=0)
    color = db.Column(db.String(7), default='#4caf50')  # 课程颜色标记

    # 时间戳
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'code': self.code,
            'teacher': self.teacher,
            'location': self.location,
            'day_of_week': self.day_of_week,
            'start_time': self.start_time.strftime('%H:%M') if self.start_time else None,
            'end_time': self.end_time.strftime('%H:%M') if self.end_time else None,
            'start_week': self.start_week,
            'end_week': self.end_week,
            'course_type': self.course_type,
            'credit': self.credit,
            'color': self.color
        }


class Exam(db.Model):
    """考试模型"""
    __tablename__ = 'exams'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.String(50), db.ForeignKey('user.id'), nullable=False, index=True)
    course_id = db.Column(db.Integer, db.ForeignKey('courses.id'))
    
    # 考试信息
    name = db.Column(db.String(100), nullable=False)
    exam_type = db.Column(db.String(20), default='期末')  # 期中/期末/补考/测验
    exam_date = db.Column(db.DateTime, nullable=False)
    duration = db.Column(db.Integer, default=120)  # 分钟
    location = db.Column(db.String(100))
    seat_number = db.Column(db.String(20))
    
    # 复习状态
    review_status = db.Column(db.Integer, default=0)  # 复习进度 0-100
    review_notes = db.Column(db.Text)
    
    # 时间戳
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'course_id': self.course_id,
            'name': self.name,
            'exam_type': self.exam_type,
            'exam_date': self.exam_date.isoformat() if self.exam_date else None,
            'duration': self.duration,
            'location': self.location,
            'seat_number': self.seat_number,
            'review_status': self.review_status,
            'review_notes': self.review_notes
        }


class Semester(db.Model):
    """学期设置模型"""
    __tablename__ = 'semesters'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.String(50), db.ForeignKey('user.id'), nullable=False, index=True)
    
    # 学期信息
    name = db.Column(db.String(50), nullable=False)  # 如：2024-2025-1
    start_date = db.Column(db.Date, nullable=False)
    end_date = db.Column(db.Date, nullable=False)
    
    # 考试周设置
    exam_week_start = db.Column(db.Date)
    exam_week_end = db.Column(db.Date)
    
    # 当前学期标记
    is_current = db.Column(db.Boolean, default=False)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'start_date': self.start_date.isoformat() if self.start_date else None,
            'end_date': self.end_date.isoformat() if self.end_date else None,
            'exam_week_start': self.exam_week_start.isoformat() if self.exam_week_start else None,
            'exam_week_end': self.exam_week_end.isoformat() if self.exam_week_end else None,
            'is_current': self.is_current
        }
    
    def get_current_week(self):
        """获取当前是第几周"""
        if not self.start_date:
            return 1
        today = date.today()
        days_passed = (today - self.start_date).days
        return max(1, (days_passed // 7) + 1)
    
    def is_exam_week(self):
        """检查当前是否在考试周"""
        if not self.exam_week_start or not self.exam_week_end:
            return False
        today = date.today()
        return self.exam_week_start <= today <= self.exam_week_end
