"""
数据模型定义 - 多用户隔离版本
包含User（用户）、Task（任务）、Tag（标签）、TaskTag（任务标签关联）、
RecurringRule（重复任务规则）、AIAnalysis（AI分析结果）模型
"""

from datetime import datetime, timedelta
from enum import Enum
import uuid

from extensions import db


def format_datetime(dt):
    """格式化日期时间"""
    return dt.strftime('%Y-%m-%d %H:%M:%S') if dt else None


class PriorityLevel(Enum):
    """优先级等级"""
    LOWEST = 1
    LOW = 2
    MEDIUM = 3
    HIGH = 4
    HIGHEST = 5


class User(db.Model):
    """用户模型 - 支持用户名密码认证和匿名访问"""
    __tablename__ = 'user'

    id = db.Column(db.String(50), primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=True)  # 可选，用于认证
    password_hash = db.Column(db.String(256), nullable=True)  # 可选，用于认证
    email = db.Column(db.String(100), unique=True, nullable=True)  # 可选
    nickname = db.Column(db.String(50), nullable=True)
    avatar = db.Column(db.String(200), nullable=True)  # 头像URL
    push_subscription = db.Column(db.Text, nullable=True)  # JSON格式的推送订阅信息
    created_at = db.Column(db.DateTime, default=datetime.now)
    last_visit = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now)
    
    # 用户设置
    settings = db.Column(db.Text, default='{}')  # JSON格式的用户设置
    
    # AI使用额度
    ai_api_key = db.Column(db.String(256), nullable=True)  # 用户自定义AI API Key
    ai_usage_count = db.Column(db.Integer, default=0)  # 当日AI使用次数
    ai_usage_date = db.Column(db.Date, nullable=True)  # AI使用日期（用于重置每日额度）
    
    # 免费AI额度配置
    FREE_AI_QUOTA = 10  # 每日免费额度
    
    def set_password(self, password):
        """设置密码（哈希加密）"""
        from werkzeug.security import generate_password_hash
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        """验证密码"""
        if not self.password_hash:
            return False
        from werkzeug.security import check_password_hash
        return check_password_hash(self.password_hash, password)
    
    def get_ai_usage(self):
        """获取AI使用情况（注意：此方法不提交事务，由调用方控制）"""
        today = datetime.now().date()
        
        # 如果是新的一天，重置计数
        if self.ai_usage_date != today:
            self.ai_usage_count = 0
            self.ai_usage_date = today
            # 标记需要保存，但不立即提交
            db.session.add(self)
        
        return {
            'used': self.ai_usage_count,
            'quota': self.FREE_AI_QUOTA,
            'remaining': max(0, self.FREE_AI_QUOTA - self.ai_usage_count),
            'has_custom_key': bool(self.ai_api_key)
        }
    
    def increment_ai_usage(self):
        """增加AI使用次数（注意：此方法不提交事务，由调用方控制）"""
        today = datetime.now().date()
        
        # 如果是新的一天，重置计数
        if self.ai_usage_date != today:
            self.ai_usage_count = 0
            self.ai_usage_date = today
        
        self.ai_usage_count += 1
        # 标记需要保存，但不立即提交
        db.session.add(self)
    
    def can_use_ai(self):
        """检查是否可以使用AI"""
        # 如果有自定义Key，总是可以使用
        if self.ai_api_key:
            return True, 'custom_key'
        
        # 检查免费额度
        usage = self.get_ai_usage()
        if usage['remaining'] > 0:
            return True, 'free_quota'
        
        return False, 'exhausted'
    
    def to_dict(self, include_sensitive=False):
        data = {
            'id': self.id,
            'nickname': self.nickname or f'用户{self.id[:8]}',
            'avatar': self.avatar,
            'push_enabled': bool(self.push_subscription),
            'created_at': format_datetime(self.created_at),
            'last_visit': format_datetime(self.last_visit),
            'ai_usage': self.get_ai_usage()
        }
        if include_sensitive:
            data['username'] = self.username
            data['email'] = self.email
            data['has_ai_key'] = bool(self.ai_api_key)
        return data


class Task(db.Model):
    """任务模型 - 多用户隔离版"""
    __tablename__ = 'task'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.String(50), db.ForeignKey('user.id'), nullable=False, index=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    category = db.Column(db.String(50), default='学习')
    priority = db.Column(db.Integer, default=0)
    manual_order = db.Column(db.Integer, default=0)
    start_time = db.Column(db.DateTime)  # 任务开始时间
    end_time = db.Column(db.DateTime)    # 任务结束时间（截止时间）
    is_completed = db.Column(db.Integer, default=0)
    ai_suggestion = db.Column(db.Text)
    
    # 六维度评分字段（用于AI智能排序）
    time_score = db.Column(db.Float, default=0.0)
    importance_score = db.Column(db.Float, default=0.0)
    impact_score = db.Column(db.Float, default=0.0)
    money_score = db.Column(db.Float, default=0.0)
    relation_score = db.Column(db.Float, default=0.0)
    skill_score = db.Column(db.Float, default=0.0)
    ai_sort_score = db.Column(db.Float, default=0.0)
    
    # 实际执行记录
    actual_start_time = db.Column(db.DateTime)
    actual_end_time = db.Column(db.DateTime)
    actual_duration = db.Column(db.Integer)
    
    # 预估信息（智能时间解析使用）
    estimated_duration = db.Column(db.Integer)  # 预估时长（分钟）
    difficulty_level = db.Column(db.String(10), default='medium')  # 难度: easy, medium, hard
    difficulty_factors = db.Column(db.Text)  # 难度评估因素（JSON）
    
    # 任务状态: pending(待处理), in_progress(进行中), paused(已暂停), completed(已完成)
    status = db.Column(db.String(20), default='pending')
    
    # 重复任务关联
    recurring_rule_id = db.Column(db.Integer, db.ForeignKey('recurring_rule.id'), nullable=True)
    is_recurring_instance = db.Column(db.Integer, default=0)
    parent_task_id = db.Column(db.Integer, db.ForeignKey('task.id'), nullable=True)
    
    # 批量创建标识
    batch_id = db.Column(db.String(50), nullable=True)  # 批次ID
    batch_index = db.Column(db.Integer, nullable=True)  # 批次内序号
    
    # 时间戳
    created_at = db.Column(db.DateTime, default=datetime.now)
    updated_at = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now)

    # 关联关系
    tags = db.relationship('Tag', secondary='task_tag', backref='tasks', lazy='dynamic')
    recurring_rule = db.relationship('RecurringRule', backref='tasks')
    parent_task = db.relationship('Task', remote_side=[id], backref='instances')
    user = db.relationship('User', backref='tasks')

    # 数据库索引优化
    # 使用复合索引优化常用查询，删除冗余的单列索引
    __table_args__ = (
        # 复合索引：用户+完成状态+AI排序分数（用于任务列表查询）
        db.Index('idx_task_user_status_score', 'user_id', 'is_completed', 'ai_sort_score'),
        # 复合索引：用户+结束时间（用于时间范围查询）
        db.Index('idx_task_user_time', 'user_id', 'end_time'),
        # 复合索引：用户+分类+完成状态（用于分类查询）
        db.Index('idx_task_user_category', 'user_id', 'category', 'is_completed'),
        # 单列索引：创建时间（用于排序）
        db.Index('idx_created_at', 'created_at'),
    )

    def to_dict(self, include_tags=True):
        """转换为字典"""
        data = {
            'id': self.id,
            'user_id': self.user_id,
            'title': self.title,
            'description': self.description,
            'category': self.category,
            'priority': self.priority,
            'manual_order': self.manual_order,
            'start_time': format_datetime(self.start_time),
            'end_time': format_datetime(self.end_time),
            'is_completed': self.is_completed,
            'ai_suggestion': self.ai_suggestion,
            'time_score': self.time_score,
            'importance_score': self.importance_score,
            'impact_score': self.impact_score,
            'money_score': self.money_score,
            'relation_score': self.relation_score,
            'skill_score': self.skill_score,
            'ai_sort_score': self.ai_sort_score,
            'actual_start_time': format_datetime(self.actual_start_time),
            'actual_end_time': format_datetime(self.actual_end_time),
            'actual_duration': self.actual_duration,
            'estimated_duration': self.estimated_duration,
            'difficulty_level': self.difficulty_level,
            'status': self.status,
            'recurring_rule_id': self.recurring_rule_id,
            'is_recurring_instance': self.is_recurring_instance,
            'parent_task_id': self.parent_task_id,
            'created_at': format_datetime(self.created_at),
            'updated_at': format_datetime(self.updated_at)
        }
        
        if include_tags:
            data['tags'] = [tag.to_dict() for tag in self.tags]
            data['tag_ids'] = [tag.id for tag in self.tags]
            data['tag_names'] = [tag.name for tag in self.tags]
        
        return data

    def calculate_ai_sort_score(self):
        """计算AI综合排序分数（六维度加权）"""
        weights = {
            'time': 0.25,
            'importance': 0.20,
            'impact': 0.20,
            'money': 0.15,
            'relation': 0.10,
            'skill': 0.10
        }
        
        self.ai_sort_score = (
            self.time_score * weights['time'] +
            self.importance_score * weights['importance'] +
            self.impact_score * weights['impact'] +
            self.money_score * weights['money'] +
            self.relation_score * weights['relation'] +
            self.skill_score * weights['skill']
        )
        return self.ai_sort_score


class Tag(db.Model):
    """标签模型 - 多用户隔离版"""
    __tablename__ = 'tag'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.String(50), db.ForeignKey('user.id'), nullable=False, index=True)
    name = db.Column(db.String(50), nullable=False)
    color = db.Column(db.String(7), default='#4CAF50')
    icon = db.Column(db.String(50), default='fa-tag')
    sort_order = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.now)

    user = db.relationship('User', backref='tags')

    __table_args__ = (
        db.Index('idx_tag_user_id', 'user_id'),
        db.Index('idx_tag_name', 'name'),
        db.UniqueConstraint('user_id', 'name', name='uix_user_tag_name'),
    )

    def to_dict(self, include_task_count=False):
        """转换为字典
        
        Args:
            include_task_count: 是否包含任务计数（避免N+1查询，默认False）
        """
        result = {
            'id': self.id,
            'user_id': self.user_id,
            'name': self.name,
            'color': self.color,
            'icon': self.icon,
            'sort_order': self.sort_order,
            'created_at': format_datetime(self.created_at),
        }
        
        # 仅在需要时计算task_count，避免N+1查询问题
        if include_task_count:
            from sqlalchemy import func
            try:
                task_count = db.session.query(func.count('*')).select_from(TaskTag).join(
                    Task, TaskTag.task_id == Task.id
                ).filter(
                    TaskTag.tag_id == self.id,
                    Task.user_id == self.user_id,
                    Task.is_completed == 0
                ).scalar() or 0
            except:
                task_count = 0
            result['task_count'] = task_count
        
        return result


class TaskTag(db.Model):
    """任务-标签关联表"""
    __tablename__ = 'task_tag'

    task_id = db.Column(db.Integer, db.ForeignKey('task.id'), primary_key=True)
    tag_id = db.Column(db.Integer, db.ForeignKey('tag.id'), primary_key=True)
    created_at = db.Column(db.DateTime, default=datetime.now)


class RecurringRule(db.Model):
    """重复任务规则模型 - 多用户隔离版"""
    __tablename__ = 'recurring_rule'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.String(50), db.ForeignKey('user.id'), nullable=False, index=True)
    name = db.Column(db.String(100), nullable=False)
    recurring_type = db.Column(db.String(20), default='daily')
    interval = db.Column(db.Integer, default=1)
    week_days = db.Column(db.String(20), default='')
    month_day = db.Column(db.Integer, nullable=True)
    cron_expression = db.Column(db.String(100), nullable=True)
    start_date = db.Column(db.DateTime, default=datetime.now)
    end_date = db.Column(db.DateTime, nullable=True)
    max_occurrences = db.Column(db.Integer, nullable=True)
    task_template = db.Column(db.Text)
    is_active = db.Column(db.Integer, default=1)
    last_generated_date = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.now)
    updated_at = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now)

    user = db.relationship('User', backref='recurring_rules')

    __table_args__ = (
        db.Index('idx_recurring_user_id', 'user_id'),
        db.Index('idx_recurring_active', 'is_active'),
    )

    def to_dict(self):
        """转换为字典"""
        import json
        return {
            'id': self.id,
            'user_id': self.user_id,
            'name': self.name,
            'recurring_type': self.recurring_type,
            'interval': self.interval,
            'week_days': json.loads(self.week_days) if self.week_days else [],
            'month_day': self.month_day,
            'cron_expression': self.cron_expression,
            'start_date': format_datetime(self.start_date),
            'end_date': format_datetime(self.end_date),
            'max_occurrences': self.max_occurrences,
            'task_template': json.loads(self.task_template) if self.task_template else {},
            'is_active': self.is_active,
            'last_generated_date': format_datetime(self.last_generated_date),
            'created_at': format_datetime(self.created_at),
            'updated_at': format_datetime(self.updated_at)
        }

    def get_next_occurrence(self, from_date=None):
        """计算下一次重复日期"""
        if not from_date:
            from_date = datetime.now()
        
        if self.recurring_type == 'daily':
            return from_date + timedelta(days=self.interval)
        
        elif self.recurring_type == 'weekly':
            import json
            week_days = json.loads(self.week_days) if self.week_days else []
            if not week_days:
                return from_date + timedelta(weeks=self.interval)
            
            current_weekday = from_date.weekday()
            days_ahead = None
            
            for day in sorted(week_days):
                if day > current_weekday:
                    days_ahead = day - current_weekday
                    break
            
            if days_ahead is None:
                days_ahead = (7 - current_weekday) + min(week_days)
            
            return from_date + timedelta(days=days_ahead)
        
        elif self.recurring_type == 'monthly':
            if self.month_day:
                next_month = from_date.replace(day=1) + timedelta(days=32)
                next_month = next_month.replace(day=1)
                try:
                    return next_month.replace(day=min(self.month_day, 28))
                except ValueError:
                    return next_month
            return from_date + timedelta(days=30)
        
        return None


class AIAnalysis(db.Model):
    """AI分析结果存储模型"""
    __tablename__ = 'ai_analysis'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.String(50), db.ForeignKey('user.id'), nullable=False, index=True)
    task_id = db.Column(db.Integer, db.ForeignKey('task.id'), nullable=True)
    analysis_type = db.Column(db.String(50), nullable=False)
    content = db.Column(db.Text)
    structured_data = db.Column(db.Text)
    time_score = db.Column(db.Float, nullable=True)
    importance_score = db.Column(db.Float, nullable=True)
    impact_score = db.Column(db.Float, nullable=True)
    money_score = db.Column(db.Float, nullable=True)
    relation_score = db.Column(db.Float, nullable=True)
    skill_score = db.Column(db.Float, nullable=True)
    api_model = db.Column(db.String(50))
    api_tokens_used = db.Column(db.Integer, nullable=True)
    api_latency_ms = db.Column(db.Integer, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.now)

    user = db.relationship('User', backref='ai_analyses')

    __table_args__ = (
        db.Index('idx_analysis_user_id', 'user_id'),
        db.Index('idx_analysis_type', 'analysis_type'),
    )

    def to_dict(self):
        """转换为字典"""
        import json
        return {
            'id': self.id,
            'user_id': self.user_id,
            'task_id': self.task_id,
            'analysis_type': self.analysis_type,
            'content': self.content,
            'structured_data': json.loads(self.structured_data) if self.structured_data else {},
            'six_dimensions': {
                'time': self.time_score,
                'importance': self.importance_score,
                'impact': self.impact_score,
                'money': self.money_score,
                'relation': self.relation_score,
                'skill': self.skill_score
            },
            'api_model': self.api_model,
            'api_tokens_used': self.api_tokens_used,
            'api_latency_ms': self.api_latency_ms,
            'created_at': format_datetime(self.created_at)
        }


class Reminder(db.Model):
    """提醒模型 - 多用户隔离版"""
    __tablename__ = 'reminder'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.String(50), db.ForeignKey('user.id'), nullable=False, index=True)
    task_id = db.Column(db.Integer, db.ForeignKey('task.id'))
    remind_time = db.Column(db.DateTime, nullable=False)
    is_sent = db.Column(db.Integer, default=0)
    remind_type = db.Column(db.String(20), default='before')
    advance_minutes = db.Column(db.Integer, default=15)
    created_at = db.Column(db.DateTime, default=datetime.now)

    task = db.relationship('Task', backref='reminders')
    user = db.relationship('User', backref='reminders')

    __table_args__ = (
        db.Index('idx_reminder_user_id', 'user_id'),
    )

    def to_dict(self):
        """转换为字典"""
        return {
            'id': self.id,
            'user_id': self.user_id,
            'task_id': self.task_id,
            'remind_time': format_datetime(self.remind_time),
            'is_sent': self.is_sent,
            'remind_type': self.remind_type,
            'advance_minutes': self.advance_minutes,
            'created_at': format_datetime(self.created_at)
        }


class Category(db.Model):
    """分类模型 - 多用户隔离版"""
    __tablename__ = 'category'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.String(50), db.ForeignKey('user.id'), nullable=False, index=True)
    name = db.Column(db.String(50), nullable=False)
    color = db.Column(db.String(7), default='#757575')
    icon = db.Column(db.String(50), default='fa-folder')
    is_hidden = db.Column(db.Integer, default=0)
    is_custom = db.Column(db.Integer, default=0)
    sort_order = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.now)

    user = db.relationship('User', backref='categories')

    __table_args__ = (
        db.Index('idx_category_user_id', 'user_id'),
        db.UniqueConstraint('user_id', 'name', name='uix_user_category_name'),
    )

    def to_dict(self):
        """转换为字典"""
        return {
            'id': self.id,
            'user_id': self.user_id,
            'name': self.name,
            'color': self.color,
            'icon': self.icon,
            'is_hidden': bool(self.is_hidden),
            'is_custom': bool(self.is_custom),
            'sort_order': self.sort_order,
            'created_at': format_datetime(self.created_at)
        }
