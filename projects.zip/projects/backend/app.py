"""
智能日程助手 - 后端主程序
基于Flask框架，提供RESTful API
功能：标签体系、重复任务、六维度AI排序、完成事项分析
"""

import os
import sys
from datetime import datetime

from dotenv import load_dotenv
from flask import Flask, jsonify, send_from_directory
from flask_cors import CORS
from sqlalchemy import text

# 添加backend目录到路径
backend_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, backend_dir)

from extensions import db
from models.task import Tag, User
from models.campus import Course, Exam, Semester
from config import Config
from routes import (
    ai_bp, analysis_bp, category_bp, reminder_bp,
    stats_bp, task_bp, tag_bp, recurring_bp, ai_sort_bp,
    ai_duration_bp, ai_deadline_bp, ai_study_bp, ai_quota_bp,
    user_behavior_bp, dynamic_sort_bp, task_tracking_bp, task_batch_bp
)
from routes.user_routes import user_bp
from routes.auth_routes import auth_bp
from routes.campus import campus_bp

# 深度上下文逻辑感知系统路由
try:
    from routes.context_routes import context_bp
    CONTEXT_ROUTES_AVAILABLE = True
except ImportError:
    CONTEXT_ROUTES_AVAILABLE = False


def get_database_path():
    """获取数据库路径，确保在可写目录下"""
    # 检查是否为生产环境
    env = os.getenv('COZE_PROJECT_ENV', 'DEV')
    
    if env == 'PROD':
        # 生产环境使用 /tmp 目录（唯一确定可写的目录）
        db_dir = '/tmp/smart_scheduler'
        os.makedirs(db_dir, exist_ok=True)
        db_path = os.path.join(db_dir, 'schedule.db')
        print(f"[DB] 生产环境数据库路径: {db_path}")
        return db_path
    else:
        # 开发环境使用项目目录
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        db_dir = os.path.join(base_dir, 'instance')
        os.makedirs(db_dir, exist_ok=True)
        db_path = os.path.join(db_dir, 'schedule.db')
        print(f"[DB] 开发环境数据库路径: {db_path}")
        return db_path


def create_app():
    """应用工厂函数"""
    # 清除 VAPID 密钥缓存，确保使用新格式密钥
    try:
        from utils.push_notification import clear_vapid_keys_cache
        clear_vapid_keys_cache()
    except Exception:
        pass
    
    # 确定静态文件目录
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    static_folder = os.path.join(base_dir, 'frontend')
    
    # 使用可写目录作为instance路径
    db_path = get_database_path()
    instance_path = os.path.dirname(db_path)
    
    app = Flask(__name__, 
                static_folder=static_folder,
                instance_path=instance_path)

    # 配置 - 使用可写目录的数据库
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + db_path
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    # SECRET_KEY 已在 Config 中处理，这里不再重复设置
    # 确保从 Config 类加载
    app.config.from_object(Config)
    
    # SQLite 特定配置 + 连接池配置
    app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {
        'connect_args': {
            'check_same_thread': False
        },
        # 连接池配置
        'pool_size': 10,              # 连接池大小
        'max_overflow': 20,           # 最大溢出连接
        'pool_timeout': 30,           # 获取连接超时时间（秒）
        'pool_recycle': 3600,         # 连接回收时间（秒）
        'pool_pre_ping': True,        # 连接前 ping 测试，自动回收失效连接
    }

    # 初始化扩展
    db.init_app(app)
    
    # CORS配置 - 支持 httpOnly Cookie
    # 从环境变量读取允许的源，支持多个域名逗号分隔
    allowed_origins_str = os.getenv('CORS_ALLOWED_ORIGINS', 'http://localhost:5000,http://127.0.0.1:5000')
    allowed_origins = [origin.strip() for origin in allowed_origins_str.split(',') if origin.strip()]
    
    # 生产环境安全检查
    env = os.getenv('COZE_PROJECT_ENV', 'DEV')
    if env == 'PROD':
        # 生产环境必须配置具体域名，不能使用通配符
        if '*' in allowed_origins or not allowed_origins:
            print("[WARN] 生产环境CORS配置不安全，请设置 CORS_ALLOWED_ORIGINS 环境变量指定允许的域名")
            allowed_origins = []  # 生产环境不允许任何跨域请求
    
    CORS(app, resources={
        r"/api/*": {
            "origins": allowed_origins,
            "methods": ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
            "allow_headers": ["Content-Type", "Authorization", "Accept", "X-User-ID"],
            "supports_credentials": True,  # 关键：支持 Cookie
            "expose_headers": ["Set-Cookie"],
            "max_age": 86400  # 预检请求缓存24小时
        }
    })
    
    print(f"[CORS] 配置: 允许的源 = {allowed_origins}")

    # 注册蓝图
    blueprints = [
        auth_bp, user_bp, task_bp, reminder_bp, ai_bp, stats_bp, analysis_bp,
        category_bp, tag_bp, recurring_bp, ai_sort_bp,
        # 拆分后的AI功能模块
        ai_duration_bp, ai_deadline_bp, ai_study_bp, ai_quota_bp,
        # 用户行为分析模块
        user_behavior_bp,
        # 动态排序模块
        dynamic_sort_bp,
        # 任务状态跟踪模块
        task_tracking_bp,
        # 批量任务管理模块
        task_batch_bp,
        # 校园场景模块
        campus_bp
    ]
    
    # 深度上下文逻辑感知系统模块（如果可用）
    if CONTEXT_ROUTES_AVAILABLE:
        blueprints.append(context_bp)
        print("[深度上下文逻辑感知] 模块已加载")
    else:
        print("[深度上下文逻辑感知] 模块未加载")
    
    for bp in blueprints:
        app.register_blueprint(bp)

    # 初始化性能监控中间件
    from utils.performance import PerformanceMiddleware
    performance_middleware = PerformanceMiddleware(app)
    
    # 每次请求开始时刷新会话，确保读取最新数据
    @app.before_request
    def before_request():
        db.session.expire_all()

    # 全局错误处理
    @app.after_request
    def after_request(response):
        response.headers.add('Access-Control-Allow-Origin', '*')
        response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization,Accept')
        response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS')
        return response

    @app.errorhandler(Exception)
    def handle_exception(e):
        print(f"服务器错误: {e}")
        return jsonify({
            "success": False,
            "message": f"服务器错误: {str(e)}"
        }), 500

    # 静态文件路由
    @app.route('/')
    def index():
        return send_from_directory(static_folder, 'index.html')

    @app.route('/login.html')
    def login_page():
        return send_from_directory(static_folder, 'login.html')

    @app.route('/<path:path>')
    def serve_static(path):
        try:
            return send_from_directory(static_folder, path)
        except:
            return send_from_directory(static_folder, 'index.html')

    # API路由
    @app.route('/api/health')
    def health_check():
        """健康检查接口"""
        try:
            db.session.execute(text('SELECT 1'))
            db_status = "connected"
        except Exception as e:
            db_status = f"error: {str(e)}"

        return jsonify({
            "status": "healthy",
            "timestamp": datetime.now().isoformat(),
            "database": db_status,
            "version": "2.0.0"
        })

    @app.route('/api/features')
    def get_features():
        """获取功能列表"""
        return jsonify({
            "success": True,
            "features": {
                "task_management": {
                    "name": "任务管理",
                    "description": "创建、编辑、删除、完成任务",
                    "endpoints": ["/api/tasks"]
                },
                "tag_system": {
                    "name": "标签体系",
                    "description": "滴答清单风格的标签管理",
                    "endpoints": ["/api/tags"]
                },
                "recurring_tasks": {
                    "name": "重复任务",
                    "description": "日/周/月重复任务设定",
                    "endpoints": ["/api/recurring"]
                },
                "ai_sorting": {
                    "name": "AI智能排序",
                    "description": "六维度本地AI排序",
                    "endpoints": ["/api/ai/sort"]
                },
                "ai_analysis": {
                    "name": "AI完成事项分析",
                    "description": "千问API驱动的完成事项分析",
                    "endpoints": ["/api/analysis/completion"]
                },
                "statistics": {
                    "name": "数据统计",
                    "description": "任务完成统计和可视化",
                    "endpoints": ["/api/stats"]
                }
            }
        })

    # 性能监控API
    @app.route('/api/performance/stats')
    def performance_stats():
        """获取性能统计信息"""
        from utils.performance import metrics
        return jsonify({
            "success": True,
            "stats": metrics.get_stats()
        })
    
    @app.route('/api/performance/slow-requests')
    def slow_requests():
        """获取慢请求列表"""
        from flask import request
        from utils.performance import metrics
        limit = request.args.get('limit', 20, type=int)
        return jsonify({
            "success": True,
            "slow_requests": metrics.get_slow_requests(limit)
        })

    return app


def init_database(app):
    """初始化数据库"""
    with app.app_context():
        db.create_all()
        print("[DB] 数据库表创建成功！")
        
        # 注意：预设标签现在由用户首次访问时通过 /api/tags/init 初始化
        # 不再在启动时创建全局预设标签，实现多用户数据隔离
        print("[DB] 数据库初始化完成！")
        
        # 初始化调度器（用于智能提醒）
        try:
            from utils.scheduler import scheduler
            scheduler.init_app(app)
        except Exception as e:
            print(f"[WARN] 调度器初始化失败: {e}")


def main():
    """主函数"""
    load_dotenv()
    application = create_app()
    init_database(application)

    # 获取端口
    port = int(os.getenv('DEPLOY_RUN_PORT', 5000))
    
    print("[START] 智能日程助手后端服务启动中...")
    print(f"[START] 服务地址: http://localhost:{port}")
    print(f"[START] API文档: http://localhost:{port}/api/features")
    
    application.run(debug=True, host='0.0.0.0', port=port)


# 创建应用实例
app = create_app()
init_database(app)

if __name__ == '__main__':
    main()
