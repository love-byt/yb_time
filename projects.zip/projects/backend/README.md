# Backend - 智能日程助手后端服务

基于 Flask 框架的 RESTful API 服务，提供任务管理、AI 分析、用户认证等核心功能。

## 技术栈

| 技术 | 版本 | 用途 |
|------|------|------|
| Python | 3.12+ | 编程语言 |
| Flask | 3.1 | Web 框架 |
| SQLAlchemy | 2.0+ | ORM 数据库操作 |
| Alembic | 1.13+ | 数据库迁移 |
| pytest | 8.0+ | 测试框架 |
| Redis | 7.0+ | 缓存 (可选) |

## 目录结构

```
backend/
├── app.py                 # Flask 应用入口
├── config.py              # 应用配置
├── extensions.py          # Flask 扩展初始化
├── migrate.py             # 数据库迁移脚本
├── pytest.ini             # 测试配置
├── requirements.txt       # Python 依赖
├── alembic.ini            # Alembic 配置
├── models/                # 数据模型
│   ├── __init__.py
│   ├── task.py            # 核心模型 (User, Task, Tag, Category, RecurringRule)
│   └── readme.txt
├── routes/                # API 路由
│   ├── __init__.py
│   ├── auth_routes.py     # 认证路由
│   ├── user_routes.py     # 用户管理
│   ├── task_routes.py     # 任务管理
│   ├── task_batch_routes.py  # 批量任务
│   ├── tag_routes.py      # 标签管理
│   ├── category_routes.py # 分类管理
│   ├── recurring_routes.py # 重复任务
│   ├── reminder_routes.py # 提醒功能
│   ├── stats_routes.py    # 统计分析
│   ├── ai_routes.py       # AI 分析
│   ├── ai_sort_routes.py  # AI 排序
│   └── analysis_routes.py # 任务分析
├── utils/                 # 工具函数
│   ├── __init__.py
│   ├── auth.py            # 统一认证模块
│   ├── ai_sorter.py       # AI 智能排序算法
│   ├── ai_helper.py       # AI 助手封装
│   ├── cache.py           # 缓存系统
│   ├── smart_time_parser.py # 智能时间解析
│   ├── smart_time_recommender.py # 智能时间推荐
│   ├── difficulty_evaluator.py   # 任务难度评估
│   ├── batch_parser.py    # 批量任务解析
│   ├── file_importer.py   # 文件导入器
│   ├── scheduler.py       # 定时任务
│   └── push_notification.py # 推送通知
├── tests/                 # 测试用例
│   ├── conftest.py        # pytest 配置
│   ├── test_auth.py       # 认证测试
│   ├── test_ai_sorter.py  # AI 排序测试
│   ├── test_tasks.py      # 任务管理测试
│   ├── test_batch_tasks.py # 批量任务测试
│   └── test_routes.py     # 路由集成测试
└── migrations/            # 数据库迁移
    ├── env.py
    ├── script.py.mako
    └── versions/          # 迁移版本
```

## 核心文件说明

### app.py

Flask 应用主入口，包含：
- 应用工厂函数 `create_app()`
- 蓝图注册
- 扩展初始化
- 静态文件服务配置
- 错误处理

### config.py

应用配置管理，支持：
- 开发/测试/生产环境配置
- 数据库连接配置
- 密钥配置
- AI API 配置
- 缓存配置

### extensions.py

Flask 扩展初始化：
- SQLAlchemy 数据库实例
- 扩展懒加载模式

### migrate.py

数据库迁移命令封装：
```bash
# 创建迁移
python migrate.py migrate -m "描述"

# 执行升级
python migrate.py upgrade

# 回滚
python migrate.py downgrade
```

## 数据模型

### 核心模型 (models/task.py)

| 模型 | 说明 |
|------|------|
| `User` | 用户模型，包含认证信息 |
| `Task` | 任务模型，核心数据实体 |
| `Tag` | 标签模型 |
| `Category` | 分类模型 |
| `RecurringRule` | 重复任务规则 |

### Task 模型字段

```python
- id: 主键
- user_id: 用户ID (外键)
- title: 任务标题
- description: 任务描述
- category: 分类
- priority: 优先级 (1-4)
- start_time/end_time: 开始/截止时间
- is_completed: 完成状态
- ai_suggestion: AI建议
- time_score/importance_score/...: 六维度评分
- actual_duration: 实际耗时
- estimated_duration: 预估耗时
- difficulty_level: 难度等级
- batch_id/batch_index: 批量标识
- created_at/updated_at: 时间戳
```

## API 路由

### 认证路由 (auth_routes.py)

| 端点 | 方法 | 说明 |
|------|------|------|
| `/api/auth/register` | POST | 用户注册 |
| `/api/auth/login` | POST | 用户登录 |
| `/api/auth/refresh` | POST | 刷新 Token |
| `/api/auth/logout` | POST | 退出登录 |

### 任务路由 (task_routes.py)

| 端点 | 方法 | 说明 |
|------|------|------|
| `/api/tasks` | GET | 获取任务列表 |
| `/api/tasks` | POST | 创建任务 |
| `/api/tasks/<id>` | GET | 获取任务详情 |
| `/api/tasks/<id>` | PUT | 更新任务 |
| `/api/tasks/<id>` | DELETE | 删除任务 |
| `/api/tasks/<id>/complete` | POST | 完成任务 |
| `/api/tasks/batch` | POST | 批量创建 |
| `/api/tasks/parse-text` | POST | 文本解析 |
| `/api/tasks/import` | POST | 文件导入 |

### AI 路由 (ai_*.py)

| 端点 | 说明 |
|------|------|
| `/api/ai/sort` | 智能排序 |
| `/api/ai/analyze-duration` | 耗时分析 |
| `/api/ai/analyze-deadline` | 截止分析 |
| `/api/ai/study-plan/daily` | 学习计划 |
| `/api/ai/quota` | AI 配额查询 |

## 工具函数

### 认证模块 (utils/auth.py)

```python
class AuthManager:
    - generate_token(user_id)  # 生成 JWT
    - verify_token(token)      # 验证 Token
    
@require_auth  # 认证装饰器
```

### AI 排序 (utils/ai_sorter.py)

```python
class SixDimensionSorter:
    - 六维度评分算法
    - 支持权重配置
    - 分类加成
    - 长任务因子
```

### 智能时间解析 (utils/smart_time_parser.py)

```python
class SmartTimeParser:
    - 自然语言时间解析
    - 支持相对时间（明天、下周）
    - 支持时间段（上午、下午）
    - 支持周几（周一、周末）
```

### 智能时间推荐 (utils/smart_time_recommender.py)

```python
class SmartTimeRecommender:
    - 基于用户历史行为推荐
    - 智能截止时间生成
    - 任务难度评估
```

### 批量任务 (utils/batch_parser.py, file_importer.py)

```python
class BatchTaskParser:
    - 自然语言批量解析
    - 支持时间、耗时、优先级提取

class TaskFileImporter:
    - Excel/CSV 导入
    - 自动字段映射
```

## 测试

### 运行测试

```bash
# 运行所有测试
pytest

# 运行特定测试文件
pytest tests/test_auth.py

# 运行特定测试函数
pytest tests/test_auth.py::test_register

# 带覆盖率报告
pytest --cov=./ --cov-report=html

# 查看 HTML 报告
open htmlcov/index.html
```

### 测试配置 (pytest.ini)

```ini
[pytest]
testpaths = tests
python_files = test_*.py
python_classes = Test*
python_functions = test_*
addopts = -v --tb=short
```

## 开发指南

### 添加新路由

1. 在 `routes/` 创建新文件
2. 定义蓝图和路由函数
3. 在 `routes/__init__.py` 导出
4. 在 `app.py` 注册蓝图

### 添加新模型

1. 在 `models/` 定义模型类
2. 创建数据库迁移
3. 更新 `models/__init__.py`

### 添加新工具函数

1. 在 `utils/` 创建模块
2. 实现功能函数/类
3. 在 `utils/__init__.py` 导出公共接口

## 环境变量

| 变量 | 必需 | 说明 |
|------|------|------|
| `SECRET_KEY` | 是 | Flask 密钥 |
| `DATABASE_URL` | 是 | 数据库连接 |
| `AI_API_KEY` | 否 | 千问 API 密钥 |
| `REDIS_URL` | 否 | Redis 连接 |
| `DEBUG` | 否 | 调试模式 |

## 常见问题

### 数据库迁移失败

```bash
# 删除迁移记录，重新创建
rm -rf migrations/versions/*.py
python migrate.py migrate -m "initial"
python migrate.py upgrade
```

### 导入错误

确保在 `backend/` 目录下运行：
```bash
cd backend
python app.py
```

### 测试数据库

测试使用独立的内存数据库，不会影响开发数据。

## 许可证

MIT License
