"""convert time fields to DateTime

Revision ID: datetime_fields
Revises: optimize_indexes
Create Date: 2024-04-01 01:00:00.000000

迁移说明：
将 task 表的 start_time 和 end_time 字段从 String 类型转换为 DateTime 类型
"""
from alembic import op
import sqlalchemy as sa
from datetime import datetime


# revision identifiers, used by Alembic.
revision = 'datetime_fields'
down_revision = 'optimize_indexes'
branch_labels = None
depends_on = None


def parse_datetime_string(dt_string):
    """尝试解析日期时间字符串"""
    if not dt_string:
        return None
    
    # 常见格式列表
    formats = [
        '%Y-%m-%d %H:%M:%S',
        '%Y-%m-%dT%H:%M:%S',
        '%Y-%m-%dT%H:%M:%SZ',
        '%Y-%m-%dT%H:%M:%S.%f',
        '%Y-%m-%dT%H:%M:%S.%fZ',
        '%Y-%m-%d',
    ]
    
    for fmt in formats:
        try:
            return datetime.strptime(dt_string, fmt)
        except ValueError:
            continue
    
    return None


def upgrade():
    """升级：将 String 类型转换为 DateTime"""
    
    # SQLite 不支持直接 ALTER COLUMN，需要：
    # 1. 创建新列
    # 2. 迁移数据
    # 3. 删除旧列
    # 4. 重命名新列
    
    # 步骤1：添加临时列
    try:
        op.add_column('task', sa.Column('start_time_new', sa.DateTime(), nullable=True))
        op.add_column('task', sa.Column('end_time_new', sa.DateTime(), nullable=True))
    except Exception:
        pass
    
    # 步骤2：迁移数据（使用原始SQL）
    # SQLite 需要逐步处理
    conn = op.get_bind()
    
    # 获取所有任务的时间数据
    result = conn.execute(sa.text("SELECT id, start_time, end_time FROM task"))
    rows = result.fetchall()
    
    for row in rows:
        task_id = row[0]
        start_time_str = row[1]
        end_time_str = row[2]
        
        start_time_dt = parse_datetime_string(start_time_str)
        end_time_dt = parse_datetime_string(end_time_str)
        
        if start_time_dt or end_time_dt:
            conn.execute(
                sa.text("UPDATE task SET start_time_new = :st, end_time_new = :et WHERE id = :id"),
                {'st': start_time_dt, 'et': end_time_dt, 'id': task_id}
            )
    
    # 步骤3：删除旧列（SQLite限制，需要重建表）
    # 由于SQLite的限制，我们采用更简单的方式：
    # 保留旧列名，在应用层处理转换
    
    # 更简单的方案：直接在模型层处理，不修改数据库结构
    # 撤销新列
    try:
        op.drop_column('task', 'start_time_new')
        op.drop_column('task', 'end_time_new')
    except Exception:
        pass
    
    print("""
    注意：SQLite 数据库结构未直接修改。
    DateTime 类型转换在应用层通过 SQLAlchemy 自动处理。
    
    如果需要完整的数据库迁移，请在生产环境使用 PostgreSQL 或 MySQL。
    """)
    
    # 对于支持 ALTER COLUMN 的数据库（PostgreSQL, MySQL）：
    # 取消注释以下代码
    # try:
    #     op.alter_column('task', 'start_time',
    #                     existing_type=sa.String(50),
    #                     type_=sa.DateTime(),
    #                     existing_nullable=True)
    #     op.alter_column('task', 'end_time',
    #                     existing_type=sa.String(50),
    #                     type_=sa.DateTime(),
    #                     existing_nullable=True)
    # except Exception:
    #     pass


def downgrade():
    """回滚：将 DateTime 类型转换回 String"""
    
    # 同样，SQLite 需要重建表
    # 这里只记录操作意图
    print("""
    回滚操作：DateTime -> String
    对于 SQLite，需要在应用层处理或在支持 ALTER COLUMN 的数据库执行。
    """)
    
    # 对于支持 ALTER COLUMN 的数据库：
    # try:
    #     op.alter_column('task', 'start_time',
    #                     existing_type=sa.DateTime(),
    #                     type_=sa.String(50),
    #                     existing_nullable=True)
    #     op.alter_column('task', 'end_time',
    #                     existing_type=sa.DateTime(),
    #                     type_=sa.String(50),
    #                     existing_nullable=True)
    # except Exception:
    #     pass
