"""初始数据库结构

Revision ID: 001
Revises: 
Create Date: 2026-03-29 14:30:00

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '001'
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """升级数据库 - 创建所有表"""
    
    # 创建用户表
    op.create_table(
        'user',
        sa.Column('id', sa.String(50), primary_key=True),
        sa.Column('username', sa.String(50), unique=True, nullable=True),
        sa.Column('password_hash', sa.String(256), nullable=True),
        sa.Column('email', sa.String(100), unique=True, nullable=True),
        sa.Column('nickname', sa.String(50), nullable=True),
        sa.Column('avatar', sa.String(200), nullable=True),
        sa.Column('push_subscription', sa.Text, nullable=True),
        sa.Column('created_at', sa.DateTime, server_default=sa.func.now()),
        sa.Column('last_visit', sa.DateTime, server_default=sa.func.now()),
        sa.Column('settings', sa.Text, server_default='{}'),
    )
    
    # 创建任务表
    op.create_table(
        'task',
        sa.Column('id', sa.Integer, primary_key=True),
        sa.Column('user_id', sa.String(50), sa.ForeignKey('user.id'), nullable=False),
        sa.Column('title', sa.String(200), nullable=False),
        sa.Column('description', sa.Text),
        sa.Column('category', sa.String(50), server_default='学习'),
        sa.Column('priority', sa.Integer, server_default='0'),
        sa.Column('manual_order', sa.Integer, server_default='0'),
        sa.Column('start_time', sa.String(50)),
        sa.Column('end_time', sa.String(50)),
        sa.Column('is_completed', sa.Integer, server_default='0'),
        sa.Column('ai_suggestion', sa.Text),
        # 六维度评分
        sa.Column('time_score', sa.Float, server_default='0.0'),
        sa.Column('importance_score', sa.Float, server_default='0.0'),
        sa.Column('impact_score', sa.Float, server_default='0.0'),
        sa.Column('money_score', sa.Float, server_default='0.0'),
        sa.Column('relation_score', sa.Float, server_default='0.0'),
        sa.Column('skill_score', sa.Float, server_default='0.0'),
        sa.Column('ai_sort_score', sa.Float, server_default='0.0'),
        # 实际执行
        sa.Column('actual_start_time', sa.DateTime),
        sa.Column('actual_end_time', sa.DateTime),
        sa.Column('actual_duration', sa.Integer),
        # 重复任务
        sa.Column('recurring_rule_id', sa.Integer, sa.ForeignKey('recurring_rule.id'), nullable=True),
        sa.Column('is_recurring_instance', sa.Integer, server_default='0'),
        sa.Column('parent_task_id', sa.Integer, sa.ForeignKey('task.id'), nullable=True),
        # 时间戳
        sa.Column('created_at', sa.DateTime, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime, server_default=sa.func.now()),
    )
    
    # 创建任务索引
    op.create_index('idx_task_user_id', 'task', ['user_id'])
    op.create_index('idx_category', 'task', ['category'])
    op.create_index('idx_is_completed', 'task', ['is_completed'])
    op.create_index('idx_created_at', 'task', ['created_at'])
    op.create_index('idx_priority', 'task', ['priority'])
    op.create_index('idx_ai_sort_score', 'task', ['ai_sort_score'])
    
    # 创建标签表
    op.create_table(
        'tag',
        sa.Column('id', sa.Integer, primary_key=True),
        sa.Column('user_id', sa.String(50), sa.ForeignKey('user.id'), nullable=False),
        sa.Column('name', sa.String(50), nullable=False),
        sa.Column('color', sa.String(7), server_default='#4CAF50'),
        sa.Column('icon', sa.String(50), server_default='fa-tag'),
        sa.Column('sort_order', sa.Integer, server_default='0'),
        sa.Column('created_at', sa.DateTime, server_default=sa.func.now()),
    )
    
    op.create_index('idx_tag_user_id', 'tag', ['user_id'])
    op.create_index('idx_tag_name', 'tag', ['name'])
    op.create_unique_constraint('uix_user_tag_name', 'tag', ['user_id', 'name'])
    
    # 创建任务-标签关联表
    op.create_table(
        'task_tag',
        sa.Column('task_id', sa.Integer, sa.ForeignKey('task.id'), primary_key=True),
        sa.Column('tag_id', sa.Integer, sa.ForeignKey('tag.id'), primary_key=True),
        sa.Column('created_at', sa.DateTime, server_default=sa.func.now()),
    )
    
    # 创建重复任务规则表
    op.create_table(
        'recurring_rule',
        sa.Column('id', sa.Integer, primary_key=True),
        sa.Column('user_id', sa.String(50), sa.ForeignKey('user.id'), nullable=False),
        sa.Column('name', sa.String(100), nullable=False),
        sa.Column('recurring_type', sa.String(20), server_default='daily'),
        sa.Column('interval', sa.Integer, server_default='1'),
        sa.Column('week_days', sa.String(20), server_default=''),
        sa.Column('month_day', sa.Integer, nullable=True),
        sa.Column('cron_expression', sa.String(100), nullable=True),
        sa.Column('start_date', sa.DateTime, server_default=sa.func.now()),
        sa.Column('end_date', sa.DateTime, nullable=True),
        sa.Column('max_occurrences', sa.Integer, nullable=True),
        sa.Column('task_template', sa.Text),
        sa.Column('is_active', sa.Integer, server_default='1'),
        sa.Column('last_generated_date', sa.DateTime, nullable=True),
        sa.Column('created_at', sa.DateTime, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime, server_default=sa.func.now()),
    )
    
    op.create_index('idx_recurring_user_id', 'recurring_rule', ['user_id'])
    op.create_index('idx_recurring_active', 'recurring_rule', ['is_active'])
    
    # 创建AI分析结果表
    op.create_table(
        'ai_analysis',
        sa.Column('id', sa.Integer, primary_key=True),
        sa.Column('user_id', sa.String(50), sa.ForeignKey('user.id'), nullable=False),
        sa.Column('task_id', sa.Integer, sa.ForeignKey('task.id'), nullable=True),
        sa.Column('analysis_type', sa.String(50), nullable=False),
        sa.Column('content', sa.Text),
        sa.Column('structured_data', sa.Text),
        sa.Column('time_score', sa.Float, nullable=True),
        sa.Column('importance_score', sa.Float, nullable=True),
        sa.Column('impact_score', sa.Float, nullable=True),
        sa.Column('money_score', sa.Float, nullable=True),
        sa.Column('relation_score', sa.Float, nullable=True),
        sa.Column('skill_score', sa.Float, nullable=True),
        sa.Column('api_model', sa.String(50)),
        sa.Column('api_tokens_used', sa.Integer, nullable=True),
        sa.Column('api_latency_ms', sa.Integer, nullable=True),
        sa.Column('created_at', sa.DateTime, server_default=sa.func.now()),
    )
    
    op.create_index('idx_analysis_user_id', 'ai_analysis', ['user_id'])
    op.create_index('idx_analysis_type', 'ai_analysis', ['analysis_type'])
    
    # 创建提醒表
    op.create_table(
        'reminder',
        sa.Column('id', sa.Integer, primary_key=True),
        sa.Column('user_id', sa.String(50), sa.ForeignKey('user.id'), nullable=False),
        sa.Column('task_id', sa.Integer, sa.ForeignKey('task.id')),
        sa.Column('remind_time', sa.DateTime, nullable=False),
        sa.Column('is_sent', sa.Integer, server_default='0'),
        sa.Column('remind_type', sa.String(20), server_default='before'),
        sa.Column('advance_minutes', sa.Integer, server_default='15'),
        sa.Column('created_at', sa.DateTime, server_default=sa.func.now()),
    )
    
    op.create_index('idx_reminder_user_id', 'reminder', ['user_id'])
    
    # 创建分类表
    op.create_table(
        'category',
        sa.Column('id', sa.Integer, primary_key=True),
        sa.Column('user_id', sa.String(50), sa.ForeignKey('user.id'), nullable=False),
        sa.Column('name', sa.String(50), nullable=False),
        sa.Column('color', sa.String(7), server_default='#757575'),
        sa.Column('icon', sa.String(50), server_default='fa-folder'),
        sa.Column('is_hidden', sa.Integer, server_default='0'),
        sa.Column('is_custom', sa.Integer, server_default='0'),
        sa.Column('sort_order', sa.Integer, server_default='0'),
        sa.Column('created_at', sa.DateTime, server_default=sa.func.now()),
    )
    
    op.create_index('idx_category_user_id', 'category', ['user_id'])
    op.create_unique_constraint('uix_user_category_name', 'category', ['user_id', 'name'])


def downgrade() -> None:
    """回滚数据库 - 删除所有表"""
    op.drop_table('category')
    op.drop_table('reminder')
    op.drop_table('ai_analysis')
    op.drop_table('task_tag')
    op.drop_table('tag')
    op.drop_table('task')
    op.drop_table('recurring_rule')
    op.drop_table('user')
