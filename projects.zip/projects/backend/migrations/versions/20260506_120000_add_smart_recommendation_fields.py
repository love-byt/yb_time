"""添加智能推荐相关字段

Revision ID: 20260506_120000
Revises: 20260506_100000
Create Date: 2026-05-06 12:00:00

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '20260506_120000'
down_revision = '20260506_100000'
branch_labels = None
depends_on = None


def upgrade():
    # 添加难度相关字段
    op.add_column('task', sa.Column('difficulty_level', sa.String(20), nullable=True))
    op.add_column('task', sa.Column('difficulty_factors', sa.Text(), nullable=True))
    
    # 添加AI推荐信息字段
    op.add_column('task', sa.Column('ai_suggestion', sa.Text(), nullable=True))
    
    # 添加索引以提高查询性能
    op.create_index('ix_task_difficulty_level', 'task', ['difficulty_level'])
    op.create_index('ix_task_user_category', 'task', ['user_id', 'category'])


def downgrade():
    # 删除索引
    op.drop_index('ix_task_user_category', table_name='task')
    op.drop_index('ix_task_difficulty_level', table_name='task')
    
    # 删除字段
    op.drop_column('task', 'ai_suggestion')
    op.drop_column('task', 'difficulty_factors')
    op.drop_column('task', 'difficulty_level')
