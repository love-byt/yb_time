"""添加批量任务相关字段

Revision ID: 20260506_140000
Revises: 20260506_120000
Create Date: 2026-05-06 14:00:00

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '20260506_140000'
down_revision = '20260506_120000'
branch_labels = None
depends_on = None


def upgrade():
    # 添加批量创建标识字段
    op.add_column('task', sa.Column('batch_id', sa.String(50), nullable=True))
    op.add_column('task', sa.Column('batch_index', sa.Integer, nullable=True))
    
    # 创建索引以提高批量查询性能
    op.create_index('idx_task_batch_id', 'task', ['batch_id'])
    op.create_index('idx_task_batch', 'task', ['user_id', 'batch_id'])
    
    # 新增批量导入记录表
    op.create_table(
        'batch_imports',
        sa.Column('id', sa.String(50), primary_key=True),
        sa.Column('user_id', sa.String(50), nullable=False),
        sa.Column('import_type', sa.String(20)),  # manual/text/file
        sa.Column('source_text', sa.Text, nullable=True),
        sa.Column('file_name', sa.String(200), nullable=True),
        sa.Column('total_count', sa.Integer),
        sa.Column('success_count', sa.Integer),
        sa.Column('failed_count', sa.Integer),
        sa.Column('created_at', sa.DateTime, server_default=sa.func.now())
    )
    
    # 创建索引
    op.create_index('idx_batch_imports_user', 'batch_imports', ['user_id'])


def downgrade():
    # 删除索引
    op.drop_index('idx_task_batch', table_name='task')
    op.drop_index('idx_task_batch_id', table_name='task')
    op.drop_index('idx_batch_imports_user', table_name='batch_imports')
    
    # 删除表
    op.drop_table('batch_imports')
    
    # 删除字段
    op.drop_column('task', 'batch_index')
    op.drop_column('task', 'batch_id')
