"""optimize database indexes

Revision ID: optimize_indexes
Revises: 20260329_143000_initial_schema
Create Date: 2024-04-01 00:00:00.000000

索引优化说明：
1. 删除冗余单列索引
2. 创建复合索引优化常用查询
3. 添加覆盖索引减少回表查询
"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'optimize_indexes'
down_revision = '001'
branch_labels = None
depends_on = None


def upgrade():
    """优化数据库索引"""
    
    # 1. 删除冗余的单列索引（SQLite不支持DROP INDEX IF EXISTS，使用try-except）
    indexes_to_drop = [
        'idx_category',
        'idx_is_completed',
        'idx_priority',
        'idx_ai_sort_score'
    ]
    
    for idx_name in indexes_to_drop:
        try:
            op.drop_index(idx_name, table_name='task')
        except Exception:
            # 索引可能不存在，忽略错误
            pass
    
    # 2. 创建复合索引 - 优化常用查询
    
    # 任务列表查询：按用户+完成状态+排序
    # 查询模式：SELECT * FROM task WHERE user_id = ? AND is_completed = 0 ORDER BY ai_sort_score DESC
    try:
        op.create_index(
            'idx_task_user_status_score',
            'task',
            ['user_id', 'is_completed', 'ai_sort_score'],
            unique=False
        )
    except Exception:
        pass
    
    # 任务时间范围查询：按用户+时间范围
    # 查询模式：SELECT * FROM task WHERE user_id = ? AND end_time BETWEEN ? AND ?
    try:
        op.create_index(
            'idx_task_user_time',
            'task',
            ['user_id', 'end_time'],
            unique=False
        )
    except Exception:
        pass
    
    # 任务分类查询：按用户+分类+完成状态
    # 查询模式：SELECT * FROM task WHERE user_id = ? AND category = ? AND is_completed = ?
    try:
        op.create_index(
            'idx_task_user_category',
            'task',
            ['user_id', 'category', 'is_completed'],
            unique=False
        )
    except Exception:
        pass
    
    # 3. 保留有用的单列索引
    
    # 用户ID索引（用于简单查询）
    try:
        op.create_index('idx_task_user_id', 'task', ['user_id'], unique=False)
    except Exception:
        pass
    
    # 创建时间索引（用于排序和范围查询）
    try:
        op.create_index('idx_created_at', 'task', ['created_at'], unique=False)
    except Exception:
        pass
    
    print("[DB] 索引优化完成")


def downgrade():
    """回滚索引优化"""
    
    # 删除新创建的复合索引
    composite_indexes = [
        'idx_task_user_status_score',
        'idx_task_user_time',
        'idx_task_user_category'
    ]
    
    for idx_name in composite_indexes:
        try:
            op.drop_index(idx_name, table_name='task')
        except Exception:
            pass
    
    # 恢复原始单列索引
    try:
        op.create_index('idx_category', 'task', ['category'], unique=False)
    except Exception:
        pass
    
    try:
        op.create_index('idx_is_completed', 'task', ['is_completed'], unique=False)
    except Exception:
        pass
    
    try:
        op.create_index('idx_priority', 'task', ['priority'], unique=False)
    except Exception:
        pass
    
    try:
        op.create_index('idx_ai_sort_score', 'task', ['ai_sort_score'], unique=False)
    except Exception:
        pass
    
    print("[DB] 索引已回滚")
