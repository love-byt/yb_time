"""
Alembic环境配置
支持多环境数据库路径切换（开发/生产）
"""

import os
import sys
from logging.config import fileConfig

from alembic import context
from sqlalchemy import engine_from_config, pool

# 添加backend目录到路径
backend_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, backend_dir)

# 导入模型和扩展
from extensions import db
from models.task import User, Task, Tag, TaskTag, RecurringRule, AIAnalysis, Reminder, Category

# Alembic配置对象
config = context.config

# 设置数据库URL
def get_database_url():
    """获取数据库URL，支持开发/生产环境切换"""
    env = os.getenv('COZE_PROJECT_ENV', 'DEV')
    
    if env == 'PROD':
        # 生产环境使用 /tmp 目录
        db_dir = '/tmp/smart_scheduler'
        os.makedirs(db_dir, exist_ok=True)
        db_path = os.path.join(db_dir, 'schedule.db')
    else:
        # 开发环境使用项目目录
        base_dir = os.path.dirname(backend_dir)
        db_dir = os.path.join(base_dir, 'instance')
        os.makedirs(db_dir, exist_ok=True)
        db_path = os.path.join(db_dir, 'schedule.db')
    
    return f'sqlite:///{db_path}'


# 设置SQLAlchemy URL
config.set_main_option('sqlalchemy.url', get_database_url())

# 日志配置
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# 元数据对象，用于autogenerate
target_metadata = db.Model.metadata


def run_migrations_offline() -> None:
    """离线模式运行迁移（生成SQL脚本）"""
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )

    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    """在线模式运行迁移（直接操作数据库）"""
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )

    with connectable.connect() as connection:
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            compare_type=True,  # 比较字段类型变化
            compare_server_default=True,  # 比较默认值变化
        )

        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
