"""
测试脚本：检查校园场景数据库中的数据
"""
import os
import sys

# 添加 backend 目录到路径
backend_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, backend_dir)

from app import create_app
from extensions import db
from models.campus import Course, Exam, Semester
from models.task import User

def check_campus_data():
    app = create_app()
    with app.app_context():
        print("=" * 60)
        print("校园场景数据检查")
        print("=" * 60)
        
        # 检查用户
        users = User.query.all()
        print(f"\n📊 用户数量: {len(users)}")
        for user in users:
            print(f"   - {user.id}: {user.nickname or user.username}")
        
        if not users:
            print("   ⚠️ 没有用户数据！")
            return
        
        # 对每个用户检查数据
        for user in users:
            print(f"\n{'='*60}")
            print(f"用户: {user.id}")
            print(f"{'='*60}")
            
            # 检查课程
            courses = Course.query.filter_by(user_id=user.id).all()
            print(f"\n📚 课程数量: {len(courses)}")
            for course in courses:
                print(f"   - {course.name} ({course.code or '无代码'}) | "
                      f"周{course.day_of_week} {course.start_time}-{course.end_time}")
            
            # 检查考试
            exams = Exam.query.filter_by(user_id=user.id).all()
            print(f"\n📝 考试数量: {len(exams)}")
            for exam in exams:
                print(f"   - {exam.name} | {exam.exam_date} | {exam.location or '待定'}")
            
            # 检查学期
            semesters = Semester.query.filter_by(user_id=user.id).all()
            print(f"\n📅 学期数量: {len(semesters)}")
            for sem in semesters:
                current = "(当前)" if sem.is_current else ""
                print(f"   - {sem.name} {current} | {sem.start_date} ~ {sem.end_date}")
        
        print("\n" + "=" * 60)
        print("检查完成")
        print("=" * 60)

if __name__ == '__main__':
    check_campus_data()
