"""
测试配置文件
"""

import os
import sys
import pytest
import tempfile

# 添加backend目录到路径
backend_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, backend_dir)

from app import create_app
from extensions import db
from models.task import User, Task, Tag, Category


@pytest.fixture
def app():
    """创建测试应用"""
    # 创建临时数据库
    db_fd, db_path = tempfile.mkstemp(suffix='.db')
    
    app = create_app()
    app.config.update({
        'TESTING': True,
        'SQLALCHEMY_DATABASE_URI': f'sqlite:///{db_path}',
        'SQLALCHEMY_TRACK_MODIFICATIONS': False
    })
    
    with app.app_context():
        db.create_all()
        # 创建测试用户（如果不存在）
        test_user = User.query.filter_by(id='test-user-001').first()
        if not test_user:
            test_user = User(id='test-user-001', nickname='测试用户')
            db.session.add(test_user)
            db.session.commit()
    
    yield app
    
    # 清理
    os.close(db_fd)
    os.unlink(db_path)


@pytest.fixture
def client(app):
    """创建测试客户端"""
    return app.test_client()


@pytest.fixture
def runner(app):
    """创建测试CLI运行器"""
    return app.test_cli_runner()


@pytest.fixture
def test_user_id():
    """返回测试用户ID"""
    return 'test-user-001'
