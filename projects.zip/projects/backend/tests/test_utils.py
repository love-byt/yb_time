"""
缓存和性能监控测试用例
"""

import pytest
import json
import time


class TestCache:
    """缓存功能测试类"""
    
    def test_memory_cache_basic(self):
        """测试内存缓存基本功能"""
        from utils.cache import MemoryCache
        
        cache = MemoryCache()
        
        # 测试设置和获取
        cache.set('test_key', {'data': 'test_value'}, ttl=60)
        result = cache.get('test_key')
        assert result == {'data': 'test_value'}
        
        # 测试删除
        cache.delete('test_key')
        result = cache.get('test_key')
        assert result is None
    
    def test_cache_expiry(self):
        """测试缓存过期"""
        from utils.cache import MemoryCache
        
        cache = MemoryCache()
        
        # 设置1秒过期的缓存
        cache.set('expire_key', 'value', ttl=1)
        result = cache.get('expire_key')
        assert result == 'value'
        
        # 等待过期
        time.sleep(1.5)
        result = cache.get('expire_key')
        assert result is None
    
    def test_cache_clear_pattern(self):
        """测试清除匹配模式的缓存"""
        from utils.cache import MemoryCache
        
        cache = MemoryCache()
        
        # 设置多个缓存
        cache.set('tasks:user1', ['task1'], ttl=60)
        cache.set('tasks:user2', ['task2'], ttl=60)
        cache.set('tags:user1', ['tag1'], ttl=60)
        
        # 清除tasks前缀的缓存
        count = cache.clear_pattern('tasks:*')
        assert count == 2
        
        # 验证结果
        assert cache.get('tasks:user1') is None
        assert cache.get('tasks:user2') is None
        assert cache.get('tags:user1') == ['tag1']


class TestPerformance:
    """性能监控测试类"""
    
    def test_metrics_recording(self):
        """测试指标记录"""
        from utils.performance import PerformanceMetrics
        
        metrics = PerformanceMetrics()
        metrics.reset()
        
        # 记录请求
        metrics.record_request(
            endpoint='/api/tasks',
            method='GET',
            duration_ms=150.5,
            status_code=200,
            user_id='test-user'
        )
        
        # 获取统计
        stats = metrics.get_stats('GET:/api/tasks')
        assert 'GET:/api/tasks' in stats
        assert stats['GET:/api/tasks']['count'] == 1
        assert stats['GET:/api/tasks']['avg_ms'] == 150.5
    
    def test_slow_request_detection(self):
        """测试慢请求检测"""
        from utils.performance import PerformanceMetrics
        
        metrics = PerformanceMetrics()
        metrics.reset()
        
        # 记录慢请求（>1秒）
        metrics.record_request(
            endpoint='/api/slow',
            method='GET',
            duration_ms=1500.0,
            status_code=200
        )
        
        # 获取慢请求列表
        slow_requests = metrics.get_slow_requests()
        assert len(slow_requests) == 1
        assert slow_requests[0]['endpoint'] == '/api/slow'
        assert slow_requests[0]['duration_ms'] == 1500.0
    
    def test_error_count(self):
        """测试错误计数"""
        from utils.performance import PerformanceMetrics
        
        metrics = PerformanceMetrics()
        metrics.reset()
        
        # 记录错误请求
        metrics.record_request(
            endpoint='/api/error',
            method='POST',
            duration_ms=50.0,
            status_code=400
        )
        
        metrics.record_request(
            endpoint='/api/error',
            method='POST',
            duration_ms=60.0,
            status_code=500
        )
        
        # 获取统计
        stats = metrics.get_stats('POST:/api/error')
        assert stats['POST:/api/error']['error_count'] == 2


class TestHealthCheck:
    """健康检查测试类"""
    
    def test_health_endpoint(self, client):
        """测试健康检查接口"""
        response = client.get('/api/health')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['status'] == 'healthy'
        assert 'timestamp' in data
        assert 'database' in data
    
    def test_features_endpoint(self, client):
        """测试功能列表接口"""
        response = client.get('/api/features')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['success'] is True
        assert 'features' in data
        assert 'task_management' in data['features']


class TestPerformanceAPI:
    """性能监控API测试类"""
    
    def test_performance_stats_endpoint(self, client, test_user_id):
        """测试性能统计接口"""
        # 先执行一些请求以生成指标
        client.get('/api/tasks', headers={'X-User-ID': test_user_id})
        
        # 获取性能统计
        response = client.get('/api/performance/stats')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['success'] is True
        assert 'stats' in data
    
    def test_response_time_header(self, client, test_user_id):
        """测试响应时间头"""
        response = client.get('/api/tasks', headers={'X-User-ID': test_user_id})
        
        assert 'X-Response-Time' in response.headers
        response_time = float(response.headers['X-Response-Time'].replace('ms', ''))
        assert response_time >= 0
