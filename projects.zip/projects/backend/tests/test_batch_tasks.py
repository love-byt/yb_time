"""
批量任务管理功能测试
"""

import pytest
import json
from datetime import datetime, timedelta


def test_batch_create_tasks(client, auth_headers):
    """测试批量创建任务"""
    data = {
        'tasks': [
            {'title': '任务1', 'deadline': '2026-05-10T23:59:00', 'duration': 60},
            {'title': '任务2', 'deadline': '2026-05-11T23:59:00', 'duration': 120},
            {'title': '任务3', 'deadline': '2026-05-12T23:59:00', 'duration': 90}
        ],
        'auto_sort': False,
        'ai_analyze': False
    }
    
    response = client.post('/api/tasks/batch',
                          json=data,
                          headers=auth_headers)
    
    assert response.status_code == 200
    result = response.get_json()
    assert result['success'] is True
    assert result['data']['created'] == 3
    assert result['data']['failed'] == 0
    assert 'batch_id' in result['data']


def test_batch_create_empty_tasks(client, auth_headers):
    """测试批量创建空任务列表"""
    data = {
        'tasks': [],
        'auto_sort': False
    }
    
    response = client.post('/api/tasks/batch',
                          json=data,
                          headers=auth_headers)
    
    assert response.status_code == 400
    result = response.get_json()
    assert result['success'] is False


def test_batch_create_too_many_tasks(client, auth_headers):
    """测试批量创建超过限制的任务数"""
    data = {
        'tasks': [{'title': f'任务{i}'} for i in range(101)],
        'auto_sort': False
    }
    
    response = client.post('/api/tasks/batch',
                          json=data,
                          headers=auth_headers)
    
    assert response.status_code == 400
    result = response.get_json()
    assert result['success'] is False
    assert '100' in result['message']


def test_parse_text_to_tasks(client, auth_headers):
    """测试文本解析功能"""
    data = {
        'text': '数学作业明天截止需要2小时，英语论文后天交预计3小时'
    }
    
    response = client.post('/api/tasks/parse-text',
                          json=data,
                          headers=auth_headers)
    
    assert response.status_code == 200
    result = response.get_json()
    assert result['success'] is True
    assert result['count'] == 2
    
    tasks = result['data']
    assert tasks[0]['title'] == '数学作业'
    assert tasks[0]['duration'] == 120
    assert tasks[1]['title'] == '英语论文'
    assert tasks[1]['duration'] == 180


def test_parse_empty_text(client, auth_headers):
    """测试解析空文本"""
    data = {
        'text': ''
    }
    
    response = client.post('/api/tasks/parse-text',
                          json=data,
                          headers=auth_headers)
    
    assert response.status_code == 400
    result = response.get_json()
    assert result['success'] is False


def test_parse_complex_text(client, auth_headers):
    """测试解析复杂文本"""
    data = {
        'text': '''
        高等数学第三章习题明天截止，需要2小时完成
        大学英语阅读理解后天交，预计1.5小时
        物理实验报告下周三完成，大概需要90分钟
        紧急：化学期中论文今天必须提交，需要3小时
        '''
    }
    
    response = client.post('/api/tasks/parse-text',
                          json=data,
                          headers=auth_headers)
    
    assert response.status_code == 200
    result = response.get_json()
    assert result['success'] is True
    assert result['count'] >= 3
    
    tasks = result['data']
    # 检查优先级解析
    priority_tasks = [t for t in tasks if t.get('priority') == 4]
    assert len(priority_tasks) >= 1  # 至少有一个紧急任务


def test_download_template(client, auth_headers):
    """测试下载导入模板"""
    response = client.get('/api/tasks/template?format=excel',
                         headers=auth_headers)
    
    assert response.status_code == 200
    assert response.content_type == 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    
    # 检查文件名
    assert '任务导入模板.xlsx' in response.headers.get('Content-Disposition', '')


def test_download_csv_template(client, auth_headers):
    """测试下载CSV模板"""
    response = client.get('/api/tasks/template?format=csv',
                         headers=auth_headers)
    
    assert response.status_code == 200
    assert response.content_type == 'text/csv'
    
    # 检查文件名
    assert '任务导入模板.csv' in response.headers.get('Content-Disposition', '')


# ==================== 单元测试 ====================

def test_batch_parser_basic():
    """测试批量解析器基础功能"""
    from utils.batch_parser import BatchTaskParser
    
    parser = BatchTaskParser()
    text = "数学作业明天截止需要2小时"
    
    tasks = parser.parse_text(text)
    
    assert len(tasks) == 1
    assert tasks[0]['title'] == '数学作业'
    assert tasks[0]['duration'] == 120
    assert 'deadline' in tasks[0]


def test_batch_parser_multiple():
    """测试批量解析多条任务"""
    from utils.batch_parser import BatchTaskParser
    
    parser = BatchTaskParser()
    text = "数学作业明天需要2小时，英语论文后天要3小时，物理实验下周三完成90分钟"
    
    tasks = parser.parse_text(text)
    
    assert len(tasks) == 3
    assert tasks[0]['title'] == '数学作业'
    assert tasks[1]['title'] == '英语论文'
    assert tasks[2]['title'] == '物理实验'


def test_batch_parser_weekday():
    """测试星期解析"""
    from utils.batch_parser import BatchTaskParser
    
    parser = BatchTaskParser()
    text = "数学作业下周一截止"
    
    tasks = parser.parse_text(text)
    
    assert len(tasks) == 1
    assert 'deadline' in tasks[0]


def test_file_importer_template():
    """测试文件导入器模板生成"""
    from utils.file_importer import TaskFileImporter
    
    importer = TaskFileImporter()
    template = importer.generate_template()
    
    assert len(template) > 0
    assert '任务名称' in template.columns
    assert '课程' in template.columns


def test_file_importer_excel():
    """测试生成Excel模板"""
    from utils.file_importer import TaskFileImporter
    
    excel_content = TaskFileImporter.generate_template_excel()
    
    assert len(excel_content) > 0
    # Excel文件应该以PK开头（ZIP格式）
    assert excel_content[:2] == b'PK'


def test_file_importer_csv():
    """测试生成CSV模板"""
    from utils.file_importer import TaskFileImporter
    
    csv_content = TaskFileImporter.generate_template_csv()
    
    assert len(csv_content) > 0
    # CSV应该包含标题行（UTF-8编码）
    assert '任务名称'.encode('utf-8') in csv_content


# ==================== 集成测试 ====================

@pytest.mark.integration
def test_full_batch_workflow(client, auth_headers):
    """测试完整的批量任务工作流"""
    # 1. 解析文本
    parse_data = {'text': '数学作业明天需要2小时，英语论文后天需要3小时'}
    parse_response = client.post('/api/tasks/parse-text',
                                json=parse_data,
                                headers=auth_headers)
    
    assert parse_response.status_code == 200
    parsed_tasks = parse_response.get_json()['data']
    
    # 2. 批量创建
    create_data = {
        'tasks': parsed_tasks,
        'auto_sort': True,
        'ai_analyze': True
    }
    create_response = client.post('/api/tasks/batch',
                                 json=create_data,
                                 headers=auth_headers)
    
    assert create_response.status_code == 200
    result = create_response.get_json()
    assert result['data']['created'] == 2
    
    # 3. 验证任务列表
    tasks_response = client.get('/api/tasks', headers=auth_headers)
    assert tasks_response.status_code == 200
    tasks = tasks_response.get_json()
    
    # 应该包含刚创建的任务
    titles = [t['title'] for t in tasks]
    assert '数学作业' in titles or any('数学' in t for t in titles)
    assert '英语论文' in titles or any('英语' in t for t in titles)
