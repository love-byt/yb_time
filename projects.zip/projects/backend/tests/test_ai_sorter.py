"""
六维度排序模块测试

测试严格基于6个维度的任务评估和排序功能
"""

import pytest
from datetime import datetime, timedelta
from utils.ai_sorter import (
    SixDimensionSorter,
    SixDimensions,
    DimensionCalculator,
    DimensionKeywords,
    sort_tasks_by_six_dimensions,
    evaluate_task_six_dimensions,
    get_six_dimensions_info
)


class TestSixDimensions:
    """六维度常量定义测试"""
    
    def test_dimension_names(self):
        """测试维度名称列表"""
        assert len(SixDimensions.NAMES) == 6
        assert 'time' in SixDimensions.NAMES
        assert 'importance' in SixDimensions.NAMES
        assert 'impact' in SixDimensions.NAMES
        assert 'money' in SixDimensions.NAMES
        assert 'relation' in SixDimensions.NAMES
        assert 'skill' in SixDimensions.NAMES
    
    def test_default_weights_sum(self):
        """测试默认权重总和为1.0"""
        total = sum(SixDimensions.DEFAULT_WEIGHTS.values())
        assert abs(total - 1.0) < 0.001
    
    def test_validate_weights(self):
        """测试权重验证"""
        # 有效权重
        assert SixDimensions.validate_weights(SixDimensions.DEFAULT_WEIGHTS)
        
        # 无效权重（缺少维度）
        invalid = {'time': 0.5, 'importance': 0.5}
        assert not SixDimensions.validate_weights(invalid)
    
    def test_normalize_weights(self):
        """测试权重归一化"""
        # 原始权重
        raw = {'time': 0.5, 'importance': 0.3, 'impact': 0.3, 'money': 0.15, 'relation': 0.1, 'skill': 0.1}
        normalized = SixDimensions.normalize_weights(raw)
        
        # 归一化后总和应为1.0
        total = sum(normalized.values())
        assert abs(total - 1.0) < 0.001


class TestDimensionCalculator:
    """维度评分计算器测试"""
    
    def setup_method(self):
        self.calculator = DimensionCalculator()
    
    def test_calculate_returns_all_dimensions(self):
        """测试返回所有6个维度"""
        task = {'title': '测试任务'}
        scores = self.calculator.calculate(task)
        
        for dim in SixDimensions.NAMES:
            assert dim in scores
    
    def test_time_score_expired(self):
        """测试过期任务时间分数"""
        task = {
            'title': '已过期任务',
            'end_time': (datetime.now() - timedelta(hours=1)).isoformat()
        }
        score = self.calculator.calculate_time_score(task)
        assert score == 5.0
    
    def test_time_score_within_2_hours(self):
        """测试2小时内任务时间分数"""
        task = {
            'title': '紧急任务',
            'end_time': (datetime.now() + timedelta(hours=1)).isoformat()
        }
        score = self.calculator.calculate_time_score(task)
        assert score == 5.0
    
    def test_time_score_no_deadline(self):
        """测试无截止时间任务"""
        task = {'title': '无截止任务'}
        score = self.calculator.calculate_time_score(task)
        assert score == 2.5
    
    def test_importance_score_with_priority(self):
        """测试带优先级的重要性分数"""
        task = {'title': '高优先级任务', 'priority': 5}
        score = self.calculator.calculate_importance_score(task)
        assert score == 5.0
    
    def test_importance_score_with_category(self):
        """测试带分类的重要性分数"""
        task = {'title': '考试任务', 'category': '考试'}
        score = self.calculator.calculate_importance_score(task)
        assert score > 2.5
    
    def test_impact_score(self):
        """测试影响力分数"""
        task = {'title': '架构设计任务', 'description': '设计系统架构'}
        score = self.calculator.calculate_impact_score(task)
        assert score > 2.5
    
    def test_money_score(self):
        """测试金钱价值分数"""
        task = {'title': '赚钱项目', 'description': '增加收入'}
        score = self.calculator.calculate_money_score(task)
        assert score > 2.0
    
    def test_relation_score(self):
        """测试关系价值分数"""
        task = {'title': '客户会议', 'description': '与客户沟通'}
        score = self.calculator.calculate_relation_score(task)
        assert score > 2.0
    
    def test_skill_score(self):
        """测试技能成长分数"""
        task = {'title': '学习Python', 'description': '学习编程技能'}
        score = self.calculator.calculate_skill_score(task)
        assert score > 2.5


class TestSixDimensionSorter:
    """六维度排序器测试"""
    
    def setup_method(self):
        self.sorter = SixDimensionSorter()
    
    def test_evaluate_returns_structure(self):
        """测试评估返回结构化结果"""
        task = {'title': '测试任务', 'id': 'task-1'}
        result = self.sorter.evaluate(task)
        
        assert 'task_id' in result
        assert 'task_title' in result
        assert 'dimensions' in result
        assert 'total_score' in result
        assert 'weights_config' in result
    
    def test_evaluate_contains_all_dimensions(self):
        """测试评估包含所有6个维度"""
        task = {'title': '测试任务'}
        result = self.sorter.evaluate(task)
        
        assert len(result['dimensions']) == 6
        for dim in SixDimensions.NAMES:
            assert dim in result['dimensions']
            assert 'name_cn' in result['dimensions'][dim]
            assert 'name_en' in result['dimensions'][dim]
            assert 'description' in result['dimensions'][dim]
            assert 'weight' in result['dimensions'][dim]
            assert 'score' in result['dimensions'][dim]
            assert 'weighted_contribution' in result['dimensions'][dim]
    
    def test_sort_tasks(self):
        """测试任务排序"""
        task1 = {'title': '吃饭', 'end_time': (datetime.now() + timedelta(hours=10)).isoformat()}
        task2 = {'title': '提交作品', 'end_time': (datetime.now() + timedelta(hours=6)).isoformat()}
        
        sorted_tasks = self.sorter.sort_tasks([task1, task2])
        
        # 提交作品时间更紧迫，应该排在前面
        assert sorted_tasks[0]['title'] == '提交作品'
    
    def test_sort_tasks_with_custom_weights(self):
        """测试自定义权重排序"""
        # 降低时间权重，升高重要性权重
        weights = {
            'time': 0.10,
            'importance': 0.40,
            'impact': 0.20,
            'money': 0.15,
            'relation': 0.10,
            'skill': 0.05
        }
        sorter = SixDimensionSorter(weights)
        
        task1 = {'title': '吃饭', 'priority': 1, 'end_time': (datetime.now() + timedelta(hours=1)).isoformat()}
        task2 = {'title': '高优先级任务', 'priority': 5, 'end_time': (datetime.now() + timedelta(hours=24)).isoformat()}
        
        sorted_tasks = sorter.sort_tasks([task1, task2])
        
        # 在降低时间权重后，高优先级任务可能排在前面
        assert len(sorted_tasks) == 2
    
    def test_get_comparison(self):
        """测试任务比较"""
        task1 = {'title': '吃饭'}
        task2 = {'title': '提交作品'}
        
        result = self.sorter.get_comparison(task1, task2)
        
        assert 'task1' in result
        assert 'task2' in result
        assert 'recommended' in result
        assert 'reason' in result
    
    def test_get_dimension_info(self):
        """测试获取维度信息"""
        info = self.sorter.get_dimension_info()
        
        assert 'dimensions' in info
        assert 'weight_validation' in info
        assert len(info['dimensions']) == 6


class TestSubmitVsDinnerScenario:
    """提交作品 vs 吃晚饭场景测试"""
    
    def test_submit_before_dinner(self):
        """
        核心测试：下午6点提交作品应排在晚上10点吃晚饭之前
        
        场景：
        - 当前时间：中午12点
        - 任务1：今晚10点吃晚饭（剩余10小时）
        - 任务2：下午6点提交作品（剩余6小时）
        
        预期：提交作品排在前面（时间维度得分更高）
        """
        sorter = SixDimensionSorter()
        
        now = datetime.now()
        
        # 任务1：今晚10点吃晚饭
        dinner_time = now.replace(hour=22, minute=0, second=0, microsecond=0)
        if dinner_time < now:
            dinner_time += timedelta(days=1)
        
        # 任务2：下午6点提交作品
        submit_time = now.replace(hour=18, minute=0, second=0, microsecond=0)
        if submit_time < now:
            submit_time += timedelta(days=1)
        
        task1 = {
            'title': '今晚10点吃晚饭',
            'description': '和家人一起吃晚饭',
            'end_time': dinner_time.isoformat()
        }
        
        task2 = {
            'title': '下午6点提交作品',
            'description': '必须按时提交，否则扣分',
            'end_time': submit_time.isoformat()
        }
        
        # 评估两个任务
        eval1 = sorter.evaluate(task1)
        eval2 = sorter.evaluate(task2)
        
        # 提交作品的时间分数应更高
        time_score1 = eval1['dimensions']['time']['score']
        time_score2 = eval2['dimensions']['time']['score']
        
        assert time_score2 > time_score1, \
            f"提交作品时间分数({time_score2})应高于吃饭({time_score1})"
        
        # 排序验证
        sorted_tasks = sorter.sort_tasks([task1, task2])
        
        assert sorted_tasks[0]['title'] == '下午6点提交作品', \
            "提交作品应排在吃饭之前"
    
    def test_detailed_evaluation(self):
        """测试详细评估结果"""
        sorter = SixDimensionSorter()
        
        task = {
            'title': '下午6点提交作品',
            'description': '必须按时提交，否则扣分',
            'priority': 4,
            'category': '工作',
            'end_time': (datetime.now() + timedelta(hours=6)).isoformat()
        }
        
        result = sorter.evaluate(task)
        
        # 验证结构
        assert result['task_title'] == '下午6点提交作品'
        assert 'dimensions' in result
        assert 'total_score' in result
        
        # 验证维度分数
        dimensions = result['dimensions']
        
        # 时间分数应该较高（因为有截止时间且6小时内）
        assert dimensions['time']['score'] >= 4.5
        
        # 重要性分数应该较高（因为有priority和category）
        assert dimensions['importance']['score'] >= 4.0
        
        # 验证加权贡献
        for dim in SixDimensions.NAMES:
            expected_contribution = dimensions[dim]['score'] * dimensions[dim]['weight']
            assert abs(dimensions[dim]['weighted_contribution'] - expected_contribution) < 0.001


class TestConvenienceFunctions:
    """便捷函数测试"""
    
    def test_sort_tasks_by_six_dimensions(self):
        """测试便捷排序函数"""
        tasks = [
            {'title': '任务A'},
            {'title': '任务B'}
        ]
        
        result = sort_tasks_by_six_dimensions(tasks)
        assert len(result) == 2
    
    def test_evaluate_task_six_dimensions(self):
        """测试便捷评估函数"""
        task = {'title': '测试任务'}
        result = evaluate_task_six_dimensions(task)
        
        assert 'dimensions' in result
        assert 'total_score' in result
    
    def test_get_six_dimensions_info(self):
        """测试获取维度信息函数"""
        info = get_six_dimensions_info()
        
        assert 'dimensions' in info
        assert len(info['dimensions']) == 6


class TestEdgeCases:
    """边界情况测试"""
    
    def setup_method(self):
        self.sorter = SixDimensionSorter()
    
    def test_empty_task(self):
        """测试空任务"""
        task = {}
        result = self.sorter.evaluate(task)
        assert result['total_score'] >= 0
    
    def test_task_with_all_fields(self):
        """测试包含所有字段的任务"""
        task = {
            'id': 'test-1',
            'title': '完整任务',
            'description': '这是一个完整描述的任务',
            'priority': 4,
            'category': '工作',
            'end_time': (datetime.now() + timedelta(hours=6)).isoformat(),
            'start_time': (datetime.now() + timedelta(hours=2)).isoformat(),
            'estimated_hours': 3
        }
        
        result = self.sorter.evaluate(task)
        assert 'dimensions' in result
        assert result['dimensions']['time']['score'] > 3.0
    
    def test_weights_config(self):
        """测试权重配置"""
        custom_weights = {
            'time': 0.30,
            'importance': 0.25,
            'impact': 0.20,
            'money': 0.10,
            'relation': 0.10,
            'skill': 0.05
        }
        
        sorter = SixDimensionSorter(custom_weights)
        assert sum(sorter.weights.values()) == pytest.approx(1.0, abs=0.001)
