"""智能时间推荐器测试"""

import pytest
from datetime import datetime, timedelta
from utils.smart_time_recommender import SmartTimeRecommender, TimeRecommendation
from utils.difficulty_evaluator import DifficultyEvaluator


class TestSmartTimeRecommender:
    """测试智能时间推荐器"""
    
    def test_recommend_start_time_with_user_habit(self, app, test_user_id):
        """测试基于用户习惯推荐开始时间"""
        with app.app_context():
            recommender = SmartTimeRecommender(test_user_id)
            
            result = recommender.recommend_start_time(
                category='学习',
                difficulty='hard'
            )
            
            assert result.start_time is not None
            assert result.confidence > 0
            assert result.reasoning != ''
    
    def test_recommend_end_time_with_historical_data(self, app, test_user_id):
        """测试基于历史数据推荐结束时间"""
        with app.app_context():
            recommender = SmartTimeRecommender(test_user_id)
            start_time = datetime.now().replace(hour=9, minute=0)
            
            result = recommender.recommend_end_time(
                start_time=start_time,
                category='学习',
                difficulty='medium',
                title='复习数学'
            )
            
            assert result.end_time > start_time
            duration_minutes = (result.end_time - start_time).total_seconds() / 60
            assert 30 <= duration_minutes <= 240  # 合理时长范围
    
    def test_recommend_time_range_complete(self, app, test_user_id):
        """测试完整时间范围推荐"""
        with app.app_context():
            recommender = SmartTimeRecommender(test_user_id)
            
            result = recommender.recommend_time_range(
                category='考试',
                difficulty='hard',
                title='期末考试',
                estimated_duration=120
            )
            
            assert 'start_time' in result
            assert 'end_time' in result
            assert 'confidence' in result
            assert result['estimated_duration'] == 120
    
    def test_recommend_start_time_default_fallback(self, app, test_user_id):
        """测试无用户习惯时的默认推荐"""
        with app.app_context():
            recommender = SmartTimeRecommender(test_user_id)
            
            # 测试困难任务默认推荐上午9点
            result = recommender.recommend_start_time(
                category='测试',
                difficulty='hard'
            )
            
            assert result.start_time.hour == 9
            assert result.source == 'default'
            
            # 测试简单任务默认推荐下午4点
            result = recommender.recommend_start_time(
                category='测试',
                difficulty='easy'
            )
            
            assert result.start_time.hour == 16
    
    def test_recommend_end_time_with_user_input(self, app, test_user_id):
        """测试使用用户指定时长的推荐"""
        with app.app_context():
            recommender = SmartTimeRecommender(test_user_id)
            start_time = datetime.now()
            
            result = recommender.recommend_end_time(
                start_time=start_time,
                category='学习',
                difficulty='medium',
                title='测试任务',
                estimated_duration=90
            )
            
            assert result.source == 'user_input'
            assert result.confidence == 0.95
            duration = (result.end_time - start_time).total_seconds() / 60
            assert duration == 90


class TestDifficultyEvaluator:
    """测试任务难度评估器"""
    
    def test_evaluate_very_hard_task(self):
        """测试极难任务识别"""
        result = DifficultyEvaluator.evaluate(
            title='准备毕业答辩',
            description='完成PPT和演讲稿',
            category='考试'
        )
        
        assert result['difficulty_level'] == 'very_hard'
        assert result['difficulty_score'] >= 3.5
    
    def test_evaluate_easy_task(self):
        """测试简单任务识别"""
        result = DifficultyEvaluator.evaluate(
            title='背诵英语单词',
            description='',
            category='学习'
        )
        
        assert result['difficulty_level'] in ['easy', 'medium']
    
    def test_evaluate_with_duration(self):
        """测试基于时长的难度评估"""
        result = DifficultyEvaluator.evaluate(
            title='完成项目',
            description='',
            category='工作',
            estimated_duration=200
        )
        
        assert result['difficulty_level'] in ['hard', 'very_hard']
    
    def test_evaluate_keyword_score(self):
        """测试关键词评分"""
        # 测试包含"考试"关键词
        result = DifficultyEvaluator.evaluate(title='期末考试复习')
        assert result['factors']['keyword_score'] >= 4.0
        
        # 测试包含"背诵"关键词
        result = DifficultyEvaluator.evaluate(title='背诵单词')
        assert result['factors']['keyword_score'] <= 2.0
    
    def test_evaluate_category_weight(self):
        """测试分类权重"""
        # 考试分类应该是 very_hard
        result = DifficultyEvaluator.evaluate(
            title='普通任务',
            category='考试'
        )
        assert result['factors']['category_score'] == 4.0
        
        # 娱乐分类应该是 easy
        result = DifficultyEvaluator.evaluate(
            title='普通任务',
            category='娱乐'
        )
        assert result['factors']['category_score'] == 1.0
