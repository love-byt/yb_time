"""
分类路由测试模块
"""
import pytest
import json


class TestCategoryAPI:
    """分类API测试类"""
    
    def test_get_categories(self, client, test_user_id):
        """测试获取分类列表"""
        response = client.get(
            '/api/categories',
            headers={'X-User-ID': test_user_id}
        )
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['success'] is True
        assert isinstance(data['categories'], list)
    
    def test_get_category_presets(self, client):
        """测试获取预设分类"""
        response = client.get('/api/categories/presets')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['success'] is True
        assert 'presets' in data


class TestTagAPI:
    """标签API测试类"""
    
    def test_get_tags(self, client, test_user_id):
        """测试获取标签列表"""
        response = client.get(
            '/api/tags',
            headers={'X-User-ID': test_user_id}
        )
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['success'] is True
        assert isinstance(data['tags'], list)
        assert 'presets' in data


class TestStatsAPI:
    """统计API测试类"""
    
    def test_get_stats_overview(self, client, test_user_id):
        """测试获取统计概览"""
        response = client.get(
            '/api/stats/overview',
            headers={'X-User-ID': test_user_id}
        )
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['success'] is True


class TestReminderAPI:
    """提醒API测试类"""
    
    def test_get_reminders(self, client, test_user_id):
        """测试获取提醒列表"""
        response = client.get(
            '/api/reminders',
            headers={'X-User-ID': test_user_id}
        )
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['success'] is True


class TestRecurringAPI:
    """重复任务API测试类"""
    
    def test_get_recurring(self, client, test_user_id):
        """测试获取重复任务列表"""
        response = client.get(
            '/api/recurring',
            headers={'X-User-ID': test_user_id}
        )
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['success'] is True
