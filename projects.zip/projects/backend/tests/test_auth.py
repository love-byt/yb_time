"""
认证模块测试用例
测试用户注册、登录、Token验证等功能
"""

import pytest
import json
import re
import uuid


def get_unique_username():
    """生成唯一的用户名"""
    return f"test_{uuid.uuid4().hex[:8]}"


class TestAuthRegistration:
    """用户注册测试类"""
    
    def test_register_success(self, client):
        """测试注册成功"""
        unique_username = get_unique_username()
        response = client.post(
            '/api/auth/register',
            data=json.dumps({
                'username': unique_username,
                'password': 'password123',
                'email': f'{unique_username}@test.com',
                'nickname': 'New User'
            }),
            content_type='application/json'
        )
        
        data = json.loads(response.data)
        assert response.status_code == 201, f"Expected 201, got {response.status_code}: {data}"
        assert data['success'] is True
        assert 'token' in data
        assert 'user' in data
        assert data['user']['username'] == unique_username
    
    def test_register_missing_username(self, client):
        """测试注册时缺少用户名"""
        response = client.post(
            '/api/auth/register',
            data=json.dumps({
                'password': 'password123'
            }),
            content_type='application/json'
        )
        
        assert response.status_code == 400
        data = json.loads(response.data)
        assert data['success'] is False
        assert '用户名' in data['message']
    
    def test_register_missing_password(self, client):
        """测试注册时缺少密码"""
        response = client.post(
            '/api/auth/register',
            data=json.dumps({
                'username': 'testuser'
            }),
            content_type='application/json'
        )
        
        assert response.status_code == 400
        data = json.loads(response.data)
        assert data['success'] is False
        assert '密码' in data['message']
    
    def test_register_short_password(self, client):
        """测试密码太短"""
        response = client.post(
            '/api/auth/register',
            data=json.dumps({
                'username': 'testuser',
                'password': '12345'
            }),
            content_type='application/json'
        )
        
        assert response.status_code == 400
        data = json.loads(response.data)
        assert data['success'] is False
        assert '6' in data['message']
    
    def test_register_short_username(self, client):
        """测试用户名太短"""
        response = client.post(
            '/api/auth/register',
            data=json.dumps({
                'username': 'ab',
                'password': 'password123'
            }),
            content_type='application/json'
        )
        
        assert response.status_code == 400
        data = json.loads(response.data)
        assert data['success'] is False
        assert '3' in data['message']
    
    def test_register_duplicate_username(self, client):
        """测试重复用户名"""
        username = get_unique_username()
        # 第一次注册
        client.post(
            '/api/auth/register',
            data=json.dumps({
                'username': username,
                'password': 'password123'
            }),
            content_type='application/json'
        )
        
        # 第二次注册相同用户名
        response = client.post(
            '/api/auth/register',
            data=json.dumps({
                'username': username,
                'password': 'password456'
            }),
            content_type='application/json'
        )
        
        assert response.status_code == 400
        data = json.loads(response.data)
        assert data['success'] is False
        assert '已被使用' in data['message']
    
    def test_register_duplicate_email(self, client):
        """测试重复邮箱"""
        email = f'{get_unique_username()}@test.com'
        # 第一次注册
        client.post(
            '/api/auth/register',
            data=json.dumps({
                'username': get_unique_username(),
                'password': 'password123',
                'email': email
            }),
            content_type='application/json'
        )
        
        # 第二次注册相同邮箱
        response = client.post(
            '/api/auth/register',
            data=json.dumps({
                'username': get_unique_username(),
                'password': 'password123',
                'email': email
            }),
            content_type='application/json'
        )
        
        assert response.status_code == 400
        data = json.loads(response.data)
        assert data['success'] is False
        assert '邮箱' in data['message']
    
    def test_register_invalid_username_chars(self, client):
        """测试用户名包含非法字符"""
        response = client.post(
            '/api/auth/register',
            data=json.dumps({
                'username': 'test@user!',
                'password': 'password123'
            }),
            content_type='application/json'
        )
        
        assert response.status_code == 400
        data = json.loads(response.data)
        assert data['success'] is False


class TestAuthLogin:
    """用户登录测试类"""
    
    def test_login_success(self, client):
        """测试登录成功"""
        # 先注册
        username = get_unique_username()
        client.post(
            '/api/auth/register',
            data=json.dumps({
                'username': username,
                'password': 'password123'
            }),
            content_type='application/json'
        )
        
        # 登录
        response = client.post(
            '/api/auth/login',
            data=json.dumps({
                'username': username,
                'password': 'password123'
            }),
            content_type='application/json'
        )
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['success'] is True
        assert 'token' in data
        assert 'user' in data
    
    def test_login_with_email(self, client):
        """测试使用邮箱登录"""
        # 先注册带邮箱的用户
        username = get_unique_username()
        email = f'{username}@test.com'
        client.post(
            '/api/auth/register',
            data=json.dumps({
                'username': username,
                'password': 'password123',
                'email': email
            }),
            content_type='application/json'
        )
        
        # 使用邮箱登录
        response = client.post(
            '/api/auth/login',
            data=json.dumps({
                'username': email,
                'password': 'password123'
            }),
            content_type='application/json'
        )
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['success'] is True
    
    def test_login_wrong_password(self, client):
        """测试密码错误"""
        # 先注册
        username = get_unique_username()
        client.post(
            '/api/auth/register',
            data=json.dumps({
                'username': username,
                'password': 'password123'
            }),
            content_type='application/json'
        )
        
        # 错误密码登录
        response = client.post(
            '/api/auth/login',
            data=json.dumps({
                'username': username,
                'password': 'wrongpassword'
            }),
            content_type='application/json'
        )
        
        assert response.status_code == 401
        data = json.loads(response.data)
        assert data['success'] is False
    
    def test_login_nonexistent_user(self, client):
        """测试不存在的用户"""
        response = client.post(
            '/api/auth/login',
            data=json.dumps({
                'username': f'nonexistent_{uuid.uuid4().hex[:8]}',
                'password': 'password123'
            }),
            content_type='application/json'
        )
        
        assert response.status_code == 401
        data = json.loads(response.data)
        assert data['success'] is False
    
    def test_login_missing_fields(self, client):
        """测试缺少登录字段"""
        response = client.post(
            '/api/auth/login',
            data=json.dumps({
                'username': 'testuser'
            }),
            content_type='application/json'
        )
        
        assert response.status_code == 400
        data = json.loads(response.data)
        assert data['success'] is False


class TestAuthToken:
    """Token验证测试类"""
    
    def test_verify_valid_token(self, client):
        """测试验证有效Token"""
        # 注册获取Token
        username = get_unique_username()
        register_response = client.post(
            '/api/auth/register',
            data=json.dumps({
                'username': username,
                'password': 'password123'
            }),
            content_type='application/json'
        )
        token = json.loads(register_response.data)['token']
        
        # 验证Token
        response = client.get(
            '/api/auth/verify',
            headers={'Authorization': f'Bearer {token}'}
        )
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['success'] is True
        assert data['valid'] is True
    
    def test_verify_invalid_token(self, client):
        """测试验证无效Token"""
        response = client.get(
            '/api/auth/verify',
            headers={'Authorization': 'Bearer invalid_token'}
        )
        
        assert response.status_code == 401
        data = json.loads(response.data)
        assert data['success'] is False
        assert data['valid'] is False
    
    def test_verify_missing_token(self, client):
        """测试缺少Token"""
        response = client.get('/api/auth/verify')
        
        assert response.status_code == 401
        data = json.loads(response.data)
        assert data['success'] is False


class TestAuthProfile:
    """用户信息测试类"""
    
    def test_get_profile(self, client):
        """测试获取用户信息"""
        # 注册
        username = get_unique_username()
        register_response = client.post(
            '/api/auth/register',
            data=json.dumps({
                'username': username,
                'password': 'password123',
                'nickname': 'Profile User'
            }),
            content_type='application/json'
        )
        token = json.loads(register_response.data)['token']
        
        # 获取用户信息
        response = client.get(
            '/api/auth/profile',
            headers={'Authorization': f'Bearer {token}'}
        )
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['success'] is True
        assert data['user']['username'] == username
    
    def test_update_profile(self, client):
        """测试更新用户信息"""
        # 注册
        username = get_unique_username()
        register_response = client.post(
            '/api/auth/register',
            data=json.dumps({
                'username': username,
                'password': 'password123'
            }),
            content_type='application/json'
        )
        token = json.loads(register_response.data)['token']
        
        # 更新用户信息
        response = client.put(
            '/api/auth/profile',
            data=json.dumps({
                'nickname': 'Updated Nickname',
                'email': f'{username}@updated.com'
            }),
            content_type='application/json',
            headers={'Authorization': f'Bearer {token}'}
        )
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['success'] is True
    
    def test_update_password(self, client):
        """测试更新密码"""
        # 注册
        username = get_unique_username()
        register_response = client.post(
            '/api/auth/register',
            data=json.dumps({
                'username': username,
                'password': 'oldpassword'
            }),
            content_type='application/json'
        )
        token = json.loads(register_response.data)['token']
        
        # 更新密码
        response = client.put(
            '/api/auth/profile',
            data=json.dumps({
                'old_password': 'oldpassword',
                'new_password': 'newpassword123'
            }),
            content_type='application/json',
            headers={'Authorization': f'Bearer {token}'}
        )
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['success'] is True
        
        # 验证新密码可以登录
        login_response = client.post(
            '/api/auth/login',
            data=json.dumps({
                'username': username,
                'password': 'newpassword123'
            }),
            content_type='application/json'
        )
        assert login_response.status_code == 200


class TestForgotPassword:
    """忘记密码测试类"""
    
    def test_forgot_password_existing_user(self, client):
        """测试已存在用户的忘记密码"""
        # 注册用户
        username = get_unique_username()
        client.post(
            '/api/auth/register',
            data=json.dumps({
                'username': username,
                'password': 'password123',
                'email': f'{username}@test.com'
            }),
            content_type='application/json'
        )
        
        # 忘记密码请求
        response = client.post(
            '/api/auth/forgot-password',
            data=json.dumps({
                'username_or_email': username
            }),
            content_type='application/json'
        )
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['success'] is True
    
    def test_forgot_password_with_email(self, client):
        """测试使用邮箱请求重置密码"""
        # 注册用户
        username = get_unique_username()
        email = f'{username}@test.com'
        client.post(
            '/api/auth/register',
            data=json.dumps({
                'username': username,
                'password': 'password123',
                'email': email
            }),
            content_type='application/json'
        )
        
        # 使用邮箱请求重置
        response = client.post(
            '/api/auth/forgot-password',
            data=json.dumps({
                'username_or_email': email
            }),
            content_type='application/json'
        )
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['success'] is True
    
    def test_forgot_password_missing_field(self, client):
        """测试缺少字段的忘记密码请求"""
        response = client.post(
            '/api/auth/forgot-password',
            data=json.dumps({}),
            content_type='application/json'
        )
        
        assert response.status_code == 400
        data = json.loads(response.data)
        assert data['success'] is False
