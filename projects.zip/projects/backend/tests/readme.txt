================================================================================
                          Tests 文件夹说明
================================================================================

【文件夹作用】
本文件夹包含 pytest 测试用例，用于验证后端功能的正确性和稳定性。
包括单元测试、集成测试和端到端测试。

================================================================================
                              文件说明
================================================================================

1. conftest.py
   - pytest 配置文件
   - 作用:
     * 定义测试固件（fixtures）
     * 配置测试环境
     * 初始化测试数据
   - 核心固件:
     * app: 创建测试 Flask 应用
     * client: 创建测试 HTTP 客户端
     * runner: 创建测试 CLI 运行器
     * test_user_id: 测试用户 ID
   - 特点:
     * 使用临时数据库
     * 自动清理测试数据
     * 隔离测试环境

================================================================================

【测试文件】

2. test_auth.py
   - 认证模块测试
   - 测试类:
     * TestAuthRegistration: 用户注册测试
       - test_register_success: 注册成功
       - test_register_missing_username: 缺少用户名
       - test_register_missing_password: 缺少密码
       - test_register_duplicate_username: 重复用户名
       - test_register_invalid_email: 无效邮箱
     * TestAuthLogin: 用户登录测试
       - test_login_success: 登录成功
       - test_login_invalid_credentials: 无效凭证
       - test_login_missing_fields: 缺少字段
     * TestAuthToken: Token 测试
       - test_token_generation: Token 生成
       - test_token_verification: Token 验证
       - test_token_expiration: Token 过期
   - 覆盖率目标: >90%

3. test_ai_sorter.py
   - AI 排序算法测试
   - 测试类:
     * TestSixDimensionSorter: 排序器测试
       - test_default_weights: 默认权重
       - test_custom_weights: 自定义权重
       - test_weights_normalization: 权重归一化
       - test_time_score_calculation: 时间分计算
       - test_category_bonus: 分类加成
       - test_long_task_bonus: 长任务加成
       - test_user_priority: 用户优先级
       - test_sort_tasks: 任务排序
       - test_sort_with_explanations: 带解释的排序
     * TestSortTasksByAI: 便捷函数测试
       - test_sort_tasks_by_ai: 便捷排序函数
   - 覆盖率目标: >85%

4. test_tasks.py
   - 任务管理测试
   - 测试类:
     * TestTaskAPI: 任务 API 测试
       - test_create_task_success: 创建任务成功
       - test_create_task_with_default_time: 自动填充时间
       - test_create_task_without_title: 缺少标题
       - test_get_tasks: 获取任务列表
       - test_update_task: 更新任务
       - test_delete_task: 删除任务
       - test_complete_task: 完成任务
       - test_task_filtering: 任务筛选
       - test_task_sorting: 任务排序
   - 覆盖率目标: >80%

5. test_routes.py
   - 路由集成测试
   - 测试类:
     * TestCategoryAPI: 分类 API 测试
       - test_get_categories: 获取分类列表
       - test_get_category_presets: 获取预设分类
     * TestTagAPI: 标签 API 测试
       - test_get_tags: 获取标签列表
       - test_create_tag: 创建标签
     * TestStatsAPI: 统计 API 测试
       - test_get_stats_overview: 统计概览
     * TestReminderAPI: 提醒 API 测试
       - test_get_reminders: 获取提醒列表
   - 覆盖率目标: >75%

6. test_utils.py
   - 工具函数测试
   - 测试内容:
     * 缓存工具测试
     * 时间解析测试
     * 辅助函数测试
   - 覆盖率目标: >70%

================================================================================
                              测试策略
================================================================================

1. 测试金字塔
   
   单元测试 (70%)
   - 函数/方法级别测试
   - 快速执行
   - 高覆盖率
   
   集成测试 (20%)
   - API 端点测试
   - 数据库交互测试
   - 中等执行速度
   
   E2E 测试 (10%)
   - 完整业务流程
   - 较慢执行
   - 关键路径覆盖

2. 测试原则
   - 独立性: 每个测试独立运行
   - 可重复性: 多次运行结果一致
   - 快速反馈: 测试执行速度快
   - 自动化: CI/CD 集成

3. 测试数据
   - 使用 fixtures 管理测试数据
   - 临时数据库隔离
   - 自动清理机制

================================================================================
                              运行测试
================================================================================

【运行所有测试】
pytest

【运行特定测试文件】
pytest tests/test_auth.py

【运行特定测试类】
pytest tests/test_auth.py::TestAuthRegistration

【运行特定测试方法】
pytest tests/test_auth.py::TestAuthRegistration::test_register_success

【带覆盖率报告】
pytest --cov=. --cov-report=html

【详细输出】
pytest -v

【调试模式】
pytest --tb=long

================================================================================
                              测试配置
================================================================================

【pytest.ini 配置】
- testpaths: 测试文件路径
- python_files: 测试文件命名模式
- addopts: 默认选项
  * -v: 详细输出
  * --tb=short: 简短错误追踪
  * --cov=.: 覆盖率统计
  * --cov-report=term-missing: 终端报告
  * --cov-report=html: HTML 报告

================================================================================
                              测试覆盖率目标
================================================================================

| 模块         | 当前覆盖 | 目标覆盖 | 状态 |
|--------------|----------|----------|------|
| 认证模块     | 85%      | 90%      | 🟡   |
| AI 排序      | 80%      | 85%      | 🟡   |
| 任务管理     | 75%      | 80%      | 🟡   |
| 路由集成     | 70%      | 75%      | 🟡   |
| 工具函数     | 65%      | 70%      | 🟡   |
| 整体         | 75%      | 80%      | 🟡   |

================================================================================
