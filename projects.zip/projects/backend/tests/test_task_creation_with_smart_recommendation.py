"""任务创建智能推荐集成测试"""

import pytest
import json
from datetime import datetime


class TestTaskCreationWithSmartRecommendation:
    """测试任务创建中的智能推荐功能"""
    
    def test_create_task_without_time_uses_recommendation(self, client, auth_headers):
        """测试不指定时间时自动使用智能推荐"""
        response = client.post(
            '/api/tasks',
            headers=auth_headers,
            json={
                'title': '准备期末考试',
                'category': '考试',
                'description': '复习高数'
            }
        )
        
        assert response.status_code == 201
        data = response.get_json()
        
        assert data['success'] is True
        assert data['task']['start_time'] is not None
        assert data['task']['end_time'] is not None
        assert data['recommendation']['used_smart_recommendation'] is True
    
    def test_create_task_with_explicit_time_ignores_recommendation(self, client, auth_headers):
        """测试明确指定时间时不使用推荐"""
        response = client.post(
            '/api/tasks',
            headers=auth_headers,
            json={
                'title': '开会',
                'start_time': '2026-05-10 14:00:00',
                'end_time': '2026-05-10 15:00:00'
            }
        )
        
        assert response.status_code == 201
        data = response.get_json()
        
        assert data['task']['start_time'] == '2026-05-10 14:00:00'
        assert data['recommendation']['used_smart_recommendation'] is False
    
    def test_auto_difficulty_evaluation(self, client, auth_headers):
        """测试自动难度评估"""
        response = client.post(
            '/api/tasks',
            headers=auth_headers,
            json={
                'title': '完成毕业论文',
                'category': '项目'
            }
        )
        
        assert response.status_code == 201
        data = response.get_json()
        
        assert data['task']['difficulty_level'] in ['hard', 'very_hard']
    
    def test_create_task_with_estimated_duration(self, client, auth_headers):
        """测试使用用户指定预估时长"""
        response = client.post(
            '/api/tasks',
            headers=auth_headers,
            json={
                'title': '复习数学',
                'category': '学习',
                'estimated_duration': 120
            }
        )
        
        assert response.status_code == 201
        data = response.get_json()
        
        assert data['success'] is True
        assert data['recommendation']['estimated_duration'] == 120
    
    def test_create_task_preserves_explicit_difficulty(self, client, auth_headers):
        """测试用户指定难度时保留用户选择"""
        response = client.post(
            '/api/tasks',
            headers=auth_headers,
            json={
                'title': '简单任务',
                'category': '学习',
                'difficulty_level': 'easy'
            }
        )
        
        assert response.status_code == 201
        data = response.get_json()
        
        assert data['task']['difficulty_level'] == 'easy'
