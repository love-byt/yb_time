"""
任务管理API测试用例
"""

import pytest
import json


class TestTaskAPI:
    """任务API测试类"""
    
    def test_create_task_success(self, client, test_user_id):
        """测试创建任务成功"""
        response = client.post(
            '/api/tasks',
            data=json.dumps({
                'title': '测试任务',
                'category': '学习',
                'priority': 3
            }),
            content_type='application/json',
            headers={'X-User-ID': test_user_id}
        )
        
        assert response.status_code == 201
        data = json.loads(response.data)
        assert data['success'] is True
        assert data['task']['title'] == '测试任务'
        assert 'start_time' in data['task']  # 应该自动填充当前时刻
    
    def test_create_task_with_default_time(self, client, test_user_id):
        """测试创建任务时自动填充当前时刻"""
        response = client.post(
            '/api/tasks',
            data=json.dumps({
                'title': '默认时间任务'
            }),
            content_type='application/json',
            headers={'X-User-ID': test_user_id}
        )
        
        assert response.status_code == 201
        data = json.loads(response.data)
        assert data['success'] is True
        # 验证start_time已自动填充
        assert data['task']['start_time'] is not None
        assert len(data['task']['start_time']) > 0
    
    def test_create_task_without_title(self, client, test_user_id):
        """测试创建任务时缺少标题"""
        response = client.post(
            '/api/tasks',
            data=json.dumps({
                'category': '学习'
            }),
            content_type='application/json',
            headers={'X-User-ID': test_user_id}
        )
        
        assert response.status_code == 400
        data = json.loads(response.data)
        assert data['success'] is False
        assert '标题' in data['message']
    
    def test_get_tasks(self, client, test_user_id):
        """测试获取任务列表"""
        # 先创建一个任务
        client.post(
            '/api/tasks',
            data=json.dumps({'title': '测试任务1'}),
            content_type='application/json',
            headers={'X-User-ID': test_user_id}
        )
        
        # 获取任务列表
        response = client.get(
            '/api/tasks',
            headers={'X-User-ID': test_user_id}
        )
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert isinstance(data, list)
        assert len(data) >= 1
    
    def test_get_single_task(self, client, test_user_id):
        """测试获取单个任务"""
        # 创建任务
        create_response = client.post(
            '/api/tasks',
            data=json.dumps({'title': '单个任务测试'}),
            content_type='application/json',
            headers={'X-User-ID': test_user_id}
        )
        task_id = json.loads(create_response.data)['task']['id']
        
        # 获取任务
        response = client.get(
            f'/api/tasks/{task_id}',
            headers={'X-User-ID': test_user_id}
        )
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['title'] == '单个任务测试'
    
    def test_update_task(self, client, test_user_id):
        """测试更新任务"""
        # 创建任务
        create_response = client.post(
            '/api/tasks',
            data=json.dumps({'title': '更新前标题'}),
            content_type='application/json',
            headers={'X-User-ID': test_user_id}
        )
        task_id = json.loads(create_response.data)['task']['id']
        
        # 更新任务
        response = client.put(
            f'/api/tasks/{task_id}',
            data=json.dumps({'title': '更新后标题', 'priority': 5}),
            content_type='application/json',
            headers={'X-User-ID': test_user_id}
        )
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['success'] is True
        assert data['task']['title'] == '更新后标题'
        assert data['task']['priority'] == 5
    
    def test_complete_task(self, client, test_user_id):
        """测试完成任务（使用新的状态API）"""
        # 创建任务
        create_response = client.post(
            '/api/tasks',
            data=json.dumps({'title': '待完成任务'}),
            content_type='application/json',
            headers={'X-User-ID': test_user_id}
        )
        task_id = json.loads(create_response.data)['task']['id']
        
        # 先start任务（pending -> in_progress）
        start_response = client.put(
            f'/api/tasks/{task_id}/status',
            data=json.dumps({'action': 'start'}),
            content_type='application/json',
            headers={'X-User-ID': test_user_id}
        )
        assert start_response.status_code == 200
        
        # 再complete任务（in_progress -> completed）
        response = client.put(
            f'/api/tasks/{task_id}/status',
            data=json.dumps({'action': 'complete'}),
            content_type='application/json',
            headers={'X-User-ID': test_user_id}
        )
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['success'] is True
        assert data['task']['is_completed'] == 1
    
    def test_delete_task(self, client, test_user_id):
        """测试删除任务"""
        # 获取删除前的任务数量
        before_response = client.get(
            '/api/tasks',
            headers={'X-User-ID': test_user_id}
        )
        before_count = len(json.loads(before_response.data))
        
        # 创建任务
        create_response = client.post(
            '/api/tasks',
            data=json.dumps({'title': '待删除任务'}),
            content_type='application/json',
            headers={'X-User-ID': test_user_id}
        )
        task_id = json.loads(create_response.data)['task']['id']
        
        # 删除任务
        response = client.delete(
            f'/api/tasks/{task_id}',
            headers={'X-User-ID': test_user_id}
        )
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['success'] is True
        
        # 验证任务已删除（通过任务列表数量）
        after_response = client.get(
            '/api/tasks',
            headers={'X-User-ID': test_user_id}
        )
        after_count = len(json.loads(after_response.data))
        assert after_count == before_count
    
    def test_user_isolation(self, client):
        """测试用户数据隔离"""
        # 用户A创建任务
        user_a = 'user-a-001'
        client.post(
            '/api/tasks',
            data=json.dumps({'title': '用户A的任务'}),
            content_type='application/json',
            headers={'X-User-ID': user_a}
        )
        
        # 用户B创建任务
        user_b = 'user-b-002'
        client.post(
            '/api/tasks',
            data=json.dumps({'title': '用户B的任务'}),
            content_type='application/json',
            headers={'X-User-ID': user_b}
        )
        
        # 用户A只能看到自己的任务
        response_a = client.get(
            '/api/tasks',
            headers={'X-User-ID': user_a}
        )
        tasks_a = json.loads(response_a.data)
        assert all(task['user_id'] == user_a for task in tasks_a)
        
        # 用户B只能看到自己的任务
        response_b = client.get(
            '/api/tasks',
            headers={'X-User-ID': user_b}
        )
        tasks_b = json.loads(response_b.data)
        assert all(task['user_id'] == user_b for task in tasks_b)
