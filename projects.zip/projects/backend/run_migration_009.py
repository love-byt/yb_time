"""
数据库迁移脚本 - 添加任务难度字段
"""
import sqlite3
import os

def run_migration():
    # 数据库在 backend 的父目录下的 instance 文件夹中
    backend_dir = os.path.dirname(os.path.abspath(__file__))
    db_path = os.path.join(backend_dir, '..', 'instance', 'schedule.db')
    db_path = os.path.normpath(db_path)
    
    if not os.path.exists(db_path):
        print(f'数据库文件不存在: {db_path}')
        return
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # 检查字段是否已存在
    cursor.execute("PRAGMA table_info(task)")
    columns = [col[1] for col in cursor.fetchall()]
    
    # 添加 estimated_duration 字段
    if 'estimated_duration' not in columns:
        cursor.execute('ALTER TABLE task ADD COLUMN estimated_duration INTEGER')
        print('[OK] 添加字段: estimated_duration')
    else:
        print('[SKIP] 字段已存在: estimated_duration')
    
    # 添加 difficulty_level 字段
    if 'difficulty_level' not in columns:
        cursor.execute("ALTER TABLE task ADD COLUMN difficulty_level VARCHAR(10) DEFAULT 'medium'")
        print('[OK] 添加字段: difficulty_level')
    else:
        print('[SKIP] 字段已存在: difficulty_level')
    
    # 添加 difficulty_factors 字段
    if 'difficulty_factors' not in columns:
        cursor.execute('ALTER TABLE task ADD COLUMN difficulty_factors TEXT')
        print('[OK] 添加字段: difficulty_factors')
    else:
        print('[SKIP] 字段已存在: difficulty_factors')
    
    conn.commit()
    conn.close()
    print('\n数据库迁移完成！')

if __name__ == '__main__':
    run_migration()
