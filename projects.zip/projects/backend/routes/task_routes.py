"""
任务管理路由
支持缓存优化
"""

from datetime import datetime
from dateutil import parser as date_parser
import json
import logging
from typing import Optional, Dict, Any, Tuple

from flask import Blueprint, jsonify, request

from extensions import db
from models.task import Task
from utils.user_auth import require_user, filter_by_user
from utils.cache import cached, invalidate_cache
from utils.ai_sorter import ai_sorter

logger = logging.getLogger(__name__)

task_bp = Blueprint('task', __name__)


def parse_datetime(value):
    """
    解析日期时间值，支持多种格式
    
    Args:
        value: 字符串、datetime对象或None
        
    Returns:
        datetime对象或None
    """
    if value is None:
        return None
    
    if isinstance(value, datetime):
        return value
    
    if isinstance(value, str):
        if not value.strip():
            return None
        try:
            # 使用 dateutil.parser 解析多种格式
            return date_parser.parse(value)
        except Exception:
            try:
                # 尝试常见格式
                for fmt in ['%Y-%m-%d %H:%M:%S', '%Y-%m-%dT%H:%M:%S', 
                            '%Y-%m-%dT%H:%M', '%Y-%m-%d %H:%M', '%Y-%m-%d']:
                    try:
                        return datetime.strptime(value, fmt)
                    except ValueError:
                        continue
            except Exception:
                pass
    
    return None


@task_bp.route('/api/tasks', methods=['GET'])
@require_user
def get_tasks(user):
    """获取所有任务（支持缓存）"""
    # 检查是否使用缓存
    use_cache = request.args.get('cache', 'true').lower() == 'true'
    
    if use_cache:
        from utils.cache import cache
        cache_key = f"tasks:{user.id}"
        cached_tasks = cache.get(cache_key)
        
        if cached_tasks is not None:
            return jsonify(cached_tasks)
    
    # 查询数据库
    tasks = Task.query.filter_by(user_id=user.id).order_by(Task.created_at.desc()).all()
    tasks_data = [task.to_dict() for task in tasks]
    
    # 存入缓存（TTL: 60秒）
    if use_cache:
        from utils.cache import cache
        cache.set(f"tasks:{user.id}", tasks_data, ttl=60)
    
    return jsonify(tasks_data)


@task_bp.route('/api/tasks', methods=['POST'])
@require_user
def create_task(user):
    """创建新任务（增强版：智能时间推荐）"""
    data = request.get_json()
    
    # 基础字段验证
    title = data.get('title', '').strip()
    if not title:
        return jsonify({"success": False, "message": "任务标题不能为空"}), 400
    
    description = data.get('description', '')
    category = data.get('category', '学习')
    
    # ==================== 第一步：解析用户明确指定的时间 ====================
    start_time = parse_datetime(data.get('start_time'))
    end_time = parse_datetime(data.get('end_time'))
    
    # 如果前端没有明确指定时间，尝试从文本中智能提取
    if start_time is None or end_time is None:
        try:
            from utils.smart_time_parser import smart_parse_time
            
            parsed_start, parsed_end = smart_parse_time(
                title=title,
                description=description,
                base_time=datetime.now()
            )
            
            if start_time is None and parsed_start:
                start_time = parsed_start
            
            if end_time is None and parsed_end:
                end_time = parsed_end
                
        except Exception as e:
            print(f"智能时间解析失败: {e}")
    
    # ==================== 第二步：智能时间推荐（新增） ====================
    estimated_duration = data.get('estimated_duration')
    difficulty_level = data.get('difficulty_level')
    difficulty_factors = data.get('difficulty_factors')
    
    # 如果用户没有指定难度，自动评估
    if not difficulty_level:
        from utils.difficulty_evaluator import DifficultyEvaluator
        
        difficulty_result = DifficultyEvaluator.evaluate(
            title=title,
            description=description,
            category=category,
            estimated_duration=estimated_duration
        )
        
        difficulty_level = difficulty_result['difficulty_level']
        difficulty_factors = difficulty_result['factors']
    
    # 如果仍然没有完整的时间信息，使用智能推荐
    ai_suggestion = None
    if start_time is None or end_time is None:
        from utils.smart_time_recommender import SmartTimeRecommender
        
        recommender = SmartTimeRecommender(user.id)
        
        recommendation = recommender.recommend_time_range(
            category=category,
            difficulty=difficulty_level,
            title=title,
            estimated_duration=estimated_duration,
            earliest_time=start_time or datetime.now()
        )
        
        # 如果没有开始时间，使用推荐的开始时间
        if start_time is None:
            start_time = recommendation['start_time']
        
        # 如果没有结束时间，使用推荐的结束时间
        if end_time is None:
            end_time = recommendation['end_time']
        
        # 如果没有预估时长，使用推荐的时长
        if estimated_duration is None:
            estimated_duration = recommendation['estimated_duration']
        
        # 记录推荐信息（用于调试和用户反馈）
        ai_suggestion = f"智能推荐：{recommendation['reasoning']['start']}；{recommendation['reasoning']['end']}"
    
    # 如果仍然没有开始时间（兜底逻辑），使用当前时间
    if start_time is None:
        start_time = datetime.now()
    
    # ==================== 创建任务对象 ====================
    task = Task(
        user_id=user.id,
        title=title,
        description=description,
        category=category,
        priority=data.get('priority', 0),
        start_time=start_time,
        end_time=end_time,
        estimated_duration=estimated_duration,
        difficulty_level=difficulty_level,
        difficulty_factors=json.dumps(difficulty_factors) if difficulty_factors else None,
        ai_suggestion=ai_suggestion,
        recurring_rule_id=data.get('recurring_rule_id')
    )
    
    db.session.add(task)
    db.session.commit()
    
    # 清除缓存
    from utils.cache import cache
    cache.delete(f"tasks:{user.id}")
    
    return jsonify({
        "success": True,
        "task": task.to_dict(),
        "recommendation": {
            "used_smart_recommendation": ai_suggestion is not None,
            "difficulty_level": difficulty_level,
            "estimated_duration": estimated_duration
        }
    }), 201


@task_bp.route('/api/tasks/batch', methods=['POST'])
@require_user
def create_tasks_batch(user):
    """
    批量创建任务
    
    请求体:
    {
        "tasks": [
            {
                "title": "任务标题（必填）",
                "description": "任务描述",
                "category": "分类",
                "priority": 0,
                "start_time": "2024-01-01T10:00",
                "end_time": "2024-01-01T12:00",
                "estimated_duration": 120
            }
        ],
        "options": {
            "auto_deadline": true,  // 是否自动为无截止时间的任务生成截止时间
            "default_category": "学习"  // 默认分类
        }
    }
    
    响应:
    {
        "success": true,
        "created": 5,  // 成功创建的任务数
        "failed": 0,   // 失败的任务数
        "tasks": [...], // 创建的任务列表
        "errors": []   // 错误信息列表
    }
    """
    data = request.get_json() or {}
    tasks_data = data.get('tasks', [])
    options = data.get('options', {})
    
    if not tasks_data or not isinstance(tasks_data, list):
        return jsonify({
            "success": False,
            "message": "请提供任务列表（tasks数组）"
        }), 400
    
    if len(tasks_data) > 100:
        return jsonify({
            "success": False,
            "message": "单次最多支持100个任务"
        }), 400
    
    auto_deadline = options.get('auto_deadline', True)
    default_category = options.get('default_category', '学习')
    
    created_tasks = []
    errors = []
    
    # 批量处理任务
    for index, task_data in enumerate(tasks_data):
        try:
            title = task_data.get('title', '').strip()
            if not title:
                errors.append({
                    "index": index,
                    "message": "任务标题不能为空"
                })
                continue
            
            description = task_data.get('description', '') or ''
            category = task_data.get('category', default_category)
            priority = task_data.get('priority', 0)
            
            # 解析时间
            start_time = parse_datetime(task_data.get('start_time'))
            end_time = parse_datetime(task_data.get('end_time'))
            
            # 智能时间解析
            if start_time is None or end_time is None:
                try:
                    from utils.smart_time_parser import smart_parse_time
                    parsed_start, parsed_end = smart_parse_time(
                        title=title,
                        description=description,
                        base_time=datetime.now()
                    )
                    if start_time is None and parsed_start:
                        start_time = parsed_start
                    if end_time is None and parsed_end:
                        end_time = parsed_end
                except Exception as e:
                    logger.debug(f"任务 {index} 智能时间解析失败: {e}")
            
            if start_time is None:
                start_time = datetime.now()
            
            estimated_duration = task_data.get('estimated_duration')
            difficulty_level = task_data.get('difficulty_level', 'medium')
            difficulty_factors = task_data.get('difficulty_factors')
            
            task = Task(
                user_id=user.id,
                title=title,
                description=description,
                category=category,
                priority=priority,
                start_time=start_time,
                end_time=end_time,
                estimated_duration=estimated_duration,
                difficulty_level=difficulty_level,
                difficulty_factors=json.dumps(difficulty_factors) if difficulty_factors else None,
                recurring_rule_id=task_data.get('recurring_rule_id')
            )
            
            db.session.add(task)
            db.session.flush()  # 获取ID但不提交
            
            # 自动生成截止时间
            if not task.end_time and auto_deadline:
                try:
                    from routes.ai_routes import generate_smart_deadline_internal
                    smart_deadline = generate_smart_deadline_internal(
                        user=user,
                        title=task.title,
                        description=task.description,
                        category=task.category,
                        start_time=task.start_time
                    )
                    if smart_deadline:
                        task.end_time = smart_deadline
                except Exception as e:
                    logger.debug(f"任务 {index} 自动生成截止时间失败: {e}")
            
            created_tasks.append(task)
            
        except Exception as e:
            logger.error(f"批量创建任务 {index} 失败: {e}")
            errors.append({
                "index": index,
                "title": task_data.get('title', ''),
                "message": str(e)
            })
    
    # 提交所有成功创建的任务
    if created_tasks:
        db.session.commit()
        
        # 清除缓存
        from utils.cache import cache
        cache.delete(f"tasks:{user.id}")
    
    return jsonify({
        "success": True,
        "created": len(created_tasks),
        "failed": len(errors),
        "tasks": [task.to_dict() for task in created_tasks],
        "errors": errors,
        "message": f"成功创建 {len(created_tasks)} 个任务" + (f"，{len(errors)} 个失败" if errors else "")
    }), 201


@task_bp.route('/api/tasks/<int:task_id>', methods=['GET'])
@require_user
def get_task(user, task_id):
    """获取单个任务"""
    task = Task.query.filter_by(id=task_id, user_id=user.id).first_or_404()
    return jsonify(task.to_dict())


@task_bp.route('/api/tasks/<int:task_id>', methods=['PUT'])
@require_user
def update_task(user, task_id):
    """更新任务"""
    task = Task.query.filter_by(id=task_id, user_id=user.id).first_or_404()
    data = request.get_json()
    
    if 'title' in data:
        task.title = data['title'].strip()
    if 'description' in data:
        task.description = data['description']
    if 'category' in data:
        task.category = data['category']
    if 'priority' in data:
        task.priority = data['priority']
    if 'start_time' in data:
        # 解析时间字符串
        parsed_time = parse_datetime(data['start_time'])
        # 直接赋值（parse_datetime 已经处理了 None 和字符串）
        task.start_time = parsed_time
    if 'end_time' in data:
        # 解析时间字符串
        parsed_time = parse_datetime(data['end_time'])
        # 直接赋值（parse_datetime 已经处理了 None 和字符串）
        task.end_time = parsed_time
    if 'ai_suggestion' in data:
        task.ai_suggestion = data['ai_suggestion']
    
    # 六维度分数
    for dim in ['time_score', 'importance_score', 'impact_score', 
                'money_score', 'relation_score', 'skill_score', 'ai_sort_score']:
        if dim in data:
            setattr(task, dim, data[dim])
    
    db.session.commit()
    
    # 清除任务列表缓存
    from utils.cache import cache
    cache.delete(f"tasks:{user.id}")
    
    return jsonify({
        "success": True,
        "task": task.to_dict(),
        "message": "任务更新成功"
    })


@task_bp.route('/api/tasks/<int:task_id>', methods=['DELETE'])
@require_user
def delete_task(user, task_id):
    """删除任务"""
    task = Task.query.filter_by(id=task_id, user_id=user.id).first_or_404()
    db.session.delete(task)
    db.session.commit()
    
    # 清除任务列表缓存
    from utils.cache import cache
    cache.delete(f"tasks:{user.id}")
    
    return jsonify({
        "success": True,
        "message": "任务删除成功"
    })


# ==================== 任务状态更新核心逻辑 ====================

# 定义任务状态
TASK_STATUS_PENDING = 'pending'       # 待处理
TASK_STATUS_IN_PROGRESS = 'in_progress'  # 进行中
TASK_STATUS_PAUSED = 'paused'         # 已暂停
TASK_STATUS_COMPLETED = 'completed'   # 已完成

# 定义状态转换规则（状态机）
STATUS_TRANSITIONS = {
    TASK_STATUS_PENDING: ['start'],
    TASK_STATUS_IN_PROGRESS: ['complete', 'pause'],
    TASK_STATUS_PAUSED: ['start'],
    TASK_STATUS_COMPLETED: ['uncomplete']
}

# 操作的中文名称
ACTION_DISPLAY_NAMES = {
    'start': '开始',
    'complete': '完成',
    'uncomplete': '取消完成',
    'pause': '暂停'
}


def get_task_status(task):
    """
    根据任务属性推断当前状态
    
    Args:
        task: Task对象
        
    Returns:
        状态字符串
    """
    # 优先使用 status 字段
    if task.status:
        return task.status
    
    # 兼容旧数据：根据其他字段推断状态
    if task.is_completed:
        return TASK_STATUS_COMPLETED
    
    if task.actual_start_time:
        return TASK_STATUS_IN_PROGRESS
    
    return TASK_STATUS_PENDING


def validate_status_transition(current_status, action):
    """
    验证状态转换是否合法
    
    Args:
        current_status: 当前状态
        action: 要执行的操作
        
    Returns:
        (is_valid, error_message)
    """
    allowed_actions = STATUS_TRANSITIONS.get(current_status, [])
    
    if action not in allowed_actions:
        return False, f"当前状态 '{current_status}' 不允许执行 '{action}' 操作。允许的操作: {allowed_actions}"
    
    return True, None


def _do_update_task_status(user, task_id, action, options=None):
    """
    内部函数：执行任务状态更新
    
    Args:
        user: 用户对象
        task_id: 任务ID
        action: 操作类型 (start/complete/uncomplete/pause)
        options: 可选参数 (actual_duration等)
    
    Returns:
        Flask响应对象
    """
    if options is None:
        options = {}
    
    # 验证操作类型
    valid_actions = {'start', 'complete', 'uncomplete', 'pause'}
    if action not in valid_actions:
        return jsonify({
            "success": False,
            "message": f"无效的操作: {action}。支持的操作: {valid_actions}"
        }), 400
    
    # 查询任务
    task = Task.query.filter_by(id=task_id, user_id=user.id).first()
    if not task:
        return jsonify({
            "success": False,
            "message": "任务不存在"
        }), 404
    
    # 获取当前状态并验证转换
    current_status = get_task_status(task)
    is_valid, error_msg = validate_status_transition(current_status, action)
    
    if not is_valid:
        return jsonify({
            "success": False,
            "message": error_msg,
            "current_status": current_status,
            "action": action
        }), 400
    
    # 记录前一个状态
    previous_status = current_status
    now = datetime.now()
    
    # 执行状态更新
    if action == 'start':
        task.actual_start_time = now
        task.status = TASK_STATUS_IN_PROGRESS
        
    elif action == 'complete':
        task.is_completed = 1
        task.actual_end_time = now
        task.status = TASK_STATUS_COMPLETED

        # 计算实际耗时
        if task.actual_start_time:
            delta = task.actual_end_time - task.actual_start_time
            task.actual_duration = int(delta.total_seconds() / 60)

        # 使用传入的实际耗时（如果有）
        if options.get('actual_duration'):
            task.actual_duration = options['actual_duration']

        # 收集执行反馈用于动态排序优化
        try:
            _collect_execution_feedback(task, user.id)
        except Exception as e:
            logger.error(f"收集执行反馈失败: {e}")
    
    elif action == 'uncomplete':
        task.is_completed = 0
        task.actual_end_time = None
        task.actual_start_time = None
        task.status = TASK_STATUS_PENDING
        # 可选：保留 actual_duration 作为历史记录
    
    elif action == 'pause':
        # 暂停：计算已用时间并更新状态
        if task.actual_start_time:
            delta = now - task.actual_start_time
            task.actual_duration = int(delta.total_seconds() / 60)
        task.status = TASK_STATUS_PAUSED
    
    db.session.commit()
    
    # 清除缓存
    from utils.cache import cache
    cache.delete(f"tasks:{user.id}")
    
    # 获取新状态
    new_status = get_task_status(task)
    
    return jsonify({
        "success": True,
        "task": task.to_dict(),
        "message": f"任务已{ACTION_DISPLAY_NAMES.get(action, action)}",
        "previous_status": previous_status,
        "current_status": new_status
    })


# ==================== 统一任务状态更新接口 ====================

@task_bp.route('/api/tasks/<int:task_id>/status', methods=['PUT'])
@require_user
def update_task_status(user, task_id):
    """
    统一任务状态更新接口
    
    支持的状态操作:
    - start: 开始任务（设置 actual_start_time）
    - complete: 完成任务（设置 is_completed=1, actual_end_time）
    - uncomplete: 取消完成（设置 is_completed=0）
    - pause: 暂停任务（计算已用时间）
    
    请求体:
    {
        "action": "start" | "complete" | "uncomplete" | "pause",
        "actual_duration": 30  // 可选，实际耗时（分钟）
    }
    
    状态机规则:
    - pending -> start -> in_progress
    - in_progress -> complete -> completed
    - in_progress -> pause -> paused
    - paused -> start -> in_progress
    - completed -> uncomplete -> pending
    """
    data = request.get_json() or {}
    action = data.get('action', '').lower()
    options = {
        'actual_duration': data.get('actual_duration')
    }
    return _do_update_task_status(user, task_id, action, options)


# ==================== 兼容旧接口（调用统一接口）====================
# [DEPRECATED] 以下接口已废弃，请使用 PUT /api/tasks/<id>/status 代替

import logging
_deprecated_logger = logging.getLogger('deprecated')


def _log_deprecated_api(old_endpoint, new_endpoint):
    """记录废弃API的使用"""
    _deprecated_logger.warning(
        f"废弃API调用: {old_endpoint} -> 请使用 {new_endpoint}"
    )


@task_bp.route('/api/tasks/<int:task_id>/complete', methods=['PUT'])
@require_user
def complete_task(user, task_id):
    """
    完成任务
    
    @deprecated 请使用 PUT /api/tasks/<id>/status (action=complete)
    """
    _log_deprecated_api(
        'PUT /api/tasks/<id>/complete',
        'PUT /api/tasks/<id>/status (action=complete)'
    )
    result = _do_update_task_status(user, task_id, 'complete')
    # 添加废弃警告到响应头
    if hasattr(result, 'headers'):
        result.headers['X-Deprecated-API'] = 'true'
        result.headers['X-Replacement-API'] = 'PUT /api/tasks/<id>/status'
    return result


@task_bp.route('/api/tasks/<int:task_id>/uncomplete', methods=['PUT'])
@require_user
def uncomplete_task(user, task_id):
    """
    取消完成
    
    @deprecated 请使用 PUT /api/tasks/<id>/status (action=uncomplete)
    """
    _log_deprecated_api(
        'PUT /api/tasks/<id>/uncomplete',
        'PUT /api/tasks/<id>/status (action=uncomplete)'
    )
    result = _do_update_task_status(user, task_id, 'uncomplete')
    if hasattr(result, 'headers'):
        result.headers['X-Deprecated-API'] = 'true'
        result.headers['X-Replacement-API'] = 'PUT /api/tasks/<id>/status'
    return result


@task_bp.route('/api/tasks/<int:task_id>/start', methods=['PUT'])
@require_user
def start_task(user, task_id):
    """
    开始任务
    
    @deprecated 请使用 PUT /api/tasks/<id>/status (action=start)
    """
    _log_deprecated_api(
        'PUT /api/tasks/<id>/start',
        'PUT /api/tasks/<id>/status (action=start)'
    )
    result = _do_update_task_status(user, task_id, 'start')
    if hasattr(result, 'headers'):
        result.headers['X-Deprecated-API'] = 'true'
        result.headers['X-Replacement-API'] = 'PUT /api/tasks/<id>/status'
    return result


@task_bp.route('/api/tasks/<int:task_id>/finish', methods=['PUT'])
@require_user
def finish_task(user, task_id):
    """
    结束任务
    
    @deprecated 请使用 PUT /api/tasks/<id>/status (action=complete)
    """
    _log_deprecated_api(
        'PUT /api/tasks/<id>/finish',
        'PUT /api/tasks/<id>/status (action=complete)'
    )
    result = _do_update_task_status(user, task_id, 'complete')
    if hasattr(result, 'headers'):
        result.headers['X-Deprecated-API'] = 'true'
        result.headers['X-Replacement-API'] = 'PUT /api/tasks/<id>/status'
    return result


@task_bp.route('/api/tasks/<int:task_id>/pause', methods=['PUT'])
@require_user
def pause_task(user, task_id):
    """
    暂停任务
    
    这是新接口，也可以通过 PUT /api/tasks/<id>/status (action=pause) 调用
    """
    return _do_update_task_status(user, task_id, 'pause')


@task_bp.route('/api/tasks/reorder', methods=['POST'])
@require_user
def reorder_tasks(user):
    """重新排序任务"""
    data = request.get_json()
    orders = data.get('orders', [])

    for item in orders:
        task = Task.query.filter_by(id=item.get('id'), user_id=user.id).first()
        if task:
            task.manual_order = item.get('order', 0)

    db.session.commit()

    # 记录用户手动重排序，用于动态权重学习
    try:
        _record_manual_reorder(user.id, orders)
    except Exception as e:
        logger.error(f"记录手动重排序失败: {e}")

    return jsonify({
        "success": True,
        "message": "排序已保存"
    })


def _collect_execution_feedback(task, user_id):
    """
    收集任务执行反馈用于动态排序优化

    Args:
        task: 完成的任务对象
        user_id: 用户ID
    """
    from database.db_manager import get_db

    db = get_db()
    cursor = db.cursor()

    # 计算是否按时完成
    on_time = True
    if task.deadline and task.actual_end_time:
        on_time = task.actual_end_time <= task.deadline

    # 获取AI排序时的维度分数（如果有）
    dimension_scores = {}
    try:
        scores = ai_sorter._calculate_dimension_scores(task)
        dimension_scores = scores
    except Exception:
        pass

    # 获取预估耗时
    estimated_duration = task.estimated_duration or task.expected_duration or 0

    # 获取AI推荐顺序（从排序缓存中）
    ai_recommended_order = None
    try:
        cursor.execute("""
            SELECT task_order FROM task_sort_cache
            WHERE user_id = ? AND expires_at > datetime('now')
            ORDER BY created_at DESC LIMIT 1
        """, (user_id,))
        row = cursor.fetchone()
        if row:
            task_order = json.loads(row[0])
            if task.id in task_order:
                ai_recommended_order = task_order.index(task.id) + 1
    except Exception:
        pass

    # 保存执行反馈
    cursor.execute("""
        INSERT OR REPLACE INTO sort_execution_feedback
        (task_id, user_id, dimension_scores, actual_duration, estimated_duration,
         ai_recommended_order, on_time, completed_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))
    """, (
        task.id,
        user_id,
        json.dumps(dimension_scores),
        task.actual_duration,
        estimated_duration,
        ai_recommended_order,
        on_time
    ))

    db.commit()
    logger.debug(f"已收集任务 {task.id} 的执行反馈")


def _record_manual_reorder(user_id, orders):
    """
    记录用户手动重排序

    Args:
        user_id: 用户ID
        orders: 排序列表 [{id, order}, ...]
    """
    from utils.dynamic_weight_adjuster import get_weight_adjuster

    adjuster = get_weight_adjuster()

    # 为每个被移动的任务记录反馈
    for item in orders:
        task_id = item.get('id')
        if task_id:
            # 触发权重学习
            adjuster.process_user_feedback(
                user_id=user_id,
                feedback_type='reorder',
                task_id=task_id,
                details=f"用户手动调整排序到位置 {item.get('order', 0)}"
            )
