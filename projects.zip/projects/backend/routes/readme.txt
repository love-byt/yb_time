================================================================================
                          Routes 文件夹说明
================================================================================

【文件夹作用】
本文件夹包含 Flask 蓝图（Blueprint）定义，实现 RESTful API 路由端点。
每个路由文件负责特定功能模块的 HTTP 请求处理。

================================================================================
                              文件说明
================================================================================

1. __init__.py
   - 路由包初始化文件
   - 注册所有蓝图到 Flask 应用
   - 统一路由入口管理

================================================================================

【认证相关路由】

2. auth_routes.py
   - 用户认证路由
   - API 端点:
     * POST /api/auth/register    : 用户注册
     * POST /api/auth/login       : 用户登录
     * POST /api/auth/logout      : 用户登出
     * GET  /api/auth/me          : 获取当前用户信息
     * POST /api/auth/refresh     : 刷新 Token
   - 功能:
     * 用户名/密码验证
     * JWT Token 生成与验证
     * 密码哈希加密

3. user_routes.py
   - 用户管理路由
   - API 端点:
     * GET    /api/users          : 获取用户列表（管理员）
     * GET    /api/users/<id>     : 获取用户信息
     * PUT    /api/users/<id>     : 更新用户信息
     * DELETE /api/users/<id>     : 删除用户
     * PUT    /api/users/settings : 更新用户设置
   - 功能:
     * 用户信息管理
     * 用户设置更新

================================================================================

【任务相关路由】

4. task_routes.py
   - 任务管理路由
   - API 端点:
     * GET    /api/tasks              : 获取任务列表（支持缓存）
     * POST   /api/tasks              : 创建任务
     * GET    /api/tasks/<id>         : 获取任务详情
     * PUT    /api/tasks/<id>         : 更新任务
     * DELETE /api/tasks/<id>         : 删除任务
     * PUT    /api/tasks/<id>/complete: 完成任务
     * PUT    /api/tasks/<id>/start   : 开始任务
   - 功能:
     * 任务 CRUD 操作
     * 任务状态管理
     * 缓存支持
     * 时间解析（使用 dateutil）

5. tag_routes.py
   - 标签管理路由
   - API 端点:
     * GET    /api/tags          : 获取标签列表
     * POST   /api/tags          : 创建标签
     * GET    /api/tags/<id>     : 获取标签详情
     * PUT    /api/tags/<id>     : 更新标签
     * DELETE /api/tags/<id>     : 删除标签
     * GET    /api/tags/presets  : 获取预设标签
   - 功能:
     * 标签 CRUD
     * 标签与任务关联
     * 预设标签管理

6. category_routes.py
   - 分类管理路由
   - API 端点:
     * GET    /api/categories          : 获取分类列表
     * POST   /api/categories          : 创建分类
     * GET    /api/categories/<id>     : 获取分类详情
     * PUT    /api/categories/<id>     : 更新分类
     * DELETE /api/categories/<id>     : 删除分类
     * GET    /api/categories/presets  : 获取预设分类
   - 功能:
     * 分类 CRUD
     * 预设分类管理

7. recurring_routes.py
   - 重复任务路由
   - API 端点:
     * GET    /api/recurring          : 获取重复规则列表
     * POST   /api/recurring          : 创建重复规则
     * GET    /api/recurring/<id>     : 获取规则详情
     * PUT    /api/recurring/<id>     : 更新规则
     * DELETE /api/recurring/<id>     : 删除规则
     * POST   /api/recurring/<id>/generate : 生成下一次任务
   - 功能:
     * 重复规则管理
     * 自动生成任务实例
     * 支持每日/每周/每月重复

8. reminder_routes.py
   - 提醒功能路由
   - API 端点:
     * GET    /api/reminders          : 获取提醒列表
     * POST   /api/reminders          : 创建提醒
     * GET    /api/reminders/<id>     : 获取提醒详情
     * PUT    /api/reminders/<id>     : 更新提醒
     * DELETE /api/reminders/<id>     : 删除提醒
   - 功能:
     * 提醒 CRUD
     * 提醒时间设置

================================================================================

【AI 相关路由】

9. ai_sort_routes.py
   - AI 智能排序路由
   - API 端点:
     * POST /api/ai/sort              : 对任务进行智能排序
     * GET  /api/ai/sort/presets      : 获取排序预设模式
     * POST /api/ai/sort/custom       : 自定义权重排序
   - 功能:
     * 六维度智能排序
     * 预设排序模式（均衡/截止优先/备考/自由职业）
     * 自定义权重配置
     * 排序结果解释

10. ai_routes.py
    - AI 助手功能路由
    - API 端点:
      * POST /api/ai/analyze         : AI 分析任务
      * POST /api/ai/suggest         : AI 建议任务
      * POST /api/ai/chat            : AI 对话
    - 功能:
      * 千问 API 调用
      * 任务分析建议
      * 额度检查与管理

11. analysis_routes.py
    - 任务分析路由
    - API 端点:
      * GET  /api/analysis/overview  : 获取分析概览
      * GET  /api/analysis/trends    : 获取趋势分析
      * GET  /api/analysis/efficiency: 获取效率分析
    - 功能:
      * 任务完成分析
      * 效率趋势统计
      * 时间分布分析

================================================================================

【统计相关路由】

12. stats_routes.py
    - 数据统计路由
    - API 端点:
      * GET /api/stats/overview      : 统计概览
      * GET /api/stats/completion    : 完成率统计
      * GET /api/stats/category      : 分类分布统计
      * GET /api/stats/trends        : 趋势统计
      * GET /api/stats/weekly        : 周报告
    - 功能:
      * 任务统计
      * 完成率计算
      * 图表数据生成
      * 周报告生成

================================================================================
                              路由设计特点
================================================================================

1. RESTful 设计
   - 使用标准 HTTP 方法（GET/POST/PUT/DELETE）
   - 资源导向的 URL 设计
   - 统一的响应格式

2. 认证保护
   - 使用 @require_user 装饰器保护敏感路由
   - JWT Token 验证
   - 用户数据隔离

3. 缓存支持
   - 任务列表支持缓存
   - 缓存失效策略
   - 可配置缓存开关

4. 错误处理
   - 统一的错误响应格式
   - HTTP 状态码规范使用
   - 详细的错误信息

5. 输入验证
   - 请求参数验证
   - 数据类型转换
   - 时间格式解析

================================================================================
                              API 响应格式
================================================================================

【成功响应】
{
    "success": true,
    "data": { ... },
    "message": "操作成功"
}

【错误响应】
{
    "success": false,
    "error": "错误信息",
    "code": 400
}

================================================================================
