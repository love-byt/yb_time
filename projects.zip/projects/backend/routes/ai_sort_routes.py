"""
AI排序路由
提供六维度智能排序接口，支持本地分析和AI智能分析两种模式
"""

import json

from flask import Blueprint, jsonify, request

from extensions import db
from models.task import Task
from utils.ai_sorter import SixDimensionSorter, sort_tasks_by_ai
from utils.ai_sorter_optimized import OptimizedAISorter, sort_tasks_optimized
from utils.user_auth import require_user
from utils.ai_helper import AIHelper
from utils.dynamic_weight_adjuster import (
    get_user_weights_with_fallback, 
    initialize_user_weights,
    get_weight_adjuster
)

ai_sort_bp = Blueprint('ai_sort', __name__)

# 排序模式
SORT_MODE_LOCAL = 'local'      # 本地分析模式
SORT_MODE_SMART = 'smart'      # AI智能分析模式


@ai_sort_bp.route('/api/ai/sort', methods=['POST'])
@require_user
def sort_tasks(user):
    """对任务进行六维度智能排序，支持本地分析、AI智能分析和优化模式三种模式"""
    data = request.get_json() or {}
    
    # 获取排序模式: local(本地分析) / smart(AI智能分析) / optimized(优化算法)
    sort_mode = data.get('mode', SORT_MODE_LOCAL)
    
    # 获取并校验权重配置
    weights = data.get('weights')
    cold_start_applied = False
    
    if not weights:
        # 未提供权重，使用冷启动策略获取
        try:
            weights = get_user_weights_with_fallback(user.id, db.engine.raw_connection())
            cold_start_applied = True
        except Exception as e:
            # 冷启动失败，使用默认权重
            weights = SixDimensionSorter.DEFAULT_WEIGHTS
            print(f"冷启动获取权重失败，使用默认: {e}")
    else:
        # 校验用户提供的权重
        validation = SixDimensionSorter.validate_weights_dict(weights)
        if not validation['valid']:
            return jsonify({
                "success": False,
                "message": "权重配置无效",
                "errors": validation['errors'],
                "warnings": validation['warnings']
            }), 400
        # 使用归一化后的权重
        if validation['warnings']:
            weights = validation['normalized']
    
    task_ids = data.get('task_ids')
    if task_ids:
        tasks = Task.query.filter(Task.id.in_(task_ids), Task.user_id == user.id).all()
    else:
        tasks = Task.query.filter_by(user_id=user.id, is_completed=0).all()
    
    if not tasks:
        return jsonify({"success": False, "message": "没有找到可排序的任务"}), 404
    
    task_dicts = [task.to_dict(include_tags=False) for task in tasks]
    
    use_ai = False
    ai_error = None
    
    # 智能模式：检查是否配置了AI API Key
    if sort_mode == SORT_MODE_SMART:
        ai_api_key = request.headers.get('X-AI-API-Key', '')
        ai_model = request.headers.get('X-AI-Model', 'qwen-turbo')
        
        if ai_api_key:
            try:
                ai_sorted = ai_powered_sort(task_dicts, ai_api_key, ai_model)
                if ai_sorted:
                    task_dicts = ai_sorted
                    use_ai = True
            except Exception as e:
                ai_error = str(e)
                print(f"AI排序失败，回退到本地排序: {e}")
        else:
            ai_error = "未配置AI API Key"
    
    # 优化模式：使用优化后的算法
    if sort_mode == 'optimized':
        user_context = data.get('user_context', {})
        behavior_data = data.get('behavior_data', {})
        sorted_tasks = sort_tasks_optimized(task_dicts, user_context, behavior_data, weights)
        mode_label = "optimized"
    else:
        # 本地模式或AI失败时的本地排序
        sorted_tasks = sort_tasks_by_ai(task_dicts, weights)
        mode_label = "smart" if use_ai else "local"
    
    # 保存分数
    save_scores = data.get('save_scores', False)
    if save_scores:
        for sorted_task in sorted_tasks:
            task = Task.query.get(sorted_task['id'])
            if task:
                # 兼容优化后的数据结构
                if 'ai_score_details' in sorted_task:
                    dimensions = sorted_task['ai_score_details'].get('dimensions', {})
                    task.time_score = dimensions.get('time_pressure', 50) / 20  # 映射回0-5
                    task.importance_score = dimensions.get('priority', 50) / 20
                    task.ai_sort_score = sorted_task.get('ai_sort_score', 0)
                else:
                    scores = sorted_task.get('dimension_scores', {})
                    task.time_score = scores.get('time', 0)
                    task.importance_score = scores.get('importance', 0)
                    task.impact_score = scores.get('impact', 0)
                    task.money_score = scores.get('money', 0)
                    task.relation_score = scores.get('relation', 0)
                    task.skill_score = scores.get('skill', 0)
                    task.ai_sort_score = sorted_task.get('ai_sort_score', 0)
        
        db.session.commit()
    
    response = {
        "success": True,
        "tasks": sorted_tasks,
        "count": len(sorted_tasks),
        "weights_used": weights or SixDimensionSorter.DEFAULT_WEIGHTS,
        "cold_start_applied": cold_start_applied,
        "mode": mode_label
    }
    
    if ai_error and sort_mode == SORT_MODE_SMART:
        response["ai_error"] = ai_error
        response["fallback"] = True
    
    return jsonify(response)


def ai_powered_sort(tasks, api_key, model='qwen-turbo'):
    """使用AI进行智能排序"""
    if not tasks or not api_key:
        return None
    
    ai_helper = AIHelper(api_key)
    
    # 构建任务摘要
    task_summary = "\n".join([
        f"{i+1}. [{t.get('category', '其他')}] {t.get('title', '')} - 优先级:{t.get('priority', 0)}, 截止:{t.get('end_time', '无')}"
        for i, t in enumerate(tasks[:20])  # 最多20个任务
    ])
    
    prompt = f"""你是一个专业的时间管理助手。请分析以下任务列表，为每个任务给出一个综合重要性评分(1-10分)。

任务列表：
{task_summary}

请直接返回JSON数组格式，不要其他说明：
[{{"id": 任务id, "score": 分数, "reason": "简短理由"}}]

评分标准：
- 紧急且重要：8-10分
- 重要不紧急：6-7分
- 紧急不重要：5-6分
- 不紧急不重要：1-4分
"""

    try:
        result = ai_helper.call_api(prompt, model)
        
        # 解析AI返回
        if result and '[' in result:
            # 提取JSON部分
            start = result.index('[')
            end = result.rindex(']') + 1
            json_str = result[start:end]
            scores = json.loads(json_str)
            
            # 创建ID到分数的映射
            score_map = {s['id']: s for s in scores if 'id' in s}
            
            # 更新任务分数
            for task in tasks:
                task_id = task.get('id')
                if task_id in score_map:
                    ai_score = score_map[task_id]
                    # 将AI分数(1-10)映射到综合分数
                    task['ai_sort_score'] = ai_score['score'] * 0.5
                    task['ai_reason'] = ai_score.get('reason', '')
            
            # 按AI分数排序
            tasks.sort(key=lambda x: x.get('ai_sort_score', 0), reverse=True)
            return tasks
            
    except Exception as e:
        print(f"AI分析失败: {e}")
    
    return None


@ai_sort_bp.route('/api/ai/sort/explain/<int:task_id>', methods=['GET'])
def explain_task_score(task_id):
    """获取任务排序的详细解释（支持优化算法）"""
    task = Task.query.get_or_404(task_id)
    
    task_dict = task.to_dict(include_tags=False)
    
    # 使用优化算法获取更详细的解释
    optimized_sorter = OptimizedAISorter()
    score_result = optimized_sorter.calculate_optimized_score(task_dict)
    
    return jsonify({
        "success": True,
        "task_id": task_id,
        "task_title": task.title,
        "explanation": {
            "total_score": score_result['total_score'],
            "dimensions": score_result['dimensions'],
            "factors": score_result['factors'],
            "description": score_result['explanation']
        }
    })


@ai_sort_bp.route('/api/ai/sort/batch-update', methods=['POST'])
@require_user
def batch_update_scores(user):
    """批量更新所有任务的六维度分数，支持本地分析和AI智能分析两种模式"""
    data = request.get_json() or {}
    
    # 获取排序模式
    sort_mode = data.get('mode', SORT_MODE_LOCAL)
    
    tasks = Task.query.filter_by(user_id=user.id, is_completed=0).all()
    
    if not tasks:
        return jsonify({"success": False, "message": "没有未完成的任务"}), 404
    
    task_dicts = [task.to_dict(include_tags=False) for task in tasks]
    
    use_ai = False
    ai_error = None
    
    # 智能模式：尝试AI排序
    if sort_mode == SORT_MODE_SMART:
        ai_api_key = request.headers.get('X-AI-API-Key', '')
        ai_model = request.headers.get('X-AI-Model', 'qwen-turbo')
        
        if ai_api_key:
            try:
                ai_sorted = ai_powered_sort(task_dicts, ai_api_key, ai_model)
                if ai_sorted:
                    task_dicts = ai_sorted
                    use_ai = True
            except Exception as e:
                ai_error = str(e)
                print(f"AI排序失败，使用本地排序: {e}")
        else:
            ai_error = "未配置AI API Key"
    
    sorter = SixDimensionSorter(data.get('weights'))
    updated_count = 0
    
    # 创建ID到任务字典的映射
    task_map = {t.id: t for t in tasks}
    
    for task_dict in task_dicts:
        task_id = task_dict.get('id')
        task = task_map.get(task_id)
        if not task:
            continue
            
        # 如果使用了AI排序且有AI分数，直接使用
        if use_ai and 'ai_sort_score' in task_dict:
            task.ai_sort_score = task_dict['ai_sort_score']
            # 仍然计算维度分数用于展示
            scores = sorter.calculate_all_scores(task_dict)
        else:
            scores = sorter.calculate_all_scores(task_dict)
            weighted_score = sorter.calculate_weighted_score(scores)
            task.ai_sort_score = weighted_score
        
        task.time_score = scores.get('time', 2.5)
        task.importance_score = scores.get('importance', 2.5)
        task.impact_score = scores.get('impact', 2.5)
        task.money_score = scores.get('money', 2.5)
        task.relation_score = scores.get('relation', 2.5)
        task.skill_score = scores.get('skill', 2.5)
        
        updated_count += 1
    
    db.session.commit()
    
    # 清除任务列表缓存，确保前端获取到最新的分数
    from utils.cache import cache
    cache.delete(f"tasks:{user.id}")
    
    if use_ai:
        message = f"AI智能排序完成，已更新 {updated_count} 个任务"
    else:
        message = f"本地分析完成，已更新 {updated_count} 个任务"
    
    response = {
        "success": True,
        "message": message,
        "updated_count": updated_count,
        "mode": "smart" if use_ai else "local"
    }
    
    if ai_error and sort_mode == SORT_MODE_SMART:
        response["ai_error"] = ai_error
        response["fallback"] = True
    
    return jsonify(response)


@ai_sort_bp.route('/api/ai/sort/weights', methods=['GET'])
def get_default_weights():
    """获取默认权重配置（支持新旧两种模式）"""
    mode = request.args.get('mode', 'classic')
    
    if mode == 'optimized':
        return jsonify({
            "success": True,
            "mode": "optimized",
            "default_weights": OptimizedAISorter.DEFAULT_WEIGHTS,
            "description": {
                "time_pressure": "时间压力指数（预估耗时/剩余时间）",
                "priority": "任务优先级（用户设置+分类加成）",
                "energy_match": "精力匹配度（任务精力vs用户精力）",
                "user_preference": "用户行为偏好（历史数据学习）",
                "semantic_importance": "语义重要性（NLP分析+否定词处理）",
                "context_fit": "上下文适配度（时间/场景适配）"
            }
        })
    else:
        return jsonify({
            "success": True,
            "mode": "classic",
            "default_weights": SixDimensionSorter.DEFAULT_WEIGHTS,
            "description": {
                "time": "时间紧迫度（截止时间、逾期风险）",
                "importance": "重要性（优先级、分类、关键词）",
                "impact": "影响力（长期价值、团队影响、复利效应）",
                "money": "金钱价值（收益、成本节约、投资回报）",
                "relation": "关系价值（人际关系、社交网络、合作机会）",
                "skill": "技能成长（学习、能力提升、知识积累）"
            }
        })


@ai_sort_bp.route('/api/ai/sort/weights/validate', methods=['POST'])
def validate_weights():
    """
    验证权重配置
    
    请求体:
    {
        "weights": {
            "time": 0.25,
            "importance": 0.20,
            "impact": 0.20,
            "money": 0.15,
            "relation": 0.10,
            "skill": 0.10
        }
    }
    
    返回:
    {
        "success": true,
        "validation": {
            "valid": true,
            "errors": [],
            "warnings": [],
            "normalized": {...},
            "total": 1.0
        }
    }
    """
    data = request.get_json() or {}
    weights = data.get('weights', {})
    
    if not weights:
        return jsonify({
            "success": False,
            "message": "请提供 weights 参数"
        }), 400
    
    validation = SixDimensionSorter.validate_weights_dict(weights)
    
    return jsonify({
        "success": True,
        "validation": validation
    })


@ai_sort_bp.route('/api/ai/sort/presets', methods=['GET'])
def get_weight_presets():
    """获取权重预设方案（支持经典和优化两种模式）"""
    mode = request.args.get('mode', 'classic')
    
    if mode == 'optimized':
        presets = [
            {
                "id": "balanced",
                "name": "均衡模式",
                "description": "六个维度均衡考虑，适合日常使用",
                "weights": {"time_pressure": 0.25, "priority": 0.20, "energy_match": 0.15, "user_preference": 0.20, "semantic_importance": 0.15, "context_fit": 0.05}
            },
            {
                "id": "deadline_first",
                "name": "截止优先",
                "description": "优先处理时间压力大的任务",
                "weights": {"time_pressure": 0.45, "priority": 0.20, "energy_match": 0.10, "user_preference": 0.10, "semantic_importance": 0.10, "context_fit": 0.05}
            },
            {
                "id": "energy_aware",
                "name": "精力感知",
                "description": "根据精力状态匹配任务，避免过度疲劳",
                "weights": {"time_pressure": 0.20, "priority": 0.15, "energy_match": 0.30, "user_preference": 0.15, "semantic_importance": 0.10, "context_fit": 0.10}
            },
            {
                "id": "preference_learned",
                "name": "偏好学习",
                "description": "重视用户历史行为数据",
                "weights": {"time_pressure": 0.20, "priority": 0.15, "energy_match": 0.10, "user_preference": 0.35, "semantic_importance": 0.10, "context_fit": 0.10}
            }
        ]
    else:
        presets = [
            {
                "id": "balanced",
                "name": "均衡模式",
                "description": "六个维度均衡考虑",
                "weights": {"time": 0.25, "importance": 0.20, "impact": 0.20, "money": 0.15, "relation": 0.10, "skill": 0.10}
            },
            {
                "id": "deadline_first",
                "name": "截止优先",
                "description": "优先处理临近截止的任务",
                "weights": {"time": 0.50, "importance": 0.20, "impact": 0.10, "money": 0.10, "relation": 0.05, "skill": 0.05}
            },
            {
                "id": "exam_prep",
                "name": "备考模式",
                "description": "适合备考人员，重视技能成长和时间",
                "weights": {"time": 0.30, "importance": 0.20, "impact": 0.10, "money": 0.05, "relation": 0.05, "skill": 0.30}
            },
            {
                "id": "freelancer",
                "name": "自由职业",
                "description": "适合自由职业者，重视金钱和关系",
                "weights": {"time": 0.20, "importance": 0.15, "impact": 0.15, "money": 0.25, "relation": 0.15, "skill": 0.10}
            }
        ]
    
    return jsonify({
        "success": True,
        "mode": mode,
        "presets": presets
    })


@ai_sort_bp.route('/api/ai/sort/weights/cold-start', methods=['GET'])
@require_user
def get_cold_start_status(user):
    """
    获取用户冷启动状态
    
    返回用户当前的冷启动阶段、样本数和推荐权重
    """
    from utils.dynamic_weight_adjuster import DynamicWeightAdjuster
    
    adjuster = get_weight_adjuster(db.engine.raw_connection())
    stage, sample_count = adjuster.get_user_cold_start_stage(user.id)
    
    # 获取当前权重
    current_weights = get_user_weights_with_fallback(user.id, db.engine.raw_connection())
    
    # 冷启动阶段说明
    stage_descriptions = {
        0: {"name": "纯新用户", "description": "使用系统默认权重，开始执行任务后将进入探索期"},
        1: {"name": "探索期", "description": "基于相似用户推荐权重，快速找到适合你的配置"},
        2: {"name": "成长期", "description": "结合个人执行数据，权重开始个性化调整"},
        3: {"name": "成熟期", "description": "完全个性化权重，AI深度理解你的偏好"}
    }
    
    return jsonify({
        "success": True,
        "user_id": user.id,
        "cold_start": {
            "stage": stage,
            "stage_name": stage_descriptions[stage]["name"],
            "stage_description": stage_descriptions[stage]["description"],
            "sample_count": sample_count,
            "next_stage_samples": (
                adjuster.COLD_START.STAGE_1_SAMPLES if stage == 0 else
                adjuster.COLD_START.STAGE_2_SAMPLES if stage == 1 else
                adjuster.COLD_START.STAGE_3_SAMPLES if stage == 2 else None
            )
        },
        "current_weights": current_weights,
        "is_personalized": stage >= 2
    })


@ai_sort_bp.route('/api/ai/sort/weights/initialize', methods=['POST'])
@require_user
def initialize_weights(user):
    """
    手动触发权重初始化（冷启动）
    
    适用于：
    1. 新用户首次使用AI排序
    2. 用户想要重置权重到初始状态
    3. 用户想要基于相似用户重新推荐
    """
    data = request.get_json() or {}
    force = data.get('force', False)  # 是否强制重新初始化
    
    try:
        conn = db.engine.raw_connection()
        
        # 检查是否已有权重
        cursor = conn.cursor()
        cursor.execute("""
            SELECT id FROM user_weight_preferences WHERE user_id = ?
        """, (user.id,))
        
        existing = cursor.fetchone()
        
        if existing and not force:
            return jsonify({
                "success": False,
                "message": "用户已有权重配置，如需重新初始化请设置 force=true",
                "action_required": "设置 force=true 强制重新初始化"
            }), 409
        
        # 执行初始化
        weights = initialize_user_weights(user.id, conn)
        
        # 获取冷启动阶段信息
        adjuster = get_weight_adjuster(conn)
        stage, sample_count = adjuster.get_user_cold_start_stage(user.id)
        
        return jsonify({
            "success": True,
            "message": "权重初始化成功",
            "initialized_weights": weights,
            "cold_start_stage": stage,
            "sample_count": sample_count,
            "note": "基于" + ("相似用户推荐" if stage == 1 else "系统默认") + "初始化"
        })
        
    except Exception as e:
        return jsonify({
            "success": False,
            "message": f"初始化失败: {str(e)}"
        }), 500
