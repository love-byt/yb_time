"""
重复任务管理路由
"""

import json
from datetime import datetime, timedelta

from flask import Blueprint, jsonify, request

from extensions import db
from models.task import RecurringRule, Task
from utils.user_auth import require_user

recurring_bp = Blueprint('recurring', __name__)


@recurring_bp.route('/api/recurring', methods=['GET'])
@require_user
def get_recurring_rules(user):
    """获取所有重复任务规则"""
    rules = RecurringRule.query.filter_by(user_id=user.id, is_active=1).order_by(RecurringRule.created_at.desc()).all()
    return jsonify({
        "success": True,
        "rules": [rule.to_dict() for rule in rules]
    })


@recurring_bp.route('/api/recurring', methods=['POST'])
@require_user
def create_recurring_rule(user):
    """创建重复任务规则"""
    data = request.get_json()
    
    name = data.get('name', '').strip()
    if not name:
        return jsonify({"success": False, "message": "规则名称不能为空"}), 400
    
    recurring_type = data.get('recurring_type', 'daily')
    if recurring_type not in ['daily', 'weekly', 'monthly', 'custom']:
        return jsonify({"success": False, "message": "无效的重复类型"}), 400
    
    task_template = {
        'title': data.get('task_title', name),
        'description': data.get('task_description', ''),
        'category': data.get('category', '学习'),
        'priority': data.get('priority', 0),
        'duration_minutes': data.get('duration_minutes', 60)
    }
    
    rule = RecurringRule(
        user_id=user.id,
        name=name,
        recurring_type=recurring_type,
        interval=data.get('interval', 1),
        week_days=json.dumps(data.get('week_days', [])) if data.get('week_days') else '',
        month_day=data.get('month_day'),
        cron_expression=data.get('cron_expression'),
        start_date=datetime.fromisoformat(data['start_date']) if data.get('start_date') else datetime.now(),
        end_date=datetime.fromisoformat(data['end_date']) if data.get('end_date') else None,
        max_occurrences=data.get('max_occurrences'),
        task_template=json.dumps(task_template, ensure_ascii=False),
        is_active=1
    )
    
    db.session.add(rule)
    db.session.commit()
    
    return jsonify({
        "success": True,
        "rule": rule.to_dict(),
        "message": "重复规则创建成功"
    }), 201


@recurring_bp.route('/api/recurring/<int:rule_id>', methods=['PUT'])
@require_user
def update_recurring_rule(user, rule_id):
    """更新重复任务规则"""
    rule = RecurringRule.query.filter_by(id=rule_id, user_id=user.id).first_or_404()
    data = request.get_json()
    
    if 'name' in data:
        rule.name = data['name'].strip()
    if 'recurring_type' in data:
        rule.recurring_type = data['recurring_type']
    if 'interval' in data:
        rule.interval = data['interval']
    if 'week_days' in data:
        rule.week_days = json.dumps(data['week_days'])
    if 'month_day' in data:
        rule.month_day = data['month_day']
    if 'cron_expression' in data:
        rule.cron_expression = data['cron_expression']
    if 'start_date' in data:
        rule.start_date = datetime.fromisoformat(data['start_date'])
    if 'end_date' in data:
        rule.end_date = datetime.fromisoformat(data['end_date']) if data['end_date'] else None
    if 'max_occurrences' in data:
        rule.max_occurrences = data['max_occurrences']
    if 'is_active' in data:
        rule.is_active = data['is_active']
    if 'task_template' in data:
        rule.task_template = json.dumps(data['task_template'], ensure_ascii=False)
    
    db.session.commit()
    
    return jsonify({
        "success": True,
        "rule": rule.to_dict(),
        "message": "重复规则更新成功"
    })


@recurring_bp.route('/api/recurring/<int:rule_id>', methods=['DELETE'])
@require_user
def delete_recurring_rule(user, rule_id):
    """删除重复任务规则"""
    rule = RecurringRule.query.filter_by(id=rule_id, user_id=user.id).first_or_404()
    
    delete_instances = request.args.get('delete_instances', 'false').lower() == 'true'
    if delete_instances:
        Task.query.filter_by(recurring_rule_id=rule_id, user_id=user.id, is_completed=0).delete()
    
    db.session.delete(rule)
    db.session.commit()
    
    return jsonify({
        "success": True,
        "message": "重复规则删除成功"
    })


@recurring_bp.route('/api/recurring/<int:rule_id>/generate', methods=['POST'])
@require_user
def generate_instances(user, rule_id):
    """手动生成重复任务实例"""
    rule = RecurringRule.query.filter_by(id=rule_id, user_id=user.id).first_or_404()
    
    data = request.get_json() or {}
    days_ahead = data.get('days_ahead', 7)
    
    generated_count = _generate_task_instances(rule, user, days_ahead)
    
    return jsonify({
        "success": True,
        "message": f"成功生成 {generated_count} 个任务实例",
        "generated_count": generated_count
    })


@recurring_bp.route('/api/recurring/generate-all', methods=['POST'])
@require_user
def generate_all_instances(user):
    """为所有活动规则生成任务实例"""
    rules = RecurringRule.query.filter_by(user_id=user.id, is_active=1).all()
    
    data = request.get_json() or {}
    days_ahead = data.get('days_ahead', 7)
    
    total_generated = 0
    results = []
    
    for rule in rules:
        count = _generate_task_instances(rule, user, days_ahead)
        total_generated += count
        results.append({
            'rule_id': rule.id,
            'rule_name': rule.name,
            'generated_count': count
        })
    
    return jsonify({
        "success": True,
        "message": f"总共生成 {total_generated} 个任务实例",
        "total_generated": total_generated,
        "details": results
    })


def _generate_task_instances(rule, user, days_ahead=7):
    """生成任务实例的内部函数"""
    task_template = json.loads(rule.task_template) if rule.task_template else {}
    if not task_template:
        return 0
    
    generated_count = 0
    current_date = datetime.now()
    end_date = current_date + timedelta(days=days_ahead)
    
    if rule.end_date and current_date > rule.end_date:
        return 0
    
    existing_count = Task.query.filter_by(recurring_rule_id=rule.id, user_id=user.id).count()
    if rule.max_occurrences and existing_count >= rule.max_occurrences:
        return 0
    
    next_date = rule.last_generated_date or rule.start_date
    if next_date < current_date:
        next_date = current_date
    
    attempts = 0
    max_attempts = days_ahead * 2
    
    while next_date <= end_date and attempts < max_attempts:
        attempts += 1
        
        if rule.max_occurrences and existing_count >= rule.max_occurrences:
            break
        if rule.end_date and next_date > rule.end_date:
            break
        
        date_str = next_date.strftime('%Y-%m-%d')
        existing = Task.query.filter(
            Task.recurring_rule_id == rule.id,
            Task.user_id == user.id,
            Task.start_time.like(f'{date_str}%')
        ).first()
        
        if not existing:
            task = Task(
                user_id=user.id,
                title=task_template.get('title', rule.name),
                description=task_template.get('description', ''),
                category=task_template.get('category', '学习'),
                priority=task_template.get('priority', 0),
                start_time=next_date.strftime('%Y-%m-%d %H:%M:%S'),
                recurring_rule_id=rule.id,
                is_recurring_instance=1
            )
            db.session.add(task)
            generated_count += 1
            existing_count += 1
        
        next_occurrence = rule.get_next_occurrence(next_date)
        if not next_occurrence or next_occurrence <= next_date:
            break
        next_date = next_occurrence
    
    if generated_count > 0:
        rule.last_generated_date = datetime.now()
    
    db.session.commit()
    return generated_count


@recurring_bp.route('/api/recurring/presets', methods=['GET'])
def get_recurring_presets():
    """获取重复任务预设模板（无需用户验证）"""
    presets = [
        {'id': 'daily', 'name': '每天', 'description': '每天重复执行', 'icon': 'fa-calendar-day',
         'config': {'recurring_type': 'daily', 'interval': 1}},
        {'id': 'workdays', 'name': '工作日', 'description': '周一至周五重复', 'icon': 'fa-briefcase',
         'config': {'recurring_type': 'weekly', 'week_days': [0, 1, 2, 3, 4]}},
        {'id': 'weekends', 'name': '周末', 'description': '周六周日重复', 'icon': 'fa-coffee',
         'config': {'recurring_type': 'weekly', 'week_days': [5, 6]}},
        {'id': 'weekly', 'name': '每周', 'description': '每周同一天重复', 'icon': 'fa-calendar-week',
         'config': {'recurring_type': 'weekly', 'interval': 1}},
        {'id': 'monthly', 'name': '每月', 'description': '每月同一天重复', 'icon': 'fa-calendar-alt',
         'config': {'recurring_type': 'monthly', 'interval': 1}},
    ]
    
    return jsonify({
        "success": True,
        "presets": presets
    })
