"""
分类管理路由
"""

from flask import Blueprint, jsonify, request

from extensions import db
from models.task import Task, Category
from utils.user_auth import require_user

category_bp = Blueprint('category', __name__)

DEFAULT_CATEGORIES = [
    {'name': '学习', 'color': '#2196F3', 'icon': 'fa-book'},
    {'name': '工作', 'color': '#4CAF50', 'icon': 'fa-briefcase'},
    {'name': '生活', 'color': '#9C27B0', 'icon': 'fa-home'},
    {'name': '健康', 'color': '#00BCD4', 'icon': 'fa-heartbeat'},
    {'name': '财务', 'color': '#FFEB3B', 'icon': 'fa-dollar-sign'},
    {'name': '社交', 'color': '#E91E63', 'icon': 'fa-users'},
    {'name': '考试', 'color': '#F44336', 'icon': 'fa-graduation-cap'},
    {'name': '项目', 'color': '#FF9800', 'icon': 'fa-project-diagram'},
]


@category_bp.route('/api/categories', methods=['GET'])
@require_user
def get_categories(user):
    """获取所有分类（包含任务计数和隐藏状态）"""
    # 获取任务计数（仅当前用户的任务）
    task_counts = db.session.query(
        Task.category,
        db.func.count(Task.id).label('count')
    ).filter(
        Task.user_id == user.id,
        Task.is_completed == 0
    ).group_by(Task.category).all()
    
    count_dict = {cat: count for cat, count in task_counts}
    
    # 获取用户数据库中的分类配置
    db_categories = Category.query.filter_by(user_id=user.id).order_by(Category.sort_order, Category.created_at).all()
    db_cat_names = {c.name: c for c in db_categories}
    
    result = []
    
    # 添加预设分类
    for idx, preset in enumerate(DEFAULT_CATEGORIES):
        db_cat = db_cat_names.get(preset['name'])
        is_hidden = db_cat.is_hidden if db_cat else False
        cat_id = db_cat.id if db_cat else -(idx + 1)  # 预设分类使用负数ID
        
        result.append({
            'id': cat_id,
            'name': preset['name'],
            'count': count_dict.get(preset['name'], 0),
            'color': preset['color'],
            'icon': preset['icon'],
            'hidden': bool(is_hidden),
            'is_custom': False
        })
    
    # 添加用户自定义分类
    for cat in db_categories:
        if cat.is_custom and cat.name not in [p['name'] for p in DEFAULT_CATEGORIES]:
            result.append({
                'id': cat.id,
                'name': cat.name,
                'count': count_dict.get(cat.name, 0),
                'color': cat.color,
                'icon': cat.icon,
                'hidden': bool(cat.is_hidden),
                'is_custom': True
            })
    
    return jsonify({
        "success": True,
        "categories": result,
        "presets": DEFAULT_CATEGORIES
    })


@category_bp.route('/api/categories', methods=['POST'])
@require_user
def create_category(user):
    """创建自定义分类"""
    data = request.get_json()
    name = data.get('name', '').strip()
    
    if not name:
        return jsonify({"success": False, "message": "分类名称不能为空"}), 400
    
    # 检查是否已存在（当前用户）
    existing = Category.query.filter_by(name=name, user_id=user.id).first()
    if existing:
        return jsonify({"success": False, "message": "分类已存在"}), 400
    
    # 检查是否与预设分类同名
    if name in [p['name'] for p in DEFAULT_CATEGORIES]:
        return jsonify({"success": False, "message": "不能与预设分类同名"}), 400
    
    category = Category(
        user_id=user.id,
        name=name,
        color=data.get('color', '#757575'),
        icon=data.get('icon', 'fa-folder'),
        is_custom=1,
        sort_order=data.get('sort_order', 100)
    )
    
    db.session.add(category)
    db.session.commit()
    
    return jsonify({
        "success": True,
        "message": "分类创建成功",
        "category": category.to_dict()
    }), 201


@category_bp.route('/api/categories/<name>', methods=['PUT'])
@require_user
def update_category(user, name):
    """更新分类配置（名称、颜色、图标、隐藏状态）"""
    category = Category.query.filter_by(name=name, user_id=user.id).first()
    
    data = request.get_json()
    new_name = data.get('name', name).strip()
    
    if not category:
        # 如果是预设分类，创建一个配置记录
        preset = next((p for p in DEFAULT_CATEGORIES if p['name'] == name), None)
        if preset:
            category = Category(
                user_id=user.id,
                name=name,
                color=preset['color'],
                icon=preset['icon'],
                is_custom=0
            )
            db.session.add(category)
        else:
            return jsonify({"success": False, "message": "分类不存在"}), 404
    
    # 检查是否要修改名称
    if new_name != name:
        # 检查新名称是否已存在
        existing = Category.query.filter_by(name=new_name, user_id=user.id).first()
        if existing and existing.id != category.id:
            return jsonify({"success": False, "message": "分类名称已存在"}), 400
        
        # 检查是否与预设分类同名（仅自定义分类需要检查）
        if category.is_custom and new_name in [p['name'] for p in DEFAULT_CATEGORIES]:
            return jsonify({"success": False, "message": "不能与预设分类同名"}), 400
        
        # 更新任务表中的分类名称
        Task.query.filter_by(category=name, user_id=user.id).update({'category': new_name})
        
        # 更新分类名称
        category.name = new_name
    
    # 更新其他属性
    if 'color' in data:
        category.color = data['color']
    if 'icon' in data:
        category.icon = data['icon']
    if 'hidden' in data:
        category.is_hidden = 1 if data['hidden'] else 0
    if 'is_hidden' in data:
        category.is_hidden = 1 if data['is_hidden'] else 0
    
    db.session.commit()
    
    return jsonify({
        "success": True,
        "message": "分类更新成功",
        "category": category.to_dict()
    })


@category_bp.route('/api/categories/<name>', methods=['DELETE'])
@require_user
def delete_category(user, name):
    """删除自定义分类"""
    category = Category.query.filter_by(name=name, user_id=user.id, is_custom=1).first()
    
    if not category:
        return jsonify({"success": False, "message": "分类不存在或不能删除预设分类"}), 404
    
    # 将该分类下的任务（仅当前用户的）移到"生活"分类
    Task.query.filter_by(category=name, user_id=user.id).update({'category': '生活'})
    
    db.session.delete(category)
    db.session.commit()
    
    return jsonify({
        "success": True,
        "message": "分类已删除，相关任务已移至'生活'分类"
    })


@category_bp.route('/api/categories/<name>/toggle-visibility', methods=['POST'])
@require_user
def toggle_category_visibility(user, name):
    """切换分类的显示/隐藏状态"""
    category = Category.query.filter_by(name=name, user_id=user.id).first()
    
    if not category:
        # 如果是预设分类，创建一个配置记录
        preset = next((p for p in DEFAULT_CATEGORIES if p['name'] == name), None)
        if preset:
            category = Category(
                user_id=user.id,
                name=name,
                color=preset['color'],
                icon=preset['icon'],
                is_custom=0,
                is_hidden=1  # 默认隐藏（因为是切换）
            )
            db.session.add(category)
        else:
            return jsonify({"success": False, "message": "分类不存在"}), 404
    else:
        category.is_hidden = 0 if category.is_hidden else 1
    
    db.session.commit()
    
    return jsonify({
        "success": True,
        "message": f"分类已{'隐藏' if category.is_hidden else '显示'}",
        "is_hidden": bool(category.is_hidden)
    })


@category_bp.route('/api/categories/presets', methods=['GET'])
def get_category_presets():
    """获取预设分类（无需用户验证）"""
    return jsonify({
        "success": True,
        "presets": DEFAULT_CATEGORIES
    })


@category_bp.route('/api/categories/reorder', methods=['POST'])
@require_user
def reorder_categories(user):
    """重新排序分类"""
    data = request.get_json()
    order = data.get('order', [])
    
    if not order:
        return jsonify({"success": False, "message": "排序数据为空"}), 400
    
    try:
        for idx, name in enumerate(order):
            category = Category.query.filter_by(name=name, user_id=user.id).first()
            if category:
                category.sort_order = idx
            else:
                # 为预设分类创建记录
                preset = next((p for p in DEFAULT_CATEGORIES if p['name'] == name), None)
                if preset:
                    category = Category(
                        user_id=user.id,
                        name=name,
                        color=preset['color'],
                        icon=preset['icon'],
                        is_custom=0,
                        sort_order=idx
                    )
                    db.session.add(category)
        
        db.session.commit()
        return jsonify({"success": True, "message": "排序已保存"})
    except Exception as e:
        db.session.rollback()
        return jsonify({"success": False, "message": str(e)}), 500
