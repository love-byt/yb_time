"""
提醒管理路由
"""

import json
from datetime import datetime, timedelta

from flask import Blueprint, jsonify, request

from extensions import db
from models.task import Reminder, Task
from utils.user_auth import require_user

reminder_bp = Blueprint('reminder', __name__)


@reminder_bp.route('/api/reminders', methods=['GET'])
@require_user
def get_reminders(user):
    """获取所有提醒"""
    # 通过任务关联获取当前用户的提醒
    reminders = Reminder.query.join(Task).filter(
        Task.user_id == user.id
    ).order_by(Reminder.remind_time.asc()).all()
    return jsonify({
        "success": True,
        "reminders": [r.to_dict() for r in reminders]
    })


@reminder_bp.route('/api/reminders', methods=['POST'])
@require_user
def create_reminder(user):
    """创建提醒"""
    data = request.get_json()
    
    task_id = data.get('task_id')
    remind_time_str = data.get('remind_time')
    
    if not remind_time_str:
        return jsonify({"success": False, "message": "提醒时间不能为空"}), 400
    
    # 验证任务是否属于当前用户
    task = Task.query.filter_by(id=task_id, user_id=user.id).first()
    if not task:
        return jsonify({"success": False, "message": "任务不存在或无权限"}), 404
    
    try:
        remind_time = datetime.fromisoformat(remind_time_str.replace('Z', '+00:00'))
    except:
        return jsonify({"success": False, "message": "时间格式错误"}), 400
    
    reminder = Reminder(
        task_id=task_id,
        remind_time=remind_time,
        remind_type=data.get('remind_type', 'before'),
        advance_minutes=data.get('advance_minutes', 15)
    )
    
    db.session.add(reminder)
    db.session.commit()
    
    return jsonify({
        "success": True,
        "reminder": reminder.to_dict(),
        "message": "提醒创建成功"
    }), 201


@reminder_bp.route('/api/reminders/<int:reminder_id>', methods=['DELETE'])
@require_user
def delete_reminder(user, reminder_id):
    """删除提醒"""
    # 验证提醒关联的任务是否属于当前用户
    reminder = Reminder.query.join(Task).filter(
        Reminder.id == reminder_id,
        Task.user_id == user.id
    ).first_or_404()
    
    db.session.delete(reminder)
    db.session.commit()
    
    return jsonify({
        "success": True,
        "message": "提醒删除成功"
    })


@reminder_bp.route('/api/reminders/pending', methods=['GET'])
@require_user
def get_pending_reminders(user):
    """获取待发送的提醒"""
    now = datetime.now()
    # 获取当前用户的待发送提醒
    reminders = Reminder.query.join(Task).filter(
        Task.user_id == user.id,
        Reminder.is_sent == 0,
        Reminder.remind_time <= now
    ).all()
    
    return jsonify({
        "success": True,
        "reminders": [r.to_dict() for r in reminders]
    })


@reminder_bp.route('/api/reminders/<int:reminder_id>/sent', methods=['PUT'])
@require_user
def mark_reminder_sent(user, reminder_id):
    """标记提醒已发送"""
    # 验证提醒关联的任务是否属于当前用户
    reminder = Reminder.query.join(Task).filter(
        Reminder.id == reminder_id,
        Task.user_id == user.id
    ).first_or_404()
    
    reminder.is_sent = 1
    db.session.commit()
    
    return jsonify({
        "success": True,
        "message": "提醒已标记为已发送"
    })


# ==================== 推送通知接口 ====================

@reminder_bp.route('/api/push/subscribe', methods=['POST'])
@require_user
def subscribe_push(user):
    """订阅推送通知"""
    data = request.get_json()
    subscription = data.get('subscription')
    
    if not subscription:
        return jsonify({'success': False, 'message': '订阅信息不能为空'}), 400
    
    # 存储订阅信息
    user.push_subscription = json.dumps(subscription) if isinstance(subscription, dict) else subscription
    db.session.commit()
    
    return jsonify({
        'success': True,
        'message': '推送订阅成功'
    })


@reminder_bp.route('/api/push/unsubscribe', methods=['POST'])
@require_user
def unsubscribe_push(user):
    """取消推送订阅"""
    user.push_subscription = None
    db.session.commit()
    
    return jsonify({
        'success': True,
        'message': '已取消推送订阅'
    })


@reminder_bp.route('/api/push/status', methods=['GET'])
@require_user
def get_push_status(user):
    """获取推送订阅状态"""
    return jsonify({
        'success': True,
        'push_enabled': bool(user.push_subscription)
    })


@reminder_bp.route('/api/push/vapid-key', methods=['GET'])
def get_vapid_public_key():
    """获取VAPID公钥"""
    from flask import current_app
    public_key = current_app.config.get('VAPID_PUBLIC_KEY', '')
    
    return jsonify({
        'success': True,
        'public_key': public_key
    })


@reminder_bp.route('/api/reminders/smart', methods=['GET'])
@require_user
def get_smart_reminders(user):
    """获取智能提醒列表"""
    now = datetime.now()
    
    # 获取用户未来24小时内到期的高优先级任务
    tasks = Task.query.filter(
        Task.user_id == user.id,
        Task.is_completed == 0,
        Task.end_time.isnot(None)
    ).order_by(Task.priority.desc(), Task.end_time.asc()).limit(10).all()
    
    smart_reminders = []
    for task in tasks:
        try:
            end_time_str = task.end_time
            if 'T' in end_time_str:
                end_time = datetime.fromisoformat(end_time_str.replace('Z', '+00:00').replace('+00:00', ''))
            else:
                end_time = datetime.strptime(end_time_str, '%Y-%m-%d %H:%M:%S')
            
            time_left = end_time - now
            
            if time_left.total_seconds() <= 0:
                status = 'overdue'
                urgency = 'critical'
            elif time_left <= timedelta(hours=2):
                status = 'urgent'
                urgency = 'high'
            elif time_left <= timedelta(hours=24):
                status = 'soon'
                urgency = 'medium'
            else:
                status = 'upcoming'
                urgency = 'low'
            
            smart_reminders.append({
                'task_id': task.id,
                'task_title': task.title,
                'category': task.category,
                'priority': task.priority,
                'end_time': task.end_time,
                'time_left_minutes': int(time_left.total_seconds() / 60),
                'status': status,
                'urgency': urgency
            })
        except Exception as e:
            continue
    
    return jsonify({
        'success': True,
        'reminders': smart_reminders
    })


# ==================== 配置接口 ====================

@reminder_bp.route('/api/config/vapid-public-key', methods=['GET'])
def get_config_vapid_public_key():
    """
    获取 VAPID 公钥配置
    
    此接口用于前端获取 VAPID 公钥，用于订阅 Web Push 推送通知。
    公钥是公开的，可以安全地暴露给客户端。
    
    Returns:
        {
            "success": true,
            "public_key": "BASE64_URL_ENCODED_PUBLIC_KEY",
            "subject": "mailto:admin@example.com"
        }
    """
    try:
        from utils.push_notification import get_vapid_public_key, get_vapid_subject, get_or_create_vapid_keys
        
        public_key = get_vapid_public_key()
        
        if not public_key:
            # 如果没有配置，尝试生成
            public_key, _ = get_or_create_vapid_keys()
        
        if not public_key:
            return jsonify({
                'success': False,
                'error': 'VAPID 密钥生成失败，请检查服务器配置'
            }), 500
        
        return jsonify({
            'success': True,
            'public_key': public_key,
            'subject': get_vapid_subject()
        })
    except Exception as e:
        import traceback
        print(f"[ERROR] 获取 VAPID 公钥失败: {e}")
        print(traceback.format_exc())
        return jsonify({
            'success': False,
            'error': f'服务器错误: {str(e)}'
        }), 500


@reminder_bp.route('/api/push/test', methods=['POST'])
@require_user
def test_push_notification(user):
    """
    发送测试推送通知
    
    用于测试推送通知功能是否正常工作
    """
    if not user.push_subscription:
        return jsonify({
            'success': False,
            'message': '请先订阅推送通知'
        }), 400
    
    from utils.push_notification import send_push_to_user
    
    success, message = send_push_to_user(
        user,
        title='[测试] 测试通知',
        body='这是一条测试推送通知，如果您看到此消息，说明推送功能正常工作！',
        tag='test-notification'
    )
    
    return jsonify({
        'success': success,
        'message': message
    })


@reminder_bp.route('/api/push/send', methods=['POST'])
@require_user
def send_custom_push(user):
    """
    发送自定义推送通知
    
    允许用户发送自定义内容的推送通知
    """
    data = request.get_json()
    
    if not user.push_subscription:
        return jsonify({
            'success': False,
            'message': '请先订阅推送通知'
        }), 400
    
    title = data.get('title', '通知')
    body = data.get('body', '')
    tag = data.get('tag')
    
    if not body:
        return jsonify({
            'success': False,
            'message': '通知内容不能为空'
        }), 400
    
    from utils.push_notification import send_push_to_user
    
    success, message = send_push_to_user(
        user,
        title=title,
        body=body,
        tag=tag
    )
    
    return jsonify({
        'success': success,
        'message': message
    })


@reminder_bp.route('/api/reminders/<int:reminder_id>', methods=['PUT'])
@require_user
def update_reminder(user, reminder_id):
    """更新提醒"""
    # 验证提醒关联的任务是否属于当前用户
    reminder = Reminder.query.join(Task).filter(
        Reminder.id == reminder_id,
        Task.user_id == user.id
    ).first_or_404()
    
    data = request.get_json()
    
    if 'remind_time' in data:
        try:
            remind_time_str = data['remind_time']
            reminder.remind_time = datetime.fromisoformat(remind_time_str.replace('Z', '+00:00'))
        except:
            return jsonify({"success": False, "message": "时间格式错误"}), 400
    
    if 'remind_type' in data:
        reminder.remind_type = data['remind_type']
    if 'advance_minutes' in data:
        reminder.advance_minutes = data['advance_minutes']
    if 'is_sent' in data:
        reminder.is_sent = data['is_sent']
    
    db.session.commit()
    
    return jsonify({
        "success": True,
        "reminder": reminder.to_dict(),
        "message": "提醒更新成功"
    })


@reminder_bp.route('/api/reminders/<int:reminder_id>/delay', methods=['POST'])
@require_user
def delay_reminder(user, reminder_id):
    """延迟提醒（延后15分钟）"""
    # 验证提醒关联的任务是否属于当前用户
    reminder = Reminder.query.join(Task).filter(
        Reminder.id == reminder_id,
        Task.user_id == user.id
    ).first_or_404()
    
    data = request.get_json() or {}
    delay_minutes = data.get('delay_minutes', 15)
    
    # 延后提醒时间
    reminder.remind_time = datetime.now() + timedelta(minutes=delay_minutes)
    reminder.is_sent = 0  # 重置发送状态
    
    db.session.commit()
    
    return jsonify({
        "success": True,
        "reminder": reminder.to_dict(),
        "message": f"提醒已延后 {delay_minutes} 分钟"
    })
