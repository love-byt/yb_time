"""
AI智能截止时间生成路由
"""

from datetime import datetime, timedelta
from flask import Blueprint, jsonify, request

from extensions import db
from models.task import Task
from utils.ai_helper import AIHelper
from utils.user_auth import require_user
from config import Config

ai_deadline_bp = Blueprint('ai_deadline', __name__)


# 任务关键词截止时间提示映射（小时）
DEADLINE_SUGGESTIONS = {
    '紧急': 4,
    '立即': 2,
    '马上': 1,
    '尽快': 6,
    '今天': 8,
    '今晚': 12,
    '明天': 24,
    '后天': 48,
    '下周': 168,
    '周末': 72,
    '考试': 168,
    '作业': 48,
    '复习': 72,
    '预习': 24,
    '背诵': 12,
    '会议': 24,
    '汇报': 48,
    '报告': 72,
    '项目': 168,
    '购物': 48,
    '缴费': 72,
    '预约': 48,
}


def get_ai_helper(user=None):
    """获取AI助手实例"""
    from models.task import User
    
    api_key = request.headers.get('X-AI-API-Key', '')
    if api_key:
        return AIHelper(api_key), 'user_header'
    
    if user:
        user_obj = User.query.get(user.id) if hasattr(user, 'id') else User.query.get(user)
        if user_obj and user_obj.ai_api_key:
            return AIHelper(user_obj.ai_api_key), 'user_db'
    
    return AIHelper(Config.TONGYI_API_KEY), 'system'


def get_historical_duration(title, category, user):
    """从历史完成记录获取相似任务的平均时长"""
    try:
        similar_tasks = Task.query.filter(
            Task.user_id == user.id,
            Task.category == category,
            Task.is_completed == True,
            Task.actual_duration != None,
            Task.actual_duration > 0
        ).limit(10).all()
        
        if not similar_tasks:
            return None
        
        title_keywords = set(title.lower())
        matching_durations = []
        
        for task in similar_tasks:
            task_keywords = set(task.title.lower())
            overlap = len(title_keywords & task_keywords)
            if overlap >= min(len(title_keywords), 2):
                matching_durations.append(task.actual_duration)
        
        if matching_durations:
            return int(sum(matching_durations) / len(matching_durations))
        
        durations = [t.actual_duration for t in similar_tasks if t.actual_duration]
        if durations:
            return int(sum(durations) / len(durations))
        
        return None
    except:
        return None


def estimate_by_keywords(title, category):
    """基于关键词预估时长"""
    from routes.ai_duration_routes import KEYWORD_DURATIONS, DEFAULT_DURATIONS
    
    title_lower = title.lower()
    
    for keyword, duration in KEYWORD_DURATIONS.items():
        if keyword in title_lower:
            return duration
    
    return DEFAULT_DURATIONS.get(category, 60)


def analyze_deadline_keywords(text):
    """分析任务描述中的时间关键词"""
    text_lower = text.lower()
    
    for keyword, hours in DEADLINE_SUGGESTIONS.items():
        if keyword in text_lower:
            return hours
    
    return None


def is_urgent_task(title):
    """判断是否是紧急任务"""
    urgent_keywords = ['紧急', '立即', '马上', '尽快', '今天', '今晚', 'urgent', 'asap']
    title_lower = title.lower()
    return any(kw in title_lower for kw in urgent_keywords)


def optimize_for_work_hours(end_dt, duration_minutes):
    """优化截止时间到合理的工作时间"""
    if duration_minutes > 120:
        if end_dt.hour >= 22:
            end_dt = end_dt.replace(hour=10, minute=0) + timedelta(days=1)
        elif end_dt.hour < 6:
            end_dt = end_dt.replace(hour=10, minute=0)
    
    return end_dt


def ai_analyze_deadline(title, description, category, estimated_duration, api_key):
    """使用AI分析任务截止时间"""
    try:
        helper = AIHelper(api_key)
        
        prompt = f"""你是一个专业的时间管理助手。请分析以下任务，给出建议的截止时间。

任务标题: {title}
任务描述: {description or '无'}
任务分类: {category}
预估完成时长: {estimated_duration}分钟

请分析:
1. 这个任务的紧急程度（紧急/一般/不紧急）
2. 建议多少小时内完成（考虑任务性质和合理的工作节奏）
3. 简短的理由

请以JSON格式返回:
{{"urgency": "紧急程度", "suggested_hours": 小时数, "reason": "理由"}}
"""
        
        result = helper.call_api(prompt)
        if result and '{' in result:
            import json
            start = result.index('{')
            end = result.rindex('}') + 1
            return json.loads(result[start:end])
    except Exception as e:
        print(f"AI分析失败: {e}")
    
    return None


def generate_smart_deadline_internal(user, title, description, category, start_time=None):
    """内部函数：生成智能截止时间"""
    now = datetime.now()
    
    historical_duration = get_historical_duration(title, category, user)
    keyword_hours = analyze_deadline_keywords(title + ' ' + (description or ''))
    
    if historical_duration:
        estimated_duration = historical_duration
    elif keyword_hours:
        estimated_duration = keyword_hours * 60
    else:
        estimated_duration = estimate_by_keywords(title, category)
    
    if start_time:
        try:
            start_dt = datetime.fromisoformat(start_time.replace('Z', '+00:00').replace('+08:00', ''))
        except:
            start_dt = now
    else:
        start_dt = now
    
    end_dt = start_dt + timedelta(minutes=estimated_duration)
    
    if not is_urgent_task(title):
        end_dt = optimize_for_work_hours(end_dt, estimated_duration)
    
    return end_dt.strftime('%Y-%m-%dT%H:%M')


@ai_deadline_bp.route('/api/ai/deadline', methods=['POST'])
@require_user
def generate_smart_deadline(user):
    """智能生成截止时间"""
    try:
        data = request.get_json()
        task_id = data.get('task_id')
        title = data.get('title', '')
        description = data.get('description', '')
        category = data.get('category', '学习')
        start_time = data.get('start_time')
        
        now = datetime.now()
        
        historical_duration = get_historical_duration(title, category, user)
        keyword_hours = analyze_deadline_keywords(title + ' ' + (description or ''))
        
        if historical_duration:
            estimated_duration = historical_duration
            method = "historical"
        elif keyword_hours:
            estimated_duration = keyword_hours * 60
            method = "keyword"
        else:
            estimated_duration = estimate_by_keywords(title, category)
            method = "category"
        
        if start_time:
            start_dt = datetime.fromisoformat(start_time.replace('Z', '+00:00').replace('+08:00', ''))
        else:
            start_dt = now
        
        base_end_dt = start_dt + timedelta(minutes=estimated_duration)
        
        ai_suggestion = None
        ai_api_key = request.headers.get('X-AI-API-Key', '')
        if ai_api_key:
            try:
                ai_result = ai_analyze_deadline(title, description, category, estimated_duration, ai_api_key)
                if ai_result and ai_result.get('suggested_hours'):
                    ai_hours = ai_result['suggested_hours']
                    final_hours = (estimated_duration / 60 * 0.4 + ai_hours * 0.6)
                    base_end_dt = start_dt + timedelta(hours=final_hours)
                    method = "ai_combined"
            except Exception as e:
                print(f"AI分析截止时间失败: {e}")
        
        if not is_urgent_task(title):
            base_end_dt = optimize_for_work_hours(base_end_dt, estimated_duration)
        
        suggested_end_time = base_end_dt.strftime('%Y-%m-%dT%H:%M')
        
        response = {
            "success": True,
            "suggested_end_time": suggested_end_time,
            "suggested_duration_minutes": estimated_duration,
            "method": method,
            "factors": {
                "historical_data": historical_duration is not None,
                "keyword_matched": keyword_hours is not None,
                "category": category
            }
        }
        
        if ai_suggestion:
            response["ai_analysis"] = ai_suggestion
        
        if task_id:
            task = Task.query.filter_by(id=task_id, user_id=user.id).first()
            if task and not task.end_time:
                task.end_time = suggested_end_time
                db.session.commit()
                response["task_updated"] = True
        
        return jsonify(response)
        
    except Exception as e:
        return jsonify({"success": False, "message": f"生成截止时间失败: {str(e)}"}), 500


@ai_deadline_bp.route('/api/ai/deadline/batch', methods=['POST'])
@require_user
def batch_generate_deadlines(user):
    """批量为没有截止时间的任务生成智能截止时间"""
    try:
        tasks = Task.query.filter_by(
            user_id=user.id,
            is_completed=False
        ).filter(
            (Task.end_time == None) | (Task.end_time == '')
        ).all()
        
        if not tasks:
            return jsonify({
                "success": True,
                "message": "所有任务都已有截止时间",
                "updated_count": 0
            })
        
        updated_count = 0
        results = []
        
        for task in tasks:
            historical_duration = get_historical_duration(task.title, task.category, user)
            keyword_hours = analyze_deadline_keywords(task.title + ' ' + (task.description or ''))
            
            if historical_duration:
                estimated_duration = historical_duration
            elif keyword_hours:
                estimated_duration = keyword_hours * 60
            else:
                estimated_duration = estimate_by_keywords(task.title, task.category)
            
            if task.start_time:
                start_dt = datetime.fromisoformat(task.start_time.replace('Z', '+00:00').replace('+08:00', ''))
            else:
                start_dt = datetime.now()
            
            end_dt = start_dt + timedelta(minutes=estimated_duration)
            
            if not is_urgent_task(task.title):
                end_dt = optimize_for_work_hours(end_dt, estimated_duration)
            
            task.end_time = end_dt.strftime('%Y-%m-%dT%H:%M')
            updated_count += 1
            
            results.append({
                'task_id': task.id,
                'title': task.title,
                'suggested_end_time': task.end_time
            })
        
        db.session.commit()
        
        return jsonify({
            "success": True,
            "message": f"成功为 {updated_count} 个任务生成截止时间",
            "updated_count": updated_count,
            "results": results
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({"success": False, "message": f"批量生成失败: {str(e)}"}), 500
