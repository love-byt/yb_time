"""
路由包初始化
"""

from routes.task_routes import task_bp
from routes.tag_routes import tag_bp
from routes.category_routes import category_bp
from routes.recurring_routes import recurring_bp
from routes.ai_routes import ai_bp
from routes.ai_duration_routes import ai_duration_bp
from routes.ai_deadline_routes import ai_deadline_bp
from routes.ai_study_routes import ai_study_bp
from routes.ai_quota_routes import ai_quota_bp
from routes.ai_sort_routes import ai_sort_bp
from routes.dynamic_sort_routes import dynamic_sort_bp
from routes.task_tracking_routes import task_tracking_bp
from routes.task_batch_routes import batch_bp as task_batch_bp
from routes.analysis_routes import analysis_bp
from routes.stats_routes import stats_bp
from routes.reminder_routes import reminder_bp
from routes.user_behavior_routes import user_behavior_bp

# 校园场景路由
try:
    from routes.campus_routes import campus_bp
    CAMPUS_ROUTES_AVAILABLE = True
except ImportError:
    CAMPUS_ROUTES_AVAILABLE = False

# 深度上下文逻辑感知系统路由
try:
    from routes.context_routes import context_bp
    CONTEXT_ROUTES_AVAILABLE = True
except ImportError as e:
    CONTEXT_ROUTES_AVAILABLE = False
    print(f"[深度上下文] 模块加载失败: {e}")

__all__ = [
    'task_bp', 'tag_bp', 'category_bp', 'recurring_bp',
    'ai_bp', 'ai_duration_bp', 'ai_deadline_bp', 'ai_study_bp', 'ai_quota_bp',
    'ai_sort_bp', 'dynamic_sort_bp', 'task_tracking_bp', 'task_batch_bp',
    'analysis_bp', 'stats_bp', 'reminder_bp', 'user_behavior_bp'
]

if CAMPUS_ROUTES_AVAILABLE:
    __all__.append('campus_bp')

if CONTEXT_ROUTES_AVAILABLE:
    __all__.append('context_bp')
