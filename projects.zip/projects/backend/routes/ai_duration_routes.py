"""
AI任务时长预估路由
"""

from flask import Blueprint, jsonify, request

from extensions import db
from models.task import Task
from utils.ai_helper import AIHelper
from utils.user_auth import require_user
from config import Config

ai_duration_bp = Blueprint('ai_duration', __name__)


# 任务类型默认时长（分钟）
DEFAULT_DURATIONS = {
    '学习': 60,
    '工作': 90,
    '生活': 30,
    '健康': 45,
    '财务': 30,
    '社交': 60,
    '考试': 120,
    '项目': 180
}

# 任务关键词时长映射
KEYWORD_DURATIONS = {
    # 学习相关
    '背单词': 30,
    '复习': 45,
    '预习': 30,
    '作业': 60,
    '考试': 120,
    '刷题': 60,
    '看书': 60,
    '阅读': 45,
    '笔记': 30,
    '论文': 240,
    '研究': 180,
    
    # 工作相关
    '开会': 60,
    '会议': 60,
    '报告': 90,
    '邮件': 15,
    '电话': 20,
    '汇报': 45,
    '写代码': 120,
    '编程': 120,
    '调试': 60,
    '设计': 180,
    '分析': 120,
    '面试': 60,
    
    # 生活相关
    '买菜': 30,
    '做饭': 60,
    '洗衣': 30,
    '打扫': 60,
    '购物': 60,
    '跑步': 30,
    '健身': 60,
    '运动': 45,
    '散步': 30,
    '校跑': 30,
    
    # 社交相关
    '约会': 120,
    '聚餐': 90,
    '聚会': 120,
    '聊天': 30,
}

# 难度系数调整
DIFFICULTY_MULTIPLIERS = {
    'easy': 0.7,
    'medium': 1.0,
    'hard': 1.5
}


def get_ai_helper(user=None):
    """获取AI助手实例"""
    from models.task import User
    
    api_key = request.headers.get('X-AI-API-Key', '')
    if api_key:
        return AIHelper(api_key), 'user_header'
    
    if user:
        user_obj = User.query.get(user.id) if hasattr(user, 'id') else User.query.get(user)
        if user_obj and user_obj.ai_api_key:
            return AIHelper(user_obj.ai_api_key), 'user_db'
    
    return AIHelper(Config.TONGYI_API_KEY), 'system'


def get_historical_duration(title, category, user):
    """从历史完成记录获取相似任务的平均时长"""
    try:
        similar_tasks = Task.query.filter(
            Task.user_id == user.id,
            Task.category == category,
            Task.is_completed == True,
            Task.actual_duration != None,
            Task.actual_duration > 0
        ).limit(10).all()
        
        if not similar_tasks:
            return None
        
        title_keywords = set(title.lower())
        matching_durations = []
        
        for task in similar_tasks:
            task_keywords = set(task.title.lower())
            overlap = len(title_keywords & task_keywords)
            if overlap >= min(len(title_keywords), 2):
                matching_durations.append(task.actual_duration)
        
        if matching_durations:
            return int(sum(matching_durations) / len(matching_durations))
        
        durations = [t.actual_duration for t in similar_tasks if t.actual_duration]
        if durations:
            return int(sum(durations) / len(durations))
        
        return None
    except:
        return None


def estimate_by_keywords(title, category):
    """基于关键词预估时长"""
    title_lower = title.lower()
    
    for keyword, duration in KEYWORD_DURATIONS.items():
        if keyword in title_lower:
            return duration
    
    return DEFAULT_DURATIONS.get(category, 60)


def ai_estimate_duration(title, category):
    """AI预估任务时长"""
    try:
        ai_helper = get_ai_helper()
        if not ai_helper[0].api_key:
            return None
        
        prompt = f"""请根据以下任务信息，预估完成该任务需要多少分钟。

任务标题: {title}
任务分类: {category}

请只返回一个数字（分钟数），不需要其他说明。例如: 45"""

        result = ai_helper[0].call_api(prompt)
        if result:
            import re
            numbers = re.findall(r'\d+', result)
            if numbers:
                return int(numbers[0])
    except:
        pass
    return None


@ai_duration_bp.route('/api/ai/estimate-duration', methods=['POST'])
@require_user
def estimate_duration(user):
    """AI预估任务时长 - 支持难度系数"""
    try:
        data = request.get_json()
        task_id = data.get('task_id')
        title = data.get('title', '')
        category = data.get('category', '学习')
        difficulty = data.get('difficulty', 'medium')  # 新增难度参数
        
        # 1. 获取历史数据
        historical_duration = get_historical_duration(title, category, user)
        
        # 2. 基于关键词预估
        if historical_duration:
            estimated = historical_duration
            method = "historical"
        else:
            estimated = estimate_by_keywords(title, category)
            method = "keyword"
        
        # 3. AI辅助预估
        ai_duration = ai_estimate_duration(title, category)
        if ai_duration:
            estimated = int((estimated * 0.4 + ai_duration * 0.6))
            method = "hybrid"
        
        # 4. 应用难度系数
        difficulty_multiplier = DIFFICULTY_MULTIPLIERS.get(difficulty, 1.0)
        estimated = int(estimated * difficulty_multiplier)
        
        return jsonify({
            "success": True,
            "estimated_duration": estimated,
            "method": method,
            "difficulty": difficulty,
            "difficulty_multiplier": difficulty_multiplier,
            "message": f"预估需要 {estimated} 分钟"
        })
        
    except Exception as e:
        return jsonify({"success": False, "message": f"预估失败: {str(e)}"}), 500


@ai_duration_bp.route('/api/ai/assess-difficulty', methods=['POST'])
@require_user
def assess_difficulty(user):
    """评估任务难度"""
    try:
        data = request.get_json()
        title = data.get('title', '')
        category = data.get('category', '未分类')
        
        title_lower = title.lower()
        score = 0
        factors = {
            'keywords': [],
            'category_weight': 0,
            'complexity': 0
        }
        
        # 关键词难度评分
        difficulty_keywords = {
            'hard': ['困难', '复杂', '重要', '紧急', '关键', '核心', '深度', '研究', '分析', '设计', '开发', '论文', '考试', '面试', '汇报'],
            'medium': ['准备', '整理', '复习', '练习', '修改', '优化', '测试', '文档', '报告', '作业'],
            'easy': ['简单', '快速', '查看', '阅读', '浏览', '回复', '打电话', '买', '取', '送']
        }
        
        for kw in difficulty_keywords['hard']:
            if kw in title_lower:
                score += 3
                factors['keywords'].append({'word': kw, 'weight': 3})
        
        for kw in difficulty_keywords['medium']:
            if kw in title_lower:
                score += 2
                factors['keywords'].append({'word': kw, 'weight': 2})
        
        for kw in difficulty_keywords['easy']:
            if kw in title_lower:
                score -= 1
                factors['keywords'].append({'word': kw, 'weight': -1})
        
        # 分类权重
        category_weights = {
            '考试': 3, '项目': 2.5, '学习': 2, '工作': 2,
            '健康': 1, '生活': 0.5, '社交': 0.5
        }
        factors['category_weight'] = category_weights.get(category, 1)
        score += factors['category_weight']
        
        # 复杂度评估
        task_count = len([c for c in title if c in '、,，和与及']) + 1
        factors['complexity'] = min(task_count * 0.5, 2)
        score += factors['complexity']
        
        # 确定难度等级
        if score >= 5:
            level = 'hard'
        elif score >= 2.5:
            level = 'medium'
        else:
            level = 'easy'
        
        return jsonify({
            "success": True,
            "level": level,
            "score": round(score, 1),
            "factors": factors
        })
        
    except Exception as e:
        return jsonify({"success": False, "message": f"评估失败: {str(e)}"}), 500
