"""
校园场景路由 - 已禁用
课程表、考试安排等API接口已暂时禁用
"""

from flask import Blueprint, request, jsonify, g
from datetime import datetime, date, timedelta
from extensions import db
from models.campus import Course, Exam, Semester
from utils.user_auth import require_user

campus_bp = Blueprint('campus', __name__)

# 功能已禁用标志
FEATURE_DISABLED = True


# ==================== 课程表 API ====================

@campus_bp.route('/api/campus/courses', methods=['GET'])
@require_user
def get_courses(user):
    """获取课程列表 - 已禁用"""
    return jsonify({
        'success': False,
        'message': '课程表功能已暂时禁用',
        'courses': []
    }), 403


@campus_bp.route('/api/campus/courses', methods=['POST'])
@require_user
def create_course(user):
    """创建课程 - 已禁用"""
    return jsonify({
        'success': False,
        'message': '课程表功能已暂时禁用'
    }), 403


@campus_bp.route('/api/campus/courses/<int:course_id>', methods=['PUT'])
@require_user
def update_course(user, course_id):
    """更新课程 - 已禁用"""
    return jsonify({
        'success': False,
        'message': '课程表功能已暂时禁用'
    }), 403


@campus_bp.route('/api/campus/courses/<int:course_id>', methods=['DELETE'])
@require_user
def delete_course(user, course_id):
    """删除课程 - 已禁用"""
    return jsonify({
        'success': False,
        'message': '课程表功能已暂时禁用'
    }), 403


@campus_bp.route('/api/campus/today', methods=['GET'])
@require_user
def get_today_schedule(user):
    """获取今日课程安排 - 已禁用"""
    return jsonify({
        'success': True,
        'date': date.today().isoformat(),
        'week': 1,
        'day_of_week': date.today().isoweekday(),
        'courses': []
    })


# ==================== 考试 API ====================

@campus_bp.route('/api/campus/exams', methods=['GET'])
@require_user
def get_exams(user):
    """获取考试列表 - 已禁用"""
    return jsonify({
        'success': True,
        'is_exam_week': False,
        'exams': [],
        'total_count': 0
    })


@campus_bp.route('/api/campus/exams', methods=['POST'])
@require_user
def create_exam(user):
    """创建考试 - 已禁用"""
    return jsonify({
        'success': False,
        'message': '考试周功能已暂时禁用'
    }), 403


@campus_bp.route('/api/campus/exams/<int:exam_id>/review', methods=['PUT'])
@require_user
def update_review_status(user, exam_id):
    """更新复习进度 - 已禁用"""
    return jsonify({
        'success': False,
        'message': '考试周功能已暂时禁用'
    }), 403


# ==================== 学期设置 API ====================

@campus_bp.route('/api/campus/semester', methods=['GET'])
@require_user
def get_semester(user):
    """获取当前学期信息 - 已禁用"""
    return jsonify({
        'success': True,
        'semester': None,
        'current_week': 1,
        'is_exam_week': False,
        'message': '学期功能已暂时禁用'
    })


@campus_bp.route('/api/campus/semester', methods=['POST'])
@require_user
def set_semester(user):
    """设置学期 - 已禁用"""
    return jsonify({
        'success': False,
        'message': '学期功能已暂时禁用'
    }), 403
