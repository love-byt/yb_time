"""
标签管理路由
"""

from flask import Blueprint, jsonify, request

from extensions import db
from models.task import Tag, TaskTag
from utils.user_auth import require_user

tag_bp = Blueprint('tag', __name__)

PRESET_TAGS = [
    {'name': '重要', 'color': '#F44336', 'icon': 'fa-exclamation-circle'},
    {'name': '紧急', 'color': '#FF9800', 'icon': 'fa-fire'},
    {'name': '学习', 'color': '#2196F3', 'icon': 'fa-book'},
    {'name': '工作', 'color': '#4CAF50', 'icon': 'fa-briefcase'},
    {'name': '生活', 'color': '#9C27B0', 'icon': 'fa-home'},
    {'name': '健康', 'color': '#00BCD4', 'icon': 'fa-heartbeat'},
    {'name': '财务', 'color': '#FFEB3B', 'icon': 'fa-dollar-sign'},
    {'name': '社交', 'color': '#E91E63', 'icon': 'fa-users'},
]


@tag_bp.route('/api/tags', methods=['GET'])
@require_user
def get_tags(user):
    """获取所有标签"""
    tags = Tag.query.filter_by(user_id=user.id).order_by(Tag.sort_order.asc(), Tag.created_at.desc()).all()
    return jsonify({
        "success": True,
        "tags": [tag.to_dict() for tag in tags],
        "presets": PRESET_TAGS
    })


@tag_bp.route('/api/tags', methods=['POST'])
@require_user
def create_tag(user):
    """创建标签"""
    data = request.get_json()
    name = data.get('name', '').strip()
    
    if not name:
        return jsonify({"success": False, "message": "标签名称不能为空"}), 400
    
    existing = Tag.query.filter_by(name=name, user_id=user.id).first()
    if existing:
        return jsonify({"success": False, "message": "标签已存在"}), 400
    
    tag = Tag(
        user_id=user.id,
        name=name,
        color=data.get('color', '#4CAF50'),
        icon=data.get('icon', 'fa-tag'),
        sort_order=data.get('sort_order', 0)
    )
    
    db.session.add(tag)
    db.session.commit()
    
    return jsonify({
        "success": True,
        "tag": tag.to_dict(),
        "message": "标签创建成功"
    }), 201


@tag_bp.route('/api/tags/<int:tag_id>', methods=['PUT'])
@require_user
def update_tag(user, tag_id):
    """更新标签"""
    tag = Tag.query.filter_by(id=tag_id, user_id=user.id).first_or_404()
    data = request.get_json()
    
    if 'name' in data:
        name = data['name'].strip()
        if name and name != tag.name:
            existing = Tag.query.filter_by(name=name, user_id=user.id).first()
            if existing:
                return jsonify({"success": False, "message": "标签名称已存在"}), 400
            tag.name = name
    
    if 'color' in data:
        tag.color = data['color']
    if 'icon' in data:
        tag.icon = data['icon']
    if 'sort_order' in data:
        tag.sort_order = data['sort_order']
    
    db.session.commit()
    
    return jsonify({
        "success": True,
        "tag": tag.to_dict(),
        "message": "标签更新成功"
    })


@tag_bp.route('/api/tags/<int:tag_id>', methods=['DELETE'])
@require_user
def delete_tag(user, tag_id):
    """删除标签"""
    tag = Tag.query.filter_by(id=tag_id, user_id=user.id).first_or_404()
    
    # 删除任务-标签关联
    # 先获取用户的所有任务ID
    from models.task import Task
    user_task_ids = [t.id for t in Task.query.filter_by(user_id=user.id).all()]
    TaskTag.query.filter(TaskTag.tag_id == tag_id, TaskTag.task_id.in_(user_task_ids)).delete()
    
    db.session.delete(tag)
    db.session.commit()
    
    return jsonify({
        "success": True,
        "message": "标签删除成功"
    })


@tag_bp.route('/api/tasks/<int:task_id>/tags', methods=['PUT'])
@require_user
def update_task_tags(user, task_id):
    """批量更新任务标签"""
    from models.task import Task
    task = Task.query.filter_by(id=task_id, user_id=user.id).first_or_404()
    data = request.get_json()
    tag_ids = data.get('tag_ids', [])
    
    TaskTag.query.filter_by(task_id=task_id).delete()
    
    for tag_id in tag_ids:
        # 确保标签属于当前用户
        tag = Tag.query.filter_by(id=tag_id, user_id=user.id).first()
        if tag:
            task_tag = TaskTag(task_id=task_id, tag_id=tag_id)
            db.session.add(task_tag)
    
    db.session.commit()
    
    return jsonify({
        "success": True,
        "message": "标签更新成功",
        "task": task.to_dict()
    })


@tag_bp.route('/api/tags/init', methods=['POST'])
@require_user
def init_preset_tags(user):
    """初始化预设标签"""
    created_count = 0
    
    for preset in PRESET_TAGS:
        existing = Tag.query.filter_by(name=preset['name'], user_id=user.id).first()
        if not existing:
            tag = Tag(
                user_id=user.id,
                name=preset['name'],
                color=preset['color'],
                icon=preset['icon'],
                sort_order=PRESET_TAGS.index(preset)
            )
            db.session.add(tag)
            created_count += 1
    
    db.session.commit()
    
    return jsonify({
        "success": True,
        "message": f"成功创建 {created_count} 个预设标签",
        "created_count": created_count
    })
