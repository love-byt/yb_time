"""
用户管理路由
"""

from flask import Blueprint, jsonify, request

from extensions import db
from models.task import User
from utils.user_auth import require_user

user_bp = Blueprint('user', __name__)


@user_bp.route('/api/user/profile', methods=['GET'])
@require_user
def get_user_profile(user):
    """获取当前用户信息"""
    # 强制从数据库重新加载用户数据
    db.session.refresh(user)
    return jsonify({
        "success": True,
        "user": user.to_dict()
    })


@user_bp.route('/api/user/profile', methods=['PUT'])
@require_user
def update_user_profile(user):
    """更新用户信息（昵称）"""
    data = request.get_json()
    
    if 'nickname' in data:
        nickname = data['nickname'].strip()
        if nickname and len(nickname) <= 50:
            user.nickname = nickname
        elif nickname == '':
            user.nickname = None
    
    db.session.commit()
    db.session.refresh(user)  # 刷新用户对象以获取最新数据
    
    return jsonify({
        "success": True,
        "message": "用户信息更新成功",
        "user": user.to_dict()
    })


@user_bp.route('/api/user/push/subscribe', methods=['POST'])
@require_user
def subscribe_push(user):
    """订阅推送通知"""
    import json
    from utils.push_notification import get_or_create_vapid_keys
    
    data = request.get_json()
    subscription = data.get('subscription')
    
    if not subscription:
        return jsonify({
            "success": False,
            "message": "订阅信息无效"
        }), 400
    
    # 保存订阅信息到用户
    user.push_subscription = json.dumps(subscription)
    db.session.commit()
    
    return jsonify({
        "success": True,
        "message": "推送订阅成功"
    })


@user_bp.route('/api/user/push/unsubscribe', methods=['POST'])
@require_user
def unsubscribe_push(user):
    """取消推送订阅"""
    user.push_subscription = None
    db.session.commit()
    
    return jsonify({
        "success": True,
        "message": "已取消推送订阅"
    })


@user_bp.route('/api/user/push/vapid-key', methods=['GET'])
@require_user
def get_vapid_key(user):
    """获取VAPID公钥"""
    from utils.push_notification import get_or_create_vapid_keys
    
    public_key, _ = get_or_create_vapid_keys()
    
    return jsonify({
        "success": True,
        "public_key": public_key
    })
