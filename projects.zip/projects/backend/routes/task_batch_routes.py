"""
批量任务管理路由
支持批量创建、文本解析、文件导入等功能
"""

from flask import Blueprint, request, jsonify, send_file
from extensions import db
from models.task import Task
from routes.auth_routes import require_user
from utils.batch_parser import BatchTaskParser, parse_batch_tasks
from utils.file_importer import TaskFileImporter, import_tasks_from_file
from datetime import datetime, timedelta
import io
import uuid

batch_bp = Blueprint('task_batch', __name__)


def parse_datetime(dt_str):
    """解析日期时间字符串"""
    if not dt_str:
        return None
    if isinstance(dt_str, datetime):
        return dt_str
    try:
        return datetime.fromisoformat(dt_str.replace('Z', '+00:00').replace('+00:00', ''))
    except:
        try:
            return datetime.strptime(dt_str, '%Y-%m-%d %H:%M:%S')
        except:
            try:
                return datetime.strptime(dt_str, '%Y-%m-%d')
            except:
                return None


@batch_bp.route('/api/tasks/batch', methods=['POST'])
@require_user
def create_tasks_batch(user):
    """
    批量创建任务
    
    请求体格式：
    {
        "tasks": [
            {
                "title": "任务标题",
                "category": "分类",
                "deadline": "截止时间",
                "duration": 120,
                "priority": 4,
                "course_id": "课程ID"
            }
        ],
        "auto_sort": true,
        "ai_analyze": true
    }
    """
    data = request.get_json()
    
    if not data or 'tasks' not in data:
        return jsonify({'success': False, 'message': '缺少任务列表'}), 400
    
    tasks_data = data.get('tasks', [])
    
    if not tasks_data:
        return jsonify({'success': False, 'message': '任务列表不能为空'}), 400
    
    if len(tasks_data) > 100:
        return jsonify({'success': False, 'message': '单次最多创建100个任务'}), 400
    
    auto_sort = data.get('auto_sort', False)
    ai_analyze = data.get('ai_analyze', True)
    
    created_tasks = []
    failed_tasks = []
    batch_id = str(uuid.uuid4())[:8]
    
    try:
        for index, task_item in enumerate(tasks_data):
            try:
                # 解析截止时间
                deadline = parse_datetime(task_item.get('deadline'))
                
                # 如果没有截止时间且启用AI分析，尝试智能生成
                if not deadline and ai_analyze:
                    deadline = _generate_smart_deadline(task_item, user.id)
                
                # 计算预估时长
                estimated_duration = task_item.get('duration') or task_item.get('estimated_duration')
                
                # 创建任务
                task = Task(
                    user_id=user.id,
                    title=task_item.get('title', '未命名任务'),
                    description=task_item.get('description', ''),
                    category=task_item.get('category', '学习'),
                    priority=task_item.get('priority', 3),
                    end_time=deadline,
                    estimated_duration=estimated_duration,
                    difficulty_level=_infer_difficulty(task_item),
                    batch_id=batch_id,
                    batch_index=index
                )
                
                db.session.add(task)
                created_tasks.append(task)
                
            except Exception as e:
                failed_tasks.append({
                    'index': index,
                    'title': task_item.get('title', '未知'),
                    'error': str(e)
                })
        
        db.session.commit()
        
        # 如果启用自动排序，执行批量排序
        sort_result = None
        if auto_sort and created_tasks:
            sort_result = _perform_batch_sort(user, created_tasks)
        
        return jsonify({
            'success': True,
            'data': {
                'created': len(created_tasks),
                'failed': len(failed_tasks),
                'batch_id': batch_id,
                'tasks': [t.to_dict() for t in created_tasks],
                'failed_tasks': failed_tasks,
                'sort_result': sort_result
            }
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'批量创建失败: {str(e)}'
        }), 500


@batch_bp.route('/api/tasks/parse-text', methods=['POST'])
@require_user
def parse_tasks_from_text(user):
    """
    从自然语言文本解析任务
    
    请求体：
    {
        "text": "数学作业明天截止需要2小时，英语论文后天交预计3小时"
    }
    """
    data = request.get_json()
    
    if not data or 'text' not in data:
        return jsonify({'success': False, 'message': '缺少文本内容'}), 400
    
    text = data.get('text', '').strip()
    
    if not text:
        return jsonify({'success': False, 'message': '文本内容不能为空'}), 400
    
    try:
        # 使用解析器解析文本
        parser = BatchTaskParser()
        parsed_tasks = parser.parse_text(text)
        
        return jsonify({
            'success': True,
            'data': parsed_tasks,
            'count': len(parsed_tasks)
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'解析失败: {str(e)}'
        }), 500


@batch_bp.route('/api/tasks/import', methods=['POST'])
@require_user
def import_tasks(user):
    """
    从文件导入任务（支持Excel/CSV）
    
    请求：multipart/form-data
    - file: 上传的文件
    - file_type: "excel" | "csv"
    """
    if 'file' not in request.files:
        return jsonify({'success': False, 'message': '未找到上传文件'}), 400
    
    file = request.files['file']
    file_type = request.form.get('file_type', 'excel')
    
    if file.filename == '':
        return jsonify({'success': False, 'message': '未选择文件'}), 400
    
    try:
        # 读取文件内容
        file_content = file.read()
        
        # 根据文件类型导入
        if file_type.lower() in ['excel', 'xlsx', 'xls'] or file.filename.endswith(('.xlsx', '.xls')):
            result = import_tasks_from_file(file_content, 'excel')
        elif file_type.lower() in ['csv', 'txt'] or file.filename.endswith('.csv'):
            result = import_tasks_from_file(file_content, 'csv')
        else:
            return jsonify({
                'success': False,
                'message': '不支持的文件类型，请使用 .xlsx 或 .csv 文件'
            }), 400
        
        if not result['success']:
            return jsonify({
                'success': False,
                'message': '文件解析失败',
                'errors': result.get('errors', [])
            }), 400
        
        # 返回解析结果（不自动创建，让用户确认）
        return jsonify({
            'success': True,
            'data': {
                'tasks': result['tasks'],
                'total': result.get('total', 0),
                'success_count': result.get('success_count', 0),
                'error_count': result.get('error_count', 0),
                'warnings': result.get('warnings', [])
            }
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'文件处理失败: {str(e)}'
        }), 500


@batch_bp.route('/api/tasks/template', methods=['GET'])
@require_user
def download_template():
    """下载任务导入模板"""
    file_format = request.args.get('format', 'excel')
    
    try:
        if file_format.lower() in ['excel', 'xlsx']:
            file_content = TaskFileImporter.generate_template_excel()
            mimetype = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
            filename = '任务导入模板.xlsx'
        else:
            file_content = TaskFileImporter.generate_template_csv()
            mimetype = 'text/csv'
            filename = '任务导入模板.csv'
        
        return send_file(
            io.BytesIO(file_content),
            mimetype=mimetype,
            as_attachment=True,
            download_name=filename
        )
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'模板生成失败: {str(e)}'
        }), 500


# ==================== 辅助函数 ====================

def _generate_smart_deadline(task_item, user_id):
    """智能生成截止时间"""
    # 根据分类和优先级生成默认截止时间
    category = task_item.get('category', '学习')
    priority = task_item.get('priority', 3)
    
    base_days = 3  # 默认3天后
    
    # 根据优先级调整
    if priority >= 4:
        base_days = 1
    elif priority <= 2:
        base_days = 7
    
    # 根据分类调整
    if category == '考试':
        base_days = max(base_days, 7)
    elif category == '项目':
        base_days = max(base_days, 14)
    
    deadline = datetime.now() + timedelta(days=base_days)
    return deadline.replace(hour=23, minute=59, second=0, microsecond=0)


def _infer_difficulty(task_item):
    """推断任务难度"""
    title = task_item.get('title', '').lower()
    duration = task_item.get('duration') or task_item.get('estimated_duration', 0)
    
    # 根据关键词判断
    hard_keywords = ['论文', '项目', '实验', '考试', '期末', '毕业']
    easy_keywords = ['练习', '阅读', '复习', '预习']
    
    for keyword in hard_keywords:
        if keyword in title:
            return 'hard'
    
    for keyword in easy_keywords:
        if keyword in title:
            return 'easy'
    
    # 根据时长判断
    if duration and duration > 180:  # 超过3小时
        return 'hard'
    elif duration and duration < 30:  # 少于30分钟
        return 'easy'
    
    return 'medium'


def _perform_batch_sort(user, tasks):
    """执行批量排序"""
    try:
        # 导入智能排序模块
        from utils.ai_helper import sort_tasks_ai
        
        task_dicts = [t.to_dict() for t in tasks]
        sorted_result = sort_tasks_ai(task_dicts, user.id)
        
        return {
            'sorted_tasks': sorted_result.get('sorted_tasks', []),
            'recommendations': sorted_result.get('recommendations', [])
        }
    except Exception as e:
        print(f"批量排序失败: {e}")
        return None


# 注册蓝图
def init_batch_routes(app):
    """初始化批量任务路由"""
    app.register_blueprint(batch_bp)
