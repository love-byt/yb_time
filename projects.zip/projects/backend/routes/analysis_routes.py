"""
AI分析路由
支持完成事项分析、习惯分析、每周报告
"""

import json
from datetime import datetime, timedelta

from typing import Optional

from flask import Blueprint, jsonify, request

from config import Config
from extensions import db
from models.task import Task, AIAnalysis, User
from utils.ai_helper import AIHelper
from utils.user_auth import require_user
from utils.cache import DEFAULT_TTL, CACHE_PREFIXES, AI_ANALYSIS_TYPES

analysis_bp = Blueprint('analysis', __name__)


def get_ai_helper():
    """
    获取AI助手实例，优先使用请求头中的API Key
    """
    api_key = request.headers.get('X-AI-API-Key', '')
    if api_key:
        return AIHelper(api_key)
    return AIHelper(Config.TONGYI_API_KEY)


@analysis_bp.route('/api/analysis/habit', methods=['GET'])
@require_user
def analyze_habits(user):
    """分析学习习惯（带缓存机制）"""
    try:
        ai_helper = get_ai_helper()
        
        days = request.args.get('days', 7, type=int)
        force_refresh = request.args.get('force_refresh', 'false').lower() == 'true'
        cutoff_date = datetime.now() - timedelta(days=days)
        
        completed_tasks = Task.query.filter(
            Task.user_id == user.id,
            Task.is_completed == 1,
            Task.actual_end_time >= cutoff_date
        ).all()
        
        if len(completed_tasks) < 3:
            return jsonify({
                "success": False,
                "message": "数据不足，请完成更多任务后再来分析",
                "completed_count": len(completed_tasks)
            }), 400
        
        # ========== 缓存检查逻辑 ==========
        # 使用统一TTL配置（24小时）
        if not force_refresh:
            cache_cutoff = datetime.now() - timedelta(seconds=DEFAULT_TTL['ai_analysis'])
            recent_analysis = AIAnalysis.query.filter(
                AIAnalysis.user_id == user.id,
                AIAnalysis.analysis_type == 'habit',
                AIAnalysis.created_at >= cache_cutoff
            ).order_by(AIAnalysis.created_at.desc()).first()
            
            if recent_analysis:
                # 检查任务数量是否匹配（简单验证缓存是否仍然有效）
                try:
                    cached_structured = json.loads(recent_analysis.structured_data or '{}')
                    cached_task_count = cached_structured.get('total_tasks', 0)
                    
                    # 如果任务数量变化不大（±2个），认为缓存仍然有效
                    if abs(cached_task_count - len(completed_tasks)) <= 2:
                        return jsonify({
                            "success": True,
                            "analysis": recent_analysis.content,
                            "stats": cached_structured,
                            "cached": True,
                            "cached_at": recent_analysis.created_at.strftime('%Y-%m-%d %H:%M:%S')
                        })
                except:
                    pass  # 缓存解析失败，继续生成新分析
        
        time_records = []
        total_duration = 0
        category_stats = {}
        
        for task in completed_tasks:
            duration = task.actual_duration or 0
            total_duration += duration
            
            cat = task.category or '未分类'
            if cat not in category_stats:
                category_stats[cat] = {'count': 0, 'duration': 0}
            category_stats[cat]['count'] += 1
            category_stats[cat]['duration'] += duration
            
            time_records.append(f"- {task.title}（{task.category}）: {duration}分钟")
        
        analysis = ai_helper.analyze_completion("\n".join(time_records))
        
        ai_analysis = AIAnalysis(
            user_id=user.id,
            task_id=completed_tasks[0].id if completed_tasks else None,
            analysis_type='habit',
            content=analysis,
            structured_data=json.dumps({
                'total_tasks': len(completed_tasks),
                'total_duration': total_duration,
                'category_stats': category_stats,
                'days': days
            }, ensure_ascii=False),
            api_model='qwen-turbo'
        )
        db.session.add(ai_analysis)
        db.session.commit()
        
        return jsonify({
            "success": True,
            "analysis": analysis,
            "stats": {
                "total_tasks": len(completed_tasks),
                "total_duration": total_duration,
                "category_stats": category_stats
            },
            "cached": False
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({"success": False, "message": f"分析错误: {str(e)}"}), 500


@analysis_bp.route('/api/analysis/completion', methods=['POST'])
@require_user
def analyze_completion(user):
    """AI完成事项分析（带缓存机制）"""
    try:
        ai_helper = get_ai_helper()
        
        data = request.get_json() or {}
        task_ids = data.get('task_ids', [])
        days = data.get('days', 7)
        # 是否强制刷新缓存
        force_refresh = data.get('force_refresh', False)
        
        if task_ids:
            tasks = Task.query.filter(
                Task.id.in_(task_ids),
                Task.user_id == user.id,
                Task.is_completed == 1
            ).all()
        else:
            cutoff_date = datetime.now() - timedelta(days=days)
            tasks = Task.query.filter(
                Task.user_id == user.id,
                Task.is_completed == 1,
                Task.actual_end_time >= cutoff_date
            ).order_by(Task.actual_end_time.desc()).limit(20).all()
        
        if not tasks:
            # 返回空数据而不是错误
            return jsonify({
                "success": True,
                "report": {
                    "total_tasks": 0,
                    "total_duration": 0,
                    "rate": 0,
                    "category_stats": {},
                    "efficiency_trend": []
                }
            })
        
        # ========== 缓存检查逻辑 ==========
        # 检查是否有近期（24小时内）的相同分析缓存
        if not force_refresh:
            cache_cutoff = datetime.now() - timedelta(hours=24)
            recent_analysis = AIAnalysis.query.filter(
                AIAnalysis.user_id == user.id,
                AIAnalysis.analysis_type == 'completion',
                AIAnalysis.created_at >= cache_cutoff
            ).order_by(AIAnalysis.created_at.desc()).first()
            
            if recent_analysis:
                # 检查任务数量是否匹配（简单验证缓存是否仍然有效）
                try:
                    cached_structured = json.loads(recent_analysis.structured_data or '{}')
                    cached_task_count = cached_structured.get('summary', {}).get('total_count', 0)
                    
                    # 如果任务数量变化不大（±2个），认为缓存仍然有效
                    if abs(cached_task_count - len(tasks)) <= 2:
                        return jsonify({
                            "success": True,
                            "analysis": recent_analysis.content,
                            "structured_data": cached_structured,
                            "tasks_analyzed": len(tasks),
                            "cached": True,
                            "cached_at": recent_analysis.created_at.strftime('%Y-%m-%d %H:%M:%S')
                        })
                except:
                    pass  # 缓存解析失败，继续生成新分析
        
        # ========== 生成新分析 ==========
        analysis_data = _build_completion_analysis_data(tasks)
        
        tasks_summary = "\n".join([
            f"- {t['title']}（{t['category']}）: {t['duration']}分钟"
            for t in analysis_data['tasks'][:10]
        ])
        
        analysis_result = ai_helper.analyze_completion(tasks_summary)
        
        structured_data = {
            'raw_analysis': analysis_result,
            'summary': analysis_data['summary']
        }
        
        # 保存到数据库
        ai_analysis = AIAnalysis(
            user_id=user.id,
            task_id=tasks[0].id if tasks else None,
            analysis_type='completion',
            content=analysis_result,
            structured_data=json.dumps(structured_data, ensure_ascii=False),
            api_model='qwen-turbo'
        )
        db.session.add(ai_analysis)
        db.session.commit()
        
        return jsonify({
            "success": True,
            "analysis": analysis_result,
            "structured_data": structured_data,
            "tasks_analyzed": len(tasks),
            "cached": False
        })
        
    except Exception as e:
        return jsonify({"success": False, "message": f"分析错误: {str(e)}"}), 500


@analysis_bp.route('/api/analysis/completion/history', methods=['GET'])
@require_user
def get_completion_analysis_history(user):
    """获取完成事项分析历史"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 10, type=int)
        
        analyses = AIAnalysis.query.filter_by(
            user_id=user.id,
            analysis_type='completion'
        ).order_by(
            AIAnalysis.created_at.desc()
        ).paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        return jsonify({
            "success": True,
            "analyses": [a.to_dict() for a in analyses.items],
            "total": analyses.total,
            "pages": analyses.pages,
            "current_page": page
        })
        
    except Exception as e:
        return jsonify({"success": False, "message": f"获取历史错误: {str(e)}"}), 500


@analysis_bp.route('/api/analysis/efficiency', methods=['GET'])
@require_user
def analyze_efficiency(user):
    """分析时间效率（带缓存机制）"""
    try:
        days = request.args.get('days', 7, type=int)
        # 是否强制刷新缓存
        force_refresh = request.args.get('force_refresh', 'false').lower() == 'true'
        
        cutoff_date = datetime.now() - timedelta(days=days)
        
        completed_tasks = Task.query.filter(
            Task.user_id == user.id,
            Task.is_completed == 1,
            Task.actual_end_time >= cutoff_date
        ).all()
        
        if not completed_tasks:
            # 返回空数据而不是错误
            return jsonify({
                "success": True,
                "efficiency": {
                    "total_tasks": 0,
                    "total_duration": 0,
                    "avg_duration": 0,
                    "hourly_distribution": [0] * 24,
                    "peak_hours": [],
                    "category_efficiency": {},
                    "trend": []
                }
            })
        
        # ========== 缓存检查逻辑 ==========
        # 检查是否有近期（1小时内）的相同分析缓存
        if not force_refresh:
            cache_cutoff = datetime.now() - timedelta(hours=1)
            recent_analysis = AIAnalysis.query.filter(
                AIAnalysis.user_id == user.id,
                AIAnalysis.analysis_type == 'efficiency',
                AIAnalysis.created_at >= cache_cutoff
            ).order_by(AIAnalysis.created_at.desc()).first()
            
            if recent_analysis and recent_analysis.structured_data:
                try:
                    cached_efficiency = json.loads(recent_analysis.structured_data)
                    # 验证缓存的任务数量是否匹配
                    cached_task_count = cached_efficiency.get('total_tasks', 0)
                    if abs(cached_task_count - len(completed_tasks)) <= 2:
                        return jsonify({
                            "success": True,
                            "efficiency": cached_efficiency,
                            "cached": True,
                            "cached_at": recent_analysis.created_at.strftime('%Y-%m-%d %H:%M:%S')
                        })
                except:
                    pass  # 缓存解析失败，继续生成新分析
        
        # ========== 生成新分析 ==========
        total_tasks = len(completed_tasks)
        total_duration = sum(t.actual_duration or 0 for t in completed_tasks)
        avg_duration = total_duration / total_tasks if total_tasks > 0 else 0
        
        hourly_distribution = [0] * 24
        for task in completed_tasks:
            if task.actual_start_time:
                hour = task.actual_start_time.hour
                hourly_distribution[hour] += 1
        
        peak_hours = sorted(
            range(24), 
            key=lambda h: hourly_distribution[h], 
            reverse=True
        )[:3]
        
        category_efficiency = {}
        for task in completed_tasks:
            cat = task.category or '未分类'
            if cat not in category_efficiency:
                category_efficiency[cat] = {'count': 0, 'total_duration': 0}
            category_efficiency[cat]['count'] += 1
            category_efficiency[cat]['total_duration'] += task.actual_duration or 0
        
        for cat in category_efficiency:
            count = category_efficiency[cat]['count']
            category_efficiency[cat]['avg_duration'] = round(
                category_efficiency[cat]['total_duration'] / count, 1
            ) if count > 0 else 0
        
        efficiency_data = {
            "total_tasks": total_tasks,
            "total_duration": total_duration,
            "avg_duration": round(avg_duration, 1),
            "peak_hours": peak_hours,
            "hourly_distribution": hourly_distribution,
            "category_efficiency": category_efficiency
        }
        
        # 保存到数据库缓存
        ai_analysis = AIAnalysis(
            user_id=user.id,
            task_id=completed_tasks[0].id if completed_tasks else None,
            analysis_type='efficiency',
            content='',
            structured_data=json.dumps(efficiency_data, ensure_ascii=False),
            api_model='cached'
        )
        db.session.add(ai_analysis)
        db.session.commit()
        
        return jsonify({
            "success": True,
            "efficiency": efficiency_data,
            "cached": False
        })
        
    except Exception as e:
        return jsonify({"success": False, "message": f"效率分析错误: {str(e)}"}), 500


def _build_completion_analysis_data(tasks):
    """构建完成事项分析数据"""
    data = {
        'tasks': [],
        'summary': {
            'total_count': len(tasks),
            'total_duration': 0,
            'categories': {}
        }
    }
    
    for task in tasks:
        task_data = {
            'id': task.id,
            'title': task.title,
            'category': task.category,
            'duration': task.actual_duration or 0,
            'priority': task.priority,
            'six_dimensions': {
                'time': task.time_score,
                'importance': task.importance_score,
                'impact': task.impact_score,
                'money': task.money_score,
                'relation': task.relation_score,
                'skill': task.skill_score
            }
        }
        data['tasks'].append(task_data)
        
        data['summary']['total_duration'] += task_data['duration']
        
        cat = task.category or '未分类'
        if cat not in data['summary']['categories']:
            data['summary']['categories'][cat] = {'count': 0, 'duration': 0}
        data['summary']['categories'][cat]['count'] += 1
        data['summary']['categories'][cat]['duration'] += task_data['duration']
    
    return data


# ==================== 每周报告接口 ====================

@analysis_bp.route('/api/analysis/weekly-report', methods=['GET'])
@require_user
def generate_weekly_report(user):
    """
    生成每周学习报告
    
    返回本周的任务完成情况、时间分布、效率趋势和AI个性化建议
    
    Query Parameters:
        detailed: 是否包含详细任务列表 (default: false)
        compare: 是否与上周对比 (default: false)
    """
    try:
        ai_helper = get_ai_helper()
        
        detailed = request.args.get('detailed', 'false').lower() == 'true'
        compare = request.args.get('compare', 'false').lower() == 'true'
        
        # 获取本周数据
        week_start = datetime.now() - timedelta(days=7)
        week_end = datetime.now()
        
        # 本周完成的任务
        completed_tasks = Task.query.filter(
            Task.user_id == user.id,
            Task.is_completed == 1,
            Task.actual_end_time >= week_start,
            Task.actual_end_time < week_end
        ).all()
        
        # 本周创建的任务
        created_tasks = Task.query.filter(
            Task.user_id == user.id,
            Task.created_at >= week_start,
            Task.created_at < week_end
        ).all()
        
        # 本周到期的任务
        due_tasks = Task.query.filter(
            Task.user_id == user.id,
            Task.end_time.isnot(None)
        ).all()
        
        # 筛选本周到期的任务
        week_due_tasks = []
        for t in due_tasks:
            try:
                if 'T' in t.end_time:
                    deadline = datetime.fromisoformat(t.end_time.replace('Z', '+00:00').replace('+00:00', ''))
                else:
                    deadline = datetime.strptime(t.end_time, '%Y-%m-%d %H:%M:%S')
                if week_start <= deadline < week_end:
                    week_due_tasks.append(t)
            except:
                pass
        
        # ========== 基础统计 ==========
        total_completed = len(completed_tasks)
        total_created = len(created_tasks)
        total_due = len(week_due_tasks)
        
        # 完成率 = 本周完成的任务 / 本周到期的任务
        completion_rate = round(total_completed / total_due * 100, 1) if total_due > 0 else 0
        
        # 总时长和平均时长
        total_duration = sum([t.actual_duration or 0 for t in completed_tasks])
        avg_duration = total_duration / total_completed if total_completed > 0 else 0
        
        # ========== 分类统计 ==========
        category_stats = {}
        for task in completed_tasks:
            cat = task.category or '未分类'
            if cat not in category_stats:
                category_stats[cat] = {'count': 0, 'duration': 0, 'tasks': []}
            category_stats[cat]['count'] += 1
            category_stats[cat]['duration'] += task.actual_duration or 0
            if detailed:
                category_stats[cat]['tasks'].append({
                    'id': task.id,
                    'title': task.title,
                    'duration': task.actual_duration or 0,
                    'priority': task.priority
                })
        
        # 计算分类占比
        for cat in category_stats:
            category_stats[cat]['percentage'] = round(
                category_stats[cat]['count'] / total_completed * 100, 1
            ) if total_completed > 0 else 0
            category_stats[cat]['avg_duration'] = round(
                category_stats[cat]['duration'] / category_stats[cat]['count'], 1
            ) if category_stats[cat]['count'] > 0 else 0
        
        # ========== 优先级分布 ==========
        priority_distribution = {1: 0, 2: 0, 3: 0, 4: 0, 5: 0}
        for task in completed_tasks:
            if task.priority and 1 <= task.priority <= 5:
                priority_distribution[task.priority] += 1
        
        # ========== 每日分布 ==========
        daily_distribution = _calculate_daily_distribution(completed_tasks)
        daily_completion_trend = _calculate_daily_completion_trend(completed_tasks, 7)
        
        # ========== 效率趋势 ==========
        efficiency_trend = _calculate_efficiency_trend(user)
        
        # ========== 最佳学习时段 ==========
        peak_hours = _calculate_peak_hours(completed_tasks)
        
        # ========== 与上周对比 ==========
        comparison = None
        if compare:
            comparison = _compare_with_last_week(user, completed_tasks)
        
        # ========== 任务详情列表 ==========
        task_list = []
        if detailed:
            task_list = [{
                'id': t.id,
                'title': t.title,
                'category': t.category,
                'priority': t.priority,
                'duration': t.actual_duration or 0,
                'completed_at': t.actual_end_time.strftime('%Y-%m-%d %H:%M') if t.actual_end_time else None,
                'on_time': _check_on_time(t)
            } for t in sorted(completed_tasks, key=lambda x: x.actual_end_time or datetime.min, reverse=True)]
        
        # ========== 生成报告数据 ==========
        report_data = {
            # 基础统计
            'total_tasks': total_completed,
            'total_created': total_created,
            'total_due': total_due,
            'completion_rate': completion_rate,
            'total_duration': total_duration,
            'avg_duration': round(avg_duration, 2),
            
            # 分类统计
            'category_stats': category_stats,
            'top_category': max(category_stats.items(), key=lambda x: x[1]['count'])[0] if category_stats else None,
            
            # 优先级分布
            'priority_distribution': priority_distribution,
            
            # 时间分布
            'daily_distribution': daily_distribution,
            'daily_completion_trend': daily_completion_trend,
            'peak_hours': peak_hours,
            
            # 效率趋势
            'efficiency_trend': efficiency_trend,
            
            # 时间范围
            'week_start': week_start.strftime('%Y-%m-%d'),
            'week_end': week_end.strftime('%Y-%m-%d'),
        }
        
        # 可选字段
        if compare and comparison:
            report_data['comparison'] = comparison
        
        if detailed:
            report_data['task_list'] = task_list
        
        # ========== 生成AI建议 ==========
        ai_suggestions = _generate_ai_suggestions(report_data, user, ai_helper)
        report_data['ai_suggestions'] = ai_suggestions
        
        return jsonify({
            'success': True,
            'report': report_data
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'生成报告失败: {str(e)}'
        }), 500


def _calculate_daily_completion_trend(tasks, days=7):
    """计算每日完成趋势"""
    trend = []
    for i in range(days - 1, -1, -1):
        date = datetime.now() - timedelta(days=i)
        date_str = date.strftime('%Y-%m-%d')
        
        count = sum(1 for t in tasks if t.actual_end_time and t.actual_end_time.strftime('%Y-%m-%d') == date_str)
        duration = sum(t.actual_duration or 0 for t in tasks if t.actual_end_time and t.actual_end_time.strftime('%Y-%m-%d') == date_str)
        
        trend.append({
            'date': date_str,
            'day_name': ['周一', '周二', '周三', '周四', '周五', '周六', '周日'][date.weekday()],
            'count': count,
            'duration': duration
        })
    
    return trend


def _calculate_peak_hours(tasks):
    """计算最佳学习时段"""
    hourly_distribution = [0] * 24
    for task in tasks:
        if task.actual_start_time:
            hourly_distribution[task.actual_start_time.hour] += 1
    
    # 找出任务最多的时段
    peak_hours = []
    sorted_hours = sorted(range(24), key=lambda h: hourly_distribution[h], reverse=True)
    for h in sorted_hours[:3]:
        if hourly_distribution[h] > 0:
            peak_hours.append({
                'hour': h,
                'label': f'{h:02d}:00-{h+1:02d}:00',
                'count': hourly_distribution[h]
            })
    
    return peak_hours


def _check_on_time(task):
    """检查任务是否按时完成"""
    if not task.actual_end_time or not task.end_time:
        return None
    
    try:
        if 'T' in task.end_time:
            deadline = datetime.fromisoformat(task.end_time.replace('Z', '+00:00').replace('+00:00', ''))
        else:
            deadline = datetime.strptime(task.end_time, '%Y-%m-%d %H:%M:%S')
        
        return task.actual_end_time <= deadline
    except:
        return None


def _compare_with_last_week(user, this_week_tasks):
    """与上周对比"""
    week_start = datetime.now() - timedelta(days=14)
    week_end = datetime.now() - timedelta(days=7)
    
    last_week_tasks = Task.query.filter(
        Task.user_id == user.id,
        Task.is_completed == 1,
        Task.actual_end_time >= week_start,
        Task.actual_end_time < week_end
    ).all()
    
    this_week_count = len(this_week_tasks)
    last_week_count = len(last_week_tasks)
    
    this_week_duration = sum(t.actual_duration or 0 for t in this_week_tasks)
    last_week_duration = sum(t.actual_duration or 0 for t in last_week_tasks)
    
    def calc_change(current, previous):
        if previous == 0:
            return {'value': current, 'change': 0, 'percent': 0}
        change = current - previous
        percent = round(change / previous * 100, 1)
        return {'value': current, 'change': change, 'percent': percent}
    
    return {
        'tasks': calc_change(this_week_count, last_week_count),
        'duration': calc_change(this_week_duration, last_week_duration),
        'last_week_total': last_week_count,
        'last_week_duration': last_week_duration
    }


def _calculate_daily_distribution(tasks):
    """计算每日时间分布"""
    daily = {}
    for task in tasks:
        if task.actual_end_time:
            day = task.actual_end_time.strftime('%Y-%m-%d')
            if day not in daily:
                daily[day] = {'count': 0, 'duration': 0}
            daily[day]['count'] += 1
            daily[day]['duration'] += task.actual_duration or 0
    return daily


def _calculate_efficiency_trend(user):
    """计算效率趋势"""
    weeks = []
    for i in range(4):
        week_start = datetime.now() - timedelta(days=(i+1)*7)
        week_end = datetime.now() - timedelta(days=i*7)
        
        tasks = Task.query.filter(
            Task.user_id == user.id,
            Task.is_completed == 1,
            Task.actual_end_time >= week_start,
            Task.actual_end_time < week_end
        ).all()
        
        total = len(tasks)
        on_time = 0
        for t in tasks:
            if t.actual_end_time and t.end_time:
                try:
                    if 'T' in t.end_time:
                        deadline = datetime.fromisoformat(t.end_time.replace('Z', '+00:00').replace('+00:00', ''))
                    else:
                        deadline = datetime.strptime(t.end_time, '%Y-%m-%d %H:%M:%S')
                    if t.actual_end_time <= deadline:
                        on_time += 1
                except:
                    pass
        
        weeks.append({
            'week': f'第{4-i}周',
            'total': total,
            'on_time': on_time,
            'rate': round(on_time / total * 100, 2) if total > 0 else 0
        })
    
    return weeks


def _generate_ai_suggestions(report_data, user, ai_helper=None):
    """生成AI建议"""
    if not ai_helper or not ai_helper.api_key:
        return _get_default_suggestions(report_data)
    
    try:
        # 构建更详细的提示词
        comparison_text = ""
        if 'comparison' in report_data and report_data['comparison']:
            comp = report_data['comparison']
            tasks_change = comp['tasks']['percent']
            duration_change = comp['duration']['percent']
            comparison_text = f"""
            与上周对比：
            - 任务数量变化：{'+' if tasks_change >= 0 else ''}{tasks_change}%
            - 学习时长变化：{'+' if duration_change >= 0 else ''}{duration_change}%
            """
        
        peak_hours_text = ""
        if report_data.get('peak_hours'):
            peak_hours_text = f"最佳学习时段：{', '.join([h['label'] for h in report_data['peak_hours']])}"
        
        prompt = f"""
        你是一位专业的学习顾问，请根据以下学习数据给出个性化建议：
        
        === 本周学习概况 ===
        - 完成任务数：{report_data['total_tasks']} 个
        - 创建任务数：{report_data['total_created']} 个
        - 到期任务数：{report_data['total_due']} 个
        - 完成率：{report_data['completion_rate']}%
        - 总学习时长：{report_data['total_duration']} 分钟
        - 平均每任务时长：{report_data['avg_duration']} 分钟
        {comparison_text}
        {peak_hours_text}
        
        === 分类分布 ===
        {json.dumps(report_data['category_stats'], ensure_ascii=False, indent=2)}
        
        === 优先级分布 ===
        {json.dumps(report_data['priority_distribution'], ensure_ascii=False)}
        
        === 效率趋势（过去4周） ===
        {json.dumps(report_data['efficiency_trend'], ensure_ascii=False)}
        
        === 每日完成趋势 ===
        {json.dumps(report_data.get('daily_completion_trend', []), ensure_ascii=False)}
        
        请从以下几个维度给出建议：
        
        1. **学习总结**（一句话总结本周表现）
        2. **时间管理建议**（如何更高效利用时间）
        3. **任务规划建议**（如何更好地规划任务）
        4. **改进方向**（下周可以改进的地方）
        5. **激励话语**（一句鼓励的话）
        
        要求：
        - 每条建议控制在30字以内
        - 语气积极正面，具有指导性
        - 针对数据给出具体建议，不要泛泛而谈
        """
        
        suggestion = ai_helper.call_api(prompt)
        return suggestion
    except Exception as e:
        print(f"AI建议生成失败: {e}")
        return _get_default_suggestions(report_data)


def _get_default_suggestions(report_data):
    """默认建议（无AI时）"""
    suggestions = []
    
    # 1. 学习总结
    total = report_data['total_tasks']
    rate = report_data['completion_rate']
    
    if total == 0:
        suggestions.append("[学习总结] 本周暂无任务完成记录，下周加油！")
    elif total < 5:
        suggestions.append(f"[学习总结] 本周完成{total}个任务，建议增加学习量。")
    elif total > 20:
        suggestions.append(f"[学习总结] 本周完成{total}个任务，学习效率很高！")
    else:
        suggestions.append(f"[学习总结] 本周完成{total}个任务，保持稳定节奏。")
    
    # 2. 时间管理建议
    avg = report_data['avg_duration']
    if avg > 120:
        suggestions.append("[时间管理] 单任务耗时较长，建议拆分为小任务提高效率。")
    elif avg < 30 and total > 0:
        suggestions.append("[时间管理] 任务碎片化，建议集中处理相似任务。")
    else:
        suggestions.append("[时间管理] 任务时长分配合理，继续保持。")
    
    # 3. 任务规划建议
    if rate < 50:
        suggestions.append("[任务规划] 完成率较低，建议设定更合理的截止时间。")
    elif rate >= 80:
        suggestions.append("[任务规划] 完成率优秀，时间预估准确！")
    else:
        suggestions.append("[任务规划] 完成率良好，可适当增加挑战性任务。")
    
    # 4. 改进方向
    if 'comparison' in report_data and report_data['comparison']:
        comp = report_data['comparison']
        if comp['tasks']['change'] < 0:
            suggestions.append("[改进方向] 相比上周任务量下降，建议保持学习动力。")
        elif comp['tasks']['change'] > 0:
            suggestions.append("[改进方向] 相比上周进步明显，继续保持！")
        else:
            suggestions.append("[改进方向] 保持稳定，尝试提升学习深度。")
    else:
        suggestions.append("[改进方向] 建立固定的学习习惯，提升效率。")
    
    # 5. 激励话语
    encouragements = [
        "[激励] 每一份努力都不会白费，继续加油！",
        "[激励] 你的坚持正在创造改变！",
        "[激励] 目标在前方，坚持就是胜利！",
        "[激励] 优秀是一种习惯，保持下去！",
        "[激励] 今天的努力是明天的收获！"
    ]
    import random
    suggestions.append(random.choice(encouragements))
    
    return "\n\n".join(suggestions)


@analysis_bp.route('/api/analysis/monthly-report', methods=['GET'])
@require_user
def generate_monthly_report(user):
    """生成每月学习报告"""
    try:
        month_start = datetime.now() - timedelta(days=30)
        
        completed_tasks = Task.query.filter(
            Task.user_id == user.id,
            Task.is_completed == 1,
            Task.actual_end_time >= month_start
        ).all()
        
        total_tasks = len(completed_tasks)
        total_duration = sum([t.actual_duration or 0 for t in completed_tasks])
        
        # 每周分布
        weekly_distribution = []
        for i in range(4):
            week_start = datetime.now() - timedelta(days=(i+1)*7)
            week_end = datetime.now() - timedelta(days=i*7)
            
            week_tasks = [t for t in completed_tasks if week_start <= t.actual_end_time < week_end] if completed_tasks else []
            weekly_distribution.append({
                'week': f'第{4-i}周',
                'tasks': len(week_tasks),
                'duration': sum([t.actual_duration or 0 for t in week_tasks])
            })
        
        # 分类统计
        category_stats = {}
        for task in completed_tasks:
            cat = task.category or '未分类'
            if cat not in category_stats:
                category_stats[cat] = {'count': 0, 'duration': 0}
            category_stats[cat]['count'] += 1
            category_stats[cat]['duration'] += task.actual_duration or 0
        
        return jsonify({
            'success': True,
            'report': {
                'total_tasks': total_tasks,
                'total_duration': total_duration,
                'avg_daily_duration': round(total_duration / 30, 1),
                'weekly_distribution': weekly_distribution,
                'category_stats': category_stats,
                'month_start': month_start.strftime('%Y-%m-%d'),
                'month_end': datetime.now().strftime('%Y-%m-%d')
            }
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'生成月报失败: {str(e)}'
        }), 500


@analysis_bp.route('/api/analysis/learning-insights', methods=['GET'])
@require_user
def get_learning_insights(user):
    """获取学习洞察"""
    try:
        # 获取最近30天的数据
        month_start = datetime.now() - timedelta(days=30)
        
        all_tasks = Task.query.filter(
            Task.user_id == user.id,
            Task.created_at >= month_start
        ).all()
        
        completed_tasks = [t for t in all_tasks if t.is_completed == 1]
        
        # 最佳学习时段
        hourly_distribution = [0] * 24
        for task in completed_tasks:
            if task.actual_start_time:
                hourly_distribution[task.actual_start_time.hour] += 1
        
        peak_hours = sorted(range(24), key=lambda h: hourly_distribution[h], reverse=True)[:3]
        peak_hours = [h for h in peak_hours if hourly_distribution[h] > 0]
        
        # 任务完成率
        completion_rate = len(completed_tasks) / len(all_tasks) * 100 if all_tasks else 0
        
        # 平均完成时间
        avg_completion_time = sum([t.actual_duration or 0 for t in completed_tasks]) / len(completed_tasks) if completed_tasks else 0
        
        # 高频分类
        category_counts = {}
        for task in completed_tasks:
            cat = task.category or '未分类'
            category_counts[cat] = category_counts.get(cat, 0) + 1
        
        top_categories = sorted(category_counts.items(), key=lambda x: x[1], reverse=True)[:3]
        
        return jsonify({
            'success': True,
            'insights': {
                'peak_learning_hours': peak_hours,
                'completion_rate': round(completion_rate, 1),
                'avg_completion_time': round(avg_completion_time, 1),
                'total_tasks_created': len(all_tasks),
                'total_tasks_completed': len(completed_tasks),
                'top_categories': [{'category': c, 'count': n} for c, n in top_categories],
                'hourly_distribution': hourly_distribution
            }
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'获取洞察失败: {str(e)}'
        }), 500
