"""
AI功能路由（精简版）
其他AI功能已拆分到独立模块：
- ai_duration_routes.py: 任务时长预估
- ai_deadline_routes.py: 智能截止时间生成
- ai_study_routes.py: 学习计划
- ai_quota_routes.py: AI额度管理
"""

from flask import Blueprint, jsonify, request

from config import Config
from extensions import db
from models.task import Task
from utils.ai_helper import AIHelper
from utils.user_auth import require_user

ai_bp = Blueprint('ai', __name__)


def get_ai_helper(user=None):
    """
    获取AI助手实例，优先级：
    1. 请求头中的API Key
    2. 用户数据库中存储的API Key
    3. 系统默认API Key
    """
    from models.task import User
    
    api_key = request.headers.get('X-AI-API-Key', '')
    if api_key:
        return AIHelper(api_key), 'user_header'
    
    if user:
        user_obj = User.query.get(user.id) if hasattr(user, 'id') else User.query.get(user)
        if user_obj and user_obj.ai_api_key:
            return AIHelper(user_obj.ai_api_key), 'user_db'
    
    return AIHelper(Config.TONGYI_API_KEY), 'system'


@ai_bp.route('/api/ai/schedule', methods=['POST'])
@require_user
def ai_schedule(user):
    """AI智能排期"""
    try:
        ai_helper = get_ai_helper()
        
        data = request.get_json()
        task_ids = data.get('task_ids', [])

        if not task_ids:
            return jsonify({"success": False, "message": "请选择至少一个任务"}), 400

        tasks = Task.query.filter(Task.id.in_(task_ids), Task.user_id == user.id).all()
        if not tasks:
            return jsonify({"success": False, "message": "未找到任务"}), 404

        tasks_list = [
            f"{i+1}. {t.title}（{t.category}）"
            for i, t in enumerate(tasks)
        ]
        suggestion = ai_helper[0].intelligent_scheduling("\n".join(tasks_list))

        return jsonify({"success": True, "suggestion": suggestion})

    except Exception as e:
        return jsonify({"success": False, "message": f"AI服务错误: {str(e)}"}), 500


@ai_bp.route('/api/ai/priority', methods=['POST'])
@require_user
def ai_priority(user):
    """AI评估任务优先级"""
    try:
        ai_helper = get_ai_helper()
        
        data = request.get_json()
        task_id = data.get('task_id')

        if not task_id:
            return jsonify({"success": False, "message": "请提供任务ID"}), 400

        task = Task.query.filter_by(id=task_id, user_id=user.id).first()
        if not task:
            return jsonify({"success": False, "message": "任务不存在"}), 404

        result = ai_helper[0].evaluate_priority(
            task.title, task.description, task.end_time
        )

        task.priority = result.get('priority', 0)
        task.ai_suggestion = result.get('analysis', '')
        db.session.commit()

        return jsonify({
            "success": True,
            "priority": result.get('priority'),
            "urgency": result.get('urgency'),
            "importance": result.get('importance'),
            "analysis": result.get('analysis')
        })

    except Exception as e:
        return jsonify({"success": False, "message": f"AI服务错误: {str(e)}"}), 500


@ai_bp.route('/api/ai/priority/batch', methods=['POST'])
@require_user
def ai_priority_batch(user):
    """AI批量评估任务优先级"""
    try:
        ai_helper = get_ai_helper()
        
        data = request.get_json()
        task_ids = data.get('task_ids', [])

        if not task_ids:
            return jsonify({"success": False, "message": "请选择至少一个任务"}), 400

        tasks = Task.query.filter(Task.id.in_(task_ids), Task.user_id == user.id).all()
        results = []

        for task in tasks:
            result = ai_helper[0].evaluate_priority(
                task.title, task.description, task.end_time
            )
            task.priority = result.get('priority', 0)
            task.ai_suggestion = result.get('analysis', '')

            results.append({
                'task_id': task.id,
                'title': task.title,
                'priority': result.get('priority'),
                'analysis': result.get('analysis')
            })

        db.session.commit()

        return jsonify({
            "success": True,
            "results": results,
            "evaluated_count": len(results)
        })

    except Exception as e:
        return jsonify({"success": False, "message": f"AI服务错误: {str(e)}"}), 500
