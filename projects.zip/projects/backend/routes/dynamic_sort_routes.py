"""
动态排序路由
提供自动排序、权重调整、用户反馈等API
"""
from flask import Blueprint, request, jsonify, g
from functools import wraps
import json
import logging

from utils.dynamic_weight_adjuster import DynamicWeightAdjuster, get_weight_adjuster
from services.auto_sort_service import AutoSortService, get_auto_sort_service
from database.db_manager import get_db

logger = logging.getLogger(__name__)

dynamic_sort_bp = Blueprint('dynamic_sort', __name__, url_prefix='/api/sort')


def login_required(f):
    """登录验证装饰器"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not g.get('user_id'):
            return jsonify({'success': False, 'message': '请先登录'}), 401
        return f(*args, **kwargs)
    return decorated_function


# ==================== 自动排序配置 ====================

@dynamic_sort_bp.route('/config', methods=['GET'])
@login_required
def get_sort_config():
    """获取自动排序配置"""
    try:
        service = get_auto_sort_service(get_db())
        config = service.get_config(g.user_id)
        
        return jsonify({
            'success': True,
            'config': config
        })
    except Exception as e:
        logger.error(f"获取排序配置失败: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500


@dynamic_sort_bp.route('/config', methods=['POST'])
@login_required
def update_sort_config():
    """更新自动排序配置"""
    try:
        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'message': '请求数据为空'}), 400
        
        service = get_auto_sort_service(get_db())
        result = service.update_config(g.user_id, data)
        
        if result.get('success'):
            return jsonify(result)
        else:
            return jsonify(result), 400
            
    except Exception as e:
        logger.error(f"更新排序配置失败: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500


# ==================== 自动排序触发 ====================

@dynamic_sort_bp.route('/auto', methods=['POST'])
@login_required
def trigger_auto_sort():
    """
    手动触发自动排序
    
    请求体:
    {
        "reason": "manual"  // 可选，默认为 manual
    }
    """
    try:
        data = request.get_json() or {}
        reason = data.get('reason', 'manual')
        
        import asyncio
        service = get_auto_sort_service(get_db())
        
        # 使用 asyncio.run 运行异步函数
        result = asyncio.run(service.sort_user_tasks(g.user_id, reason))
        
        if result.get('success'):
            return jsonify({
                'success': True,
                'message': result.get('message', '排序完成'),
                'data': {
                    'task_count': result.get('task_count', 0),
                    'ai_mode': result.get('ai_mode', False),
                    'weights_adjusted': result.get('weights_adjusted', 0),
                    'reason': reason
                }
            })
        else:
            return jsonify({
                'success': False,
                'message': result.get('message', '排序失败')
            }), 400
            
    except Exception as e:
        logger.error(f"触发自动排序失败: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500


@dynamic_sort_bp.route('/history', methods=['GET'])
@login_required
def get_sort_history():
    """获取自动排序历史"""
    try:
        limit = request.args.get('limit', 30, type=int)
        
        service = get_auto_sort_service(get_db())
        history = service.get_sort_history(g.user_id, limit)
        
        return jsonify({
            'success': True,
            'history': history,
            'total': len(history)
        })
    except Exception as e:
        logger.error(f"获取排序历史失败: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500


# ==================== 权重调整 ====================

@dynamic_sort_bp.route('/weights/auto-adjust', methods=['POST'])
@login_required
def auto_adjust_weights():
    """
    手动触发权重自动调整
    
    基于用户历史执行数据，自动优化权重配置
    """
    try:
        adjuster = get_weight_adjuster(get_db())
        result = adjuster.auto_adjust_weights(g.user_id)
        
        if result.get('success'):
            return jsonify({
                'success': True,
                'message': result.get('message'),
                'data': {
                    'adjustments': result.get('adjustments', []),
                    'weights': result.get('weights', {})
                }
            })
        else:
            return jsonify({
                'success': False,
                'message': result.get('message')
            }), 400
            
    except Exception as e:
        logger.error(f"自动调整权重失败: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500


@dynamic_sort_bp.route('/weights/adjustment-history', methods=['GET'])
@login_required
def get_weight_adjustment_history():
    """获取权重调整历史"""
    try:
        limit = request.args.get('limit', 50, type=int)
        
        adjuster = get_weight_adjuster(get_db())
        history = adjuster.get_adjustment_history(g.user_id, limit)
        
        return jsonify({
            'success': True,
            'history': history,
            'total': len(history)
        })
    except Exception as e:
        logger.error(f"获取权重调整历史失败: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500


# ==================== 用户反馈 ====================

@dynamic_sort_bp.route('/feedback', methods=['POST'])
@login_required
def submit_sort_feedback():
    """
    提交排序反馈
    
    请求体:
    {
        "feedback_type": "positive" | "negative" | "reorder",
        "task_id": 123,  // 可选
        "details": "说明文字"  // 可选
    }
    """
    try:
        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'message': '请求数据为空'}), 400
        
        feedback_type = data.get('feedback_type')
        task_id = data.get('task_id')
        details = data.get('details')
        
        if feedback_type not in ['positive', 'negative', 'reorder']:
            return jsonify({
                'success': False, 
                'message': 'feedback_type 必须是 positive, negative 或 reorder'
            }), 400
        
        adjuster = get_weight_adjuster(get_db())
        adjustments = adjuster.process_user_feedback(
            g.user_id, feedback_type, task_id, details
        )
        
        return jsonify({
            'success': True,
            'message': '反馈已记录',
            'data': {
                'feedback_type': feedback_type,
                'adjustments_made': len(adjustments),
                'adjustments': [
                    {
                        'dimension': a.dimension,
                        'dimension_name': adjuster.DIMENSION_MAP.get(a.dimension, a.dimension),
                        'old_value': a.old_value,
                        'new_value': a.new_value,
                        'reason': a.reason
                    }
                    for a in adjustments
                ]
            }
        })
        
    except Exception as e:
        logger.error(f"提交反馈失败: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500


# ==================== 执行反馈 ====================

@dynamic_sort_bp.route('/execution-feedback', methods=['POST'])
@login_required
def submit_execution_feedback():
    """
    提交任务执行反馈
    
    请求体:
    {
        "task_id": 123,
        "actual_duration": 60,  // 实际耗时（分钟）
        "estimated_duration": 45,  // 预估耗时（分钟）
        "execution_order": 3,  // 实际执行顺序
        "ai_recommended_order": 2,  // AI推荐顺序
        "on_time": true,  // 是否按时完成
        "dimension_scores": {  // 各维度分数
            "urgency": 0.8,
            "importance": 0.7,
            ...
        }
    }
    """
    try:
        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'message': '请求数据为空'}), 400
        
        task_id = data.get('task_id')
        if not task_id:
            return jsonify({'success': False, 'message': 'task_id 不能为空'}), 400
        
        # 保存执行反馈
        db = get_db()
        cursor = db.cursor()
        
        cursor.execute("""
            INSERT OR REPLACE INTO sort_execution_feedback 
            (task_id, user_id, dimension_scores, actual_duration, estimated_duration,
             execution_order, ai_recommended_order, on_time, completed_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
        """, (
            task_id,
            g.user_id,
            json.dumps(data.get('dimension_scores', {})),
            data.get('actual_duration'),
            data.get('estimated_duration'),
            data.get('execution_order'),
            data.get('ai_recommended_order'),
            data.get('on_time', False)
        ))
        
        db.commit()
        
        # 检查是否需要触发权重调整
        significantly_delayed = (
            data.get('actual_duration', 0) > data.get('estimated_duration', 0) * 1.5
        )
        
        return jsonify({
            'success': True,
            'message': '执行反馈已记录',
            'data': {
                'significantly_delayed': significantly_delayed,
                'suggest_reorder': significantly_delayed
            }
        })
        
    except Exception as e:
        logger.error(f"提交执行反馈失败: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500


# ==================== 分析数据 ====================

@dynamic_sort_bp.route('/analysis/patterns', methods=['GET'])
@login_required
def get_execution_patterns():
    """获取执行模式分析"""
    try:
        days = request.args.get('days', 30, type=int)
        
        adjuster = get_weight_adjuster(get_db())
        patterns = adjuster.analyze_execution_patterns(g.user_id, days)
        
        return jsonify({
            'success': True,
            'data': {
                'patterns': {
                    dim: {
                        'dimension': p.dimension,
                        'dimension_name': adjuster.DIMENSION_MAP.get(p.dimension, p.dimension),
                        'trend': p.trend,
                        'avg_deviation': p.avg_deviation,
                        'sample_count': p.sample_count,
                        'recommended_adjustment': p.recommended_adjustment
                    }
                    for dim, p in patterns.items()
                },
                'total_dimensions': len(patterns)
            }
        })
        
    except Exception as e:
        logger.error(f"获取执行模式失败: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500


@dynamic_sort_bp.route('/analysis/summary', methods=['GET'])
@login_required
def get_sort_analysis_summary():
    """获取排序分析汇总"""
    try:
        db = get_db()
        cursor = db.cursor()
        
        # 获取执行统计
        cursor.execute("""
            SELECT 
                COUNT(*) as total_tasks,
                SUM(CASE WHEN on_time = 1 THEN 1 ELSE 0 END) as on_time_count,
                AVG(actual_duration) as avg_duration,
                AVG(CASE WHEN estimated_duration > 0 
                    THEN (actual_duration - estimated_duration) * 1.0 / estimated_duration 
                    ELSE 0 END) as avg_time_deviation
            FROM sort_execution_feedback
            WHERE user_id = ? AND completed_at >= datetime('now', '-30 days')
        """, (g.user_id,))
        
        row = cursor.fetchone()
        
        # 获取反馈统计
        cursor.execute("""
            SELECT 
                feedback_type,
                COUNT(*) as count
            FROM sort_user_feedback
            WHERE user_id = ? AND created_at >= datetime('now', '-30 days')
            GROUP BY feedback_type
        """, (g.user_id,))
        
        feedback_stats = {row[0]: row[1] for row in cursor.fetchall()}
        
        # 获取排序历史统计
        cursor.execute("""
            SELECT 
                COUNT(*) as total_sorts,
                SUM(CASE WHEN ai_mode = 1 THEN 1 ELSE 0 END) as ai_sorts
            FROM auto_sort_history
            WHERE user_id = ? AND created_at >= datetime('now', '-30 days')
        """, (g.user_id,))
        
        sort_row = cursor.fetchone()
        
        return jsonify({
            'success': True,
            'data': {
                'execution_stats': {
                    'total_tasks': row[0] or 0,
                    'on_time_count': row[1] or 0,
                    'on_time_rate': round((row[1] or 0) / (row[0] or 1) * 100, 1),
                    'avg_duration': round(row[2] or 0, 1),
                    'avg_time_deviation': round((row[3] or 0) * 100, 1)
                },
                'feedback_stats': feedback_stats,
                'sort_stats': {
                    'total_sorts': sort_row[0] or 0,
                    'ai_sorts': sort_row[1] or 0,
                    'local_sorts': (sort_row[0] or 0) - (sort_row[1] or 0)
                }
            }
        })
        
    except Exception as e:
        logger.error(f"获取分析汇总失败: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500


# ==================== 状态检查 ====================

@dynamic_sort_bp.route('/status', methods=['GET'])
@login_required
def get_dynamic_sort_status():
    """获取动态排序状态"""
    try:
        db = get_db()
        cursor = db.cursor()
        
        # 获取今日排序次数
        cursor.execute("""
            SELECT COUNT(*) FROM auto_sort_history
            WHERE user_id = ? AND created_at >= date('now') AND reason != 'manual'
        """, (g.user_id,))
        
        today_sorts = cursor.fetchone()[0]
        
        # 获取最近排序时间
        cursor.execute("""
            SELECT created_at, reason FROM auto_sort_history
            WHERE user_id = ?
            ORDER BY created_at DESC
            LIMIT 1
        """, (g.user_id,))
        
        last_sort = cursor.fetchone()
        
        # 获取配置
        service = get_auto_sort_service(db)
        config = service.get_config(g.user_id)
        
        return jsonify({
            'success': True,
            'data': {
                'auto_sort_enabled': config.get('auto_sort_enabled', True),
                'today_auto_sorts': today_sorts,
                'max_sorts_per_day': config.get('max_sort_per_day', 10),
                'last_sort': {
                    'time': last_sort[0] if last_sort else None,
                    'reason': last_sort[1] if last_sort else None
                } if last_sort else None,
                'daily_sort_time': config.get('daily_sort_time', '08:00'),
                'next_scheduled_sort': _calculate_next_sort_time(config.get('daily_sort_time', '08:00'))
            }
        })
        
    except Exception as e:
        logger.error(f"获取状态失败: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500


def _calculate_next_sort_time(daily_time: str) -> str:
    """计算下次排序时间"""
    from datetime import datetime, timedelta
    
    now = datetime.now()
    target = datetime.strptime(daily_time, '%H:%M').replace(
        year=now.year, month=now.month, day=now.day
    )
    
    if target <= now:
        target += timedelta(days=1)
    
    return target.isoformat()
