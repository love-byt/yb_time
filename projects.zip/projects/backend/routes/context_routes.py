"""
深度上下文逻辑感知系统 API 路由 v2.0
提供对话管理、意图识别、任务依赖管理等功能（优化版本）
"""

from flask import Blueprint, request, jsonify, Response, stream_with_context
from datetime import datetime
import json
import asyncio

from utils.user_auth import require_user
from utils.context_inference import ContextInferenceEngine
from utils.dialogue_history import DialogueHistoryStore, DialogueSession, Message, MessageType
from utils.task_dependency import TaskDependencyGraph
from utils.intent_recognition import IntentClassifier, EntityExtractor, UserIntent

# 导入 v2 优化模块（如果可用）
try:
    from utils.intent_recognition_v2 import IntentRecognitionEngine, IntentResult
    INTENT_V2_AVAILABLE = True
    print("[深度上下文] 意图识别 v2.0 已加载")
except ImportError as e:
    INTENT_V2_AVAILABLE = False
    print(f"[深度上下文] 意图识别 v2.0 不可用: {e}")

try:
    from utils.hierarchical_context import HierarchicalContextManager, RetrievedContext
    CONTEXT_V2_AVAILABLE = True
    print("[深度上下文] 分层上下文管理已加载")
except ImportError as e:
    CONTEXT_V2_AVAILABLE = False
    print(f"[深度上下文] 分层上下文管理不可用: {e}")

try:
    from utils.behavior_tree_dialogue import HierarchicalDialogueManager, NodeStatus
    DIALOGUE_V2_AVAILABLE = True
    print("[深度上下文] 行为树对话管理已加载")
except ImportError as e:
    DIALOGUE_V2_AVAILABLE = False
    print(f"[深度上下文] 行为树对话管理不可用: {e}")

try:
    from utils.intelligent_dependency import (
        IntelligentDependencyManager, DependencySuggestion,
        ValidationResult, ExecutionConstraints, OptimizedPlan
    )
    DEPENDENCY_V2_AVAILABLE = True
    print("[深度上下文] 智能依赖管理已加载")
except ImportError as e:
    DEPENDENCY_V2_AVAILABLE = False
    print(f"[深度上下文] 智能依赖管理不可用: {e}")

try:
    from utils.context_performance import PerformanceOptimizer, timed
    PERFORMANCE_AVAILABLE = True
    print("[深度上下文] 性能优化器已加载")
except ImportError as e:
    PERFORMANCE_AVAILABLE = False
    print(f"[深度上下文] 性能优化器不可用: {e}")

context_bp = Blueprint('context', __name__)

# 全局引擎缓存
_engines: dict = {}


def get_engine(user_id: str) -> ContextInferenceEngine:
    """获取或创建用户的上下文推理引擎"""
    if user_id not in _engines:
        from flask import current_app
        import os
        # 使用应用的数据库目录
        db_path = os.path.join(current_app.instance_path, 'dialogue_history.db')
        _engines[user_id] = ContextInferenceEngine(user_id, db_path)
    return _engines[user_id]


# ==================== 对话管理接口 ====================

@context_bp.route('/api/context/dialogue', methods=['POST'])
@require_user
def process_dialogue(user):
    """
    处理对话消息
    
    请求体:
    {
        "message": "用户输入的消息"
    }
    
    返回:
    {
        "success": true,
        "response": {
            "message": "AI回复",
            "intent": "create_task",
            "confidence": 0.95,
            "entities": {...},
            "current_state": "idle"
        }
    }
    """
    try:
        data = request.get_json()
        user_message = data.get('message', '').strip()
        
        if not user_message:
            return jsonify({
                "success": False,
                "error": "消息不能为空"
            }), 400
        
        # 获取用户的推理引擎
        engine = get_engine(user.id)
        
        # 处理消息
        response = engine.process_message(user_message)
        
        return jsonify({
            "success": True,
            "response": response
        })
        
    except Exception as e:
        return jsonify({
            "success": False,
            "error": f"处理对话失败: {str(e)}"
        }), 500


@context_bp.route('/api/context/dialogue/history', methods=['GET'])
@require_user
def get_dialogue_history(user):
    """
    获取对话历史
    
    查询参数:
    - limit: 返回消息数量限制（默认20）
    
    返回:
    {
        "success": true,
        "history": {
            "session_id": "...",
            "message_count": 10,
            "current_state": "idle",
            "context_summary": "...",
            "messages": [...]
        }
    }
    """
    try:
        limit = request.args.get('limit', 20, type=int)
        
        engine = get_engine(user.id)
        context = engine.get_dialogue_context()
        
        # 限制消息数量
        if 'recent_messages' in context:
            context['messages'] = context['recent_messages'][-limit:]
            del context['recent_messages']
        
        return jsonify({
            "success": True,
            "history": context
        })
        
    except Exception as e:
        return jsonify({
            "success": False,
            "error": f"获取对话历史失败: {str(e)}"
        }), 500


@context_bp.route('/api/context/dialogue/reset', methods=['POST'])
@require_user
def reset_dialogue(user):
    """
    重置对话状态
    
    返回:
    {
        "success": true,
        "message": "对话已重置"
    }
    """
    try:
        engine = get_engine(user.id)
        engine.state_machine.reset()
        engine.session.state = "idle"
        engine.session.messages = []
        
        # 保存重置后的会话
        engine.history_store.save_session(engine.session)
        
        return jsonify({
            "success": True,
            "message": "对话已重置"
        })
        
    except Exception as e:
        return jsonify({
            "success": False,
            "error": f"重置对话失败: {str(e)}"
        }), 500


# ==================== 意图识别接口 ====================

@context_bp.route('/api/context/intent', methods=['POST'])
@require_user
def classify_intent(user):
    """
    识别用户意图
    
    请求体:
    {
        "text": "用户输入文本"
    }
    
    返回:
    {
        "success": true,
        "intent": {
            "type": "create_task",
            "confidence": 0.95
        },
        "entities": [
            {"type": "priority", "value": "high", ...}
        ]
    }
    """
    try:
        data = request.get_json()
        text = data.get('text', '').strip()
        
        if not text:
            return jsonify({
                "success": False,
                "error": "文本不能为空"
            }), 400
        
        # 意图分类
        classifier = IntentClassifier()
        intent, confidence = classifier.classify(text)
        
        # 实体提取
        extractor = EntityExtractor()
        entities = extractor.extract(text)
        
        return jsonify({
            "success": True,
            "intent": {
                "type": intent.value,
                "confidence": confidence
            },
            "entities": [
                {
                    "type": e.type,
                    "value": str(e.value),
                    "raw_text": e.raw_text,
                    "confidence": e.confidence
                }
                for e in entities
            ]
        })
        
    except Exception as e:
        return jsonify({
            "success": False,
            "error": f"意图识别失败: {str(e)}"
        }), 500


# ==================== 任务依赖管理接口 ====================

@context_bp.route('/api/context/dependencies', methods=['GET'])
@require_user
def get_dependencies(user):
    """
    获取任务依赖图
    
    返回:
    {
        "success": true,
        "dependencies": {
            "nodes": {...},
            "topological_order": [...]
        }
    }
    """
    try:
        engine = get_engine(user.id)
        
        return jsonify({
            "success": True,
            "dependencies": engine.task_graph.to_dict()
        })
        
    except Exception as e:
        return jsonify({
            "success": False,
            "error": f"获取依赖图失败: {str(e)}"
        }), 500


@context_bp.route('/api/context/dependencies', methods=['POST'])
@require_user
def add_dependency(user):
    """
    添加任务依赖关系
    
    请求体:
    {
        "from_task": "任务A的ID",
        "to_task": "任务B的ID"
    }
    
    说明: 表示 from_task 依赖于 to_task（to_task 必须在 from_task 之前完成）
    
    返回:
    {
        "success": true,
        "message": "依赖关系添加成功"
    }
    """
    try:
        data = request.get_json()
        from_task = data.get('from_task')
        to_task = data.get('to_task')
        
        if not from_task or not to_task:
            return jsonify({
                "success": False,
                "error": "缺少任务ID参数"
            }), 400
        
        engine = get_engine(user.id)
        engine.task_graph.add_dependency(from_task, to_task)
        
        return jsonify({
            "success": True,
            "message": f"已设置 {to_task} 为 {from_task} 的前置任务"
        })
        
    except ValueError as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 400
    except Exception as e:
        return jsonify({
            "success": False,
            "error": f"添加依赖失败: {str(e)}"
        }), 500


@context_bp.route('/api/context/dependencies/execution-plan', methods=['GET'])
@require_user
def get_execution_plan(user):
    """
    获取任务执行计划
    
    返回:
    {
        "success": true,
        "plan": {
            "execution_order": [...],
            "critical_path": [...],
            "parallel_groups": [...],
            "total_tasks": 5
        }
    }
    """
    try:
        engine = get_engine(user.id)
        plan = engine.get_task_execution_plan()
        
        if 'error' in plan:
            return jsonify({
                "success": False,
                "error": plan['error'],
                "cycles": plan.get('cycles', [])
            }), 400
        
        return jsonify({
            "success": True,
            "plan": plan
        })
        
    except Exception as e:
        return jsonify({
            "success": False,
            "error": f"获取执行计划失败: {str(e)}"
        }), 500


@context_bp.route('/api/context/dependencies/detect-cycles', methods=['GET'])
@require_user
def detect_cycles(user):
    """
    检测依赖图中的循环
    
    返回:
    {
        "success": true,
        "cycles": [["task1", "task2", "task1"]],
        "has_cycles": true
    }
    """
    try:
        engine = get_engine(user.id)
        cycles = engine.task_graph.detect_cycles()
        
        return jsonify({
            "success": True,
            "cycles": cycles,
            "has_cycles": len(cycles) > 0
        })
        
    except Exception as e:
        return jsonify({
            "success": False,
            "error": f"检测循环失败: {str(e)}"
        }), 500


# ==================== 会话管理接口 ====================

@context_bp.route('/api/context/sessions', methods=['GET'])
@require_user
def list_sessions(user):
    """
    列出用户的所有会话
    
    返回:
    {
        "success": true,
        "sessions": [
            {"session_id": "...", "created_at": "...", "message_count": 10}
        ]
    }
    """
    try:
        # 这里简化实现，实际应从数据库查询
        engine = get_engine(user.id)
        
        return jsonify({
            "success": True,
            "sessions": [
                {
                    "session_id": engine.session_id,
                    "created_at": engine.session.created_at.isoformat() if engine.session.created_at else None,
                    "updated_at": engine.session.updated_at.isoformat() if engine.session.updated_at else None,
                    "message_count": len(engine.session.messages),
                    "state": engine.session.state
                }
            ]
        })
        
    except Exception as e:
        return jsonify({
            "success": False,
            "error": f"获取会话列表失败: {str(e)}"
        }), 500


# ==================== 健康检查接口 ====================

@context_bp.route('/api/context/health', methods=['GET'])
def context_health():
    """
    深度上下文逻辑感知系统健康检查
    
    返回:
    {
        "status": "healthy",
        "modules": {
            "dialogue_history": true,
            "task_dependency": true,
            "intent_recognition": true,
            "context_inference": true
        }
    }
    """
    try:
        # 检查各模块是否可用
        modules = {
            "dialogue_history": True,
            "task_dependency": True,
            "intent_recognition": True,
            "context_inference": True
        }
        
        return jsonify({
            "status": "healthy",
            "modules": modules,
            "timestamp": datetime.now().isoformat()
        })
        
    except Exception as e:
        return jsonify({
            "status": "unhealthy",
            "error": str(e)
        }), 500


# ==================== v2.0 优化接口 ====================

@context_bp.route('/api/context/v2/dialogue', methods=['POST'])
@require_user
def process_dialogue_v2(user):
    """
    处理对话消息 v2.0（行为树增强版本）
    
    请求体:
    {
        "message": "用户输入的消息",
        "session_id": "会话ID（可选）"
    }
    
    返回:
    {
        "success": true,
        "response": {
            "message": "AI回复",
            "intent": "create_task",
            "intent_confidence": 0.95,
            "action": "create_task",
            "action_data": {...},
            "awaiting": null
        },
        "version": "2.0"
    }
    """
    try:
        if not DIALOGUE_V2_AVAILABLE:
            return jsonify({
                "success": False,
                "error": "v2.0 对话管理模块不可用",
                "fallback_available": True
            }), 503
        
        data = request.get_json()
        message = data.get('message', '').strip()
        session_id = data.get('session_id')
        
        if not message:
            return jsonify({
                "success": False,
                "error": "消息内容不能为空"
            }), 400
        
        # 获取或创建会话
        engine = get_engine(user.id)
        session = None
        if session_id:
            session = engine.dialogue_store.get_session(session_id)
            if session is None:
                return jsonify({
                    "success": False,
                    "error": f"会话 {session_id} 不存在"
                }), 404
        else:
            session = engine.dialogue_store.create_session(user.id)
        
        # 使用 v2 对话管理器处理
        result = asyncio.run(dialogue_manager_v2.process(message, session))
        
        # 保存消息到历史
        engine.dialogue_store.add_message(
            session_id=session.session_id,
            role="user",
            content=message,
            intent=result.get('intent')
        )
        
        if result.get('response'):
            engine.dialogue_store.add_message(
                session_id=session.session_id,
                role="assistant",
                content=result['response']
            )
        
        return jsonify({
            "success": True,
            "response": result,
            "session_id": session.session_id,
            "version": "2.0"
        })
        
    except Exception as e:
        import traceback
        print(f"[ERROR] v2 对话处理失败: {e}")
        print(traceback.format_exc())
        return jsonify({
            "success": False,
            "error": f"处理失败: {str(e)}"
        }), 500


@context_bp.route('/api/context/v2/intent', methods=['POST'])
@require_user
def recognize_intent_v2(user):
    """
    意图识别 v2.0（混合架构版本）
    
    请求体:
    {
        "text": "用户输入文本",
        "session_id": "会话ID（可选，用于上下文增强）"
    }
    
    返回:
    {
        "success": true,
        "result": {
            "intent": "create_task",
            "confidence": 0.92,
            "candidates": [
                {"intent": "create_task", "score": 0.92},
                {"intent": "update_task", "score": 0.05}
            ],
            "reasoning": "规则匹配: create_task(0.85) | 语义相似: create_task(0.90)"
        },
        "version": "2.0"
    }
    """
    try:
        if not INTENT_V2_AVAILABLE:
            return jsonify({
                "success": False,
                "error": "v2.0 意图识别模块不可用",
                "fallback_available": True
            }), 503
        
        data = request.get_json()
        text = data.get('text', '').strip()
        session_id = data.get('session_id')
        
        if not text:
            return jsonify({
                "success": False,
                "error": "文本内容不能为空"
            }), 400
        
        # 获取会话（用于上下文增强）
        session = None
        if session_id:
            engine = get_engine(user.id)
            session = engine.dialogue_store.get_session(session_id)
        
        # 使用 v2 意图引擎
        import asyncio
        result = asyncio.run(intent_engine.recognize(text, session))
        
        return jsonify({
            "success": True,
            "result": {
                "intent": result.intent.value,
                "confidence": result.confidence,
                "candidates": [
                    {"intent": i.value, "score": s}
                    for i, s in result.candidates[:5]
                ],
                "reasoning": result.reasoning,
                "context_features": result.context_features
            },
            "version": "2.0"
        })
        
    except Exception as e:
        import traceback
        print(f"[ERROR] v2 意图识别失败: {e}")
        print(traceback.format_exc())
        return jsonify({
            "success": False,
            "error": f"识别失败: {str(e)}"
        }), 500


@context_bp.route('/api/context/v2/dependencies/discover', methods=['POST'])
@require_user
def discover_dependencies_v2(user):
    """
    智能依赖发现 v2.0
    
    请求体:
    {
        "task_id": "目标任务ID",
        "context": "对话上下文（可选）"
    }
    
    返回:
    {
        "success": true,
        "suggestions": [
            {
                "source": "task_1",
                "target": "task_2",
                "type": "semantic",
                "confidence": 0.85,
                "reason": "语义相似度: 0.82，分析为semantic依赖"
            }
        ],
        "version": "2.0"
    }
    """
    try:
        if not DEPENDENCY_V2_AVAILABLE:
            return jsonify({
                "success": False,
                "error": "v2.0 智能依赖管理模块不可用",
                "fallback_available": True
            }), 503
        
        data = request.get_json()
        task_id = data.get('task_id')
        context = data.get('context', '')
        
        if not task_id:
            return jsonify({
                "success": False,
                "error": "缺少任务ID"
            }), 400
        
        # 获取任务信息（这里简化实现，实际应从任务服务获取）
        # TODO: 集成任务服务获取任务详情
        target_task = {"id": task_id, "title": "示例任务", "description": ""}
        all_tasks = [target_task]  # 简化
        
        # 使用 v2 依赖管理器
        import asyncio
        suggestions = asyncio.run(
            dependency_manager.discover_dependencies(
                target_task, all_tasks, context, user.id
            )
        )
        
        return jsonify({
            "success": True,
            "suggestions": [
                {
                    "source": s.source,
                    "target": s.target,
                    "type": s.type.value,
                    "confidence": s.confidence,
                    "reason": s.reason
                }
                for s in suggestions[:10]
            ],
            "version": "2.0"
        })
        
    except Exception as e:
        import traceback
        print(f"[ERROR] v2 依赖发现失败: {e}")
        print(traceback.format_exc())
        return jsonify({
            "success": False,
            "error": f"发现失败: {str(e)}"
        }), 500


@context_bp.route('/api/context/v2/dependencies/optimize', methods=['POST'])
@require_user
def optimize_execution_plan_v2(user):
    """
    执行计划优化 v2.0
    
    请求体:
    {
        "task_ids": ["task_1", "task_2", ...],
        "constraints": {
            "max_parallel_tasks": 3,
            "balance_workload": true
        }
    }
    
    返回:
    {
        "success": true,
        "plan": {
            "execution_order": ["task_2", "task_1", "task_3"],
            "critical_path": ["task_2", "task_1"],
            "parallel_groups": [["task_2"], ["task_1", "task_3"]],
            "estimated_completion": "2h 30m",
            "suggestions": ["关键路径较长，考虑分解或并行化"]
        },
        "version": "2.0"
    }
    """
    try:
        if not DEPENDENCY_V2_AVAILABLE:
            return jsonify({
                "success": False,
                "error": "v2.0 智能依赖管理模块不可用",
                "fallback_available": True
            }), 503
        
        data = request.get_json()
        task_ids = data.get('task_ids', [])
        constraints_data = data.get('constraints', {})
        
        if not task_ids:
            return jsonify({
                "success": False,
                "error": "缺少任务ID列表"
            }), 400
        
        # 构建约束对象
        constraints = ExecutionConstraints(
            max_parallel_tasks=constraints_data.get('max_parallel_tasks'),
            balance_workload=constraints_data.get('balance_workload', True)
        )
        
        # 获取任务详情（简化实现）
        tasks = [{"id": tid, "title": f"Task {tid}"} for tid in task_ids]
        
        # 使用 v2 依赖管理器
        plan = dependency_manager.optimize_execution_plan(tasks, constraints)
        
        return jsonify({
            "success": True,
            "plan": {
                "execution_order": plan.execution_order,
                "critical_path": plan.critical_path,
                "parallel_groups": plan.parallel_groups,
                "estimated_completion": str(plan.estimated_completion),
                "suggestions": plan.suggestions
            },
            "version": "2.0"
        })
        
    except Exception as e:
        import traceback
        print(f"[ERROR] v2 执行计划优化失败: {e}")
        print(traceback.format_exc())
        return jsonify({
            "success": False,
            "error": f"优化失败: {str(e)}"
        }), 500


@context_bp.route('/api/context/v2/performance', methods=['GET'])
@require_user
def get_performance_stats(user):
    """
    获取性能统计信息
    
    返回:
    {
        "success": true,
        "stats": {
            "intent_cache": {"hits": 100, "misses": 20, "hit_rate": 0.83},
            "embedding_cache": {"hits": 50, "misses": 10, "hit_rate": 0.83},
            "average_latency_ms": 45.2
        },
        "version": "2.0"
    }
    """
    try:
        if not PERFORMANCE_AVAILABLE:
            return jsonify({
                "success": False,
                "error": "性能优化模块不可用"
            }), 503
        
        stats = performance_optimizer.get_stats()
        
        return jsonify({
            "success": True,
            "stats": stats,
            "version": "2.0"
        })
        
    except Exception as e:
        return jsonify({
            "success": False,
            "error": f"获取统计失败: {str(e)}"
        }), 500


@context_bp.route('/api/context/v2/performance/clear-cache', methods=['POST'])
@require_user
def clear_performance_cache(user):
    """清空性能缓存"""
    try:
        if not PERFORMANCE_AVAILABLE:
            return jsonify({
                "success": False,
                "error": "性能优化模块不可用"
            }), 503
        
        performance_optimizer.clear_caches()
        
        return jsonify({
            "success": True,
            "message": "缓存已清空"
        })
        
    except Exception as e:
        return jsonify({
            "success": False,
            "error": f"清空缓存失败: {str(e)}"
        }), 500
