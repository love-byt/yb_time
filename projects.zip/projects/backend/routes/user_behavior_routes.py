"""
用户行为路由 - 提供用户习惯学习和个性化推荐接口
"""

from datetime import datetime
from flask import Blueprint, jsonify, request

from extensions import db
from models.user_behavior import UserStudyPattern, UserStudySession, UserTaskPreference
from utils.user_behavior_analyzer import UserBehaviorAnalyzer, PersonalizedPlanGenerator
from utils.user_auth import require_user

user_behavior_bp = Blueprint('user_behavior', __name__)


@user_behavior_bp.route('/api/user/behavior/pattern', methods=['GET'])
@require_user
def get_study_pattern(user):
    """获取用户学习模式"""
    analyzer = UserBehaviorAnalyzer(user.id)
    pattern_data = analyzer.analyze_study_patterns()
    
    if not pattern_data:
        return jsonify({
            "success": True,
            "message": "暂无足够数据，请完成更多任务以生成个性化推荐",
            "pattern": None
        })
    
    return jsonify({
        "success": True,
        "pattern": pattern_data
    })


@user_behavior_bp.route('/api/user/behavior/pattern/update', methods=['POST'])
@require_user
def update_study_pattern(user):
    """更新用户学习模式分析"""
    analyzer = UserBehaviorAnalyzer(user.id)
    pattern = analyzer.update_study_pattern()
    
    if not pattern:
        return jsonify({
            "success": False,
            "message": "暂无足够数据更新学习模式"
        }), 400
    
    return jsonify({
        "success": True,
        "message": "学习模式已更新",
        "pattern": pattern.to_dict()
    })


@user_behavior_bp.route('/api/user/behavior/preferences', methods=['GET'])
@require_user
def get_category_preferences(user):
    """获取用户任务分类偏好"""
    analyzer = UserBehaviorAnalyzer(user.id)
    preferences = analyzer.analyze_category_preferences()
    
    return jsonify({
        "success": True,
        "preferences": preferences
    })


@user_behavior_bp.route('/api/user/behavior/settings', methods=['GET'])
@require_user
def get_personalized_settings(user):
    """获取个性化设置"""
    analyzer = UserBehaviorAnalyzer(user.id)
    settings = analyzer.get_personalized_settings()
    
    return jsonify({
        "success": True,
        "settings": settings
    })


@user_behavior_bp.route('/api/user/behavior/session', methods=['POST'])
@require_user
def record_study_session(user):
    """记录学习会话"""
    data = request.get_json() or {}
    
    task_id = data.get('task_id')
    start_time_str = data.get('start_time')
    end_time_str = data.get('end_time')
    session_type = data.get('session_type', 'focus')
    interruptions = data.get('interruptions', 0)
    efficiency_rating = data.get('efficiency_rating')
    category = data.get('category', '')
    
    if not start_time_str or not end_time_str:
        return jsonify({
            "success": False,
            "message": "请提供开始和结束时间"
        }), 400
    
    try:
        start_time = datetime.fromisoformat(start_time_str.replace('Z', '+00:00'))
        end_time = datetime.fromisoformat(end_time_str.replace('Z', '+00:00'))
    except:
        return jsonify({
            "success": False,
            "message": "时间格式错误"
        }), 400
    
    analyzer = UserBehaviorAnalyzer(user.id)
    session = analyzer.record_study_session(
        task_id=task_id,
        start_time=start_time,
        end_time=end_time,
        session_type=session_type,
        interruptions=interruptions,
        efficiency_rating=efficiency_rating,
        category=category
    )
    
    return jsonify({
        "success": True,
        "message": "学习会话已记录",
        "session": session.to_dict()
    })


@user_behavior_bp.route('/api/user/behavior/plan/personalized', methods=['POST'])
@require_user
def generate_personalized_plan(user):
    """生成个性化学习计划"""
    from models.task import Task
    
    data = request.get_json() or {}
    available_hours = data.get('available_hours', 8)
    task_ids = data.get('task_ids', [])
    
    # 获取任务列表
    if task_ids:
        tasks = Task.query.filter(
            Task.id.in_(task_ids),
            Task.user_id == user.id,
            Task.is_completed == False
        ).all()
    else:
        tasks = Task.query.filter_by(
            user_id=user.id,
            is_completed=False
        ).all()
    
    if not tasks:
        return jsonify({
            "success": False,
            "message": "没有待办任务"
        }), 400
    
    # 转换为字典列表
    task_dicts = []
    for task in tasks:
        duration = task.actual_duration or 60
        task_dicts.append({
            'id': task.id,
            'title': task.title,
            'category': task.category or '未分类',
            'priority': task.priority or 3,
            'duration': duration
        })
    
    # 生成个性化计划
    generator = PersonalizedPlanGenerator(user.id)
    plan = generator.generate_plan(task_dicts, available_hours)
    
    return jsonify({
        "success": True,
        "plan": plan
    })


@user_behavior_bp.route('/api/user/behavior/peak-hours', methods=['GET'])
@require_user
def get_peak_hours(user):
    """获取用户最佳学习时段"""
    analyzer = UserBehaviorAnalyzer(user.id)
    pattern_data = analyzer.analyze_study_patterns()
    
    if not pattern_data:
        # 返回默认时段
        return jsonify({
            "success": True,
            "peak_hours": [9, 10, 14, 15],
            "is_default": True,
            "message": "暂无足够数据，使用默认推荐时段"
        })
    
    return jsonify({
        "success": True,
        "peak_hours": pattern_data['peak_hours'],
        "hourly_distribution": pattern_data['hourly_distribution'],
        "is_default": False
    })


@user_behavior_bp.route('/api/user/behavior/stats', methods=['GET'])
@require_user
def get_behavior_stats(user):
    """获取用户行为统计"""
    from datetime import timedelta
    
    days = request.args.get('days', 30, type=int)
    cutoff_date = datetime.now() - timedelta(days=days)
    
    # 学习会话统计
    sessions = UserStudySession.query.filter(
        UserStudySession.user_id == user.id,
        UserStudySession.start_time >= cutoff_date
    ).all()
    
    total_focus_time = sum(s.duration_minutes for s in sessions if s.session_type == 'focus')
    total_sessions = len([s for s in sessions if s.session_type == 'focus'])
    
    # 平均效率
    rated_sessions = [s for s in sessions if s.efficiency_rating]
    avg_efficiency = sum(s.efficiency_rating for s in rated_sessions) / len(rated_sessions) if rated_sessions else 0
    
    # 分类分布
    category_dist = {}
    for s in sessions:
        cat = s.category or '未分类'
        if cat not in category_dist:
            category_dist[cat] = 0
        category_dist[cat] += s.duration_minutes
    
    # 学习模式
    pattern = UserStudyPattern.query.filter_by(user_id=user.id).first()
    
    return jsonify({
        "success": True,
        "stats": {
            "total_focus_time": total_focus_time,
            "total_sessions": total_sessions,
            "avg_session_duration": round(total_focus_time / total_sessions, 1) if total_sessions > 0 else 0,
            "avg_efficiency": round(avg_efficiency, 2),
            "category_distribution": category_dist,
            "study_pattern": pattern.to_dict() if pattern else None
        }
    })
