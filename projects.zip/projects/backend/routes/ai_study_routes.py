"""
AI学习计划路由
"""

import math
from datetime import datetime, timedelta
from flask import Blueprint, jsonify, request

from extensions import db
from models.task import Task
from utils.ai_helper import AIHelper
from utils.user_auth import require_user
from utils.user_behavior_analyzer import UserBehaviorAnalyzer, PersonalizedPlanGenerator
from config import Config

ai_study_bp = Blueprint('ai_study', __name__)


def get_ai_helper(user=None):
    """获取AI助手实例"""
    from models.task import User
    
    api_key = request.headers.get('X-AI-API-Key', '')
    if api_key:
        return AIHelper(api_key), 'user_header'
    
    if user:
        user_obj = User.query.get(user.id) if hasattr(user, 'id') else User.query.get(user)
        if user_obj and user_obj.ai_api_key:
            return AIHelper(user_obj.ai_api_key), 'user_db'
    
    return AIHelper(Config.TONGYI_API_KEY), 'system'


def estimate_by_keywords(title, category):
    """基于关键词预估时长"""
    from routes.ai_duration_routes import KEYWORD_DURATIONS, DEFAULT_DURATIONS
    
    title_lower = title.lower()
    
    for keyword, duration in KEYWORD_DURATIONS.items():
        if keyword in title_lower:
            return duration
    
    return DEFAULT_DURATIONS.get(category, 60)


def ai_estimate_duration(title, category):
    """AI预估任务时长"""
    try:
        ai_helper = get_ai_helper()
        if not ai_helper[0].api_key:
            return None
        
        prompt = f"""请根据以下任务信息，预估完成该任务需要多少分钟。

任务标题: {title}
任务分类: {category}

请只返回一个数字（分钟数），不需要其他说明。"""

        result = ai_helper[0].call_api(prompt)
        if result:
            import re
            numbers = re.findall(r'\d+', result)
            if numbers:
                return int(numbers[0])
    except:
        pass
    return None


def is_urgent_task(title):
    """判断是否是紧急任务"""
    urgent_keywords = ['紧急', '立即', '马上', '尽快', '今天', '今晚', 'urgent', 'asap']
    title_lower = title.lower()
    return any(kw in title_lower for kw in urgent_keywords)


def generate_optimized_plan(tasks, available_minutes, preferences=None):
    """生成优化的学习计划"""
    if preferences is None:
        preferences = {}
    
    pomodoro_minutes = preferences.get('pomodoro_minutes', 25)
    break_minutes = preferences.get('break_minutes', 5)
    long_break_minutes = preferences.get('long_break_minutes', 15)
    pomodoros_before_long_break = preferences.get('pomodoros_before_long_break', 4)
    
    schedule = []
    current_time = 0
    total_scheduled = 0
    pomodoro_count = 0
    current_category = None
    
    for task in tasks:
        if total_scheduled + task['duration'] > available_minutes:
            remaining = available_minutes - total_scheduled
            if remaining >= pomodoro_minutes:
                task_copy = task.copy()
                task_copy['duration'] = remaining
                task_copy['is_split'] = True
                task_copy['split_note'] = f"任务已拆分，剩余部分请稍后安排"
                schedule.append(create_schedule_item(
                    task_copy, current_time, pomodoro_minutes, break_minutes
                ))
            break
        
        schedule_item = create_schedule_item(
            task, current_time, pomodoro_minutes, break_minutes
        )
        
        pomodoros_needed = math.ceil(task['duration'] / pomodoro_minutes)
        pomodoro_count += pomodoros_needed
        
        if pomodoro_count >= pomodoros_before_long_break:
            schedule_item['break_after'] = long_break_minutes
            pomodoro_count = 0
        else:
            schedule_item['break_after'] = break_minutes * pomodoros_needed
        
        if current_category and current_category != task['category']:
            schedule_item['category_switch'] = True
            schedule_item['switch_note'] = f"从{current_category}切换到{task['category']}，建议深呼吸调整状态"
        current_category = task['category']
        
        schedule.append(schedule_item)
        current_time += task['duration'] + schedule_item['break_after']
        total_scheduled += task['duration']
    
    time_slots = generate_time_slots(schedule, preferences.get('start_hour', 8))
    
    return {
        'schedule': schedule,
        'time_slots': time_slots,
        'total_break_minutes': sum(item.get('break_after', 0) for item in schedule),
        'pomodoro_settings': {
            'work_minutes': pomodoro_minutes,
            'break_minutes': break_minutes,
            'long_break_minutes': long_break_minutes
        }
    }


def create_schedule_item(task, start_minute, pomodoro_minutes, break_minutes):
    """创建计划项"""
    pomodoros = math.ceil(task['duration'] / pomodoro_minutes)
    
    return {
        'task_id': task['id'],
        'title': task['title'],
        'category': task['category'],
        'priority': task['priority'],
        'duration': task['duration'],
        'start_minute': start_minute,
        'pomodoros': pomodoros,
        'tags': task.get('tags', []),
        'end_time_deadline': task.get('end_time'),
        'is_split': task.get('is_split', False)
    }


def generate_time_slots(schedule, start_hour=8):
    """生成具体的时间段安排"""
    now = datetime.now()
    base_time = now.replace(hour=start_hour, minute=0, second=0, microsecond=0)
    
    time_slots = []
    current_time = base_time
    
    for item in schedule:
        start_time = current_time
        end_time = current_time + timedelta(minutes=item['duration'])
        break_end = end_time + timedelta(minutes=item.get('break_after', 5))
        
        time_slots.append({
            'task_id': item['task_id'],
            'title': item['title'],
            'start_time': start_time.strftime('%H:%M'),
            'end_time': end_time.strftime('%H:%M'),
            'break_end_time': break_end.strftime('%H:%M'),
            'duration_minutes': item['duration'],
            'break_minutes': item.get('break_after', 5)
        })
        
        current_time = break_end
    
    return time_slots


def get_ai_study_recommendations(plan, available_hours, preferences, ai_helper=None):
    """获取AI学习建议"""
    if not ai_helper or not ai_helper.api_key:
        return None
    
    try:
        tasks_desc = "\n".join([
            f"- {item['title']}（{item['category']}，{item['duration']}分钟，优先级{item['priority']}）"
            for item in plan['schedule'][:10]
        ])
        
        prompt = f"""作为一个专业的时间管理顾问，请分析以下学习计划并给出建议：

可用学习时间: {available_hours}小时
已安排任务:
{tasks_desc}

请从以下几个方面给出建议：
1. 学习效率优化建议
2. 时间分配是否合理
3. 休息安排建议
4. 注意事项

请用简洁的语言回答，不超过200字。
"""
        
        result = ai_helper.call_api(prompt)
        return {
            'suggestions': result,
            'generated_at': datetime.now().isoformat()
        }
    except Exception as e:
        print(f"AI建议生成失败: {e}")
        return None


@ai_study_bp.route('/api/ai/study-plan', methods=['POST'])
@require_user
def generate_study_plan(user):
    """AI学习计划推荐（集成用户习惯学习）"""
    try:
        ai_helper = get_ai_helper()
        
        data = request.get_json()
        available_hours = data.get('available_hours', 8)
        target_date = data.get('target_date')
        task_ids = data.get('task_ids', [])
        preferences = data.get('preferences', {})
        use_personalized = data.get('use_personalized', True)  # 是否使用个性化推荐
        
        if task_ids:
            tasks = Task.query.filter(
                Task.id.in_(task_ids),
                Task.user_id == user.id,
                Task.is_completed == False
            ).all()
        else:
            tasks = Task.query.filter_by(
                user_id=user.id,
                is_completed=False
            ).order_by(Task.priority.desc(), Task.end_time).all()
        
        if not tasks:
            return jsonify({
                "success": False,
                "message": "没有待办任务，请先创建任务"
            }), 400
        
        # 获取用户个性化设置
        analyzer = UserBehaviorAnalyzer(user.id)
        personalized_settings = analyzer.get_personalized_settings()
        
        # 合并用户偏好：传入的 preferences 优先级高于个性化设置
        merged_preferences = {
            'pomodoro_minutes': preferences.get('pomodoro_minutes', personalized_settings.get('pomodoro_minutes', 25)),
            'break_minutes': preferences.get('break_minutes', personalized_settings.get('break_minutes', 5)),
            'long_break_minutes': preferences.get('long_break_minutes', personalized_settings.get('long_break_minutes', 15)),
            'pomodoros_before_long_break': preferences.get('pomodoros_before_long_break', personalized_settings.get('pomodoros_before_long_break', 4)),
            'peak_hours': preferences.get('peak_hours', personalized_settings.get('peak_hours', [9, 10, 14, 15]))
        }
        
        total_estimated_minutes = 0
        task_list = []
        
        for task in tasks:
            if task.actual_duration and task.actual_duration > 0:
                duration = task.actual_duration
            else:
                duration = estimate_by_keywords(task.title, task.category)
                ai_duration = ai_estimate_duration(task.title, task.category)
                if ai_duration:
                    duration = int(duration * 0.4 + ai_duration * 0.6)
            
            total_estimated_minutes += duration
            
            task_list.append({
                'id': task.id,
                'title': task.title,
                'category': task.category,
                'priority': task.priority,
                'duration': duration,
                'end_time': task.end_time,
                'tags': [tag.name for tag in task.tags] if task.tags else []
            })
        
        # 如果使用个性化推荐，使用 PersonalizedPlanGenerator
        if use_personalized and personalized_settings.get('is_personalized'):
            generator = PersonalizedPlanGenerator(user.id)
            personalized_plan = generator.generate_plan(task_list, available_hours)
            
            # 转换格式以兼容原有接口
            plan = {
                'schedule': personalized_plan['schedule'],
                'time_slots': generate_time_slots_from_schedule(personalized_plan['schedule']),
                'pomodoro_settings': merged_preferences,
                'is_personalized': True,
                'category_preferences': personalized_plan.get('category_preferences', [])
            }
        else:
            # 使用传统排序方式
            task_list.sort(key=lambda x: (
                -x['priority'],
                x['end_time'] or '9999-99-99'
            ))
            
            available_minutes = available_hours * 60
            plan = generate_optimized_plan(task_list, available_minutes, merged_preferences)
            plan['is_personalized'] = False
        
        ai_recommendations = None
        if ai_helper[0].api_key:
            try:
                ai_recommendations = get_ai_study_recommendations(
                    plan, available_hours, merged_preferences, ai_helper[0]
                )
            except Exception as e:
                print(f"AI学习建议生成失败: {e}")
        
        scheduled_minutes = sum(item['duration'] for item in plan['schedule'])
        stats = {
            'total_tasks': len(task_list),
            'scheduled_tasks': len(plan['schedule']),
            'total_estimated_minutes': total_estimated_minutes,
            'scheduled_minutes': scheduled_minutes,
            'available_minutes': available_hours * 60,
            'utilization_rate': round(scheduled_minutes / (available_hours * 60) * 100, 1) if available_hours > 0 else 0,
            'remaining_minutes': available_hours * 60 - scheduled_minutes,
            'is_personalized': plan.get('is_personalized', False)
        }
        
        return jsonify({
            "success": True,
            "plan": plan,
            "stats": stats,
            "ai_recommendations": ai_recommendations,
            "personalized_settings": personalized_settings if plan.get('is_personalized') else None
        })
        
    except Exception as e:
        return jsonify({"success": False, "message": f"生成学习计划失败: {str(e)}"}), 500


def generate_time_slots_from_schedule(schedule, start_hour=8):
    """从个性化计划生成时间段"""
    now = datetime.now()
    time_slots = []
    
    for item in schedule:
        recommended_hour = item.get('recommended_start_hour', start_hour)
        duration = item.get('duration', 60)
        break_after = item.get('break_after', 5)
        
        start_time = now.replace(hour=recommended_hour, minute=0, second=0, microsecond=0)
        end_time = start_time + timedelta(minutes=duration)
        break_end = end_time + timedelta(minutes=break_after)
        
        time_slots.append({
            'task_id': item.get('task_id'),
            'title': item.get('title'),
            'start_time': start_time.strftime('%H:%M'),
            'end_time': end_time.strftime('%H:%M'),
            'break_end_time': break_end.strftime('%H:%M'),
            'duration_minutes': duration,
            'break_minutes': break_after,
            'in_peak_hour': item.get('in_peak_hour', False)
        })
    
    return time_slots


@ai_study_bp.route('/api/ai/study-plan/daily', methods=['GET'])
@require_user
def get_daily_study_plan(user):
    """获取今日学习计划"""
    try:
        today = datetime.now().date()
        today_str = today.strftime('%Y-%m-%d')
        
        tasks = Task.query.filter(
            Task.user_id == user.id,
            Task.is_completed == False
        ).filter(
            (Task.end_time == None) | 
            (Task.end_time.startswith(today_str)) |
            (Task.end_time < today_str + ' 23:59:59')
        ).order_by(Task.priority.desc()).all()
        
        if not tasks:
            return jsonify({
                "success": True,
                "message": "今天没有待办任务",
                "plan": None,
                "stats": {
                    'total_tasks': 0,
                    'scheduled_minutes': 0
                }
            })
        
        now = datetime.now()
        remaining_hours = max(1, 22 - now.hour)
        available_hours = min(8, remaining_hours)
        
        task_list = []
        for task in tasks:
            duration = estimate_by_keywords(task.title, task.category)
            task_list.append({
                'id': task.id,
                'title': task.title,
                'category': task.category,
                'priority': task.priority,
                'duration': duration,
                'end_time': task.end_time
            })
        
        plan = generate_optimized_plan(task_list, available_hours * 60)
        
        return jsonify({
            "success": True,
            "date": today_str,
            "plan": plan,
            "available_hours": available_hours,
            "total_tasks": len(task_list)
        })
        
    except Exception as e:
        return jsonify({"success": False, "message": f"获取今日计划失败: {str(e)}"}), 500


@ai_study_bp.route('/api/ai/study-tips', methods=['GET'])
@require_user
def get_study_tips(user):
    """获取学习建议"""
    try:
        completed_tasks = Task.query.filter_by(
            user_id=user.id,
            is_completed=True
        ).order_by(Task.updated_at.desc()).limit(30).all()
        
        pending_tasks = Task.query.filter_by(
            user_id=user.id,
            is_completed=False
        ).all()
        
        tips = []
        
        total_tasks = len(completed_tasks) + len(pending_tasks)
        if total_tasks > 0:
            completion_rate = len(completed_tasks) / total_tasks * 100
            if completion_rate < 50:
                tips.append({
                    'type': 'warning',
                    'title': '任务完成率偏低',
                    'content': f'当前完成率为{completion_rate:.1f}%，建议将大任务拆分为小任务，提高完成成就感。'
                })
            elif completion_rate > 80:
                tips.append({
                    'type': 'success',
                    'title': '任务完成率优秀',
                    'content': f'太棒了！当前完成率为{completion_rate:.1f}%，继续保持！'
                })
        
        category_count = {}
        for task in pending_tasks:
            category_count[task.category] = category_count.get(task.category, 0) + 1
        
        if category_count:
            max_category = max(category_count, key=category_count.get)
            tips.append({
                'type': 'info',
                'title': '任务分布分析',
                'content': f'当前"{max_category}"分类下有{category_count[max_category]}个待办任务，建议优先处理。'
            })
        
        urgent_tasks = [t for t in pending_tasks if is_urgent_task(t.title)]
        if urgent_tasks:
            tips.append({
                'type': 'urgent',
                'title': '紧急任务提醒',
                'content': f'有{len(urgent_tasks)}个紧急任务需要处理：{", ".join([t.title for t in urgent_tasks[:3]])}'
            })
        
        tips.append({
            'type': 'tip',
            'title': '番茄工作法建议',
            'content': '建议每25分钟专注学习后休息5分钟，每4个番茄钟后休息15-20分钟。'
        })
        
        return jsonify({
            "success": True,
            "tips": tips,
            "stats": {
                "completed_count": len(completed_tasks),
                "pending_count": len(pending_tasks),
                "completion_rate": round(len(completed_tasks) / total_tasks * 100, 1) if total_tasks > 0 else 0
            }
        })
        
    except Exception as e:
        return jsonify({"success": False, "message": f"获取学习建议失败: {str(e)}"}), 500
