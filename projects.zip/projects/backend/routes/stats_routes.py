"""
数据统计路由
"""

from datetime import datetime, timedelta

from flask import Blueprint, jsonify, request

from extensions import db
from models.task import Task
from utils.user_auth import require_user

stats_bp = Blueprint('stats', __name__)


@stats_bp.route('/api/stats/category', methods=['GET'])
@require_user
def get_category_stats(user):
    """获取分类统计"""
    stats = db.session.query(
        Task.category,
        db.func.count(Task.id).label('total'),
        db.func.sum(db.case((Task.is_completed == 1, 1), else_=0)).label('completed')
    ).filter(
        Task.user_id == user.id
    ).group_by(Task.category).all()
    
    result = []
    for category, total, completed in stats:
        result.append({
            'category': category,
            'total': total,
            'completed': completed or 0,
            'pending': total - (completed or 0)
        })
    
    return jsonify({
        "success": True,
        "stats": result
    })


@stats_bp.route('/api/stats/daily', methods=['GET'])
@require_user
def get_daily_stats(user):
    """获取每日统计"""
    days = request.args.get('days', 7, type=int)
    start_date = datetime.now() - timedelta(days=days)
    
    stats = []
    for i in range(days):
        date = start_date + timedelta(days=i)
        date_str = date.strftime('%Y-%m-%d')
        
        total = Task.query.filter(
            Task.user_id == user.id,
            Task.created_at >= date,
            Task.created_at < date + timedelta(days=1)
        ).count()
        
        completed = Task.query.filter(
            Task.user_id == user.id,
            Task.is_completed == 1,
            Task.actual_end_time >= date,
            Task.actual_end_time < date + timedelta(days=1)
        ).count()
        
        stats.append({
            'date': date_str,
            'total': total,
            'completed': completed
        })
    
    return jsonify({
        "success": True,
        "stats": stats
    })


@stats_bp.route('/api/stats/trend', methods=['GET'])
@require_user
def get_trend_stats(user):
    """获取趋势统计"""
    days = request.args.get('days', 7, type=int)
    
    now = datetime.now()
    start_date = now - timedelta(days=days)
    
    tasks = Task.query.filter(
        Task.user_id == user.id,
        Task.created_at >= start_date
    ).all()
    
    daily_stats = {}
    for i in range(days):
        date = (start_date + timedelta(days=i)).strftime('%Y-%m-%d')
        daily_stats[date] = {'created': 0, 'completed': 0}
    
    for task in tasks:
        created_date = task.created_at.strftime('%Y-%m-%d')
        if created_date in daily_stats:
            daily_stats[created_date]['created'] += 1
        
        if task.is_completed and task.actual_end_time:
            completed_date = task.actual_end_time.strftime('%Y-%m-%d')
            if completed_date in daily_stats:
                daily_stats[completed_date]['completed'] += 1
    
    trend = []
    for date, stats in sorted(daily_stats.items()):
        trend.append({
            'date': date,
            'created': stats['created'],
            'completed': stats['completed']
        })
    
    return jsonify({
        "success": True,
        "trend": trend
    })


@stats_bp.route('/api/stats/overview', methods=['GET'])
@require_user
def get_overview_stats(user):
    """获取总览统计"""
    total_tasks = Task.query.filter_by(user_id=user.id).count()
    completed_tasks = Task.query.filter_by(user_id=user.id, is_completed=1).count()
    pending_tasks = total_tasks - completed_tasks
    
    today = datetime.now().date()
    today_tasks = Task.query.filter(
        Task.user_id == user.id,
        Task.created_at >= datetime.combine(today, datetime.min.time())
    ).count()
    
    today_completed = Task.query.filter(
        Task.user_id == user.id,
        Task.is_completed == 1,
        Task.actual_end_time >= datetime.combine(today, datetime.min.time())
    ).count()
    
    # 计算完成率
    completion_rate = round(completed_tasks / total_tasks * 100, 1) if total_tasks > 0 else 0
    
    # 本周统计
    week_start = datetime.now() - timedelta(days=datetime.now().weekday())
    week_tasks = Task.query.filter(
        Task.user_id == user.id,
        Task.created_at >= week_start
    ).count()
    
    week_completed = Task.query.filter(
        Task.user_id == user.id,
        Task.is_completed == 1,
        Task.actual_end_time >= week_start
    ).count()
    
    return jsonify({
        "success": True,
        "overview": {
            "total_tasks": total_tasks,
            "completed_tasks": completed_tasks,
            "pending_tasks": pending_tasks,
            "completion_rate": completion_rate,
            "today": {
                "created": today_tasks,
                "completed": today_completed
            },
            "week": {
                "created": week_tasks,
                "completed": week_completed
            }
        }
    })



# ==================== 高级统计接口（支持Chart.js可视化） ====================

@stats_bp.route('/api/stats/chart/category-bar', methods=['GET'])
@require_user
def get_category_bar_chart(user):
    """
    分类统计柱状图数据
    返回适合Chart.js bar chart的数据格式
    """
    from sqlalchemy import func, case
    
    # 获取分类统计数据
    stats = db.session.query(
        Task.category,
        func.count(Task.id).label('total'),
        func.sum(case((Task.is_completed == 1, 1), else_=0)).label('completed')
    ).filter(
        Task.user_id == user.id
    ).group_by(Task.category).all()
    
    # 分类颜色映射
    category_colors = {
        '学习': '#2196F3',
        '工作': '#4CAF50',
        '生活': '#9C27B0',
        '健康': '#00BCD4',
        '财务': '#FFEB3B',
        '社交': '#E91E63',
        '考试': '#F44336',
        '项目': '#FF9800'
    }
    
    labels = []
    total_data = []
    completed_data = []
    pending_data = []
    colors = []
    
    for category, total, completed in stats:
        labels.append(category)
        total_data.append(total)
        completed_data.append(completed or 0)
        pending_data.append(total - (completed or 0))
        colors.append(category_colors.get(category, '#757575'))
    
    return jsonify({
        "success": True,
        "chart": {
            "type": "bar",
            "data": {
                "labels": labels,
                "datasets": [
                    {
                        "label": "已完成",
                        "data": completed_data,
                        "backgroundColor": colors,
                        "borderColor": colors,
                        "borderWidth": 1
                    },
                    {
                        "label": "待完成",
                        "data": pending_data,
                        "backgroundColor": [c + '80' for c in colors],  # 半透明
                        "borderColor": colors,
                        "borderWidth": 1
                    }
                ]
            },
            "options": {
                "responsive": True,
                "plugins": {
                    "title": {
                        "display": True,
                        "text": "分类任务统计"
                    }
                },
                "scales": {
                    "y": {
                        "beginAtZero": True
                    }
                }
            }
        },
        "raw_data": {
            "categories": labels,
            "total": total_data,
            "completed": completed_data,
            "pending": pending_data
        }
    })


@stats_bp.route('/api/stats/chart/completion-line', methods=['GET'])
@require_user
def get_completion_line_chart(user):
    """
    完成率趋势折线图数据
    返回适合Chart.js line chart的数据格式
    """
    days = request.args.get('days', 30, type=int)
    
    now = datetime.now()
    start_date = now - timedelta(days=days)
    
    # 获取每日数据
    daily_data = {}
    for i in range(days):
        date = (start_date + timedelta(days=i)).strftime('%Y-%m-%d')
        daily_data[date] = {'created': 0, 'completed': 0}
    
    # 查询创建的任务
    created_tasks = Task.query.filter(
        Task.user_id == user.id,
        Task.created_at >= start_date
    ).all()
    
    for task in created_tasks:
        date = task.created_at.strftime('%Y-%m-%d')
        if date in daily_data:
            daily_data[date]['created'] += 1
    
    # 查询完成的任务
    completed_tasks = Task.query.filter(
        Task.user_id == user.id,
        Task.is_completed == 1,
        Task.actual_end_time >= start_date
    ).all()
    
    for task in completed_tasks:
        if task.actual_end_time:
            date = task.actual_end_time.strftime('%Y-%m-%d')
            if date in daily_data:
                daily_data[date]['completed'] += 1
    
    # 构建图表数据
    labels = []
    created_data = []
    completed_data = []
    rate_data = []
    
    for date in sorted(daily_data.keys()):
        labels.append(date[-5:])  # 只显示月-日
        created_data.append(daily_data[date]['created'])
        completed_data.append(daily_data[date]['completed'])
        
        # 计算累计完成率
        total_so_far = sum(created_data)
        completed_so_far = sum(completed_data)
        rate = round(completed_so_far / total_so_far * 100, 1) if total_so_far > 0 else 0
        rate_data.append(rate)
    
    return jsonify({
        "success": True,
        "chart": {
            "type": "line",
            "data": {
                "labels": labels,
                "datasets": [
                    {
                        "label": "新建任务",
                        "data": created_data,
                        "borderColor": "#2196F3",
                        "backgroundColor": "#2196F320",
                        "fill": False,
                        "tension": 0.3
                    },
                    {
                        "label": "完成任务",
                        "data": completed_data,
                        "borderColor": "#4CAF50",
                        "backgroundColor": "#4CAF5020",
                        "fill": False,
                        "tension": 0.3
                    },
                    {
                        "label": "完成率(%)",
                        "data": rate_data,
                        "borderColor": "#FF9800",
                        "backgroundColor": "#FF980020",
                        "fill": False,
                        "tension": 0.3,
                        "yAxisID": "y1"
                    }
                ]
            },
            "options": {
                "responsive": True,
                "plugins": {
                    "title": {
                        "display": True,
                        "text": f"近{days}天任务趋势"
                    }
                },
                "scales": {
                    "y": {
                        "beginAtZero": True,
                        "title": {
                            "display": True,
                            "text": "任务数"
                        }
                    },
                    "y1": {
                        "beginAtZero": True,
                        "position": "right",
                        "max": 100,
                        "title": {
                            "display": True,
                            "text": "完成率(%)"
                        }
                    }
                }
            }
        }
    })


@stats_bp.route('/api/stats/chart/time-pie', methods=['GET'])
@require_user
def get_time_pie_chart(user):
    """
    时间分配饼图数据
    返回适合Chart.js pie/doughnut chart的数据格式
    """
    from sqlalchemy import func
    
    # 获取各分类的实际完成时长
    stats = db.session.query(
        Task.category,
        func.sum(func.coalesce(Task.actual_duration, 0)).label('total_duration')
    ).filter(
        Task.user_id == user.id,
        Task.is_completed == 1
    ).group_by(Task.category).all()
    
    # 分类颜色映射
    category_colors = {
        '学习': '#2196F3',
        '工作': '#4CAF50',
        '生活': '#9C27B0',
        '健康': '#00BCD4',
        '财务': '#FFEB3B',
        '社交': '#E91E63',
        '考试': '#F44336',
        '项目': '#FF9800'
    }
    
    labels = []
    durations = []
    colors = []
    total_minutes = 0
    
    for category, duration in stats:
        if duration and duration > 0:
            labels.append(category)
            durations.append(duration)
            colors.append(category_colors.get(category, '#757575'))
            total_minutes += duration
    
    return jsonify({
        "success": True,
        "chart": {
            "type": "doughnut",
            "data": {
                "labels": labels,
                "datasets": [{
                    "data": durations,
                    "backgroundColor": colors,
                    "borderColor": "#ffffff",
                    "borderWidth": 2
                }]
            },
            "options": {
                "responsive": True,
                "plugins": {
                    "title": {
                        "display": True,
                        "text": "时间分配统计"
                    },
                    "tooltip": {
                        "callbacks": {
                            "label": "function(context) { return context.label + ': ' + Math.round(context.raw / 60 * 10) / 10 + '小时'; }"
                        }
                    }
                }
            }
        },
        "raw_data": {
            "total_minutes": total_minutes,
            "total_hours": round(total_minutes / 60, 1),
            "categories": labels,
            "durations_minutes": durations
        }
    })


@stats_bp.route('/api/stats/chart/radar', methods=['GET'])
@require_user
def get_category_radar_chart(user):
    """
    分类完成度雷达图数据
    返回适合Chart.js radar chart的数据格式
    """
    from sqlalchemy import func, case
    
    # 获取各分类的完成情况
    stats = db.session.query(
        Task.category,
        func.count(Task.id).label('total'),
        func.sum(case((Task.is_completed == 1, 1), else_=0)).label('completed')
    ).filter(
        Task.user_id == user.id
    ).group_by(Task.category).all()
    
    # 分类标签
    all_categories = ['学习', '工作', '生活', '健康', '财务', '社交']
    
    completion_rates = []
    for cat in all_categories:
        total = 0
        completed = 0
        for category, t, c in stats:
            if category == cat:
                total = t
                completed = c or 0
                break
        
        rate = round(completed / total * 100) if total > 0 else 0
        completion_rates.append(rate)
    
    return jsonify({
        "success": True,
        "chart": {
            "type": "radar",
            "data": {
                "labels": all_categories,
                "datasets": [{
                    "label": "完成度(%)",
                    "data": completion_rates,
                    "backgroundColor": "#2196F340",
                    "borderColor": "#2196F3",
                    "borderWidth": 2,
                    "pointBackgroundColor": "#2196F3"
                }]
            },
            "options": {
                "responsive": True,
                "plugins": {
                    "title": {
                        "display": True,
                        "text": "各分类完成度"
                    }
                },
                "scales": {
                    "r": {
                        "beginAtZero": True,
                        "max": 100,
                        "ticks": {
                            "stepSize": 20
                        }
                    }
                }
            }
        },
        "raw_data": {
            "categories": all_categories,
            "completion_rates": completion_rates
        }
    })


@stats_bp.route('/api/stats/chart/all', methods=['GET'])
@require_user
def get_all_chart_data(user):
    """
    获取所有图表数据（一次性请求）
    适用于仪表盘页面初始化
    """
    try:
        # 复用各个接口的逻辑
        category_bar = get_category_bar_chart.__wrapped__(user)
        completion_line = get_completion_line_chart.__wrapped__(user)
        time_pie = get_time_pie_chart.__wrapped__(user)
        radar = get_category_radar_chart.__wrapped__(user)
        overview = get_overview_stats.__wrapped__(user)
        
        return jsonify({
            "success": True,
            "charts": {
                "category_bar": category_bar.get_json()["chart"],
                "completion_line": completion_line.get_json()["chart"],
                "time_pie": time_pie.get_json()["chart"],
                "radar": radar.get_json()["chart"]
            },
            "overview": overview.get_json()["overview"]
        })
    except Exception as e:
        return jsonify({
            "success": False,
            "message": f"获取图表数据失败: {str(e)}"
        }), 500


@stats_bp.route('/api/stats/heatmap', methods=['GET'])
@require_user
def get_activity_heatmap(user):
    """
    获取活动热力图数据
    类似GitHub贡献图
    """
    import calendar
    
    year = request.args.get('year', datetime.now().year, type=int)
    months = request.args.get('months', 12, type=int)
    
    # 获取过去N个月的数据
    start_date = datetime.now() - timedelta(days=months * 30)
    
    tasks = Task.query.filter(
        Task.user_id == user.id,
        Task.created_at >= start_date
    ).all()
    
    # 构建每日数据
    daily_counts = {}
    for task in tasks:
        date = task.created_at.strftime('%Y-%m-%d')
        daily_counts[date] = daily_counts.get(date, 0) + 1
    
    # 构建热力图数据
    heatmap = []
    for date, count in sorted(daily_counts.items()):
        heatmap.append({
            'date': date,
            'count': count,
            'level': min(4, count)  # 0-4级别
        })
    
    return jsonify({
        "success": True,
        "heatmap": heatmap,
        "max_count": max(daily_counts.values()) if daily_counts else 0
    })


@stats_bp.route('/api/stats/productivity', methods=['GET'])
@require_user
def get_productivity_stats(user):
    """
    获取生产力统计
    包括最佳工作时段、平均完成时长等
    """
    from sqlalchemy import func
    
    # 获取已完成的任务
    completed_tasks = Task.query.filter(
        Task.user_id == user.id,
        Task.is_completed == 1,
        Task.actual_end_time != None
    ).all()
    
    if not completed_tasks:
        return jsonify({
            "success": True,
            "productivity": {
                "avg_completion_time": None,
                "best_hour": None,
                "most_productive_category": None,
                "total_completed": 0
            }
        })
    
    # 分析完成时段
    hour_counts = {}
    for task in completed_tasks:
        if task.actual_end_time:
            hour = task.actual_end_time.hour
            hour_counts[hour] = hour_counts.get(hour, 0) + 1
    
    best_hour = max(hour_counts, key=hour_counts.get) if hour_counts else None
    
    # 分析平均完成时长
    durations = [t.actual_duration for t in completed_tasks if t.actual_duration and t.actual_duration > 0]
    avg_duration = sum(durations) / len(durations) if durations else 0
    
    # 分析最高效分类
    category_counts = {}
    for task in completed_tasks:
        category_counts[task.category] = category_counts.get(task.category, 0) + 1
    
    most_productive = max(category_counts, key=category_counts.get) if category_counts else None
    
    return jsonify({
        "success": True,
        "productivity": {
            "avg_completion_time_minutes": round(avg_duration, 1),
            "best_hour": best_hour,
            "best_hour_display": f"{best_hour}:00-{best_hour+1}:00" if best_hour else None,
            "most_productive_category": most_productive,
            "total_completed": len(completed_tasks),
            "hour_distribution": hour_counts
        }
    })
