"""
用户认证路由
支持用户注册、登录、JWT Token认证

使用 AuthManager 统一认证模块
"""

import uuid
import re
from datetime import datetime, timedelta

from flask import Blueprint, jsonify, request, current_app, make_response
import jwt

from extensions import db
from models.task import User
from utils.user_auth import require_user
from utils.auth import AuthManager, generate_token, verify_token, create_token_response
from utils.rate_limiter import strict_rate_limit

# Cookie配置
COOKIE_NAME = 'auth_token'
COOKIE_MAX_AGE = 7 * 24 * 60 * 60  # 7天（秒）
COOKIE_SECURE = False  # 生产环境应设为True（HTTPS）
COOKIE_SAMESITE = 'Lax'  # 防止CSRF攻击

auth_bp = Blueprint('auth', __name__)


# 使用 AuthManager 的 Token 函数
# generate_token 和 verify_token 已从 utils.auth 导入


@auth_bp.route('/api/auth/register', methods=['POST'])
@strict_rate_limit(max_requests=5, window_seconds=300)  # 5分钟最多5次注册
def register():
    """用户注册"""
    data = request.get_json()
    
    if not data:
        return jsonify({
            'success': False,
            'message': '请求数据无效'
        }), 400
    
    username = data.get('username', '').strip()
    password = data.get('password', '')
    email = data.get('email', '').strip()
    nickname = data.get('nickname', '').strip()
    
    # 验证用户名
    if not username:
        return jsonify({
            'success': False,
            'message': '用户名不能为空'
        }), 400
    
    if len(username) < 3 or len(username) > 50:
        return jsonify({
            'success': False,
            'message': '用户名长度应在3-50个字符之间'
        }), 400
    
    if not re.match(r'^[a-zA-Z0-9_\u4e00-\u9fa5]+$', username):
        return jsonify({
            'success': False,
            'message': '用户名只能包含字母、数字、下划线和中文'
        }), 400
    
    # 验证密码
    if not password:
        return jsonify({
            'success': False,
            'message': '密码不能为空'
        }), 400
    
    if len(password) < 6:
        return jsonify({
            'success': False,
            'message': '密码长度至少6个字符'
        }), 400
    
    # 检查用户名是否已存在
    if User.query.filter_by(username=username).first():
        return jsonify({
            'success': False,
            'message': '用户名已被使用'
        }), 400
    
    # 检查邮箱是否已存在
    if email and User.query.filter_by(email=email).first():
        return jsonify({
            'success': False,
            'message': '邮箱已被注册'
        }), 400
    
    # 创建用户
    user_id = str(uuid.uuid4())
    user = User(
        id=user_id,
        username=username,
        email=email if email else None,
        nickname=nickname if nickname else username
    )
    user.set_password(password)
    
    try:
        db.session.add(user)
        db.session.commit()
        
        # 生成Token
        token = generate_token(user_id)
        
        # 创建响应并设置httpOnly Cookie
        response = make_response(jsonify({
            'success': True,
            'message': '注册成功',
            'user': user.to_dict(include_sensitive=True)
        }), 201)
        response.set_cookie(
            COOKIE_NAME, token,
            max_age=COOKIE_MAX_AGE,
            httponly=True,
            secure=COOKIE_SECURE,
            samesite=COOKIE_SAMESITE
        )
        return response
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'注册失败: {str(e)}'
        }), 500


@auth_bp.route('/api/auth/login', methods=['POST'])
@strict_rate_limit(max_requests=10, window_seconds=300)  # 5分钟最多10次登录
def login():
    """用户登录"""
    data = request.get_json()
    
    if not data:
        return jsonify({
            'success': False,
            'message': '请求数据无效'
        }), 400
    
    username = data.get('username', '').strip()
    password = data.get('password', '')
    
    if not username or not password:
        return jsonify({
            'success': False,
            'message': '用户名和密码不能为空'
        }), 400
    
    # 查找用户（支持用户名或邮箱登录）
    user = User.query.filter(
        (User.username == username) | (User.email == username)
    ).first()
    
    if not user:
        return jsonify({
            'success': False,
            'message': '用户不存在'
        }), 401
    
    if not user.password_hash:
        return jsonify({
            'success': False,
            'message': '该账户未设置密码，请使用其他方式登录'
        }), 401
    
    if not user.check_password(password):
        return jsonify({
            'success': False,
            'message': '密码错误'
        }), 401
    
    # 更新最后访问时间
    user.last_visit = datetime.now()
    db.session.commit()
    
    # 生成Token
    token = generate_token(user.id)
    
    # 创建响应并设置httpOnly Cookie
    response = make_response(jsonify({
        'success': True,
        'message': '登录成功',
        'user': user.to_dict(include_sensitive=True)
    }))
    response.set_cookie(
        COOKIE_NAME, token,
        max_age=COOKIE_MAX_AGE,
        httponly=True,
        secure=COOKIE_SECURE,
        samesite=COOKIE_SAMESITE
    )
    return response


@auth_bp.route('/api/auth/logout', methods=['POST'])
def logout():
    """用户登出（清除httpOnly Cookie）"""
    response = make_response(jsonify({
        'success': True,
        'message': '登出成功'
    }))
    # 清除Cookie
    response.delete_cookie(COOKIE_NAME)
    return response


@auth_bp.route('/api/auth/profile', methods=['GET'])
@require_user
def get_profile(user):
    """获取当前用户信息"""
    return jsonify({
        'success': True,
        'user': user.to_dict(include_sensitive=True)
    })


@auth_bp.route('/api/auth/profile', methods=['PUT'])
@require_user
def update_profile(user):
    """更新用户信息"""
    data = request.get_json()
    
    if not data:
        return jsonify({
            'success': False,
            'message': '请求数据无效'
        }), 400
    
    # 更新昵称
    if 'nickname' in data:
        nickname = data['nickname'].strip()
        if nickname:
            user.nickname = nickname
        elif nickname == '':
            user.nickname = None
    
    # 更新邮箱
    if 'email' in data:
        email = data['email'].strip()
        if email:
            # 检查邮箱是否被其他用户使用
            existing = User.query.filter(
                User.email == email, User.id != user.id
            ).first()
            if existing:
                return jsonify({
                    'success': False,
                    'message': '邮箱已被其他用户使用'
                }), 400
            user.email = email
        else:
            user.email = None
    
    # 更新头像
    if 'avatar' in data:
        user.avatar = data['avatar']
    
    # 更新密码
    if 'new_password' in data and data['new_password']:
        old_password = data.get('old_password', '')
        
        if not user.password_hash or user.check_password(old_password):
            if len(data['new_password']) < 6:
                return jsonify({
                    'success': False,
                    'message': '新密码长度至少6个字符'
                }), 400
            user.set_password(data['new_password'])
        else:
            return jsonify({
                'success': False,
                'message': '原密码错误'
            }), 400
    
    try:
        db.session.commit()
        return jsonify({
            'success': True,
            'message': '更新成功',
            'user': user.to_dict(include_sensitive=True)
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'更新失败: {str(e)}'
        }), 500


@auth_bp.route('/api/auth/check-username', methods=['GET'])
def check_username():
    """检查用户名是否可用"""
    username = request.args.get('username', '').strip()
    
    if not username:
        return jsonify({
            'success': False,
            'message': '用户名不能为空'
        }), 400
    
    exists = User.query.filter_by(username=username).first() is not None
    
    return jsonify({
        'success': True,
        'available': not exists,
        'message': '用户名可用' if not exists else '用户名已被使用'
    })


@auth_bp.route('/api/auth/verify', methods=['GET'])
def verify_token_endpoint():
    """验证Token是否有效"""
    auth_header = request.headers.get('Authorization', '')
    
    if not auth_header.startswith('Bearer '):
        return jsonify({
            'success': False,
            'message': '缺少Token',
            'valid': False
        }), 401
    
    token = auth_header[7:]
    user_id = verify_token(token)
    
    if not user_id:
        return jsonify({
            'success': False,
            'message': 'Token无效或已过期',
            'valid': False
        }), 401
    
    user = User.query.get(user_id)
    if not user:
        return jsonify({
            'success': False,
            'message': '用户不存在',
            'valid': False
        }), 401
    
    return jsonify({
        'success': True,
        'valid': True,
        'user': user.to_dict()
    })


# ==================== 忘记密码功能 ====================

# 临时存储重置token（生产环境应使用Redis）
_password_reset_tokens = {}


@auth_bp.route('/api/auth/email-config', methods=['GET'])
def get_email_config():
    """获取邮件服务配置状态"""
    from utils.email import get_email_config_status
    
    config = get_email_config_status()
    return jsonify({
        'success': True,
        'configured': config['configured'],
        'method': config['method']
    })


@auth_bp.route('/api/auth/forgot-password', methods=['POST'])
def forgot_password():
    """
    忘记密码 - 发送重置链接或返回重置token
    
    如果配置了邮件服务（Resend/SMTP）：发送邮件
    如果未配置邮件服务：开发模式，直接返回token
    """
    import secrets
    from utils.email import send_password_reset_email, get_email_config_status
    
    data = request.get_json()
    username_or_email = data.get('username_or_email', '').strip()
    
    if not username_or_email:
        return jsonify({
            'success': False,
            'message': '请输入用户名或邮箱'
        }), 400
    
    # 查找用户
    user = User.query.filter(
        (User.username == username_or_email) | (User.email == username_or_email)
    ).first()
    
    # 检查邮件服务配置状态
    email_config = get_email_config_status()
    
    # 如果用户不存在且配置了邮件服务，返回模糊消息（安全考虑）
    if not user:
        if email_config['configured']:
            return jsonify({
                'success': True,
                'message': '如果该用户存在，重置链接已发送到关联邮箱'
            })
        else:
            return jsonify({
                'success': False,
                'message': '用户不存在'
            }), 404
    
    # 检查用户是否有邮箱
    if not user.email:
        return jsonify({
            'success': False,
            'message': '该账户未绑定邮箱，无法重置密码'
        }), 400
    
    # 生成重置token
    reset_token = secrets.token_urlsafe(32)
    _password_reset_tokens[reset_token] = {
        'user_id': user.id,
        'expires': datetime.now() + timedelta(hours=1)
    }
    
    # 发送邮件或返回token
    if email_config['configured']:
        # 生产环境：发送邮件
        try:
            result = send_password_reset_email(user.email, reset_token, user.username)
            if result['success']:
                return jsonify({
                    'success': True,
                    'message': f'重置链接已发送到 {user.email}'
                })
            else:
                return jsonify({
                    'success': False,
                    'message': f'邮件发送失败: {result["message"]}'
                }), 500
        except Exception as e:
            return jsonify({
                'success': False,
                'message': f'发送邮件失败: {str(e)}'
            }), 500
    else:
        # 开发环境：直接返回token
        return jsonify({
            'success': True,
            'message': '验证成功（开发模式：未配置邮件服务）',
            'reset_token': reset_token,
            'email': user.email
        })


@auth_bp.route('/api/auth/reset-password', methods=['POST'])
def reset_password():
    """重置密码"""
    data = request.get_json()
    token = data.get('token', '')
    new_password = data.get('new_password', '')
    
    if not token or not new_password:
        return jsonify({
            'success': False,
            'message': '参数无效'
        }), 400
    
    if len(new_password) < 6:
        return jsonify({
            'success': False,
            'message': '密码长度至少6个字符'
        }), 400
    
    # 验证token
    token_data = _password_reset_tokens.get(token)
    
    if not token_data:
        return jsonify({
            'success': False,
            'message': '重置链接无效'
        }), 400
    
    if datetime.now() > token_data['expires']:
        del _password_reset_tokens[token]
        return jsonify({
            'success': False,
            'message': '重置链接已过期'
        }), 400
    
    # 查找用户
    user = User.query.get(token_data['user_id'])
    if not user:
        return jsonify({
            'success': False,
            'message': '用户不存在'
        }), 400
    
    # 更新密码
    user.set_password(new_password)
    db.session.commit()
    
    # 删除已使用的token
    del _password_reset_tokens[token]
    
    return jsonify({
        'success': True,
        'message': '密码重置成功'
    })
