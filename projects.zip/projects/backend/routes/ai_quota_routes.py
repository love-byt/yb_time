"""
AI额度管理路由
"""

from flask import Blueprint, jsonify

from extensions import db
from models.task import User
from utils.ai_helper import AIHelper
from utils.user_auth import require_user
from config import Config

ai_quota_bp = Blueprint('ai_quota', __name__)


def get_ai_helper(user=None):
    """获取AI助手实例"""
    api_key = ''
    
    if user:
        user_obj = User.query.get(user.id) if hasattr(user, 'id') else User.query.get(user)
        if user_obj and user_obj.ai_api_key:
            return AIHelper(user_obj.ai_api_key), 'user_db'
    
    return AIHelper(Config.TONGYI_API_KEY), 'system'


def check_ai_quota(user):
    """检查用户AI使用额度"""
    user_obj = User.query.get(user.id) if hasattr(user, 'id') else User.query.get(user)
    if not user_obj:
        return False, 'user_not_found', None, None
    
    ai_helper, source = get_ai_helper(user_obj)
    
    if source in ['user_header', 'user_db']:
        return True, 'custom_key', ai_helper, source
    
    can_use, reason = user_obj.can_use_ai()
    if can_use:
        return True, reason, ai_helper, source
    
    return False, reason, ai_helper, source


@ai_quota_bp.route('/api/ai/usage', methods=['GET'])
@require_user
def get_ai_usage(user):
    """获取AI使用情况"""
    user_obj = User.query.get(user.id)
    if not user_obj:
        return jsonify({"success": False, "message": "用户不存在"}), 404
    
    return jsonify({
        "success": True,
        "usage": user_obj.get_ai_usage()
    })


@ai_quota_bp.route('/api/ai/api-key', methods=['POST'])
@require_user
def set_ai_api_key(user):
    """设置用户AI API Key"""
    from flask import request
    
    data = request.get_json()
    api_key = data.get('api_key', '').strip()
    
    user_obj = User.query.get(user.id)
    if not user_obj:
        return jsonify({"success": False, "message": "用户不存在"}), 404
    
    if api_key:
        user_obj.ai_api_key = api_key
        message = "API Key已设置，现在可以使用无限次数的AI功能"
    else:
        user_obj.ai_api_key = None
        message = "API Key已清除，将使用系统免费额度"
    
    db.session.commit()
    
    return jsonify({
        "success": True,
        "message": message,
        "usage": user_obj.get_ai_usage()
    })


@ai_quota_bp.route('/api/ai/check-quota', methods=['GET'])
@require_user
def check_ai_quota_api(user):
    """检查AI使用额度"""
    can_use, reason, ai_helper, source = check_ai_quota(user)
    
    return jsonify({
        "success": True,
        "can_use": can_use,
        "reason": reason,
        "source": source,
        "message": "" if can_use else "今日免费额度已用完，请配置个人API Key以继续使用"
    })
