"""
配置文件
包含数据库配置、API密钥等
"""

import os

from dotenv import load_dotenv

# 加载环境变量
load_dotenv()


class Config:
    """配置类"""

    # 数据库配置 - 使用绝对路径确保数据持久化
    BASE_DIR = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or \
        'sqlite:///' + os.path.join(BASE_DIR, 'instance', 'schedule.db')
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # Flask配置
    SECRET_KEY = os.getenv('SECRET_KEY')
    DEBUG = os.getenv('FLASK_DEBUG', 'False').lower() in ('true', '1', 'yes')
    
    # 安全警告：生产环境必须设置 SECRET_KEY
    if not SECRET_KEY and not DEBUG:
        raise ValueError(
            "生产环境必须设置 SECRET_KEY 环境变量!\n"
            "请运行: export SECRET_KEY=$(python -c \"import secrets; print(secrets.token_hex(32))\")"
        )
    # 开发环境使用默认密钥（仅用于开发）
    if not SECRET_KEY:
        SECRET_KEY = 'dev-secret-key-2024-change-in-production'

    # AI API配置（从环境变量读取）
    TONGYI_API_KEY = os.getenv('TONGYI_API_KEY', '')
    WENXIN_API_KEY = os.getenv('WENXIN_API_KEY', '')
    WENXIN_SECRET_KEY = os.getenv('WENXIN_SECRET_KEY', '')

    # API基础URL
    TONGYI_API_URL = (
        'https://dashscope.aliyuncs.com/api/v1/services/aigc/text-generation/generation'
    )
    WENXIN_API_URL = (
        'https://aip.baidubce.com/rpc/2.0/ai_custom/v1/wenxinworkshop/chat/completions'
    )

    # 服务配置
    HOST = '0.0.0.0'
    PORT = int(os.getenv('DEPLOY_RUN_PORT', 5000))
    
    # VAPID配置（用于Web推送通知）
    # 生产环境应从环境变量获取
    VAPID_PUBLIC_KEY = os.getenv('VAPID_PUBLIC_KEY', '')
    VAPID_PRIVATE_KEY = os.getenv('VAPID_PRIVATE_KEY', '')
    VAPID_SUBJECT = os.getenv('VAPID_SUBJECT', 'mailto:admin@smart-scheduler.com')
    
    # 如果没有配置VAPID密钥，生成默认密钥对
    @classmethod
    def generate_vapid_keys(cls):
        """生成VAPID密钥对（首次运行时调用）"""
        try:
            from cryptography.hazmat.primitives.asymmetric import ec
            from cryptography.hazmat.backends import default_backend
            import base64
            
            private_key = ec.generate_private_key(ec.SECP256R1(), default_backend())
            
            private_numbers = private_key.private_numbers()
            public_key = private_key.public_key()
            
            # 编码私钥
            private_value = private_numbers.private_value.to_bytes(32, 'big')
            private_encoded = base64.urlsafe_b64encode(private_value).rstrip(b'=').decode('utf-8')
            
            # 编码公钥
            public_numbers = public_key.public_numbers()
            public_value = public_numbers.x.to_bytes(32, 'big') + public_numbers.y.to_bytes(32, 'big')
            public_encoded = base64.urlsafe_b64encode(public_value).rstrip(b'=').decode('utf-8')
            
            return public_encoded, private_encoded
        except Exception as e:
            print(f"生成VAPID密钥失败: {e}")
            return None, None
