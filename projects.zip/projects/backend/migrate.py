#!/usr/bin/env python
"""
数据库迁移管理脚本
使用方法：
    python migrate.py init      # 初始化迁移
    python migrate.py migrate   # 执行迁移
    python migrate.py rollback  # 回滚迁移
    python migrate.py status    # 查看状态
"""

import os
import sys
import subprocess

# 确保backend目录在路径中
backend_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, backend_dir)


def run_alembic(command: str):
    """执行alembic命令"""
    full_command = f"cd {backend_dir} && alembic {command}"
    result = subprocess.run(full_command, shell=True, capture_output=True, text=True)
    
    if result.returncode != 0:
        print(f"[ERROR] 执行失败: {result.stderr}")
        return False
    
    print(result.stdout)
    return True


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    
    action = sys.argv[1]
    
    if action == 'init':
        # 初始化迁移（标记当前版本）
        print("[MIGRATE] 初始化数据库迁移...")
        run_alembic("stamp head")
        print("[MIGRATE] 迁移初始化完成！")
        
    elif action == 'migrate':
        # 执行迁移
        print("[MIGRATE] 执行数据库迁移...")
        run_alembic("upgrade head")
        print("[MIGRATE] 迁移完成！")
        
    elif action == 'rollback':
        # 回滚迁移
        print("[MIGRATE] 回滚数据库迁移...")
        steps = sys.argv[2] if len(sys.argv) > 2 else "-1"
        run_alembic(f"downgrade {steps}")
        print("[MIGRATE] 回滚完成！")
        
    elif action == 'status':
        # 查看状态
        print("[MIGRATE] 数据库迁移状态：")
        run_alembic("current")
        
    elif action == 'history':
        # 查看历史
        print("[MIGRATE] 迁移历史：")
        run_alembic("history")
        
    elif action == 'generate':
        # 生成迁移脚本
        message = sys.argv[2] if len(sys.argv) > 2 else "auto migration"
        print(f"[MIGRATE] 生成迁移脚本: {message}")
        run_alembic(f"revision --autogenerate -m '{message}'")
        print("[MIGRATE] 迁移脚本生成完成！")
        
    else:
        print(f"[ERROR] 未知命令: {action}")
        print(__doc__)
        sys.exit(1)


if __name__ == '__main__':
    main()
