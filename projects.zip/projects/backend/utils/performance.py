"""
性能监控工具
提供API性能监控、日志记录和指标收集功能
"""

import os
import time
import json
import logging
from datetime import datetime
from functools import wraps
from typing import Dict, List, Optional
from collections import defaultdict
import threading

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('performance')


class PerformanceMetrics:
    """性能指标收集器"""
    
    _instance = None
    _lock = threading.Lock()
    
    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._metrics = defaultdict(list)
                    cls._instance._slow_requests = []
                    cls._instance._error_count = defaultdict(int)
        return cls._instance
    
    def record_request(self, endpoint: str, method: str, duration_ms: float, 
                       status_code: int, user_id: Optional[str] = None):
        """记录请求指标"""
        key = f"{method}:{endpoint}"
        
        # 记录响应时间
        self._metrics[key].append({
            'timestamp': datetime.now().isoformat(),
            'duration_ms': duration_ms,
            'status_code': status_code,
            'user_id': user_id
        })
        
        # 保留最近1000条记录
        if len(self._metrics[key]) > 1000:
            self._metrics[key] = self._metrics[key][-1000:]
        
        # 记录慢请求（>1秒）
        if duration_ms > 1000:
            self._slow_requests.append({
                'endpoint': endpoint,
                'method': method,
                'duration_ms': duration_ms,
                'timestamp': datetime.now().isoformat()
            })
            # 保留最近100条慢请求
            if len(self._slow_requests) > 100:
                self._slow_requests = self._slow_requests[-100:]
        
        # 记录错误
        if status_code >= 400:
            self._error_count[key] += 1
    
    def get_stats(self, endpoint: str = None) -> Dict:
        """获取统计信息"""
        stats = {}
        
        if endpoint:
            key = endpoint
            if key in self._metrics:
                metrics = self._metrics[key]
                durations = [m['duration_ms'] for m in metrics]
                stats[key] = {
                    'count': len(metrics),
                    'avg_ms': sum(durations) / len(durations) if durations else 0,
                    'min_ms': min(durations) if durations else 0,
                    'max_ms': max(durations) if durations else 0,
                    'p95_ms': self._percentile(durations, 95) if durations else 0,
                    'p99_ms': self._percentile(durations, 99) if durations else 0,
                    'error_count': self._error_count.get(key, 0)
                }
        else:
            # 返回所有端点的统计
            for key, metrics in self._metrics.items():
                durations = [m['duration_ms'] for m in metrics]
                stats[key] = {
                    'count': len(metrics),
                    'avg_ms': sum(durations) / len(durations) if durations else 0,
                    'min_ms': min(durations) if durations else 0,
                    'max_ms': max(durations) if durations else 0,
                    'p95_ms': self._percentile(durations, 95) if durations else 0,
                    'p99_ms': self._percentile(durations, 99) if durations else 0,
                    'error_count': self._error_count.get(key, 0)
                }
        
        return stats
    
    def get_slow_requests(self, limit: int = 20) -> List[Dict]:
        """获取慢请求列表"""
        return self._slow_requests[-limit:]
    
    def _percentile(self, data: List[float], percentile: int) -> float:
        """计算百分位数"""
        if not data:
            return 0
        sorted_data = sorted(data)
        index = int(len(sorted_data) * percentile / 100)
        return sorted_data[min(index, len(sorted_data) - 1)]
    
    def reset(self):
        """重置所有指标"""
        with self._lock:
            self._metrics.clear()
            self._slow_requests.clear()
            self._error_count.clear()


# 全局指标收集器
metrics = PerformanceMetrics()


class PerformanceMiddleware:
    """Flask性能监控中间件"""
    
    def __init__(self, app=None):
        self.app = app
        if app is not None:
            self.init_app(app)
    
    def init_app(self, app):
        """初始化中间件"""
        # 请求前
        @app.before_request
        def before_request():
            from flask import g, request
            g.start_time = time.time()
            g.request_id = f"{request.method}:{request.path}"
        
        # 请求后
        @app.after_request
        def after_request(response):
            from flask import g, request
            
            # 计算响应时间
            start_time = getattr(g, 'start_time', time.time())
            duration_ms = (time.time() - start_time) * 1000
            
            # 获取用户ID（如果已认证）
            user_id = None
            if hasattr(g, 'user'):
                user_id = g.user.id if hasattr(g.user, 'id') else str(g.user)
            
            # 记录指标
            metrics.record_request(
                endpoint=request.path,
                method=request.method,
                duration_ms=duration_ms,
                status_code=response.status_code,
                user_id=user_id
            )
            
            # 添加性能头（确保只包含ASCII字符）
            response.headers['X-Response-Time'] = f"{duration_ms:.2f}ms"
            # 对request_id进行ASCII安全编码
            request_id = getattr(g, 'request_id', '')
            if request_id:
                # 使用URL编码方式处理非ASCII字符
                from urllib.parse import quote
                safe_request_id = quote(request_id, safe=':/')
                response.headers['X-Request-ID'] = safe_request_id
            
            # 记录日志
            log_level = logging.INFO
            if duration_ms > 1000:
                log_level = logging.WARNING
            elif response.status_code >= 400:
                log_level = logging.ERROR
            
            logger.log(log_level, 
                      f"{request.method} {request.path} - "
                      f"{response.status_code} - "
                      f"{duration_ms:.2f}ms - "
                      f"user={user_id or 'anonymous'}")
            
            return response


def monitor_performance(func):
    """
    性能监控装饰器
    用于监控特定函数的执行时间
    """
    @wraps(func)
    def wrapper(*args, **kwargs):
        start_time = time.time()
        try:
            result = func(*args, **kwargs)
            duration_ms = (time.time() - start_time) * 1000
            
            # 记录函数执行时间
            logger.debug(f"Function {func.__name__} executed in {duration_ms:.2f}ms")
            
            return result
        except Exception as e:
            duration_ms = (time.time() - start_time) * 1000
            logger.error(f"Function {func.__name__} failed after {duration_ms:.2f}ms: {e}")
            raise
    
    return wrapper


def log_performance(func):
    """
    详细性能日志装饰器
    记录函数参数、执行时间和返回值
    """
    @wraps(func)
    def wrapper(*args, **kwargs):
        start_time = time.time()
        func_name = func.__name__
        
        # 记录调用参数
        logger.debug(f"Calling {func_name} with args={args[:2]}..., kwargs={list(kwargs.keys())}")
        
        try:
            result = func(*args, **kwargs)
            duration_ms = (time.time() - start_time) * 1000
            
            # 根据执行时间选择日志级别
            if duration_ms > 1000:
                logger.warning(f"Slow function: {func_name} took {duration_ms:.2f}ms")
            else:
                logger.debug(f"Function {func_name} completed in {duration_ms:.2f}ms")
            
            return result
        except Exception as e:
            duration_ms = (time.time() - start_time) * 1000
            logger.error(f"Function {func_name} failed after {duration_ms:.2f}ms: {str(e)}")
            raise
    
    return wrapper


class StructuredLogger:
    """结构化日志记录器"""
    
    def __init__(self, name: str, log_file: str = None):
        self.logger = logging.getLogger(name)
        self.log_file = log_file
        
        if log_file:
            try:
                # 确保日志目录存在
                log_dir = os.path.dirname(log_file)
                if log_dir and not os.path.exists(log_dir):
                    os.makedirs(log_dir, exist_ok=True)
                
                # 创建文件处理器
                file_handler = logging.FileHandler(log_file)
                file_handler.setFormatter(logging.Formatter(
                    '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
                ))
                self.logger.addHandler(file_handler)
            except (OSError, PermissionError) as e:
                # 如果无法创建日志文件，仅使用控制台日志
                self.logger.warning(f"无法创建日志文件 {log_file}: {e}，将仅使用控制台日志")
    
    def log(self, level: str, message: str, **kwargs):
        """记录结构化日志"""
        log_data = {
            'message': message,
            'timestamp': datetime.now().isoformat(),
            **kwargs
        }
        
        log_message = json.dumps(log_data, ensure_ascii=False)
        
        if level == 'DEBUG':
            self.logger.debug(log_message)
        elif level == 'INFO':
            self.logger.info(log_message)
        elif level == 'WARNING':
            self.logger.warning(log_message)
        elif level == 'ERROR':
            self.logger.error(log_message)
        elif level == 'CRITICAL':
            self.logger.critical(log_message)
    
    def info(self, message: str, **kwargs):
        self.log('INFO', message, **kwargs)
    
    def error(self, message: str, **kwargs):
        self.log('ERROR', message, **kwargs)
    
    def warning(self, message: str, **kwargs):
        self.log('WARNING', message, **kwargs)
    
    def debug(self, message: str, **kwargs):
        self.log('DEBUG', message, **kwargs)


# 创建API日志记录器
# 生产环境使用控制台日志，开发环境可以指定日志文件
def _create_api_logger():
    """延迟创建API日志记录器"""
    env = os.getenv('COZE_PROJECT_ENV', 'DEV')
    if env == 'PROD':
        # 生产环境仅使用控制台日志
        return StructuredLogger('api')
    else:
        # 开发环境尝试使用文件日志
        log_file = '/app/work/logs/bypass/api.log'
        try:
            log_dir = os.path.dirname(log_file)
            if log_dir and not os.path.exists(log_dir):
                os.makedirs(log_dir, exist_ok=True)
            return StructuredLogger('api', log_file)
        except (OSError, PermissionError):
            # 如果无法创建日志文件，回退到控制台日志
            return StructuredLogger('api')


api_logger = _create_api_logger()
