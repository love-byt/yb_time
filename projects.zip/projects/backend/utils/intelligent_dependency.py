"""
智能任务依赖管理系统
自动发现、验证、优化任务依赖关系
"""

import asyncio
import re
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Any, Dict, List, Optional, Set, Tuple
import numpy as np

from utils.task_dependency import TaskDependencyGraph, TaskNode


class DependencyType(Enum):
    """依赖类型"""
    EXPLICIT = "explicit"      # 显式声明
    SEMANTIC = "semantic"      # 语义分析发现
    HISTORICAL = "historical"  # 历史行为挖掘
    CONTEXT = "context"        # 上下文提取
    TEMPORAL = "temporal"      # 时间依赖
    RESOURCE = "resource"      # 资源依赖
    NONE = "none"              # 无依赖


@dataclass
class DependencySuggestion:
    """依赖建议"""
    source: str  # 源任务ID
    target: str  # 目标任务ID
    type: DependencyType
    confidence: float  # 置信度 0-1
    reason: str  # 推荐理由
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ValidationResult:
    """验证结果"""
    valid: List[DependencySuggestion] = field(default_factory=list)
    warnings: List[Tuple[DependencySuggestion, str]] = field(default_factory=list)
    low_confidence: List[DependencySuggestion] = field(default_factory=list)
    
    def add_valid(self, suggestion: DependencySuggestion):
        self.valid.append(suggestion)
    
    def add_warning(self, suggestion: DependencySuggestion, reason: str):
        self.warnings.append((suggestion, reason))
    
    def add_low_confidence(self, suggestion: DependencySuggestion):
        self.low_confidence.append(suggestion)


@dataclass
class ExecutionConstraints:
    """执行约束"""
    max_parallel_tasks: Optional[int] = None
    balance_workload: bool = True
    respect_deadlines: bool = True
    resource_limits: Dict[str, int] = field(default_factory=dict)


@dataclass
class OptimizedPlan:
    """优化后的执行计划"""
    execution_order: List[str]  # 任务执行顺序
    critical_path: List[str]    # 关键路径
    parallel_groups: List[List[str]]  # 可并行任务组
    estimated_completion: timedelta  # 预计完成时间
    resource_allocation: Dict[str, List[str]]  # 资源分配
    suggestions: List[str] = field(default_factory=list)  # 优化建议


class DependencySemanticAnalyzer:
    """
    基于语义的依赖分析器
    使用文本嵌入和LLM理解任务间的潜在依赖关系
    """
    
    def __init__(self, model: str = "text2vec"):
        self.model_name = model
        self.embedding_model = None
        self._load_model()
    
    def _load_model(self):
        """加载嵌入模型"""
        try:
            from sentence_transformers import SentenceTransformer
            self.embedding_model = SentenceTransformer('paraphrase-multilingual-MiniLM-L12-v2')
            print("[依赖管理] 语义分析器加载成功")
        except ImportError:
            print("[WARN] sentence-transformers 未安装，语义分析使用降级方案")
            self.embedding_model = None
    
    async def find_semantic_dependencies(
        self,
        target_task: Optional[Dict[str, Any]],
        candidate_tasks: Optional[List[Dict[str, Any]]]
    ) -> List[DependencySuggestion]:
        """
        基于语义相似度发现依赖关系
        """
        suggestions: List[DependencySuggestion] = []
        
        # 空值检查
        if self.embedding_model is None:
            return suggestions
        if target_task is None:
            return suggestions
        if not candidate_tasks:
            return suggestions
        
        try:
            # 1. 计算目标任务嵌入
            target_title: str = target_task.get('title', '') or ''
            target_desc: str = target_task.get('description', '') or ''
            target_text: str = f"{target_title} {target_desc}".strip()
            if not target_text:
                return suggestions
            target_embedding = self.embedding_model.encode(target_text)
            
            # 2. 筛选相似候选
            candidates_with_scores: List[Tuple[Dict[str, Any], float]] = []
            target_id: Any = target_task.get('id')
            for task in candidate_tasks:
                if task is None or not isinstance(task, dict):
                    continue
                if task.get('id') == target_id:
                    continue
                
                task_text = f"{task.get('title', '')} {task.get('description', '')}"
                task_embedding = self.embedding_model.encode(task_text)
                
                # 余弦相似度
                similarity = self._cosine_similarity(target_embedding, task_embedding)
                
                if similarity > 0.4:  # 相似度阈值
                    candidates_with_scores.append((task, similarity))
            
            # 3. 分析依赖关系
            for task, similarity in candidates_with_scores:
                dependency_type = await self._analyze_dependency_relation(
                    target_task, task
                )
                
                if dependency_type != DependencyType.NONE:
                    confidence = self._calculate_confidence(similarity, dependency_type)
                    
                    suggestions.append(DependencySuggestion(
                        source=target_task.get('id'),
                        target=task.get('id'),
                        type=dependency_type,
                        confidence=confidence,
                        reason=f"语义相似度: {similarity:.2f}，分析为{dependency_type.value}依赖",
                        metadata={"similarity": similarity}
                    ))
        
        except Exception as e:
            print(f"[ERROR] 语义依赖分析失败: {e}")
        
        return suggestions
    
    def _cosine_similarity(self, a: np.ndarray, b: np.ndarray) -> float:
        """计算余弦相似度"""
        dot_product = np.dot(a, b)
        norm_a = np.linalg.norm(a)
        norm_b = np.linalg.norm(b)
        
        if norm_a == 0 or norm_b == 0:
            return 0.0
        
        return dot_product / (norm_a * norm_b)
    
    async def _analyze_dependency_relation(
        self,
        task_a: Dict[str, Any],
        task_b: Dict[str, Any]
    ) -> DependencyType:
        """
        分析两个任务间的依赖关系
        简化实现：基于关键词和启发式规则
        """
        title_a = task_a.get('title', '').lower()
        title_b = task_b.get('title', '').lower()
        desc_a = task_a.get('description', '').lower()
        desc_b = task_b.get('description', '').lower()
        
        text_a = f"{title_a} {desc_a}"
        text_b = f"{title_b} {desc_b}"
        
        # 1. 检查显式依赖声明
        explicit_patterns = [
            r'依赖于\s*["""]?([^"""]+)["""]?',
            r'前置任务[是为:]\s*["""]?([^"""]+)["""]?',
            r'depends?\s+on\s+["""]?([^"""]+)["""]?',
            r'after\s+["""]?([^"""]+)["""]?',
        ]
        
        for pattern in explicit_patterns:
            if re.search(pattern, text_a):
                return DependencyType.EXPLICIT
        
        # 2. 检查语义关联（关键词重叠）
        keywords_a = set(self._extract_keywords(text_a))
        keywords_b = set(self._extract_keywords(text_b))
        
        overlap = len(keywords_a & keywords_b)
        total = len(keywords_a | keywords_b)
        
        if total > 0 and overlap / total > 0.5:
            # 高关键词重叠，可能是相关任务
            # 检查时间关系
            deadline_a = task_a.get('deadline')
            deadline_b = task_b.get('deadline')
            
            if deadline_a and deadline_b:
                # 如果A的截止时间在B之后，A可能依赖于B
                if deadline_a > deadline_b:
                    return DependencyType.TEMPORAL
            
            return DependencyType.SEMANTIC
        
        return DependencyType.NONE
    
    def _extract_keywords(self, text: str) -> List[str]:
        """提取关键词"""
        # 简化实现：分词并过滤停用词
        words = re.findall(r'\b\w+\b', text.lower())
        stopwords = {'the', 'a', 'an', 'is', 'are', 'was', 'were', 
                    '的', '了', '在', '是', '和', '有'}
        return [w for w in words if w not in stopwords and len(w) > 1]
    
    def _calculate_confidence(self, similarity: float, 
                             dependency_type: DependencyType) -> float:
        """计算置信度"""
        base_confidence = similarity
        
        # 根据依赖类型调整
        type_weights = {
            DependencyType.EXPLICIT: 0.95,
            DependencyType.TEMPORAL: 0.85,
            DependencyType.SEMANTIC: 0.70,
            DependencyType.HISTORICAL: 0.65,
            DependencyType.CONTEXT: 0.60,
        }
        
        weight = type_weights.get(dependency_type, 0.5)
        return min(base_confidence * weight + 0.1, 1.0)


class DependencyPatternMiner:
    """
    依赖模式挖掘器
    从用户历史行为中挖掘依赖模式
    """
    
    def __init__(self):
        self.patterns: Dict[str, List[Dict]] = {}
    
    def mine_patterns(
        self,
        user_id: str,
        task_type: Optional[str] = None
    ) -> List[DependencySuggestion]:
        """
        挖掘用户的依赖模式
        简化实现：基于常见任务序列
        """
        suggestions = []
        
        # 预定义一些常见模式
        common_patterns = {
            "开发任务": [
                ("需求分析", "设计文档", 0.9),
                ("设计文档", "编码实现", 0.95),
                ("编码实现", "代码审查", 0.9),
                ("代码审查", "测试", 0.85),
            ],
            "写作任务": [
                ("资料收集", "大纲撰写", 0.85),
                ("大纲撰写", "正文写作", 0.9),
                ("正文写作", "修改润色", 0.85),
            ],
            "学习任务": [
                ("预习", "上课", 0.8),
                ("上课", "复习", 0.85),
                ("复习", "作业", 0.8),
            ],
        }
        
        # TODO: 实现从数据库查询用户历史依赖模式
        # 当前为简化实现，返回基于规则的预定义模式
        # 后续需要接入真实的用户行为数据分析
        
        return suggestions


class DependencyValidator:
    """
    依赖验证器
    验证依赖建议的有效性
    """
    
    def __init__(self):
        self.graph = TaskDependencyGraph()
    
    def would_create_cycle(
        self,
        suggestion: DependencySuggestion,
        existing_dependencies: List[Tuple[str, str]]
    ) -> bool:
        """
        检查添加此依赖是否会产生循环
        """
        # 构建临时图
        temp_graph = TaskDependencyGraph()
        
        # 添加现有依赖
        for source, target in existing_dependencies:
            temp_graph.add_dependency(source, target)
        
        # 添加新依赖
        temp_graph.add_dependency(suggestion.source, suggestion.target)
        
        # 检查循环
        return not temp_graph.validate_no_cycles()
    
    def has_temporal_conflict(
        self,
        suggestion: DependencySuggestion,
        tasks: Dict[str, Dict[str, Any]]
    ) -> bool:
        """
        检查时间冲突
        """
        source_task = tasks.get(suggestion.source)
        target_task = tasks.get(suggestion.target)
        
        if not source_task or not target_task:
            return False
        
        source_deadline = source_task.get('deadline')
        target_deadline = target_task.get('deadline')
        
        if source_deadline and target_deadline:
            # 如果源任务截止时间早于目标任务，可能有冲突
            # 因为源任务依赖于目标任务，应该先完成目标
            if source_deadline < target_deadline:
                return True
        
        return False
    
    def has_resource_conflict(
        self,
        suggestion: DependencySuggestion,
        tasks: Dict[str, Dict[str, Any]]
    ) -> bool:
        """
        检查资源冲突
        简化实现
        """
        # 实际应该检查资源分配
        return False


class IntelligentDependencyManager:
    """
    智能依赖管理器
    自动发现、验证、优化任务依赖关系
    """
    
    def __init__(self):
        self.graph = TaskDependencyGraph()
        self.semantic_analyzer = DependencySemanticAnalyzer()
        self.pattern_miner = DependencyPatternMiner()
        self.validator = DependencyValidator()
    
    async def discover_dependencies(
        self,
        task: Dict[str, Any],
        all_tasks: List[Dict[str, Any]],
        context: str = "",
        user_id: Optional[str] = None
    ) -> List[DependencySuggestion]:
        """
        多源依赖发现
        
        1. 显式依赖：从任务描述中解析
        2. 语义依赖：基于任务内容相似度
        3. 历史依赖：从用户历史行为挖掘
        4. 上下文依赖：从对话上下文中提取
        """
        suggestions = []
        
        # 1. 显式依赖解析
        explicit_deps = self._parse_explicit_dependencies(
            task.get('description', '')
        )
        for dep in explicit_deps:
            # 查找匹配的任务
            target_task = self._find_task_by_reference(dep['reference'], all_tasks)
            if target_task:
                suggestions.append(DependencySuggestion(
                    source=task.get('id'),
                    target=target_task.get('id'),
                    type=DependencyType.EXPLICIT,
                    confidence=0.95,
                    reason=f"任务描述中明确提到: {dep['evidence']}"
                ))
        
        # 2. 语义依赖发现
        semantic_deps = await self.semantic_analyzer.find_semantic_dependencies(
            task, all_tasks
        )
        suggestions.extend(semantic_deps)
        
        # 3. 历史依赖挖掘
        if user_id:
            historical_deps = self.pattern_miner.mine_patterns(
                user_id=user_id,
                task_type=task.get('type')
            )
            suggestions.extend(historical_deps)
        
        # 4. 上下文依赖提取
        if context:
            context_deps = self._extract_context_dependencies(
                context, task, all_tasks
            )
            suggestions.extend(context_deps)
        
        # 合并和排序建议
        return self._merge_and_rank_suggestions(suggestions)
    
    def _parse_explicit_dependencies(self, description: str) -> List[Dict]:
        """解析显式依赖声明"""
        dependencies = []
        
        patterns = [
            (r'依赖于\s*["""]?([^"""]+)["""]?', '依赖于'),
            (r'前置任务[是为:]\s*["""]?([^"""]+)["""]?', '前置任务'),
            (r'depends?\s+on\s+["""]?([^"""]+)["""]?', 'depends on'),
            (r'after\s+["""]?([^"""]+)["""]?', 'after'),
            (r'在\s*["""]?([^"""]+)["""]?\s*之后', '在...之后'),
        ]
        
        for pattern, indicator in patterns:
            matches = re.finditer(pattern, description, re.IGNORECASE)
            for match in matches:
                dependencies.append({
                    'reference': match.group(1).strip(),
                    'evidence': match.group(0),
                    'indicator': indicator
                })
        
        return dependencies
    
    def _find_task_by_reference(
        self,
        reference: str,
        tasks: List[Dict[str, Any]]
    ) -> Optional[Dict[str, Any]]:
        """根据引用查找任务"""
        reference_lower = reference.lower()
        
        for task in tasks:
            # 匹配标题
            if reference_lower in task.get('title', '').lower():
                return task
            # 匹配ID
            if reference == task.get('id'):
                return task
        
        return None
    
    def _extract_context_dependencies(
        self,
        context: str,
        task: Dict[str, Any],
        all_tasks: List[Dict[str, Any]]
    ) -> List[DependencySuggestion]:
        """从上下文中提取依赖"""
        suggestions = []
        
        # 检查上下文中是否提到其他任务
        for other_task in all_tasks:
            if other_task.get('id') == task.get('id'):
                continue
            
            other_title = other_task.get('title', '')
            if other_title and other_title in context:
                suggestions.append(DependencySuggestion(
                    source=task.get('id'),
                    target=other_task.get('id'),
                    type=DependencyType.CONTEXT,
                    confidence=0.6,
                    reason=f"对话上下文中提到: {other_title}"
                ))
        
        return suggestions
    
    def _merge_and_rank_suggestions(
        self,
        suggestions: List[DependencySuggestion]
    ) -> List[DependencySuggestion]:
        """合并和排序建议"""
        # 去重：保留置信度最高的
        seen = {}
        for s in suggestions:
            key = (s.source, s.target)
            if key not in seen or seen[key].confidence < s.confidence:
                seen[key] = s
        
        # 按置信度排序
        unique_suggestions = list(seen.values())
        unique_suggestions.sort(key=lambda x: x.confidence, reverse=True)
        
        return unique_suggestions
    
    async def validate_dependencies(
        self,
        suggestions: List[DependencySuggestion],
        existing_dependencies: List[Tuple[str, str]],
        tasks: Dict[str, Dict[str, Any]]
    ) -> ValidationResult:
        """
        验证依赖建议的有效性
        """
        result = ValidationResult()
        
        for suggestion in suggestions:
            # 检查循环依赖
            if self.validator.would_create_cycle(suggestion, existing_dependencies):
                result.add_warning(suggestion, "添加此依赖将产生循环")
                continue
            
            # 检查时间冲突
            if self.validator.has_temporal_conflict(suggestion, tasks):
                result.add_warning(suggestion, "依赖任务时间冲突")
            
            # 检查资源冲突
            if self.validator.has_resource_conflict(suggestion, tasks):
                result.add_warning(suggestion, "资源分配冲突")
            
            # 置信度过滤
            if suggestion.confidence < 0.6:
                result.add_low_confidence(suggestion)
            else:
                result.add_valid(suggestion)
        
        return result
    
    def optimize_execution_plan(
        self,
        tasks: List[Dict[str, Any]],
        constraints: ExecutionConstraints
    ) -> OptimizedPlan:
        """
        生成优化的执行计划
        """
        # 1. 构建完整依赖图
        graph = TaskDependencyGraph()
        for task in tasks:
            graph.add_task(TaskNode(
                task_id=task.get('id'),
                title=task.get('title'),
                deadline=task.get('deadline'),
                priority=task.get('priority', 1)
            ))
        
        # 添加依赖关系
        for task in tasks:
            deps = task.get('dependencies', [])
            for dep_id in deps:
                graph.add_dependency(task.get('id'), dep_id)
        
        # 2. 计算关键路径
        critical_path = graph.get_critical_path()
        
        # 3. 识别可并行任务组
        parallel_groups = graph.get_parallel_groups()
        
        # 4. 应用资源约束
        if constraints.max_parallel_tasks:
            parallel_groups = self._apply_parallel_limit(
                parallel_groups,
                constraints.max_parallel_tasks
            )
        
        # 5. 时间平衡优化
        if constraints.balance_workload:
            parallel_groups = self._balance_workload(parallel_groups, tasks)
        
        # 6. 估算完成时间
        estimated_completion = self._estimate_completion(graph, tasks)
        
        # 7. 资源分配
        resource_allocation = self._allocate_resources(parallel_groups, tasks)
        
        # 8. 生成优化建议
        suggestions = self._generate_optimization_suggestions(
            graph, tasks, critical_path
        )
        
        return OptimizedPlan(
            execution_order=graph.topological_sort(),
            critical_path=critical_path,
            parallel_groups=parallel_groups,
            estimated_completion=estimated_completion,
            resource_allocation=resource_allocation,
            suggestions=suggestions
        )
    
    def _apply_parallel_limit(
        self,
        parallel_groups: List[List[str]],
        max_parallel: int
    ) -> List[List[str]]:
        """应用并行任务限制"""
        result = []
        for group in parallel_groups:
            if len(group) <= max_parallel:
                result.append(group)
            else:
                # 拆分成多个批次
                for i in range(0, len(group), max_parallel):
                    result.append(group[i:i + max_parallel])
        return result
    
    def _balance_workload(
        self,
        parallel_groups: List[List[str]],
        tasks: Dict[str, Dict[str, Any]]
    ) -> List[List[str]]:
        """平衡工作负载"""
        # 简化实现：按优先级排序
        for group in parallel_groups:
            group.sort(key=lambda t: tasks.get(t, {}).get('priority', 1), reverse=True)
        return parallel_groups
    
    def _estimate_completion(
        self,
        graph: TaskDependencyGraph,
        tasks: Dict[str, Dict[str, Any]]
    ) -> timedelta:
        """估算完成时间"""
        # 简化实现：假设每个任务需要1小时
        task_count = len(graph.tasks)
        return timedelta(hours=task_count)
    
    def _allocate_resources(
        self,
        parallel_groups: List[List[str]],
        tasks: Dict[str, Dict[str, Any]]
    ) -> Dict[str, List[str]]:
        """分配资源"""
        # 简化实现：所有任务使用默认资源
        return {"default": [t for group in parallel_groups for t in group]}
    
    def _generate_optimization_suggestions(
        self,
        graph: TaskDependencyGraph,
        tasks: Dict[str, Dict[str, Any]],
        critical_path: List[str]
    ) -> List[str]:
        """生成优化建议"""
        suggestions = []
        
        # 检查关键路径上的任务
        if len(critical_path) > 3:
            suggestions.append(
                f"关键路径较长({len(critical_path)}个任务)，考虑分解或并行化"
            )
        
        # 检查无依赖任务
        independent_tasks = [
            t for t in graph.tasks.values()
            if not t.dependencies and not t.dependents
        ]
        if len(independent_tasks) > 5:
            suggestions.append(
                f"有{len(independent_tasks)}个独立任务，可以考虑分组管理"
            )
        
        return suggestions


# 导出
__all__ = [
    'IntelligentDependencyManager',
    'DependencySemanticAnalyzer',
    'DependencyPatternMiner',
    'DependencyValidator',
    'DependencySuggestion',
    'DependencyType',
    'ValidationResult',
    'ExecutionConstraints',
    'OptimizedPlan',
]