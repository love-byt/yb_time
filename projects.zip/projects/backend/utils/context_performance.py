"""
上下文系统性能优化器
提供缓存、并行化、流式输出等优化功能
"""

import asyncio
import hashlib
import json
import time
from collections import OrderedDict
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Callable, AsyncGenerator
from functools import wraps
import numpy as np


class LRUCache:
    """LRU缓存实现"""
    
    def __init__(self, maxsize: int = 1000):
        self.maxsize = maxsize
        self.cache: OrderedDict = OrderedDict()
        self.hits = 0
        self.misses = 0
    
    def get(self, key: str) -> Optional[Any]:
        """获取缓存值"""
        if key in self.cache:
            # 移动到末尾（最近使用）
            self.cache.move_to_end(key)
            self.hits += 1
            return self.cache[key]
        self.misses += 1
        return None
    
    def set(self, key: str, value: Any):
        """设置缓存值"""
        if key in self.cache:
            self.cache.move_to_end(key)
        self.cache[key] = value
        
        # 超出容量时移除最早的
        if len(self.cache) > self.maxsize:
            self.cache.popitem(last=False)
    
    def clear(self):
        """清空缓存"""
        self.cache.clear()
        self.hits = 0
        self.misses = 0
    
    def get_stats(self) -> Dict[str, float]:
        """获取统计信息"""
        total = self.hits + self.misses
        return {
            "hits": self.hits,
            "misses": self.misses,
            "hit_rate": self.hits / total if total > 0 else 0,
            "size": len(self.cache),
            "maxsize": self.maxsize
        }


@dataclass
class PerformanceMetrics:
    """性能指标"""
    total_requests: int = 0
    total_latency: float = 0.0
    cache_hits: int = 0
    cache_misses: int = 0
    semantic_used: int = 0
    rule_only: int = 0
    errors: int = 0
    
    def record_request(self, latency: float, cache_hit: bool = False):
        """记录请求"""
        self.total_requests += 1
        self.total_latency += latency
        if cache_hit:
            self.cache_hits += 1
        else:
            self.cache_misses += 1
    
    def get_average_latency(self) -> float:
        """获取平均延迟"""
        if self.total_requests == 0:
            return 0.0
        return self.total_latency / self.total_requests
    
    def get_cache_hit_rate(self) -> float:
        """获取缓存命中率"""
        total = self.cache_hits + self.cache_misses
        if total == 0:
            return 0.0
        return self.cache_hits / total


class PerformanceOptimizer:
    """
    性能优化器
    提供缓存、并行化、流式输出等优化
    """
    
    def __init__(self):
        # 意图缓存
        self.intent_cache = LRUCache(maxsize=1000)
        # 嵌入缓存
        self.embedding_cache = LRUCache(maxsize=500)
        # 性能指标
        self.metrics = PerformanceMetrics()
        
    def get_cache_key(self, text: str, context_id: Optional[str] = None) -> str:
        """生成缓存键"""
        key = f"{text}:{context_id or 'none'}"
        return hashlib.md5(key.encode()).hexdigest()
    
    async def process_with_optimization(
        self,
        user_input: str,
        context_id: Optional[str] = None,
        process_func: Optional[Callable] = None
    ) -> Dict[str, Any]:
        """
        带优化的处理流程
        
        优化策略：
        1. 缓存检查
        2. 并行预处理
        3. 流式响应
        """
        start_time = time.time()
        
        # 1. 检查缓存
        cache_key = self.get_cache_key(user_input, context_id)
        cached_result = self.intent_cache.get(cache_key)
        
        if cached_result:
            self.metrics.record_request(time.time() - start_time, cache_hit=True)
            return {
                "result": cached_result,
                "cache_hit": True,
                "latency_ms": (time.time() - start_time) * 1000
            }
        
        # 2. 并行启动预处理任务
        if process_func:
            result = await process_func(user_input)
            
            # 更新缓存
            self.intent_cache.set(cache_key, result)
            
            latency = time.time() - start_time
            self.metrics.record_request(latency, cache_hit=False)
            
            return {
                "result": result,
                "cache_hit": False,
                "latency_ms": latency * 1000
            }
        
        return {"error": "No process function provided"}
    
    async def stream_process(
        self,
        user_input: str,
        process_func: Callable
    ) -> AsyncGenerator[str, None]:
        """
        流式处理
        先返回确认响应，再返回完整结果
        """
        # 1. 快速确认响应
        yield '{"status": "processing", "message": "正在处理..."}'
        
        # 2. 执行处理
        try:
            result = await process_func(user_input)
            yield json.dumps({"status": "success", "data": result}, ensure_ascii=False)
        except Exception as e:
            yield json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False)
    
    def get_embedding(self, text: str, embed_func: Callable) -> np.ndarray:
        """
        获取嵌入向量（带缓存）
        """
        cache_key = self.get_cache_key(text, "embedding")
        cached = self.embedding_cache.get(cache_key)
        
        if cached is not None:
            return cached
        
        # 计算嵌入
        embedding = embed_func(text)
        self.embedding_cache.set(cache_key, embedding)
        
        return embedding
    
    def get_stats(self) -> Dict[str, Any]:
        """获取性能统计"""
        return {
            "metrics": {
                "total_requests": self.metrics.total_requests,
                "average_latency_ms": self.metrics.get_average_latency() * 1000,
                "cache_hit_rate": self.metrics.get_cache_hit_rate(),
            },
            "intent_cache": self.intent_cache.get_stats(),
            "embedding_cache": self.embedding_cache.get_stats(),
        }
    
    def clear_caches(self):
        """清空所有缓存"""
        self.intent_cache.clear()
        self.embedding_cache.clear()


def timed(func):
    """计时装饰器"""
    @wraps(func)
    async def async_wrapper(*args, **kwargs):
        start = time.time()
        result = await func(*args, **kwargs)
        elapsed = time.time() - start
        print(f"[TIMING] {func.__name__} took {elapsed*1000:.2f}ms")
        return result
    
    @wraps(func)
    def sync_wrapper(*args, **kwargs):
        start = time.time()
        result = func(*args, **kwargs)
        elapsed = time.time() - start
        print(f"[TIMING] {func.__name__} took {elapsed*1000:.2f}ms")
        return result
    
    return async_wrapper if asyncio.iscoroutinefunction(func) else sync_wrapper


class BatchProcessor:
    """批处理器"""
    
    def __init__(self, batch_size: int = 10, max_wait_ms: float = 50):
        self.batch_size = batch_size
        self.max_wait_ms = max_wait_ms
        self.queue: List[Dict] = []
        self.processing = False
    
    async def add(self, item: Any, process_func: Callable) -> Any:
        """添加项目到批处理队列"""
        future = asyncio.Future()
        self.queue.append({
            "item": item,
            "future": future,
            "process_func": process_func
        })
        
        # 触发批处理
        if len(self.queue) >= self.batch_size:
            await self._process_batch()
        
        return await future
    
    async def _process_batch(self):
        """处理批次"""
        if not self.queue or self.processing:
            return
        
        self.processing = True
        batch = self.queue[:self.batch_size]
        self.queue = self.queue[self.batch_size:]
        
        try:
            # 并行处理
            tasks = [
                item["process_func"](item["item"])
                for item in batch
            ]
            results = await asyncio.gather(*tasks, return_exceptions=True)
            
            # 设置结果
            for item, result in zip(batch, results):
                if isinstance(result, Exception):
                    item["future"].set_exception(result)
                else:
                    item["future"].set_result(result)
        
        finally:
            self.processing = False
            
            # 继续处理剩余项目
            if self.queue:
                await self._process_batch()


# 导出
__all__ = [
    'PerformanceOptimizer',
    'PerformanceMetrics',
    'LRUCache',
    'BatchProcessor',
    'timed',
]