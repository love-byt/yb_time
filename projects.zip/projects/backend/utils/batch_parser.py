"""
批量任务文本解析器
支持自然语言文本解析为结构化任务数据
"""

import re
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional


class BatchTaskParser:
    """批量任务文本解析器"""
    
    # 正则模式定义
    PATTERNS = {
        'deadline': r'(明天|后天|大后天|下周[一二三四五六日]?|(?:\d{1,2})月(?:\d{1,2})日?|(?:\d{4}-)?\d{1,2}-\d{1,2}|\d{1,2}号)',
        'duration': r'(\d+(?:\.\d+)?)\s*(小时|h|分钟|min|分)',
        'course': r'([^，。,；;]+?)(?:课|作业|论文|实验|考试|练习|报告)',
        'priority_high': r'(紧急|重要|高优先级|必须| asap)',
        'priority_low': r'(低优先级|不急|可以延后)',
    }
    
    # 星期映射
    WEEKDAY_MAP = {
        '一': 0, '二': 1, '三': 2, '四': 3, '五': 4, '六': 5, '日': 6, '天': 6
    }
    
    def __init__(self, base_time: Optional[datetime] = None):
        """
        初始化解析器
        
        Args:
            base_time: 基准时间，默认为当前时间
        """
        self.base_time = base_time or datetime.now()
    
    def parse_text(self, text: str, user_context: Optional[Dict] = None) -> List[Dict[str, Any]]:
        """
        解析自然语言文本为结构化任务列表
        
        Args:
            text: 输入文本，如"数学作业明天截止需要2小时，英语论文后天交预计3小时"
            user_context: 用户上下文信息（可选）
            
        Returns:
            解析后的任务列表
            
        Example:
            >>> parser = BatchTaskParser()
            >>> tasks = parser.parse_text("数学作业明天截止需要2小时")
            >>> print(tasks[0]['title'])
            '数学作业'
        """
        if not text or not text.strip():
            return []
        
        tasks = []
        
        # 使用多种分隔符分割文本
        lines = re.split(r'[，。,；;\n]+', text)
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
            
            task = self._parse_single_line(line)
            if task and task.get('title'):
                tasks.append(task)
        
        return tasks
    
    def _parse_single_line(self, line: str) -> Optional[Dict[str, Any]]:
        """
        解析单行文本为任务
        
        Args:
            line: 单行文本
            
        Returns:
            任务字典或None
        """
        task = {
            'title': line,
            'category': '学习',
            'confidence': 0.5  # 基础置信度
        }
        
        # 提取截止时间
        deadline = self._extract_deadline(line)
        if deadline:
            task['deadline'] = deadline
            task['confidence'] += 0.2
        
        # 提取耗时
        duration = self._extract_duration(line)
        if duration:
            task['duration'] = duration
            task['confidence'] += 0.15
        
        # 提取课程/分类
        course = self._extract_course(line)
        if course:
            task['course_hint'] = course
            task['category'] = self._infer_category(course)
            task['confidence'] += 0.1
        
        # 提取优先级
        priority = self._extract_priority(line)
        if priority:
            task['priority'] = priority
        
        # 清理标题中的元信息
        task['title'] = self._clean_title(line)
        
        return task
    
    def _extract_deadline(self, text: str) -> Optional[str]:
        """提取截止时间"""
        match = re.search(self.PATTERNS['deadline'], text)
        if not match:
            return None
        
        deadline_str = match.group(1)
        deadline = self._normalize_deadline(deadline_str)
        
        return deadline.strftime('%Y-%m-%dT%H:%M:%S') if deadline else None
    
    def _normalize_deadline(self, deadline_str: str) -> Optional[datetime]:
        """标准化截止时间为datetime对象"""
        now = self.base_time
        
        # 处理相对时间
        if deadline_str == '今天':
            return now.replace(hour=23, minute=59, second=0, microsecond=0)
        elif deadline_str == '明天':
            return (now + timedelta(days=1)).replace(hour=23, minute=59, second=0, microsecond=0)
        elif deadline_str == '后天':
            return (now + timedelta(days=2)).replace(hour=23, minute=59, second=0, microsecond=0)
        elif deadline_str == '大后天':
            return (now + timedelta(days=3)).replace(hour=23, minute=59, second=0, microsecond=0)
        elif deadline_str.startswith('下周'):
            # 计算下周几
            weekday_char = deadline_str[2] if len(deadline_str) > 2 else None
            if weekday_char and weekday_char in self.WEEKDAY_MAP:
                target_weekday = self.WEEKDAY_MAP[weekday_char]
                current_weekday = now.weekday()
                days_ahead = 7 - current_weekday + target_weekday
                return (now + timedelta(days=days_ahead)).replace(hour=23, minute=59, second=0, microsecond=0)
            else:
                # 默认下周一
                days_ahead = 7 - now.weekday()
                return (now + timedelta(days=days_ahead)).replace(hour=23, minute=59, second=0, microsecond=0)
        
        # 处理日期格式（简化处理）
        try:
            # 尝试解析 "5月10日" 格式
            month_day_match = re.match(r'(\d{1,2})月(\d{1,2})日?', deadline_str)
            if month_day_match:
                month = int(month_day_match.group(1))
                day = int(month_day_match.group(2))
                year = now.year
                # 如果月份已过，假设是明年
                if month < now.month:
                    year += 1
                return datetime(year, month, day, 23, 59, 0)
            
            # 尝试解析 "5-10" 或 "05-10" 格式
            md_match = re.match(r'(\d{1,2})-(\d{1,2})', deadline_str)
            if md_match:
                month = int(md_match.group(1))
                day = int(md_match.group(2))
                year = now.year
                if month < now.month:
                    year += 1
                return datetime(year, month, day, 23, 59, 0)
                
        except (ValueError, IndexError):
            pass
        
        return None
    
    def _extract_duration(self, text: str) -> Optional[int]:
        """提取预计耗时（分钟）"""
        match = re.search(self.PATTERNS['duration'], text)
        if not match:
            return None
        
        value = float(match.group(1))
        unit = match.group(2)
        
        return self._normalize_duration(value, unit)
    
    def _normalize_duration(self, value: float, unit: str) -> int:
        """标准化耗时为分钟"""
        if unit in ['小时', 'h', 'hr', 'hrs']:
            return int(value * 60)
        else:  # 分钟、min、分
            return int(value)
    
    def _extract_course(self, text: str) -> Optional[str]:
        """提取课程名称"""
        match = re.search(self.PATTERNS['course'], text)
        if match:
            return match.group(1).strip()
        return None
    
    def _infer_category(self, course_hint: str) -> str:
        """根据课程提示推断分类"""
        category_keywords = {
            '实验': '实验',
            '论文': '论文',
            '考试': '考试',
            '测验': '考试',
        }
        
        for keyword, category in category_keywords.items():
            if keyword in course_hint:
                return category
        
        return '学习'
    
    def _extract_priority(self, text: str) -> Optional[int]:
        """提取优先级（1-5）"""
        if re.search(self.PATTERNS['priority_high'], text):
            return 4  # 高优先级
        elif re.search(self.PATTERNS['priority_low'], text):
            return 2  # 低优先级
        return None
    
    def _clean_title(self, text: str) -> str:
        """清理标题，移除已解析的元信息"""
        # 移除时间信息
        cleaned = re.sub(self.PATTERNS['deadline'], '', text)
        # 移除耗时信息
        cleaned = re.sub(self.PATTERNS['duration'], '', cleaned)
        # 移除优先级关键词
        cleaned = re.sub(self.PATTERNS['priority_high'], '', cleaned)
        cleaned = re.sub(self.PATTERNS['priority_low'], '', cleaned)
        # 清理多余标点
        cleaned = re.sub(r'[，。,；;\s]+', ' ', cleaned)
        
        return cleaned.strip()


# 便捷函数
def parse_batch_tasks(text: str, base_time: Optional[datetime] = None) -> List[Dict[str, Any]]:
    """
    便捷函数：解析批量任务文本
    
    Args:
        text: 输入文本
        base_time: 基准时间
        
    Returns:
        解析后的任务列表
    """
    parser = BatchTaskParser(base_time)
    return parser.parse_text(text)


if __name__ == '__main__':
    # 测试解析功能
    test_text = """
    数学作业明天截止需要2小时
    英语论文后天交预计3小时
    物理实验下周三完成，大概需要90分钟
    紧急：化学报告今天必须交，1.5小时
    """
    
    parser = BatchTaskParser()
    tasks = parser.parse_text(test_text)
    
    print(f"解析到 {len(tasks)} 个任务:")
    for i, task in enumerate(tasks, 1):
        print(f"\n任务 {i}:")
        print(f"  标题: {task.get('title')}")
        print(f"  截止时间: {task.get('deadline')}")
        print(f"  耗时: {task.get('duration')} 分钟")
        print(f"  分类: {task.get('category')}")
        print(f"  优先级: {task.get('priority')}")
        print(f"  置信度: {task.get('confidence')}")
