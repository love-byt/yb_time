"""
用户行为分析器 - 分析用户学习习惯，生成个性化推荐
"""

import json
from datetime import datetime, timedelta
from collections import defaultdict
from typing import Dict, List, Any, Optional

from extensions import db
from models.user_behavior import UserStudyPattern, UserStudySession, UserTaskPreference
from models.task import Task


class UserBehaviorAnalyzer:
    """用户行为分析器"""
    
    def __init__(self, user_id: str) -> None:
        """初始化用户行为分析器
        
        Args:
            user_id: 用户ID
            
        Raises:
            ValueError: 当user_id为空时
        """
        if not user_id or not isinstance(user_id, str):
            raise ValueError("user_id 必须是非空字符串")
        self.user_id: str = user_id
    
    def record_study_session(self, task_id: int, start_time: datetime, 
                            end_time: datetime, session_type: str = 'focus',
                            interruptions: int = 0, efficiency_rating: Optional[int] = None,
                            category: str = '') -> Optional[Any]:
        """记录学习会话
        
        Args:
            task_id: 任务ID
            start_time: 开始时间
            end_time: 结束时间
            session_type: 会话类型，默认'focus'
            interruptions: 中断次数
            efficiency_rating: 效率评分（1-5）
            category: 任务分类
            
        Returns:
            创建的会话对象，失败时返回None
        """
        # 参数校验
        if not isinstance(task_id, int) or task_id <= 0:
            raise ValueError("task_id 必须是正整数")
        if not isinstance(start_time, datetime) or not isinstance(end_time, datetime):
            raise ValueError("start_time 和 end_time 必须是 datetime 对象")
        if end_time <= start_time:
            raise ValueError("end_time 必须晚于 start_time")
            
        duration: int = int((end_time - start_time).total_seconds() / 60)
        
        session = UserStudySession(
            user_id=self.user_id,
            task_id=task_id,
            start_time=start_time,
            end_time=end_time,
            duration_minutes=duration,
            session_type=session_type,
            interruptions=interruptions,
            efficiency_rating=efficiency_rating,
            category=category,
            day_of_week=start_time.weekday(),
            hour_of_day=start_time.hour
        )
        
        db.session.add(session)
        db.session.commit()
        
        return session
    
    def analyze_study_patterns(self, days: int = 30) -> Dict[str, Any]:
        """分析用户学习模式"""
        cutoff_date = datetime.now() - timedelta(days=days)
        
        # 获取近期的学习会话
        sessions = UserStudySession.query.filter(
            UserStudySession.user_id == self.user_id,
            UserStudySession.start_time >= cutoff_date,
            UserStudySession.session_type == 'focus'
        ).all()
        
        if not sessions:
            return None
        
        # 分析每小时的学习频率
        hourly_counts = defaultdict(int)
        hourly_efficiency = defaultdict(list)
        
        for session in sessions:
            hour = session.hour_of_day
            hourly_counts[hour] += 1
            if session.efficiency_rating:
                hourly_efficiency[hour].append(session.efficiency_rating)
        
        # 计算每小时的学习频率（归一化）
        total_sessions = len(sessions)
        hourly_distribution = {}
        for hour in range(24):
            count = hourly_counts.get(hour, 0)
            hourly_distribution[hour] = round(count / total_sessions, 4) if total_sessions > 0 else 0
        
        # 识别最佳学习时段（学习频率高且效率高的时段）
        peak_hours = []
        for hour in range(24):
            freq = hourly_distribution.get(hour, 0)
            avg_eff = sum(hourly_efficiency.get(hour, [3])) / len(hourly_efficiency.get(hour, [1]))
            # 频率 > 5% 且 效率 >= 3.5
            if freq > 0.05 and avg_eff >= 3.5:
                peak_hours.append(hour)
        
        # 如果没有识别到，使用频率最高的3个时段
        if not peak_hours:
            sorted_hours = sorted(hourly_distribution.items(), key=lambda x: x[1], reverse=True)
            peak_hours = [h for h, _ in sorted_hours[:3]]
        
        # 计算平均专注时长
        focus_sessions = [s for s in sessions if s.duration_minutes > 0]
        avg_focus_duration = int(
            sum(s.duration_minutes for s in focus_sessions) / len(focus_sessions)
        ) if focus_sessions else 25
        
        # 限制在合理范围（15-60分钟）
        avg_focus_duration = max(15, min(60, avg_focus_duration))
        
        # 计算任务完成率
        completed_tasks = Task.query.filter(
            Task.user_id == self.user_id,
            Task.is_completed == True,
            Task.updated_at >= cutoff_date
        ).count()
        
        created_tasks = Task.query.filter(
            Task.user_id == self.user_id,
            Task.created_at >= cutoff_date
        ).count()
        
        completion_rate = completed_tasks / created_tasks if created_tasks > 0 else 0
        
        return {
            'hourly_distribution': hourly_distribution,
            'peak_hours': sorted(peak_hours),
            'avg_focus_duration': avg_focus_duration,
            'completion_rate': round(completion_rate, 4),
            'total_sessions': len(sessions)
        }
    
    def update_study_pattern(self):
        """更新用户学习模式"""
        pattern_data = self.analyze_study_patterns()
        
        if not pattern_data:
            return None
        
        pattern = UserStudyPattern.query.filter_by(user_id=self.user_id).first()
        
        if not pattern:
            pattern = UserStudyPattern(user_id=self.user_id)
            db.session.add(pattern)
        
        pattern.hourly_distribution = json.dumps(pattern_data['hourly_distribution'])
        pattern.peak_hours = ','.join(map(str, pattern_data['peak_hours']))
        pattern.avg_focus_duration = pattern_data['avg_focus_duration']
        pattern.completion_rate = pattern_data['completion_rate']
        
        db.session.commit()
        
        return pattern
    
    def analyze_category_preferences(self, days: int = 30) -> List[Dict[str, Any]]:
        """分析用户对不同任务分类的偏好"""
        cutoff_date = datetime.now() - timedelta(days=days)
        
        # 获取完成的任务
        completed_tasks = Task.query.filter(
            Task.user_id == self.user_id,
            Task.is_completed == True,
            Task.updated_at >= cutoff_date
        ).all()
        
        category_stats = defaultdict(lambda: {
            'total_duration': 0,
            'count': 0,
            'hourly_distribution': defaultdict(int)
        })
        
        for task in completed_tasks:
            cat = task.category or '未分类'
            duration = task.actual_duration or 60
            
            category_stats[cat]['total_duration'] += duration
            category_stats[cat]['count'] += 1
            
            # 记录完成时段
            if task.actual_end_time:
                hour = task.actual_end_time.hour
                category_stats[cat]['hourly_distribution'][hour] += 1
        
        # 计算偏好权重和最佳时段
        preferences = []
        total_count = sum(s['count'] for s in category_stats.values())
        
        for category, stats in category_stats.items():
            count = stats['count']
            avg_duration = stats['total_duration'] // count if count > 0 else 60
            
            # 偏好权重 = 完成频率 * 0.6 + 效率因子 * 0.4
            frequency_weight = count / total_count if total_count > 0 else 0
            preference_weight = min(1.0, frequency_weight * 0.6 + 0.4)
            
            # 识别最佳完成时段
            hourly_dist = stats['hourly_distribution']
            best_hours = sorted(hourly_dist.items(), key=lambda x: x[1], reverse=True)[:3]
            best_hours = [h for h, _ in best_hours]
            
            preferences.append({
                'category': category,
                'avg_duration': avg_duration,
                'completion_count': count,
                'preference_weight': round(preference_weight, 4),
                'best_hours': best_hours
            })
            
            # 更新数据库
            self._update_category_preference(category, avg_duration, count, preference_weight, best_hours)
        
        return sorted(preferences, key=lambda x: x['preference_weight'], reverse=True)
    
    def _update_category_preference(self, category: str, avg_duration: int, 
                                   count: int, weight: float, best_hours: List[int]):
        """更新分类偏好到数据库"""
        pref = UserTaskPreference.query.filter_by(
            user_id=self.user_id, 
            category=category
        ).first()
        
        if not pref:
            pref = UserTaskPreference(
                user_id=self.user_id,
                category=category
            )
            db.session.add(pref)
        
        pref.avg_duration = avg_duration
        pref.completion_count = count
        pref.preference_weight = weight
        pref.best_hours = json.dumps(best_hours)
        
        db.session.commit()
    
    def get_personalized_settings(self) -> Dict[str, Any]:
        """获取个性化设置"""
        pattern = UserStudyPattern.query.filter_by(user_id=self.user_id).first()
        
        if not pattern:
            # 返回默认设置
            return {
                'pomodoro_minutes': 25,
                'break_minutes': 5,
                'long_break_minutes': 15,
                'pomodoros_before_long_break': 4,
                'peak_hours': [9, 10, 14, 15],
                'preferred_categories': [],
                'is_personalized': False
            }
        
        preferred_categories = []
        if pattern.preferred_categories:
            preferred_categories = json.loads(pattern.preferred_categories)
        
        # 如果没有偏好分类，从分类偏好表获取
        if not preferred_categories:
            prefs = UserTaskPreference.query.filter_by(user_id=self.user_id).order_by(
                UserTaskPreference.preference_weight.desc()
            ).limit(5).all()
            preferred_categories = [p.category for p in prefs]
        
        return {
            'pomodoro_minutes': pattern.avg_focus_duration,
            'break_minutes': pattern.avg_break_interval,
            'long_break_minutes': 15,
            'pomodoros_before_long_break': pattern.pomodoros_before_long_break,
            'peak_hours': [int(h) for h in pattern.peak_hours.split(',') if h] if pattern.peak_hours else [9, 10, 14, 15],
            'preferred_categories': preferred_categories,
            'completion_rate': pattern.completion_rate,
            'is_personalized': True
        }
    
    def get_category_best_hours(self, category: str) -> List[int]:
        """获取某分类的最佳完成时段"""
        pref = UserTaskPreference.query.filter_by(
            user_id=self.user_id,
            category=category
        ).first()
        
        if pref and pref.best_hours:
            return json.loads(pref.best_hours)
        
        # 返回用户整体最佳时段
        pattern = UserStudyPattern.query.filter_by(user_id=self.user_id).first()
        if pattern and pattern.peak_hours:
            return [int(h) for h in pattern.peak_hours.split(',') if h]
        
        return [9, 10, 14, 15]  # 默认时段
    
    def get_recommended_schedule_time(self, task_category: str, 
                                     current_hour: int = None) -> int:
        """推荐任务的计划时间"""
        best_hours = self.get_category_best_hours(task_category)
        
        if current_hour is None:
            current_hour = datetime.now().hour
        
        # 找到当前时间之后的最佳时段
        future_hours = [h for h in best_hours if h > current_hour]
        
        if future_hours:
            return future_hours[0]
        
        # 如果今天没有合适时段，返回明天的第一个最佳时段
        return best_hours[0] if best_hours else 9
    
    def get_optimal_study_time(self, category: str = '') -> Dict[str, Any]:
        """
        获取用户最佳学习/工作时段
        
        Args:
            category: 任务分类（可选）
            
        Returns:
            包含最佳时段信息的字典
        """
        # 获取分类特定的最佳时段
        if category:
            best_hours = self.get_category_best_hours(category)
        else:
            # 获取用户整体最佳时段
            pattern = UserStudyPattern.query.filter_by(user_id=self.user_id).first()
            if pattern and pattern.peak_hours:
                best_hours = [int(h) for h in pattern.peak_hours.split(',') if h]
            else:
                best_hours = []
        
        # 如果没有数据，返回空结果
        if not best_hours:
            return {
                'has_pattern': False,
                'peak_performance_hour': 9,
                'good_performance_hour': 14,
                'available_hour': 16
            }
        
        # 分析学习模式获取更多信息
        pattern_data = self.analyze_study_patterns(days=30)
        
        if pattern_data:
            hourly_dist = pattern_data.get('hourly_distribution', {})
            peak_hours = pattern_data.get('peak_hours', best_hours)
            
            # 根据频率排序找出最佳时段
            sorted_hours = sorted(
                [(h, hourly_dist.get(h, 0)) for h in range(24)],
                key=lambda x: x[1],
                reverse=True
            )
            
            return {
                'has_pattern': True,
                'peak_performance_hour': peak_hours[0] if peak_hours else best_hours[0],
                'good_performance_hour': peak_hours[1] if len(peak_hours) > 1 else (best_hours[1] if len(best_hours) > 1 else 14),
                'available_hour': sorted_hours[-1][0] if sorted_hours else 16,
                'peak_hours': peak_hours,
                'best_hours': best_hours
            }
        
        # 简化返回
        return {
            'has_pattern': len(best_hours) > 0,
            'peak_performance_hour': best_hours[0] if best_hours else 9,
            'good_performance_hour': best_hours[1] if len(best_hours) > 1 else 14,
            'available_hour': best_hours[-1] if best_hours else 16,
            'best_hours': best_hours
        }


class PersonalizedPlanGenerator:
    """个性化计划生成器"""
    
    def __init__(self, user_id: str):
        self.user_id = user_id
        self.analyzer = UserBehaviorAnalyzer(user_id)
    
    def generate_plan(self, tasks: List[Dict], available_hours: int = 8) -> Dict[str, Any]:
        """生成个性化学习计划"""
        # 获取用户个性化设置
        settings = self.analyzer.get_personalized_settings()
        
        # 分析任务分类偏好
        category_prefs = self.analyzer.analyze_category_preferences()
        category_weight_map = {p['category']: p['preference_weight'] for p in category_prefs}
        
        # 为每个任务计算个性化分数
        scored_tasks = []
        for task in tasks:
            category = task.get('category', '未分类')
            
            # 基础分数：优先级
            base_score = task.get('priority', 3) * 2
            
            # 个性化加分：分类偏好权重
            pref_weight = category_weight_map.get(category, 0.5)
            pref_bonus = pref_weight * 5
            
            # 时段匹配加分：如果当前时间在最佳时段内
            best_hours = self.analyzer.get_category_best_hours(category)
            current_hour = datetime.now().hour
            time_bonus = 2 if current_hour in best_hours else 0
            
            total_score = base_score + pref_bonus + time_bonus
            
            scored_tasks.append({
                **task,
                'personalized_score': round(total_score, 2),
                'category_pref_weight': round(pref_weight, 4),
                'in_peak_hour': current_hour in best_hours
            })
        
        # 按个性化分数排序
        scored_tasks.sort(key=lambda x: x['personalized_score'], reverse=True)
        
        # 生成时间安排
        schedule = self._generate_time_schedule(
            scored_tasks, 
            available_hours,
            settings
        )
        
        return {
            'schedule': schedule,
            'settings_used': settings,
            'category_preferences': category_prefs,
            'total_tasks': len(tasks),
            'is_personalized': settings.get('is_personalized', False)
        }
    
    def _generate_time_schedule(self, tasks: List[Dict], available_hours: int,
                               settings: Dict) -> List[Dict]:
        """生成时间安排"""
        pomodoro_minutes = settings.get('pomodoro_minutes', 25)
        break_minutes = settings.get('break_minutes', 5)
        long_break_minutes = settings.get('long_break_minutes', 15)
        pomodoros_before_long_break = settings.get('pomodoros_before_long_break', 4)
        peak_hours = settings.get('peak_hours', [9, 10, 14, 15])
        
        schedule = []
        current_hour = datetime.now().hour
        pomodoro_count = 0
        
        for task in tasks:
            # 推荐最佳开始时间
            recommended_hour = self.analyzer.get_recommended_schedule_time(
                task.get('category', ''),
                current_hour
            )
            
            pomodoros = max(1, task.get('duration', 60) // pomodoro_minutes)
            pomodoro_count += pomodoros
            
            # 确定休息时长
            if pomodoro_count >= pomodoros_before_long_break:
                break_after = long_break_minutes
                pomodoro_count = 0
            else:
                break_after = break_minutes * pomodoros
            
            schedule.append({
                'task_id': task.get('id'),
                'title': task.get('title'),
                'category': task.get('category'),
                'duration': task.get('duration', 60),
                'recommended_start_hour': recommended_hour,
                'in_peak_hour': task.get('in_peak_hour', False),
                'personalized_score': task.get('personalized_score'),
                'pomodoros': pomodoros,
                'break_after': break_after
            })
        
        return schedule
