"""
对话历史存储模型
提供消息存储、会话管理和上下文压缩功能
"""

import json
import pickle
import sqlite3
import uuid
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional


class MessageType(Enum):
    """消息类型枚举"""
    USER = "user"           # 用户输入
    ASSISTANT = "assistant" # AI回复
    SYSTEM = "system"       # 系统消息
    TOOL = "tool"           # 工具调用结果
    CONTEXT = "context"     # 上下文注入


class IntentType(Enum):
    """意图类型枚举"""
    CREATE_TASK = "create_task"
    UPDATE_TASK = "update_task"
    DELETE_TASK = "delete_task"
    QUERY_TASK = "query_task"
    SORT_TASK = "sort_task"
    ADD_DEPENDENCY = "add_dependency"
    GENERAL_CHAT = "general_chat"
    CLARIFICATION = "clarification"


@dataclass
class Message:
    """单条消息实体"""
    id: str                          # 消息唯一ID
    session_id: str                  # 会话ID
    type: MessageType                # 消息类型
    content: str                     # 消息内容
    timestamp: datetime              # 时间戳
    intent: Optional[IntentType] = None  # 识别出的意图
    entities: Dict[str, Any] = field(default_factory=dict)  # 提取的实体
    metadata: Dict[str, Any] = field(default_factory=dict)  # 元数据
    parent_id: Optional[str] = None  # 父消息ID（用于线程）
    context_vector: Optional[List[float]] = None  # 语义向量

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "id": self.id,
            "session_id": self.session_id,
            "type": self.type.value if isinstance(self.type, MessageType) else self.type,
            "content": self.content,
            "timestamp": self.timestamp.isoformat() if self.timestamp else None,
            "intent": self.intent.value if isinstance(self.intent, IntentType) else self.intent,
            "entities": self.entities,
            "metadata": self.metadata,
            "parent_id": self.parent_id,
            "context_vector": self.context_vector
        }


@dataclass
class DialogueSession:
    """对话会话实体"""
    session_id: str                  # 会话ID
    user_id: str                     # 用户ID
    created_at: datetime             # 创建时间
    updated_at: datetime             # 更新时间
    messages: List[Message] = field(default_factory=list)  # 消息列表
    context_summary: str = ""        # 上下文摘要
    active_tasks: List[str] = field(default_factory=list)  # 当前活跃任务
    state: str = "idle"              # 当前状态
    
    def add_message(self, message: Message):
        """添加消息并更新时间戳"""
        self.messages.append(message)
        self.updated_at = datetime.now()
        
    def get_recent_context(self, n: int = 5) -> List[Message]:
        """获取最近n条消息作为上下文"""
        return self.messages[-n:] if len(self.messages) >= n else self.messages
    
    def get_thread(self, message_id: str) -> List[Message]:
        """获取指定消息的线程（关联消息链）"""
        thread = []
        current_id = message_id
        
        # 向前追溯
        while current_id:
            msg = next((m for m in self.messages if m.id == current_id), None)
            if msg:
                thread.insert(0, msg)
                current_id = msg.parent_id
            else:
                break
                
        return thread
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "session_id": self.session_id,
            "user_id": self.user_id,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "messages": [m.to_dict() for m in self.messages],
            "context_summary": self.context_summary,
            "active_tasks": self.active_tasks,
            "state": self.state
        }


class DialogueHistoryStore:
    """对话历史存储管理器"""
    
    def __init__(self, db_path: str = "dialogue_history.db"):
        self.db_path = db_path
        self._init_database()
    
    def _init_database(self):
        """初始化数据库表结构"""
        with self._get_connection() as conn:
            conn.executescript('''
                CREATE TABLE IF NOT EXISTS sessions (
                    session_id TEXT PRIMARY KEY,
                    user_id TEXT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    context_summary TEXT,
                    active_tasks TEXT,  -- JSON array
                    state TEXT DEFAULT 'idle'
                );
                
                CREATE TABLE IF NOT EXISTS messages (
                    message_id TEXT PRIMARY KEY,
                    session_id TEXT NOT NULL,
                    type TEXT NOT NULL,
                    content TEXT NOT NULL,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    intent TEXT,
                    entities TEXT,  -- JSON
                    metadata TEXT,  -- JSON
                    parent_id TEXT,
                    context_vector BLOB,  -- 序列化向量
                    FOREIGN KEY (session_id) REFERENCES sessions(session_id)
                );
                
                CREATE INDEX IF NOT EXISTS idx_messages_session 
                    ON messages(session_id, timestamp);
                CREATE INDEX IF NOT EXISTS idx_messages_parent 
                    ON messages(parent_id);
                    
                CREATE TABLE IF NOT EXISTS context_snapshots (
                    snapshot_id TEXT PRIMARY KEY,
                    session_id TEXT NOT NULL,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    snapshot_data BLOB,  -- 序列化的完整上下文
                    summary TEXT,
                    FOREIGN KEY (session_id) REFERENCES sessions(session_id)
                );
            ''')
    
    @contextmanager
    def _get_connection(self):
        """获取数据库连接上下文"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        finally:
            conn.close()
    
    def save_session(self, session: DialogueSession):
        """保存会话"""
        with self._get_connection() as conn:
            conn.execute('''
                INSERT OR REPLACE INTO sessions 
                (session_id, user_id, created_at, updated_at, context_summary, active_tasks, state)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (
                session.session_id,
                session.user_id,
                session.created_at,
                session.updated_at,
                session.context_summary,
                json.dumps(session.active_tasks),
                session.state
            ))
    
    def save_message(self, message: Message):
        """保存消息"""
        with self._get_connection() as conn:
            conn.execute('''
                INSERT OR REPLACE INTO messages 
                (message_id, session_id, type, content, timestamp, intent, 
                 entities, metadata, parent_id, context_vector)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                message.id,
                message.session_id,
                message.type.value,
                message.content,
                message.timestamp,
                message.intent.value if message.intent else None,
                json.dumps(message.entities),
                json.dumps(message.metadata),
                message.parent_id,
                pickle.dumps(message.context_vector) if message.context_vector else None
            ))
    
    def load_session(self, session_id: str) -> Optional[DialogueSession]:
        """加载完整会话"""
        with self._get_connection() as conn:
            # 加载会话基本信息
            row = conn.execute(
                'SELECT * FROM sessions WHERE session_id = ?', (session_id,)
            ).fetchone()
            
            if not row:
                return None
            
            # 加载所有消息
            messages = []
            for msg_row in conn.execute(
                'SELECT * FROM messages WHERE session_id = ? ORDER BY timestamp',
                (session_id,)
            ):
                messages.append(Message(
                    id=msg_row['message_id'],
                    session_id=msg_row['session_id'],
                    type=MessageType(msg_row['type']),
                    content=msg_row['content'],
                    timestamp=datetime.fromisoformat(msg_row['timestamp']),
                    intent=IntentType(msg_row['intent']) if msg_row['intent'] else None,
                    entities=json.loads(msg_row['entities'] or '{}'),
                    metadata=json.loads(msg_row['metadata'] or '{}'),
                    parent_id=msg_row['parent_id'],
                    context_vector=pickle.loads(msg_row['context_vector']) if msg_row['context_vector'] else None
                ))
            
            return DialogueSession(
                session_id=row['session_id'],
                user_id=row['user_id'],
                created_at=datetime.fromisoformat(row['created_at']),
                updated_at=datetime.fromisoformat(row['updated_at']),
                messages=messages,
                context_summary=row['context_summary'],
                active_tasks=json.loads(row['active_tasks'] or '[]'),
                state=row['state']
            )
    
    def search_similar_context(self, query_vector: List[float], 
                              session_id: str, 
                              top_k: int = 5) -> List[Message]:
        """基于向量相似度搜索相关历史上下文"""
        # 这里可以集成向量数据库如FAISS、Pinecone等
        # 简化实现：加载会话所有消息，计算余弦相似度
        session = self.load_session(session_id)
        if not session:
            return []
        
        try:
            from numpy import dot
            from numpy.linalg import norm
            
            def cosine_similarity(v1, v2):
                return dot(v1, v2) / (norm(v1) * norm(v2))
            
            scored_messages = []
            for msg in session.messages:
                if msg.context_vector:
                    similarity = cosine_similarity(query_vector, msg.context_vector)
                    scored_messages.append((similarity, msg))
            
            scored_messages.sort(reverse=True, key=lambda x: x[0])
            return [msg for _, msg in scored_messages[:top_k]]
        except ImportError:
            # numpy 未安装时返回最近消息
            return session.get_recent_context(top_k)
    
    def save_snapshot(self, session: DialogueSession):
        """保存上下文快照"""
        with self._get_connection() as conn:
            snapshot_id = str(uuid.uuid4())
            conn.execute('''
                INSERT INTO context_snapshots 
                (snapshot_id, session_id, snapshot_data, summary)
                VALUES (?, ?, ?, ?)
            ''', (
                snapshot_id,
                session.session_id,
                pickle.dumps(session.to_dict()),
                session.context_summary
            ))
            return snapshot_id


class ContextCompressor:
    """上下文压缩器 - 处理长对话历史"""
    
    def __init__(self):
        self.max_context_length = 4000  # 最大上下文token数
        self.summarizer = None
        
    def _get_summarizer(self):
        """延迟加载摘要模型"""
        if self.summarizer is None:
            try:
                from transformers import pipeline
                self.summarizer = pipeline("summarization", model="facebook/bart-large-cnn")
            except ImportError:
                pass
        return self.summarizer
    
    def compress_session(self, session: DialogueSession) -> str:
        """压缩整个会话为摘要"""
        if len(session.messages) <= 10:
            return self._simple_concat(session.messages)
        
        summarizer = self._get_summarizer()
        if summarizer:
            # 分段摘要
            chunks = self._chunk_messages(session.messages, chunk_size=5)
            chunk_summaries = []
            
            for chunk in chunks:
                text = self._format_chunk(chunk)
                try:
                    summary = summarizer(text, max_length=100, min_length=20)[0]['summary_text']
                    chunk_summaries.append(summary)
                except Exception:
                    chunk_summaries.append(self._format_chunk(chunk))
            
            # 合并摘要
            final_summary = " | ".join(chunk_summaries)
            return final_summary
        else:
            # 降级方案：简单拼接
            return self._simple_concat(session.messages[-20:])
    
    def _chunk_messages(self, messages: List[Message], chunk_size: int) -> List[List[Message]]:
        """将消息分块"""
        return [messages[i:i+chunk_size] for i in range(0, len(messages), chunk_size)]
    
    def _format_chunk(self, messages: List[Message]) -> str:
        """格式化消息块为文本"""
        lines = []
        for msg in messages:
            role = "User" if msg.type == MessageType.USER else "Assistant"
            lines.append(f"{role}: {msg.content}")
        return "\n".join(lines)
    
    def _simple_concat(self, messages: List[Message]) -> str:
        """简单拼接短对话"""
        return self._format_chunk(messages)
    
    def selective_retrieval(self, session: DialogueSession, 
                          current_query: str,
                          max_messages: int = 10) -> List[Message]:
        """选择性检索相关消息"""
        # 策略1: 最近消息
        recent = session.get_recent_context(n=3)
        
        # 策略2: 意图相似的消息
        current_intent = self._infer_intent(current_query)
        similar_intent = [
            m for m in session.messages 
            if m.intent == current_intent and m not in recent
        ][-3:]
        
        # 策略3: 包含相同实体的消息
        current_entities = self._extract_entities(current_query)
        entity_matches = [
            m for m in session.messages
            if any(e in m.entities for e in current_entities) and m not in recent
        ][-4:]
        
        # 合并去重，按时间排序
        combined = list(dict.fromkeys(recent + similar_intent + entity_matches))
        return combined[-max_messages:]
    
    def _infer_intent(self, text: str) -> IntentType:
        """推断意图（简化版）"""
        # 实际实现应调用意图识别模块
        text_lower = text.lower()
        if any(w in text_lower for w in ["创建", "新建", "添加", "create", "add"]):
            return IntentType.CREATE_TASK
        elif any(w in text_lower for w in ["修改", "更新", "update", "change"]):
            return IntentType.UPDATE_TASK
        return IntentType.GENERAL_CHAT
    
    def _extract_entities(self, text: str) -> List[str]:
        """提取实体（简化版）"""
        # 实际实现应使用NER模型
        import re
        # 提取任务ID、时间、人名等
        task_ids = re.findall(r'任务[\s#]*(\w+)', text)
        return task_ids


# 导出公共接口
__all__ = [
    'MessageType',
    'IntentType',
    'Message',
    'DialogueSession',
    'DialogueHistoryStore',
    'ContextCompressor'
]
