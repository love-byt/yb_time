"""
知识图谱数据库适配器
统一接口支持多种图数据库后端：Neo4j、ArangoDB
"""

import json
import hashlib
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set, Tuple, Union
from datetime import datetime
from enum import Enum


class RelationType(Enum):
    """关系类型枚举"""
    DEPENDS_ON = "depends_on"          # 依赖于
    BLOCKED_BY = "blocked_by"          # 被阻塞
    RELATED_TO = "related_to"          # 相关
    PART_OF = "part_of"                # 属于
    PRECEDES = "precedes"              # 先于
    SIMILAR_TO = "similar_to"          # 相似
    CREATED_BY = "created_by"          # 创建者
    ASSIGNED_TO = "assigned_to"        # 分配给
    TAGGED_WITH = "tagged_with"        # 标签


@dataclass
class GraphNode:
    """图节点"""
    id: str
    label: str                          # 节点标签（类型）
    properties: Dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)


@dataclass
class GraphEdge:
    """图边（关系）"""
    source: str                         # 源节点ID
    target: str                         # 目标节点ID
    relation: RelationType
    properties: Dict[str, Any] = field(default_factory=dict)
    weight: float = 1.0                 # 关系权重
    confidence: float = 1.0             # 置信度


@dataclass
class GraphQuery:
    """图查询"""
    nodes: List[GraphNode] = field(default_factory=list)
    edges: List[GraphEdge] = field(default_factory=list)
    paths: List[List[str]] = field(default_factory=list)  # 节点ID路径


@dataclass
class PathResult:
    """路径查询结果"""
    nodes: List[GraphNode]
    edges: List[GraphEdge]
    length: int
    total_weight: float


class BaseGraphStore(ABC):
    """图存储基类"""
    
    @abstractmethod
    def connect(self, **kwargs) -> bool:
        """连接数据库"""
        pass
    
    @abstractmethod
    def disconnect(self):
        """断开连接"""
        pass
    
    @abstractmethod
    def create_node(self, node: GraphNode) -> bool:
        """创建节点"""
        pass
    
    @abstractmethod
    def create_edge(self, edge: GraphEdge) -> bool:
        """创建关系"""
        pass
    
    @abstractmethod
    def get_node(self, node_id: str) -> Optional[GraphNode]:
        """获取节点"""
        pass
    
    @abstractmethod
    def get_neighbors(
        self,
        node_id: str,
        relation: Optional[RelationType] = None,
        direction: str = "both"
    ) -> List[Tuple[GraphNode, GraphEdge]]:
        """获取邻居节点"""
        pass
    
    @abstractmethod
    def find_paths(
        self,
        source: str,
        target: str,
        max_depth: int = 5,
        relation: Optional[RelationType] = None
    ) -> List[PathResult]:
        """查找路径"""
        pass
    
    @abstractmethod
    def query_by_pattern(
        self,
        pattern: Dict[str, Any]
    ) -> GraphQuery:
        """模式查询"""
        pass
    
    @abstractmethod
    def delete_node(self, node_id: str) -> bool:
        """删除节点"""
        pass
    
    @abstractmethod
    def delete_edge(
        self,
        source: str,
        target: str,
        relation: Optional[RelationType] = None
    ) -> bool:
        """删除关系"""
        pass
    
    @abstractmethod
    def execute_cypher(self, query: str, parameters: Dict = None) -> Any:
        """执行Cypher查询"""
        pass


class Neo4jGraphStore(BaseGraphStore):
    """
    Neo4j图数据库适配器
    业界最流行的图数据库，功能完善，社区活跃
    """
    
    def __init__(self):
        self.driver = None
        self.connected = False
        
    def connect(
        self,
        uri: str = "bolt://localhost:7687",
        user: str = "neo4j",
        password: str = "password",
        **kwargs
    ) -> bool:
        """连接Neo4j"""
        try:
            from neo4j import GraphDatabase
            
            self.driver = GraphDatabase.driver(uri, auth=(user, password))
            
            # 测试连接
            with self.driver.session() as session:
                result = session.run("RETURN 1 AS num")
                result.single()
            
            self.connected = True
            print(f"[Neo4j] 已连接到 {uri}")
            return True
            
        except ImportError:
            print("[Neo4j] 错误: 未安装 neo4j，请运行: pip install neo4j")
            return False
        except Exception as e:
            print(f"[Neo4j] 连接失败: {e}")
            return False
    
    def disconnect(self):
        """断开连接"""
        if self.driver:
            self.driver.close()
            self.connected = False
            print("[Neo4j] 已断开连接")
    
    def create_node(self, node: GraphNode) -> bool:
        """创建节点"""
        try:
            with self.driver.session() as session:
                # 清理属性，确保可序列化
                props = self._clean_properties(node.properties)
                props['id'] = node.id
                props['created_at'] = node.created_at.isoformat()
                props['updated_at'] = node.updated_at.isoformat()
                
                cypher = f"""
                MERGE (n:{node.label} {{id: $id}})
                SET n += $props
                RETURN n
                """
                
                session.run(cypher, id=node.id, props=props)
                return True
                
        except Exception as e:
            print(f"[Neo4j] 创建节点失败: {e}")
            return False
    
    def create_edge(self, edge: GraphEdge) -> bool:
        """创建关系"""
        try:
            with self.driver.session() as session:
                props = self._clean_properties(edge.properties)
                props['weight'] = edge.weight
                props['confidence'] = edge.confidence
                
                rel_type = edge.relation.value
                
                cypher = f"""
                MATCH (a {{id: $source}}), (b {{id: $target}})
                MERGE (a)-[r:{rel_type}]->(b)
                SET r += $props
                RETURN r
                """
                
                session.run(cypher, source=edge.source, target=edge.target, props=props)
                return True
                
        except Exception as e:
            print(f"[Neo4j] 创建关系失败: {e}")
            return False
    
    def get_node(self, node_id: str) -> Optional[GraphNode]:
        """获取节点"""
        try:
            with self.driver.session() as session:
                result = session.run(
                    "MATCH (n {id: $id}) RETURN labels(n) as labels, n",
                    id=node_id
                )
                record = result.single()
                
                if record:
                    labels = record["labels"]
                    node_data = dict(record["n"])
                    
                    return GraphNode(
                        id=node_data.pop('id'),
                        label=labels[0] if labels else "Node",
                        properties=node_data
                    )
                return None
                
        except Exception as e:
            print(f"[Neo4j] 获取节点失败: {e}")
            return None
    
    def get_neighbors(
        self,
        node_id: str,
        relation: Optional[RelationType] = None,
        direction: str = "both"
    ) -> List[Tuple[GraphNode, GraphEdge]]:
        """获取邻居节点"""
        try:
            with self.driver.session() as session:
                # 构建关系过滤
                rel_filter = f":{relation.value}" if relation else ""
                
                if direction == "out":
                    pattern = f"(n {{id: $id}})-[r{rel_filter}]->(m)"
                elif direction == "in":
                    pattern = f"(n {{id: $id}})<-[r{rel_filter}]-(m)"
                else:
                    pattern = f"(n {{id: $id}})-[r{rel_filter}]-(m)"
                
                cypher = f"""
                MATCH {pattern}
                RETURN labels(m) as labels, m, type(r) as rel_type, r
                """
                
                result = session.run(cypher, id=node_id)
                
                neighbors = []
                for record in result:
                    node = GraphNode(
                        id=record["m"]["id"],
                        label=record["labels"][0],
                        properties={k: v for k, v in record["m"].items() if k != "id"}
                    )
                    
                    edge = GraphEdge(
                        source=node_id if direction in ["out", "both"] else record["m"]["id"],
                        target=record["m"]["id"] if direction in ["out", "both"] else node_id,
                        relation=RelationType(record["rel_type"]),
                        properties=dict(record["r"])
                    )
                    
                    neighbors.append((node, edge))
                
                return neighbors
                
        except Exception as e:
            print(f"[Neo4j] 获取邻居失败: {e}")
            return []
    
    def find_paths(
        self,
        source: str,
        target: str,
        max_depth: int = 5,
        relation: Optional[RelationType] = None
    ) -> List[PathResult]:
        """查找路径"""
        try:
            with self.driver.session() as session:
                rel_filter = f"{{type: '{relation.value}'}}" if relation else ""
                
                cypher = f"""
                MATCH path = shortestPath(
                    (a {{id: $source}})-[*1..{max_depth}]-(b {{id: $target}})
                )
                RETURN path, length(path) as len
                LIMIT 10
                """
                
                result = session.run(cypher, source=source, target=target)
                
                paths = []
                for record in result:
                    path = record["path"]
                    nodes = [GraphNode(
                        id=n["id"],
                        label=list(n.labels)[0],
                        properties=dict(n)
                    ) for n in path.nodes]
                    
                    edges = [GraphEdge(
                        source=rel.start_node["id"],
                        target=rel.end_node["id"],
                        relation=RelationType(rel.type),
                        properties=dict(rel)
                    ) for rel in path.relationships]
                    
                    paths.append(PathResult(
                        nodes=nodes,
                        edges=edges,
                        length=record["len"],
                        total_weight=sum(e.weight for e in edges)
                    ))
                
                return paths
                
        except Exception as e:
            print(f"[Neo4j] 查找路径失败: {e}")
            return []
    
    def query_by_pattern(self, pattern: Dict[str, Any]) -> GraphQuery:
        """模式查询"""
        try:
            with self.driver.session() as session:
                # 构建动态查询
                node_label = pattern.get("node_label", "")
                rel_type = pattern.get("relation", "")
                properties = pattern.get("properties", {})
                
                where_clauses = []
                for key, value in properties.items():
                    where_clauses.append(f"n.{key} = ${key}")
                
                where_str = " AND ".join(where_clauses) if where_clauses else "1=1"
                
                cypher = f"""
                MATCH (n{':' + node_label if node_label else ''})
                WHERE {where_str}
                OPTIONAL MATCH (n)-[r{':' + rel_type if rel_type else ''}]-(m)
                RETURN n, r, m
                LIMIT 100
                """
                
                result = session.run(cypher, **properties)
                
                nodes = {}
                edges = []
                
                for record in result:
                    # 处理起始节点
                    n = record["n"]
                    if n and n["id"] not in nodes:
                        nodes[n["id"]] = GraphNode(
                            id=n["id"],
                            label=list(n.labels)[0] if n.labels else "Node",
                            properties=dict(n)
                        )
                    
                    # 处理关系和目标节点
                    r = record["r"]
                    m = record["m"]
                    
                    if r and m:
                        if m["id"] not in nodes:
                            nodes[m["id"]] = GraphNode(
                                id=m["id"],
                                label=list(m.labels)[0] if m.labels else "Node",
                                properties=dict(m)
                            )
                        
                        edges.append(GraphEdge(
                            source=n["id"],
                            target=m["id"],
                            relation=RelationType(r.type),
                            properties=dict(r)
                        ))
                
                return GraphQuery(
                    nodes=list(nodes.values()),
                    edges=edges
                )
                
        except Exception as e:
            print(f"[Neo4j] 模式查询失败: {e}")
            return GraphQuery()
    
    def delete_node(self, node_id: str) -> bool:
        """删除节点"""
        try:
            with self.driver.session() as session:
                session.run(
                    "MATCH (n {id: $id}) DETACH DELETE n",
                    id=node_id
                )
                return True
        except Exception as e:
            print(f"[Neo4j] 删除节点失败: {e}")
            return False
    
    def delete_edge(
        self,
        source: str,
        target: str,
        relation: Optional[RelationType] = None
    ) -> bool:
        """删除关系"""
        try:
            with self.driver.session() as session:
                rel_filter = f":{relation.value}" if relation else ""
                
                cypher = f"""
                MATCH (a {{id: $source}})-[r{rel_filter}]->(b {{id: $target}})
                DELETE r
                """
                
                session.run(cypher, source=source, target=target)
                return True
        except Exception as e:
            print(f"[Neo4j] 删除关系失败: {e}")
            return False
    
    def execute_cypher(self, query: str, parameters: Dict = None) -> Any:
        """执行Cypher查询"""
        try:
            with self.driver.session() as session:
                result = session.run(query, parameters or {})
                return [record.data() for record in result]
        except Exception as e:
            print(f"[Neo4j] 执行查询失败: {e}")
            return None
    
    def _clean_properties(self, props: Dict) -> Dict:
        """清理属性，确保可序列化"""
        cleaned = {}
        for key, value in props.items():
            if isinstance(value, (str, int, float, bool, list, dict)):
                cleaned[key] = value
            elif isinstance(value, datetime):
                cleaned[key] = value.isoformat()
            else:
                cleaned[key] = str(value)
        return cleaned


class ArangoDBGraphStore(BaseGraphStore):
    """
    ArangoDB图数据库适配器
    多模型数据库，支持文档、键值、图存储
    适合需要灵活数据模型的场景
    """
    
    def __init__(self):
        self.client = None
        self.db = None
        self.connected = False
        
    def connect(
        self,
        host: str = "localhost",
        port: int = 8529,
        database: str = "knowledge_graph",
        username: str = "root",
        password: str = "",
        **kwargs
    ) -> bool:
        """连接ArangoDB"""
        try:
            from arango import ArangoClient
            
            # 创建客户端
            self.client = ArangoClient(hosts=f"http://{host}:{port}")
            
            # 连接系统数据库
            sys_db = self.client.db("_system", username=username, password=password)
            
            # 创建数据库（如果不存在）
            if not sys_db.has_database(database):
                sys_db.create_database(database)
                print(f"[ArangoDB] 创建数据库: {database}")
            
            # 连接到目标数据库
            self.db = self.client.db(database, username=username, password=password)
            
            # 初始化图集合
            self._init_collections()
            
            self.connected = True
            print(f"[ArangoDB] 已连接到 {host}:{port}/{database}")
            return True
            
        except ImportError:
            print("[ArangoDB] 错误: 未安装 python-arango，请运行: pip install python-arango")
            return False
        except Exception as e:
            print(f"[ArangoDB] 连接失败: {e}")
            return False
    
    def _init_collections(self):
        """初始化集合"""
        # 创建顶点集合
        if not self.db.has_collection("nodes"):
            self.db.create_collection("nodes")
        
        # 创建边集合
        if not self.db.has_collection("edges"):
            self.db.create_collection("edges", edge=True)
        
        # 创建图（如果不存在）
        if not self.db.has_graph("knowledge_graph"):
            self.db.create_graph("knowledge_graph")
            graph = self.db.graph("knowledge_graph")
            graph.create_edge_definition(
                edge_collection="edges",
                from_vertex_collections=["nodes"],
                to_vertex_collections=["nodes"]
            )
    
    def disconnect(self):
        """断开连接"""
        self.client = None
        self.db = None
        self.connected = False
        print("[ArangoDB] 已断开连接")
    
    def create_node(self, node: GraphNode) -> bool:
        """创建节点"""
        try:
            collection = self.db.collection("nodes")
            
            doc = {
                "_key": node.id,
                "label": node.label,
                "properties": node.properties,
                "created_at": node.created_at.isoformat(),
                "updated_at": node.updated_at.isoformat()
            }
            
            collection.insert(doc, overwrite=True)
            return True
            
        except Exception as e:
            print(f"[ArangoDB] 创建节点失败: {e}")
            return False
    
    def create_edge(self, edge: GraphEdge) -> bool:
        """创建关系"""
        try:
            collection = self.db.collection("edges")
            
            doc = {
                "_from": f"nodes/{edge.source}",
                "_to": f"nodes/{edge.target}",
                "relation": edge.relation.value,
                "properties": edge.properties,
                "weight": edge.weight,
                "confidence": edge.confidence
            }
            
            collection.insert(doc, overwrite=True)
            return True
            
        except Exception as e:
            print(f"[ArangoDB] 创建关系失败: {e}")
            return False
    
    def get_node(self, node_id: str) -> Optional[GraphNode]:
        """获取节点"""
        try:
            collection = self.db.collection("nodes")
            doc = collection.get(node_id)
            
            if doc:
                return GraphNode(
                    id=doc["_key"],
                    label=doc.get("label", "Node"),
                    properties=doc.get("properties", {}),
                    created_at=datetime.fromisoformat(doc["created_at"]),
                    updated_at=datetime.fromisoformat(doc["updated_at"])
                )
            return None
            
        except Exception as e:
            print(f"[ArangoDB] 获取节点失败: {e}")
            return None
    
    def get_neighbors(
        self,
        node_id: str,
        relation: Optional[RelationType] = None,
        direction: str = "both"
    ) -> List[Tuple[GraphNode, GraphEdge]]:
        """获取邻居节点"""
        try:
            # 使用AQL查询
            aql = """
            FOR v, e IN 1..1 @direction @startVertex edges
            """
            
            bind_vars = {
                "startVertex": f"nodes/{node_id}"
            }
            
            if direction == "out":
                bind_vars["direction"] = "OUTBOUND"
            elif direction == "in":
                bind_vars["direction"] = "INBOUND"
            else:
                bind_vars["direction"] = "ANY"
            
            if relation:
                aql += " FILTER e.relation == @relation"
                bind_vars["relation"] = relation.value
            
            aql += """
                RETURN {node: v, edge: e}
            """
            
            cursor = self.db.aql.execute(aql, bind_vars=bind_vars)
            
            neighbors = []
            for doc in cursor:
                node_doc = doc["node"]
                edge_doc = doc["edge"]
                
                node = GraphNode(
                    id=node_doc["_key"],
                    label=node_doc.get("label", "Node"),
                    properties=node_doc.get("properties", {})
                )
                
                edge = GraphEdge(
                    source=edge_doc["_from"].split("/")[1],
                    target=edge_doc["_to"].split("/")[1],
                    relation=RelationType(edge_doc["relation"]),
                    properties=edge_doc.get("properties", {}),
                    weight=edge_doc.get("weight", 1.0),
                    confidence=edge_doc.get("confidence", 1.0)
                )
                
                neighbors.append((node, edge))
            
            return neighbors
            
        except Exception as e:
            print(f"[ArangoDB] 获取邻居失败: {e}")
            return []
    
    def find_paths(
        self,
        source: str,
        target: str,
        max_depth: int = 5,
        relation: Optional[RelationType] = None
    ) -> List[PathResult]:
        """查找路径"""
        try:
            aql = f"""
            FOR path IN ANY SHORTEST_PATH
                @source TO @target
                edges
            """
            
            bind_vars = {
                "source": f"nodes/{source}",
                "target": f"nodes/{target}"
            }
            
            if relation:
                aql += f"""
                    FILTER path.edges[*].relation ALL == '{relation.value}'
                """
            
            cursor = self.db.aql.execute(aql, bind_vars=bind_vars)
            
            paths = []
            for doc in cursor:
                vertices = [
                    GraphNode(
                        id=v["_key"],
                        label=v.get("label", "Node"),
                        properties=v.get("properties", {})
                    ) for v in doc["vertices"]
                ]
                
                edges = [
                    GraphEdge(
                        source=e["_from"].split("/")[1],
                        target=e["_to"].split("/")[1],
                        relation=RelationType(e["relation"]),
                        properties=e.get("properties", {})
                    ) for e in doc["edges"]
                ]
                
                paths.append(PathResult(
                    nodes=vertices,
                    edges=edges,
                    length=len(edges),
                    total_weight=sum(e.weight for e in edges)
                ))
            
            return paths
            
        except Exception as e:
            print(f"[ArangoDB] 查找路径失败: {e}")
            return []
    
    def query_by_pattern(self, pattern: Dict[str, Any]) -> GraphQuery:
        """模式查询"""
        try:
            # 构建AQL查询
            aql = "FOR n IN nodes"
            
            filters = []
            if "node_label" in pattern:
                filters.append(f"n.label == '{pattern['node_label']}'")
            
            if "properties" in pattern:
                for key, value in pattern["properties"].items():
                    filters.append(f"n.properties.{key} == @{key}")
            
            if filters:
                aql += " FILTER " + " AND ".join(filters)
            
            aql += """
                FOR v, e IN 1..1 ANY n edges
                RETURN {node: n, neighbor: v, edge: e}
            """
            
            cursor = self.db.aql.execute(aql, bind_vars=pattern.get("properties", {}))
            
            nodes = {}
            edges = []
            
            for doc in cursor:
                n = doc["node"]
                if n["_key"] not in nodes:
                    nodes[n["_key"]] = GraphNode(
                        id=n["_key"],
                        label=n.get("label", "Node"),
                        properties=n.get("properties", {})
                    )
                
                if doc["neighbor"]:
                    m = doc["neighbor"]
                    if m["_key"] not in nodes:
                        nodes[m["_key"]] = GraphNode(
                            id=m["_key"],
                            label=m.get("label", "Node"),
                            properties=m.get("properties", {})
                        )
                    
                    e = doc["edge"]
                    edges.append(GraphEdge(
                        source=e["_from"].split("/")[1],
                        target=e["_to"].split("/")[1],
                        relation=RelationType(e["relation"]),
                        properties=e.get("properties", {})
                    ))
            
            return GraphQuery(nodes=list(nodes.values()), edges=edges)
            
        except Exception as e:
            print(f"[ArangoDB] 模式查询失败: {e}")
            return GraphQuery()
    
    def delete_node(self, node_id: str) -> bool:
        """删除节点"""
        try:
            collection = self.db.collection("nodes")
            collection.delete(node_id)
            return True
        except Exception as e:
            print(f"[ArangoDB] 删除节点失败: {e}")
            return False
    
    def delete_edge(
        self,
        source: str,
        target: str,
        relation: Optional[RelationType] = None
    ) -> bool:
        """删除关系"""
        try:
            aql = """
            FOR e IN edges
                FILTER e._from == @from AND e._to == @to
            """
            
            bind_vars = {
                "from": f"nodes/{source}",
                "to": f"nodes/{target}"
            }
            
            if relation:
                aql += " AND e.relation == @relation"
                bind_vars["relation"] = relation.value
            
            aql += " REMOVE e IN edges"
            
            self.db.aql.execute(aql, bind_vars=bind_vars)
            return True
            
        except Exception as e:
            print(f"[ArangoDB] 删除关系失败: {e}")
            return False
    
    def execute_cypher(self, query: str, parameters: Dict = None) -> Any:
        """执行AQL查询（ArangoDB使用AQL而非Cypher）"""
        try:
            cursor = self.db.aql.execute(query, bind_vars=parameters or {})
            return [doc for doc in cursor]
        except Exception as e:
            print(f"[ArangoDB] 执行查询失败: {e}")
            return None


class GraphStoreFactory:
    """图存储工厂"""
    
    STORE_TYPES = {
        "neo4j": Neo4jGraphStore,
        "arangodb": ArangoDBGraphStore
    }
    
    @classmethod
    def create(cls, store_type: str, **kwargs) -> BaseGraphStore:
        """
        创建图存储实例
        
        Args:
            store_type: 存储类型 (neo4j/arangodb)
            **kwargs: 连接参数
        """
        store_type = store_type.lower()
        
        if store_type not in cls.STORE_TYPES:
            raise ValueError(f"不支持的存储类型: {store_type}，可用: {list(cls.STORE_TYPES.keys())}")
        
        store_class = cls.STORE_TYPES[store_type]
        store = store_class()
        
        # 自动连接
        if kwargs:
            store.connect(**kwargs)
        
        return store
    
    @classmethod
    def from_config(cls, config: Dict[str, Any]) -> BaseGraphStore:
        """从配置创建"""
        store_type = config.get("type", "neo4j")
        connection_params = config.get("connection", {})
        return cls.create(store_type, **connection_params)


# 便捷函数
def get_graph_store(
    store_type: Optional[str] = None,
    **kwargs
) -> BaseGraphStore:
    """
    获取图存储实例
    优先从环境变量读取配置
    """
    import os
    
    if store_type is None:
        store_type = os.getenv("GRAPH_STORE_TYPE", "neo4j")
    
    # 根据类型读取环境变量
    if store_type == "neo4j":
        kwargs.setdefault("uri", os.getenv("NEO4J_URI", "bolt://localhost:7687"))
        kwargs.setdefault("user", os.getenv("NEO4J_USER", "neo4j"))
        kwargs.setdefault("password", os.getenv("NEO4J_PASSWORD", "password"))
    elif store_type == "arangodb":
        kwargs.setdefault("host", os.getenv("ARANGO_HOST", "localhost"))
        kwargs.setdefault("port", int(os.getenv("ARANGO_PORT", "8529")))
        kwargs.setdefault("database", os.getenv("ARANGO_DATABASE", "knowledge_graph"))
        kwargs.setdefault("username", os.getenv("ARANGO_USER", "root"))
        kwargs.setdefault("password", os.getenv("ARANGO_PASSWORD", ""))
    
    return GraphStoreFactory.create(store_type, **kwargs)


# 配置示例
GRAPH_STORE_CONFIG_EXAMPLE = {
    "neo4j": {
        "type": "neo4j",
        "connection": {
            "uri": "bolt://localhost:7687",
            "user": "neo4j",
            "password": "password"
        }
    },
    "arangodb": {
        "type": "arangodb",
        "connection": {
            "host": "localhost",
            "port": 8529,
            "database": "knowledge_graph",
            "username": "root",
            "password": "password"
        }
    }
}
