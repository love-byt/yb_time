"""
向量数据库适配器
统一接口支持多种向量数据库后端：Milvus、Faiss、PostgreSQL pgvector
"""

import os
import json
import hashlib
import numpy as np
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple, Union
from pathlib import Path
import pickle


@dataclass
class VectorRecord:
    """向量记录"""
    id: str
    vector: np.ndarray
    metadata: Dict[str, Any] = field(default_factory=dict)
    score: float = 0.0  # 相似度分数


@dataclass
class SearchResult:
    """搜索结果"""
    records: List[VectorRecord]
    total: int
    latency_ms: float


class BaseVectorStore(ABC):
    """向量存储基类"""
    
    @abstractmethod
    def connect(self, **kwargs) -> bool:
        """连接数据库"""
        pass
    
    @abstractmethod
    def disconnect(self):
        """断开连接"""
        pass
    
    @abstractmethod
    def create_collection(
        self,
        name: str,
        dimension: int,
        metric_type: str = "cosine",
        **kwargs
    ) -> bool:
        """创建集合/表"""
        pass
    
    @abstractmethod
    def delete_collection(self, name: str) -> bool:
        """删除集合/表"""
        pass
    
    @abstractmethod
    def insert(self, collection: str, records: List[VectorRecord]) -> bool:
        """插入向量记录"""
        pass
    
    @abstractmethod
    def search(
        self,
        collection: str,
        query_vector: np.ndarray,
        top_k: int = 10,
        filters: Optional[Dict] = None
    ) -> SearchResult:
        """相似度搜索"""
        pass
    
    @abstractmethod
    def delete(self, collection: str, ids: List[str]) -> bool:
        """删除记录"""
        pass
    
    @abstractmethod
    def get_stats(self, collection: str) -> Dict[str, Any]:
        """获取统计信息"""
        pass


class MilvusVectorStore(BaseVectorStore):
    """
    Milvus向量数据库适配器
    适合大规模生产环境，支持分布式部署
    """
    
    def __init__(self):
        self.client = None
        self.connected = False
        
    def connect(
        self,
        host: str = "localhost",
        port: int = 19530,
        user: str = "",
        password: str = "",
        **kwargs
    ) -> bool:
        """连接Milvus服务器"""
        try:
            from pymilvus import connections, Collection, FieldSchema, CollectionSchema, DataType
            
            connections.connect(
                alias="default",
                host=host,
                port=port,
                user=user,
                password=password
            )
            
            self.client = connections
            self.connected = True
            print(f"[Milvus] 已连接到 {host}:{port}")
            return True
            
        except ImportError:
            print("[Milvus] 错误: 未安装 pymilvus，请运行: pip install pymilvus")
            return False
        except Exception as e:
            print(f"[Milvus] 连接失败: {e}")
            return False
    
    def disconnect(self):
        """断开连接"""
        if self.connected:
            from pymilvus import connections
            connections.disconnect("default")
            self.connected = False
            print("[Milvus] 已断开连接")
    
    def create_collection(
        self,
        name: str,
        dimension: int,
        metric_type: str = "cosine",
        **kwargs
    ) -> bool:
        """创建Milvus集合"""
        try:
            from pymilvus import FieldSchema, CollectionSchema, DataType, Collection
            
            # 定义字段
            fields = [
                FieldSchema(name="id", dtype=DataType.VARCHAR, max_length=64, is_primary=True),
                FieldSchema(name="vector", dtype=DataType.FLOAT_VECTOR, dim=dimension),
                FieldSchema(name="metadata", dtype=DataType.VARCHAR, max_length=4096)
            ]
            
            # 创建schema
            schema = CollectionSchema(fields, description=f"Collection for {name}")
            
            # 创建集合
            collection = Collection(name=name, schema=schema)
            
            # 创建索引
            index_params = {
                "metric_type": metric_type.upper(),
                "index_type": "IVF_FLAT",
                "params": {"nlist": 128}
            }
            collection.create_index(field_name="vector", index_params=index_params)
            
            print(f"[Milvus] 创建集合: {name}, 维度: {dimension}")
            return True
            
        except Exception as e:
            print(f"[Milvus] 创建集合失败: {e}")
            return False
    
    def delete_collection(self, name: str) -> bool:
        """删除集合"""
        try:
            from pymilvus import utility
            utility.drop_collection(name)
            print(f"[Milvus] 删除集合: {name}")
            return True
        except Exception as e:
            print(f"[Milvus] 删除集合失败: {e}")
            return False
    
    def insert(self, collection: str, records: List[VectorRecord]) -> bool:
        """插入记录"""
        try:
            from pymilvus import Collection
            
            coll = Collection(name=collection)
            
            # 准备数据
            ids = [r.id for r in records]
            vectors = [r.vector.tolist() for r in records]
            metadata = [json.dumps(r.metadata) for r in records]
            
            # 插入
            coll.insert([ids, vectors, metadata])
            coll.flush()
            
            return True
            
        except Exception as e:
            print(f"[Milvus] 插入失败: {e}")
            return False
    
    def search(
        self,
        collection: str,
        query_vector: np.ndarray,
        top_k: int = 10,
        filters: Optional[Dict] = None
    ) -> SearchResult:
        """相似度搜索"""
        import time
        
        start_time = time.time()
        
        try:
            from pymilvus import Collection
            
            coll = Collection(name=collection)
            coll.load()
            
            # 搜索参数
            search_params = {"metric_type": "COSINE", "params": {"nprobe": 10}}
            
            # 执行搜索
            results = coll.search(
                data=[query_vector.tolist()],
                anns_field="vector",
                param=search_params,
                limit=top_k,
                output_fields=["metadata"]
            )
            
            # 解析结果
            records = []
            for hits in results:
                for hit in hits:
                    records.append(VectorRecord(
                        id=hit.id,
                        vector=np.array([]),  # Milvus不返回原始向量
                        metadata=json.loads(hit.entity.get("metadata", "{}")),
                        score=hit.score
                    ))
            
            latency = (time.time() - start_time) * 1000
            
            return SearchResult(
                records=records,
                total=len(records),
                latency_ms=latency
            )
            
        except Exception as e:
            print(f"[Milvus] 搜索失败: {e}")
            return SearchResult(records=[], total=0, latency_ms=0)
    
    def delete(self, collection: str, ids: List[str]) -> bool:
        """删除记录"""
        try:
            from pymilvus import Collection
            
            coll = Collection(name=collection)
            expr = f'id in ["{"\", \"".join(ids)}"]'
            coll.delete(expr)
            
            return True
            
        except Exception as e:
            print(f"[Milvus] 删除失败: {e}")
            return False
    
    def get_stats(self, collection: str) -> Dict[str, Any]:
        """获取统计信息"""
        try:
            from pymilvus import Collection
            
            coll = Collection(name=collection)
            stats = {
                "name": collection,
                "count": coll.num_entities,
                "is_loaded": coll.is_loaded
            }
            
            return stats
            
        except Exception as e:
            return {"error": str(e)}


class FaissVectorStore(BaseVectorStore):
    """
    Faiss向量存储适配器
    适合单机部署，内存存储，重启后数据丢失（除非持久化）
    """
    
    def __init__(self):
        self.indexes: Dict[str, Any] = {}
        self.metadata: Dict[str, Dict[str, Dict]] = {}
        self.id_map: Dict[str, Dict[str, int]] = {}
        self.connected = False
        self.persist_dir: Optional[Path] = None
        
    def connect(self, persist_dir: Optional[str] = None, **kwargs) -> bool:
        """连接/初始化Faiss"""
        try:
            import faiss
            self.faiss = faiss
            self.connected = True
            
            if persist_dir:
                self.persist_dir = Path(persist_dir)
                self.persist_dir.mkdir(parents=True, exist_ok=True)
                self._load_from_disk()
            
            print("[Faiss] 初始化完成")
            return True
            
        except ImportError:
            print("[Faiss] 错误: 未安装 faiss，请运行: pip install faiss-cpu 或 faiss-gpu")
            return False
    
    def disconnect(self):
        """断开连接，持久化数据"""
        if self.persist_dir:
            self._save_to_disk()
        self.connected = False
        print("[Faiss] 已断开")
    
    def _save_to_disk(self):
        """持久化到磁盘"""
        if not self.persist_dir:
            return
        
        for name, index in self.indexes.items():
            # 保存索引
            index_path = self.persist_dir / f"{name}.index"
            self.faiss.write_index(index, str(index_path))
            
            # 保存元数据
            meta_path = self.persist_dir / f"{name}.meta"
            with open(meta_path, 'wb') as f:
                pickle.dump({
                    'metadata': self.metadata.get(name, {}),
                    'id_map': self.id_map.get(name, {})
                }, f)
        
        print(f"[Faiss] 数据已持久化到 {self.persist_dir}")
    
    def _load_from_disk(self):
        """从磁盘加载"""
        if not self.persist_dir:
            return
        
        for index_file in self.persist_dir.glob("*.index"):
            name = index_file.stem
            
            # 加载索引
            index = self.faiss.read_index(str(index_file))
            self.indexes[name] = index
            
            # 加载元数据
            meta_file = self.persist_dir / f"{name}.meta"
            if meta_file.exists():
                with open(meta_file, 'rb') as f:
                    data = pickle.load(f)
                    self.metadata[name] = data['metadata']
                    self.id_map[name] = data['id_map']
            
            print(f"[Faiss] 加载集合: {name}")
    
    def create_collection(
        self,
        name: str,
        dimension: int,
        metric_type: str = "cosine",
        **kwargs
    ) -> bool:
        """创建Faiss索引"""
        try:
            # 选择索引类型
            if metric_type == "cosine":
                # 归一化后使用内积
                index = self.faiss.IndexFlatIP(dimension)
            elif metric_type == "l2":
                index = self.faiss.IndexFlatL2(dimension)
            else:
                index = self.faiss.IndexFlatL2(dimension)
            
            # 包装为IDMap以支持字符串ID
            index = self.faiss.IndexIDMap(index)
            
            self.indexes[name] = index
            self.metadata[name] = {}
            self.id_map[name] = {}
            
            print(f"[Faiss] 创建索引: {name}, 维度: {dimension}")
            return True
            
        except Exception as e:
            print(f"[Faiss] 创建索引失败: {e}")
            return False
    
    def delete_collection(self, name: str) -> bool:
        """删除索引"""
        if name in self.indexes:
            del self.indexes[name]
            del self.metadata[name]
            del self.id_map[name]
            
            # 删除持久化文件
            if self.persist_dir:
                (self.persist_dir / f"{name}.index").unlink(missing_ok=True)
                (self.persist_dir / f"{name}.meta").unlink(missing_ok=True)
            
            print(f"[Faiss] 删除索引: {name}")
            return True
        return False
    
    def insert(self, collection: str, records: List[VectorRecord]) -> bool:
        """插入向量"""
        try:
            index = self.indexes.get(collection)
            if index is None:
                return False
            
            vectors = []
            ids = []
            
            for i, record in enumerate(records):
                # 生成数字ID
                numeric_id = len(self.id_map[collection])
                
                vectors.append(record.vector)
                ids.append(numeric_id)
                
                # 保存映射
                self.id_map[collection][record.id] = numeric_id
                self.metadata[collection][numeric_id] = {
                    'id': record.id,
                    'metadata': record.metadata
                }
            
            # 归一化向量（用于余弦相似度）
            vectors = np.array(vectors).astype('float32')
            faiss.normalize_L2(vectors)
            
            # 插入
            index.add_with_ids(vectors, np.array(ids).astype('int64'))
            
            return True
            
        except Exception as e:
            print(f"[Faiss] 插入失败: {e}")
            return False
    
    def search(
        self,
        collection: str,
        query_vector: np.ndarray,
        top_k: int = 10,
        filters: Optional[Dict] = None
    ) -> SearchResult:
        """相似度搜索"""
        import time
        
        start_time = time.time()
        
        try:
            index = self.indexes.get(collection)
            if index is None:
                return SearchResult(records=[], total=0, latency_ms=0)
            
            # 归一化查询向量
            query = query_vector.reshape(1, -1).astype('float32')
            self.faiss.normalize_L2(query)
            
            # 搜索
            distances, indices = index.search(query, top_k)
            
            # 解析结果
            records = []
            for idx, dist in zip(indices[0], distances[0]):
                if idx == -1:
                    continue
                
                meta = self.metadata[collection].get(int(idx), {})
                records.append(VectorRecord(
                    id=meta.get('id', str(idx)),
                    vector=np.array([]),
                    metadata=meta.get('metadata', {}),
                    score=float(dist)
                ))
            
            latency = (time.time() - start_time) * 1000
            
            return SearchResult(
                records=records,
                total=len(records),
                latency_ms=latency
            )
            
        except Exception as e:
            print(f"[Faiss] 搜索失败: {e}")
            return SearchResult(records=[], total=0, latency_ms=0)
    
    def delete(self, collection: str, ids: List[str]) -> bool:
        """Faiss不支持直接删除，需要重建索引"""
        print("[Faiss] 警告: Faiss不支持直接删除，建议标记删除或定期重建索引")
        return False
    
    def get_stats(self, collection: str) -> Dict[str, Any]:
        """获取统计信息"""
        index = self.indexes.get(collection)
        if index is None:
            return {"error": "Collection not found"}
        
        return {
            "name": collection,
            "count": index.ntotal,
            "dimension": index.d
        }


class PGVectorStore(BaseVectorStore):
    """
    PostgreSQL pgvector扩展适配器
    适合已有PostgreSQL基础设施的环境
    """
    
    def __init__(self):
        self.conn = None
        self.connected = False
        
    def connect(
        self,
        host: str = "localhost",
        port: int = 5432,
        database: str = "vectordb",
        user: str = "postgres",
        password: str = "",
        **kwargs
    ) -> bool:
        """连接PostgreSQL"""
        try:
            import psycopg2
            
            self.conn = psycopg2.connect(
                host=host,
                port=port,
                database=database,
                user=user,
                password=password
            )
            
            # 检查pgvector扩展
            with self.conn.cursor() as cur:
                cur.execute("SELECT * FROM pg_extension WHERE extname = 'vector'")
                if not cur.fetchone():
                    print("[PGVector] 正在创建pgvector扩展...")
                    cur.execute("CREATE EXTENSION IF NOT EXISTS vector")
                    self.conn.commit()
            
            self.connected = True
            print(f"[PGVector] 已连接到 {host}:{port}/{database}")
            return True
            
        except ImportError:
            print("[PGVector] 错误: 未安装 psycopg2，请运行: pip install psycopg2-binary")
            return False
        except Exception as e:
            print(f"[PGVector] 连接失败: {e}")
            return False
    
    def disconnect(self):
        """断开连接"""
        if self.conn:
            self.conn.close()
            self.connected = False
            print("[PGVector] 已断开连接")
    
    def create_collection(
        self,
        name: str,
        dimension: int,
        metric_type: str = "cosine",
        **kwargs
    ) -> bool:
        """创建向量表"""
        try:
            with self.conn.cursor() as cur:
                # 创建表
                cur.execute(f"""
                    CREATE TABLE IF NOT EXISTS {name} (
                        id VARCHAR(64) PRIMARY KEY,
                        vector vector({dimension}),
                        metadata JSONB,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                """)
                
                # 创建向量索引
                metric_ops = "vector_cosine_ops" if metric_type == "cosine" else "vector_l2_ops"
                cur.execute(f"""
                    CREATE INDEX IF NOT EXISTS idx_{name}_vector 
                    ON {name} USING ivfflat (vector {metric_ops})
                """)
                
                self.conn.commit()
                
            print(f"[PGVector] 创建表: {name}, 维度: {dimension}")
            return True
            
        except Exception as e:
            print(f"[PGVector] 创建表失败: {e}")
            self.conn.rollback()
            return False
    
    def delete_collection(self, name: str) -> bool:
        """删除表"""
        try:
            with self.conn.cursor() as cur:
                cur.execute(f"DROP TABLE IF EXISTS {name}")
                self.conn.commit()
            
            print(f"[PGVector] 删除表: {name}")
            return True
            
        except Exception as e:
            print(f"[PGVector] 删除表失败: {e}")
            return False
    
    def insert(self, collection: str, records: List[VectorRecord]) -> bool:
        """插入记录"""
        try:
            with self.conn.cursor() as cur:
                for record in records:
                    vector_str = f"[{','.join(map(str, record.vector.tolist()))}]"
                    cur.execute(f"""
                        INSERT INTO {collection} (id, vector, metadata)
                        VALUES (%s, %s::vector, %s)
                        ON CONFLICT (id) DO UPDATE SET
                            vector = EXCLUDED.vector,
                            metadata = EXCLUDED.metadata
                    """, (record.id, vector_str, json.dumps(record.metadata)))
                
                self.conn.commit()
            return True
            
        except Exception as e:
            print(f"[PGVector] 插入失败: {e}")
            self.conn.rollback()
            return False
    
    def search(
        self,
        collection: str,
        query_vector: np.ndarray,
        top_k: int = 10,
        filters: Optional[Dict] = None
    ) -> SearchResult:
        """相似度搜索"""
        import time
        
        start_time = time.time()
        
        try:
            with self.conn.cursor() as cur:
                vector_str = f"[{','.join(map(str, query_vector.tolist()))}]"
                
                # 构建查询
                query = f"""
                    SELECT id, vector, metadata, 
                           vector <=> %s::vector as distance
                    FROM {collection}
                    ORDER BY distance
                    LIMIT %s
                """
                
                cur.execute(query, (vector_str, top_k))
                
                records = []
                for row in cur.fetchall():
                    records.append(VectorRecord(
                        id=row[0],
                        vector=np.array([]),
                        metadata=row[2],
                        score=1.0 / (1.0 + row[3])  # 转换距离为相似度
                    ))
                
                latency = (time.time() - start_time) * 1000
                
                return SearchResult(
                    records=records,
                    total=len(records),
                    latency_ms=latency
                )
                
        except Exception as e:
            print(f"[PGVector] 搜索失败: {e}")
            return SearchResult(records=[], total=0, latency_ms=0)
    
    def delete(self, collection: str, ids: List[str]) -> bool:
        """删除记录"""
        try:
            with self.conn.cursor() as cur:
                cur.execute(f"""
                    DELETE FROM {collection} WHERE id = ANY(%s)
                """, (ids,))
                self.conn.commit()
            return True
            
        except Exception as e:
            print(f"[PGVector] 删除失败: {e}")
            self.conn.rollback()
            return False
    
    def get_stats(self, collection: str) -> Dict[str, Any]:
        """获取统计信息"""
        try:
            with self.conn.cursor() as cur:
                cur.execute(f"SELECT COUNT(*) FROM {collection}")
                count = cur.fetchone()[0]
                
                return {
                    "name": collection,
                    "count": count
                }
                
        except Exception as e:
            return {"error": str(e)}


class VectorStoreFactory:
    """向量存储工厂"""
    
    STORE_TYPES = {
        "milvus": MilvusVectorStore,
        "faiss": FaissVectorStore,
        "pgvector": PGVectorStore
    }
    
    @classmethod
    def create(cls, store_type: str, **kwargs) -> BaseVectorStore:
        """
        创建向量存储实例
        
        Args:
            store_type: 存储类型 (milvus/faiss/pgvector)
            **kwargs: 连接参数
        """
        store_type = store_type.lower()
        
        if store_type not in cls.STORE_TYPES:
            raise ValueError(f"不支持的存储类型: {store_type}，可用: {list(cls.STORE_TYPES.keys())}")
        
        store_class = cls.STORE_TYPES[store_type]
        store = store_class()
        
        # 自动连接
        if kwargs:
            store.connect(**kwargs)
        
        return store
    
    @classmethod
    def from_config(cls, config: Dict[str, Any]) -> BaseVectorStore:
        """从配置创建"""
        store_type = config.get("type", "faiss")
        connection_params = config.get("connection", {})
        return cls.create(store_type, **connection_params)


# 便捷函数
def get_vector_store(
    store_type: Optional[str] = None,
    **kwargs
) -> BaseVectorStore:
    """
    获取向量存储实例
    优先从环境变量读取配置
    """
    if store_type is None:
        store_type = os.getenv("VECTOR_STORE_TYPE", "faiss")
    
    # 根据类型读取环境变量
    if store_type == "milvus":
        kwargs.setdefault("host", os.getenv("MILVUS_HOST", "localhost"))
        kwargs.setdefault("port", int(os.getenv("MILVUS_PORT", "19530")))
    elif store_type == "pgvector":
        kwargs.setdefault("host", os.getenv("PG_HOST", "localhost"))
        kwargs.setdefault("port", int(os.getenv("PG_PORT", "5432")))
        kwargs.setdefault("database", os.getenv("PG_DATABASE", "vectordb"))
        kwargs.setdefault("user", os.getenv("PG_USER", "postgres"))
        kwargs.setdefault("password", os.getenv("PG_PASSWORD", ""))
    elif store_type == "faiss":
        kwargs.setdefault("persist_dir", os.getenv("FAISS_PERSIST_DIR", "./faiss_data"))
    
    return VectorStoreFactory.create(store_type, **kwargs)


# 配置示例
VECTOR_STORE_CONFIG_EXAMPLE = {
    "milvus": {
        "type": "milvus",
        "connection": {
            "host": "localhost",
            "port": 19530
        }
    },
    "faiss": {
        "type": "faiss",
        "connection": {
            "persist_dir": "./faiss_data"
        }
    },
    "pgvector": {
        "type": "pgvector",
        "connection": {
            "host": "localhost",
            "port": 5432,
            "database": "vectordb",
            "user": "postgres",
            "password": "password"
        }
    }
}
