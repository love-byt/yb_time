"""
缓存工具类
支持Redis和内存缓存双模式
"""

import os
import json
import time
import hashlib
from typing import Any, Optional, Callable, Dict, List
from functools import wraps
import logging
from datetime import datetime

logger = logging.getLogger(__name__)


# ==================== 缓存配置 ====================

# 默认TTL配置（秒）
DEFAULT_TTL = {
    'tasks': 60,                # 任务列表缓存1分钟
    'task_detail': 300,         # 任务详情缓存5分钟
    'statistics': 300,          # 统计数据缓存5分钟
    'user_info': 600,           # 用户信息缓存10分钟
    'tags': 300,                # 标签列表缓存5分钟
    'reminders': 60,            # 提醒列表缓存1分钟
    'ai_analysis': 86400,       # AI分析结果缓存24小时（新增）
}

# AI分析类型映射
AI_ANALYSIS_TYPES = {
    'habit': '学习习惯分析',
    'weekly': '每周报告',
    'completion': '完成事项分析',
}

# 缓存键前缀
CACHE_PREFIXES = {
    'tasks': 'tasks',
    'task': 'task',
    'statistics': 'stats',
    'user': 'user',
    'tags': 'tags',
    'reminders': 'reminders',
    'ai_analysis': 'ai_analysis',  # 新增
}


class CacheBackend:
    """缓存后端抽象类"""
    
    def get(self, key: str) -> Optional[Any]:
        raise NotImplementedError
    
    def set(self, key: str, value: Any, ttl: int = 300) -> bool:
        raise NotImplementedError
    
    def delete(self, key: str) -> bool:
        raise NotImplementedError
    
    def clear_pattern(self, pattern: str) -> int:
        raise NotImplementedError


class MemoryCache(CacheBackend):
    """内存缓存实现（开发环境或Redis不可用时使用）
    
    特性：
    - 支持最大条目数限制（防止内存无限增长）
    - 支持最大内存使用限制
    - LRU淘汰策略
    """
    
    # 默认配置
    DEFAULT_MAX_ENTRIES = 1000  # 最大缓存条目数
    DEFAULT_MAX_SIZE_MB = 100   # 最大内存使用（MB）
    
    def __init__(self, max_entries: int = None, max_size_mb: int = None):
        self._cache = {}
        self._expiry = {}
        self._access_time = {}  # 记录访问时间用于LRU
        self._max_entries = max_entries or self.DEFAULT_MAX_ENTRIES
        self._max_size_mb = max_size_mb or self.DEFAULT_MAX_SIZE_MB
        self._max_size_bytes = self._max_size_mb * 1024 * 1024
        logger.info(f"[CACHE] 使用内存缓存 (最大条目: {self._max_entries}, 最大内存: {self._max_size_mb}MB)")
    
    def _get_size(self, obj: Any) -> int:
        """估算对象内存大小（字节）
        
        Args:
            obj: 任意对象
            
        Returns:
            对象内存大小（字节）
        """
        import sys
        try:
            return sys.getsizeof(obj)
        except (TypeError, AttributeError):
            return 1024  # 默认估算1KB
    
    def _get_total_size(self) -> int:
        """获取缓存总大小"""
        return sum(self._get_size(v) for v in self._cache.values())
    
    def _evict_if_needed(self):
        """根据需要执行LRU淘汰"""
        # 检查条目数限制
        while len(self._cache) >= self._max_entries:
            # 找出最久未访问的key
            oldest_key = min(self._access_time, key=self._access_time.get)
            self.delete(oldest_key)
            logger.debug(f"LRU淘汰: {oldest_key}")
        
        # 检查内存限制
        total_size: int = self._get_total_size()
        while total_size > self._max_size_bytes and len(self._cache) > 0 and self._access_time:
            oldest_key: str = min(self._access_time, key=self._access_time.get)
            evicted_size: int = self._get_size(self._cache.get(oldest_key))
            self.delete(oldest_key)
            total_size -= evicted_size
            logger.debug(f"内存淘汰: {oldest_key}")
    
    def _cleanup_expired(self):
        """清理过期条目"""
        now = time.time()
        expired_keys = [
            k for k, exp in self._expiry.items() 
            if exp is not None and now > exp
        ]
        for key in expired_keys:
            self.delete(key)
    
    def get(self, key: str) -> Optional[Any]:
        # 先清理过期条目
        self._cleanup_expired()
        
        if key in self._cache:
            # 检查是否过期
            if key in self._expiry and self._expiry[key] is not None and time.time() > self._expiry[key]:
                self.delete(key)
                return None
            # 更新访问时间
            self._access_time[key] = time.time()
            return self._cache[key]
        return None
    
    def set(self, key: str, value: Any, ttl: int = 300) -> bool:
        # 如果需要，执行淘汰
        if key not in self._cache:
            self._evict_if_needed()
        
        self._cache[key] = value
        self._expiry[key] = time.time() + ttl if ttl > 0 else None
        self._access_time[key] = time.time()
        return True
    
    def delete(self, key: str) -> bool:
        if key in self._cache:
            del self._cache[key]
            if key in self._expiry:
                del self._expiry[key]
            if key in self._access_time:
                del self._access_time[key]
            return True
        return False
    
    def clear_pattern(self, pattern: str) -> int:
        """清除匹配的缓存键"""
        count = 0
        # 简单的前缀匹配
        prefix = pattern.replace('*', '')
        keys_to_delete = [k for k in self._cache.keys() if k.startswith(prefix)]
        for key in keys_to_delete:
            if self.delete(key):
                count += 1
        return count
    
    def get_stats(self) -> dict:
        """获取缓存统计信息"""
        return {
            'entries': len(self._cache),
            'max_entries': self._max_entries,
            'size_bytes': self._get_total_size(),
            'max_size_bytes': self._max_size_bytes,
            'size_mb': round(self._get_total_size() / (1024 * 1024), 2)
        }


class RedisCache(CacheBackend):
    """Redis缓存实现"""
    
    def __init__(self, redis_url: str = None):
        import redis
        
        self.redis_url = redis_url or os.getenv('REDIS_URL', 'redis://localhost:6379/0')
        
        try:
            # 尝试连接Redis
            if 'fakeredis' in self.redis_url:
                import fakeredis
                self.client = fakeredis.FakeRedis()
            else:
                self.client = redis.from_url(self.redis_url, decode_responses=True)
            # 测试连接
            self.client.ping()
            logger.info(f"[CACHE] Redis缓存连接成功: {self.redis_url}")
        except Exception as e:
            logger.warning(f"[CACHE] Redis连接失败，使用内存缓存: {e}")
            # 降级到内存缓存
            self.client = None
            self._fallback = MemoryCache()
    
    def get(self, key: str) -> Optional[Any]:
        if self.client is None:
            return self._fallback.get(key)
        
        try:
            value = self.client.get(key)
            if value:
                return json.loads(value)
            return None
        except Exception as e:
            logger.error(f"Redis get error: {e}")
            return None
    
    def set(self, key: str, value: Any, ttl: int = 300) -> bool:
        if self.client is None:
            return self._fallback.set(key, value, ttl)
        
        try:
            self.client.setex(key, ttl, json.dumps(value))
            return True
        except Exception as e:
            logger.error(f"Redis set error: {e}")
            return False
    
    def delete(self, key: str) -> bool:
        if self.client is None:
            return self._fallback.delete(key)
        
        try:
            self.client.delete(key)
            return True
        except Exception as e:
            logger.error(f"Redis delete error: {e}")
            return False
    
    def clear_pattern(self, pattern: str) -> int:
        if self.client is None:
            return self._fallback.clear_pattern(pattern)
        
        try:
            keys = self.client.keys(pattern)
            if keys:
                return self.client.delete(*keys)
            return 0
        except Exception as e:
            logger.error(f"Redis clear_pattern error: {e}")
            return 0


class CacheManager:
    """
    统一缓存管理器
    
    特性：
    - 单例模式，全局共享缓存实例
    - 支持Redis和内存缓存双模式
    - 提供完善的缓存失效策略
    - 支持用户维度的缓存隔离
    """
    
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._backend = None
            cls._instance._key_registry = {}  # 记录缓存键的关系，用于失效
        return cls._instance
    
    @property
    def backend(self) -> CacheBackend:
        if self._backend is None:
            # 根据环境选择缓存后端
            env = os.getenv('COZE_PROJECT_ENV', 'DEV')
            redis_url = os.getenv('REDIS_URL')
            
            if env == 'PROD' and redis_url:
                self._backend = RedisCache(redis_url)
            else:
                # 开发环境或无Redis配置时使用内存缓存
                self._backend = MemoryCache()
        
        return self._backend
    
    def get(self, key: str) -> Optional[Any]:
        """获取缓存值"""
        return self.backend.get(key)
    
    def set(self, key: str, value: Any, ttl: int = 300) -> bool:
        """设置缓存值"""
        return self.backend.set(key, value, ttl)
    
    def delete(self, key: str) -> bool:
        """删除缓存"""
        return self.backend.delete(key)
    
    def clear_pattern(self, pattern: str) -> int:
        """清除匹配模式的所有缓存"""
        return self.backend.clear_pattern(pattern)
    
    # ==================== 缓存失效策略 ====================
    
    def invalidate_user_cache(self, user_id: int, cache_types: List[str] = None):
        """
        清除用户相关的所有缓存
        
        Args:
            user_id: 用户ID
            cache_types: 要清除的缓存类型列表，如 ['tasks', 'statistics']
                        如果为None，清除所有用户相关缓存
        """
        if cache_types is None:
            cache_types = ['tasks', 'statistics', 'tags', 'reminders']
        
        total_cleared = 0
        for cache_type in cache_types:
            pattern = f"{cache_type}:{user_id}*"
            cleared = self.clear_pattern(pattern)
            total_cleared += cleared
            logger.debug(f"清除缓存: {pattern}, 数量: {cleared}")
        
        logger.info(f"用户 {user_id} 缓存已清除，总计: {total_cleared}")
        return total_cleared
    
    def invalidate_task_cache(self, user_id: int, task_id: int = None):
        """
        清除任务相关缓存
        
        Args:
            user_id: 用户ID
            task_id: 任务ID（可选），如果提供则同时清除任务详情缓存
        """
        # 清除任务列表缓存
        self.clear_pattern(f"tasks:{user_id}*")
        
        # 清除统计缓存
        self.clear_pattern(f"stats:{user_id}*")
        
        # 如果指定了任务ID，清除任务详情缓存
        if task_id:
            self.delete(f"task:{task_id}")
        
        logger.debug(f"任务缓存已清除: user_id={user_id}, task_id={task_id}")
    
    def invalidate_tag_cache(self, user_id: int):
        """清除标签相关缓存"""
        self.clear_pattern(f"tags:{user_id}*")
        logger.debug(f"标签缓存已清除: user_id={user_id}")
    
    def invalidate_statistics_cache(self, user_id: int):
        """清除统计相关缓存"""
        self.clear_pattern(f"stats:{user_id}*")
        logger.debug(f"统计缓存已清除: user_id={user_id}")
    
    def invalidate_reminder_cache(self, user_id: int):
        """清除提醒相关缓存"""
        self.clear_pattern(f"reminders:{user_id}*")
        logger.debug(f"提醒缓存已清除: user_id={user_id}")
    
    # ==================== 便捷方法 ====================
    
    def get_user_tasks(self, user_id: int) -> Optional[List]:
        """获取用户任务列表缓存"""
        return self.get(f"tasks:{user_id}")
    
    def set_user_tasks(self, user_id: int, tasks: List, ttl: int = None) -> bool:
        """设置用户任务列表缓存"""
        ttl = ttl or DEFAULT_TTL['tasks']
        return self.set(f"tasks:{user_id}", tasks, ttl)
    
    def get_user_statistics(self, user_id: int, stats_type: str = None) -> Optional[Dict]:
        """获取用户统计缓存"""
        key = f"stats:{user_id}:{stats_type}" if stats_type else f"stats:{user_id}"
        return self.get(key)
    
    def set_user_statistics(self, user_id: int, stats: Dict, stats_type: str = None, ttl: int = None) -> bool:
        """设置用户统计缓存"""
        ttl = ttl or DEFAULT_TTL['statistics']
        key = f"stats:{user_id}:{stats_type}" if stats_type else f"stats:{user_id}"
        return self.set(key, stats, ttl)


# 全局缓存管理器实例
cache = CacheManager()


def cache_key(*args, **kwargs) -> str:
    """生成缓存键"""
    key_parts = [str(arg) for arg in args]
    key_parts.extend(f"{k}={v}" for k, v in sorted(kwargs.items()))
    key_string = ":".join(key_parts)
    return hashlib.md5(key_string.encode()).hexdigest()


def cached(prefix: str, ttl: int = 300, key_builder: Callable = None):
    """
    缓存装饰器
    
    Args:
        prefix: 缓存键前缀
        ttl: 缓存时间（秒）
        key_builder: 自定义键生成函数
    
    Usage:
        @cached('tasks', ttl=60)
        def get_tasks(user_id):
            return Task.query.filter_by(user_id=user_id).all()
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            # 生成缓存键
            if key_builder:
                key_suffix = key_builder(*args, **kwargs)
            else:
                # 默认使用参数生成键
                key_suffix = cache_key(*args, **kwargs)
            
            cache_key_str = f"{prefix}:{key_suffix}"
            
            # 尝试从缓存获取
            cached_value = cache.get(cache_key_str)
            if cached_value is not None:
                logger.debug(f"Cache hit: {cache_key_str}")
                return cached_value
            
            # 缓存未命中，执行函数
            logger.debug(f"Cache miss: {cache_key_str}")
            result = func(*args, **kwargs)
            
            # 存入缓存
            if result is not None:
                cache.set(cache_key_str, result, ttl)
            
            return result
        
        return wrapper
    return decorator


def invalidate_cache(prefix: str, *args, **kwargs):
    """清除指定缓存"""
    if args or kwargs:
        key_suffix = cache_key(*args, **kwargs)
        cache_key_str = f"{prefix}:{key_suffix}"
        cache.delete(cache_key_str)
    else:
        # 清除所有匹配前缀的缓存
        cache.clear_pattern(f"{prefix}:*")


def user_cache_key(user_id: str, *args, **kwargs) -> str:
    """用户维度的缓存键生成器"""
    return f"{user_id}:{cache_key(*args, **kwargs)}"
