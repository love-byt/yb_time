"""
API 速率限制器
防止暴力攻击和滥用
"""

import time
import functools
from typing import Dict, Optional, Callable
from flask import request, jsonify, current_app
import logging

logger = logging.getLogger(__name__)


class RateLimiter:
    """简单的内存速率限制器（生产环境建议使用 Redis）"""
    
    def __init__(self):
        # 存储请求记录: {key: [(timestamp, count), ...]}
        self._requests: Dict[str, list] = {}
        self._cleanup_interval = 3600  # 清理间隔（秒）
        self._last_cleanup = time.time()
    
    def _cleanup_old_entries(self):
        """清理过期的记录"""
        now = time.time()
        if now - self._last_cleanup < self._cleanup_interval:
            return
        
        cutoff = now - 3600  # 保留1小时内的记录
        for key in list(self._requests.keys()):
            self._requests[key] = [
                (ts, cnt) for ts, cnt in self._requests[key]
                if ts > cutoff
            ]
            if not self._requests[key]:
                del self._requests[key]
        
        self._last_cleanup = now
    
    def is_allowed(
        self,
        key: str,
        max_requests: int = 100,
        window_seconds: int = 60
    ) -> tuple[bool, Dict]:
        """
        检查请求是否允许
        
        Returns:
            (is_allowed, rate_limit_info)
        """
        self._cleanup_old_entries()
        
        now = time.time()
        window_start = now - window_seconds
        
        # 获取该 key 的请求记录
        requests = self._requests.get(key, [])
        
        # 过滤窗口期内的请求
        recent_requests = [
            (ts, cnt) for ts, cnt in requests
            if ts > window_start
        ]
        
        # 计算当前窗口内的请求数
        current_count = sum(cnt for _, cnt in recent_requests)
        
        # 检查是否超过限制
        if current_count >= max_requests:
            # 计算重置时间
            if recent_requests:
                oldest_ts = min(ts for ts, _ in recent_requests)
                reset_time = oldest_ts + window_seconds
                retry_after = int(reset_time - now)
            else:
                retry_after = window_seconds
            
            return False, {
                'limit': max_requests,
                'remaining': 0,
                'reset_in': retry_after,
                'retry_after': retry_after
            }
        
        # 记录本次请求
        recent_requests.append((now, 1))
        self._requests[key] = recent_requests
        
        return True, {
            'limit': max_requests,
            'remaining': max_requests - current_count - 1,
            'reset_in': window_seconds
        }


# 全局限流器实例
_rate_limiter = RateLimiter()


def rate_limit(
    max_requests: int = 100,
    window_seconds: int = 60,
    key_func: Optional[Callable] = None
):
    """
    速率限制装饰器
    
    Args:
        max_requests: 时间窗口内最大请求数
        window_seconds: 时间窗口（秒）
        key_func: 自定义限流 key 生成函数，默认使用 IP + 路由
    
    Example:
        @rate_limit(max_requests=10, window_seconds=60)
        def login():
            pass
        
        @rate_limit(max_requests=5, window_seconds=60, key_func=lambda: f"user_{current_user.id}")
        def sensitive_operation():
            pass
    """
    def decorator(f):
        @functools.wraps(f)
        def decorated_function(*args, **kwargs):
            # 生成限流 key
            if key_func:
                key = key_func()
            else:
                # 默认使用 IP + 端点
                ip = request.headers.get('X-Forwarded-For', request.remote_addr) or 'unknown'
                endpoint = request.endpoint or 'unknown'
                key = f"{ip}:{endpoint}"
            
            # 检查限流
            allowed, info = _rate_limiter.is_allowed(
                key, max_requests, window_seconds
            )
            
            if not allowed:
                logger.warning(f"Rate limit exceeded for {key}")
                response = jsonify({
                    'success': False,
                    'error': '请求过于频繁，请稍后再试',
                    'retry_after': info['retry_after']
                })
                response.status_code = 429
                response.headers['Retry-After'] = str(info['retry_after'])
                response.headers['X-RateLimit-Limit'] = str(info['limit'])
                response.headers['X-RateLimit-Remaining'] = str(info['remaining'])
                return response
            
            # 添加限流信息到响应头
            response = f(*args, **kwargs)
            
            # 如果响应是 tuple (response, status_code)
            if isinstance(response, tuple):
                actual_response = response[0]
            else:
                actual_response = response
            
            # 添加限流头
            if hasattr(actual_response, 'headers'):
                actual_response.headers['X-RateLimit-Limit'] = str(info['limit'])
                actual_response.headers['X-RateLimit-Remaining'] = str(info['remaining'])
            
            return response
        
        return decorated_function
    return decorator


def strict_rate_limit(max_requests: int = 5, window_seconds: int = 60):
    """
    严格限流（用于敏感操作如登录）
    """
    return rate_limit(max_requests=max_requests, window_seconds=window_seconds)
