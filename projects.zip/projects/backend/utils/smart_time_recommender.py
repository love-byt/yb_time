"""
智能时间推荐器
基于用户行为习惯和任务难度，推荐最佳开始和结束时间
"""

from __future__ import annotations
from datetime import datetime, timedelta
from typing import Optional
from dataclasses import dataclass

from extensions import db
from models.task import Task
from utils.user_behavior_analyzer import UserBehaviorAnalyzer


@dataclass
class TimeRecommendation:
    """时间推荐结果"""
    start_time: datetime
    end_time: datetime
    confidence: float  # 推荐置信度 0.0-1.0
    reasoning: str  # 推荐理由
    source: str  # 数据来源：user_habit/historical/default


class SmartTimeRecommender:
    """智能时间推荐器"""
    
    # 任务难度与时段匹配策略
    DIFFICULTY_TIME_STRATEGY = {
        'easy': 'flexible',      # 简单任务：灵活时段
        'medium': 'good',        # 中等任务：良好时段
        'hard': 'peak',          # 困难任务：高峰时段
        'very_hard': 'peak'      # 极难任务：高峰时段
    }
    
    # 默认任务时长（分钟）
    DEFAULT_DURATION_BY_DIFFICULTY = {
        'easy': 30,
        'medium': 60,
        'hard': 120,
        'very_hard': 180
    }
    
    def __init__(self, user_id: str):
        """
        初始化推荐器
        
        Args:
            user_id: 用户ID
        """
        if not user_id:
            raise ValueError("user_id 不能为空")
        
        self.user_id = user_id
        self.behavior_analyzer = UserBehaviorAnalyzer(user_id)
    
    def recommend_start_time(
        self,
        category: str = '',
        difficulty: str = 'medium',
        earliest_time: datetime | None = None
    ) -> TimeRecommendation:
        """
        推荐任务开始时间
        
        Args:
            category: 任务分类
            difficulty: 任务难度（easy/medium/hard/very_hard）
            earliest_time: 最早开始时间（默认当前时间）
            
        Returns:
            TimeRecommendation: 时间推荐结果
        """
        if earliest_time is None:
            earliest_time = datetime.now()
        
        # 1. 获取用户最佳工作时段
        optimal_times = self.behavior_analyzer.get_optimal_study_time(category=category)
        
        if optimal_times and optimal_times.get('has_pattern'):
            # 用户有明显的工作习惯模式
            strategy = self.DIFFICULTY_TIME_STRATEGY.get(difficulty, 'good')
            
            if strategy == 'peak':
                # 高难度任务安排在效率最高时段
                recommended_hour = optimal_times.get('peak_performance_hour', 9)
                confidence = 0.9
                reasoning = f"根据您的习惯，{recommended_hour}点是效率最高的时段，适合处理困难任务"
                source = "user_habit"
                
            elif strategy == 'good':
                # 中等难度任务安排在良好时段
                recommended_hour = optimal_times.get('good_performance_hour', 14)
                confidence = 0.8
                reasoning = f"根据您的习惯，{recommended_hour}点是良好的工作时段"
                source = "user_habit"
                
            else:  # flexible
                # 简单任务可以灵活安排
                recommended_hour = optimal_times.get('available_hour', 16)
                confidence = 0.7
                reasoning = f"简单任务可在{recommended_hour}点等灵活时段完成"
                source = "user_habit"
        else:
            # 用户没有明显习惯，使用通用最佳实践
            recommended_hour = self._get_default_optimal_hour(difficulty)
            confidence = 0.5
            reasoning = f"根据通用最佳实践，{recommended_hour}点适合此类任务"
            source = "default"
        
        # 2. 计算推荐开始时间
        start_time = earliest_time.replace(
            hour=recommended_hour,
            minute=0,
            second=0,
            microsecond=0
        )
        
        # 如果推荐时间已过，移到明天
        if start_time < earliest_time:
            start_time += timedelta(days=1)
        
        # 3. 构建推荐结果（暂时不含结束时间）
        return TimeRecommendation(
            start_time=start_time,
            end_time=start_time,  # 临时值，后续会计算
            confidence=confidence,
            reasoning=reasoning,
            source=source
        )
    
    def recommend_end_time(
        self,
        start_time: datetime,
        category: str = '',
        difficulty: str = 'medium',
        title: str = '',
        estimated_duration: int | None = None
    ) -> TimeRecommendation:
        """
        推荐任务结束时间
        
        Args:
            start_time: 任务开始时间
            category: 任务分类
            difficulty: 任务难度
            title: 任务标题
            estimated_duration: 用户指定的预估时长（分钟）
            
        Returns:
            TimeRecommendation: 时间推荐结果
        """
        # 1. 优先使用用户指定的预估时长
        if estimated_duration and estimated_duration > 0:
            duration_minutes = estimated_duration
            confidence = 0.95
            reasoning = "基于您设定的预估时长"
            source = "user_input"
        else:
            # 2. 尝试从历史相似任务获取平均时长
            historical_duration = self._get_historical_duration(
                title=title,
                category=category,
                difficulty=difficulty
            )
            
            if historical_duration:
                duration_minutes = historical_duration
                confidence = 0.85
                reasoning = f"基于您之前完成的{category}类任务平均时长"
                source = "historical"
            else:
                # 3. 使用基于难度的默认时长
                duration_minutes = self.DEFAULT_DURATION_BY_DIFFICULTY.get(
                    difficulty, 
                    60
                )
                confidence = 0.6
                reasoning = f"基于{difficulty}难度的标准时长预估"
                source = "default"
        
        # 计算结束时间
        end_time = start_time + timedelta(minutes=duration_minutes)
        
        return TimeRecommendation(
            start_time=start_time,
            end_time=end_time,
            confidence=confidence,
            reasoning=reasoning,
            source=source
        )
    
    def recommend_time_range(
        self,
        category: str = '',
        difficulty: str = 'medium',
        title: str = '',
        estimated_duration: int | None = None,
        earliest_time: datetime | None = None
    ) -> dict[str, any]:
        """
        一站式推荐开始和结束时间
        
        Args:
            category: 任务分类
            difficulty: 任务难度
            title: 任务标题
            estimated_duration: 预估时长（分钟）
            earliest_time: 最早开始时间
            
        Returns:
            包含推荐时间和元信息的字典
        """
        # 1. 推荐开始时间
        start_recommendation = self.recommend_start_time(
            category=category,
            difficulty=difficulty,
            earliest_time=earliest_time
        )
        
        # 2. 推荐结束时间
        end_recommendation = self.recommend_end_time(
            start_time=start_recommendation.start_time,
            category=category,
            difficulty=difficulty,
            title=title,
            estimated_duration=estimated_duration
        )
        
        # 3. 综合置信度
        combined_confidence = (
            start_recommendation.confidence * 0.4 + 
            end_recommendation.confidence * 0.6
        )
        
        return {
            'start_time': start_recommendation.start_time,
            'end_time': end_recommendation.end_time,
            'estimated_duration': int(
                (end_recommendation.end_time - start_recommendation.start_time).total_seconds() / 60
            ),
            'confidence': combined_confidence,
            'reasoning': {
                'start': start_recommendation.reasoning,
                'end': end_recommendation.reasoning
            },
            'source': {
                'start': start_recommendation.source,
                'end': end_recommendation.source
            }
        }
    
    def _get_historical_duration(
        self,
        title: str,
        category: str,
        difficulty: str
    ) -> int | None:
        """
        从历史完成任务中获取平均时长
        
        Args:
            title: 任务标题
            category: 任务分类
            difficulty: 任务难度
            
        Returns:
            平均时长（分钟），如果没有历史数据则返回None
        """
        try:
            # 查询用户历史完成的相似任务
            similar_tasks = Task.query.filter(
                Task.user_id == self.user_id,
                Task.category == category,
                Task.is_completed == True,
                Task.actual_duration != None,
                Task.actual_duration > 0
            ).limit(20).all()
            
            if not similar_tasks:
                return None
            
            # 如果有难度信息，优先匹配相同难度
            same_difficulty_tasks = [
                t for t in similar_tasks 
                if getattr(t, 'difficulty_level', '') == difficulty
            ]
            
            if same_difficulty_tasks:
                durations = [t.actual_duration for t in same_difficulty_tasks]
                return int(sum(durations) / len(durations))
            
            # 否则使用所有相似任务的平均值
            durations = [t.actual_duration for t in similar_tasks]
            return int(sum(durations) / len(durations))
            
        except Exception as e:
            print(f"[智能推荐] 获取历史时长失败: {e}")
            return None
    
    def _get_default_optimal_hour(self, difficulty: str) -> int:
        """
        获取默认最佳工作时间（基于通用最佳实践）
        
        Args:
            difficulty: 任务难度
            
        Returns:
            推荐的小时数（0-23）
        """
        # 基于认知科学研究的通用最佳实践
        if difficulty in ['hard', 'very_hard']:
            # 困难任务：上午9-11点（大脑最清醒）
            return 9
        elif difficulty == 'medium':
            # 中等任务：下午2-4点（午休后恢复）
            return 14
        else:  # easy
            # 简单任务：下午4-6点（灵活时段）
            return 16
