"""
推送通知工具模块
支持 Web Push 推送通知和 VAPID 密钥管理
"""

import json
import os
from datetime import datetime
from typing import Optional, Dict, Any, Tuple

from flask import current_app

# VAPID 密钥缓存
_vapid_keys_cache: Optional[Tuple[str, str]] = None


def generate_vapid_keys() -> Tuple[str, str]:
    """
    生成 VAPID 密钥对
    
    Returns:
        Tuple[str, str]: (public_key, private_key) - Base64URL 编码
    """
    try:
        # 使用 cryptography 生成兼容格式的密钥
        from cryptography.hazmat.primitives.asymmetric import ec
        from cryptography.hazmat.backends import default_backend
        import base64
        
        # 生成 ECDSA 私钥 (P-256 曲线)
        private_key_obj = ec.generate_private_key(ec.SECP256R1(), default_backend())
        
        # 提取公钥的未压缩格式 (0x04 + x + y)
        public_key_obj = private_key_obj.public_key()
        public_numbers = public_key_obj.public_numbers()
        public_value = bytes([0x04]) + (
            public_numbers.x.to_bytes(32, 'big') + 
            public_numbers.y.to_bytes(32, 'big')
        )
        public_encoded = base64.urlsafe_b64encode(public_value).rstrip(b'=').decode('utf-8')
        
        # 提取私钥
        private_numbers = private_key_obj.private_numbers()
        private_value = private_numbers.private_value.to_bytes(32, 'big')
        private_encoded = base64.urlsafe_b64encode(private_value).rstrip(b'=').decode('utf-8')
        
        return public_encoded, private_encoded
        
    except ImportError as e:
        print(f"[WARN] cryptography 库未安装: {e}")
        return "", ""
    except Exception as e:
        print(f"[ERROR] 生成 VAPID 密钥失败: {e}")
        import traceback
        print(traceback.format_exc())
        return "", ""


def clear_vapid_keys_cache():
    """清除 VAPID 密钥缓存，用于重新生成密钥"""
    global _vapid_keys_cache
    _vapid_keys_cache = None
    print("[VAPID] 密钥缓存已清除，下次将生成新密钥")


def get_or_create_vapid_keys() -> Tuple[str, str]:
    """
    获取或创建 VAPID 密钥对
    
    优先从环境变量读取，如果没有则生成并缓存
    
    Returns:
        Tuple[str, str]: (public_key, private_key)
    """
    global _vapid_keys_cache
    
    # 优先使用缓存
    if _vapid_keys_cache:
        return _vapid_keys_cache
    
    # 尝试从环境变量读取
    public_key = os.getenv('VAPID_PUBLIC_KEY', '')
    private_key = os.getenv('VAPID_PRIVATE_KEY', '')
    
    if public_key and private_key:
        _vapid_keys_cache = (public_key, private_key)
        return _vapid_keys_cache
    
    # 尝试从 Flask app config 读取
    try:
        public_key = current_app.config.get('VAPID_PUBLIC_KEY', '')
        private_key = current_app.config.get('VAPID_PRIVATE_KEY', '')
        
        if public_key and private_key:
            _vapid_keys_cache = (public_key, private_key)
            return _vapid_keys_cache
    except RuntimeError:
        # 不在应用上下文中
        pass
    
    # 生成新密钥对
    public_key, private_key = generate_vapid_keys()
    
    if public_key and private_key:
        _vapid_keys_cache = (public_key, private_key)
        print("[VAPID] 已生成新的 VAPID 密钥对")
        print(f"   公钥: {public_key[:20]}...")
        print("   [WARN] 建议将密钥保存到环境变量 VAPID_PUBLIC_KEY 和 VAPID_PRIVATE_KEY")
    
    return public_key, private_key


def get_vapid_public_key() -> str:
    """
    获取 VAPID 公钥
    
    Returns:
        str: VAPID 公钥 (Base64 URL 编码)
    """
    public_key, _ = get_or_create_vapid_keys()
    return public_key


def get_vapid_subject() -> str:
    """
    获取 VAPID Subject
    
    Returns:
        str: VAPID Subject (通常是 mailto: URL)
    """
    try:
        return current_app.config.get('VAPID_SUBJECT', 'mailto:admin@smart-scheduler.com')
    except RuntimeError:
        return os.getenv('VAPID_SUBJECT', 'mailto:admin@smart-scheduler.com')


def send_push_notification(
    subscription: Dict[str, Any],
    title: str,
    body: str,
    data: Optional[Dict[str, Any]] = None,
    icon: str = '/static/icon.png',
    badge: str = '/static/badge.png',
    tag: Optional[str] = None,
    require_interaction: bool = True,
    actions: Optional[list] = None,
    vapid_private_key: Optional[str] = None,
    vapid_subject: Optional[str] = None
) -> Tuple[bool, str]:
    """
    发送 Web Push 推送通知
    
    Args:
        subscription: 推送订阅信息 (包含 endpoint, keys.p256dh, keys.auth)
        title: 通知标题
        body: 通知内容
        data: 自定义数据
        icon: 图标 URL
        badge: 徽章 URL
        tag: 通知标签 (用于分组)
        require_interaction: 是否需要用户交互
        actions: 操作按钮列表
        vapid_private_key: VAPID 私钥 (可选，默认自动获取)
        vapid_subject: VAPID Subject (可选，默认自动获取)
    
    Returns:
        Tuple[bool, str]: (是否成功, 错误信息或响应)
    """
    try:
        from pywebpush import webpush, WebPushException
    except ImportError:
        return False, "pywebpush 库未安装，请运行: pip install pywebpush"
    
    # 获取 VAPID 配置
    if not vapid_private_key:
        _, vapid_private_key = get_or_create_vapid_keys()
    
    if not vapid_private_key:
        return False, "VAPID 私钥未配置"
    
    if not vapid_subject:
        vapid_subject = get_vapid_subject()
    
    # 构建通知负载
    payload = {
        'title': title,
        'body': body,
        'icon': icon,
        'badge': badge,
        'requireInteraction': require_interaction,
        'timestamp': int(datetime.now().timestamp() * 1000)
    }
    
    if data:
        payload['data'] = data
    
    if tag:
        payload['tag'] = tag
    
    if actions:
        payload['actions'] = actions
    
    # 默认操作按钮
    if not actions:
        payload['actions'] = [
            {'action': 'view', 'title': '查看详情'},
            {'action': 'complete', 'title': '标记完成'},
            {'action': 'delay', 'title': '稍后提醒'}
        ]
    
    try:
        # 发送推送
        response = webpush(
            subscription_info=subscription,
            data=json.dumps(payload),
            vapid_private_key=vapid_private_key,
            vapid_claims={
                'sub': vapid_subject
            }
        )
        
        print(f"[PUSH] 推送通知发送成功: {title}")
        return True, f"发送成功，状态码: {response.status_code if hasattr(response, 'status_code') else 'N/A'}"
        
    except WebPushException as e:
        error_msg = f"WebPush 错误: {e}"
        if e.response and e.response.json():
            error_detail = e.response.json()
            error_msg += f" - {error_detail}"
        print(f"[ERROR] {error_msg}")
        return False, error_msg
        
    except Exception as e:
        error_msg = f"推送发送失败: {str(e)}"
        print(f"[ERROR] {error_msg}")
        return False, error_msg


def send_push_to_user(user, title: str, body: str, **kwargs) -> Tuple[bool, str]:
    """
    向指定用户发送推送通知
    
    Args:
        user: 用户对象 (需要有 push_subscription 属性)
        title: 通知标题
        body: 通知内容
        **kwargs: 其他参数传递给 send_push_notification
    
    Returns:
        Tuple[bool, str]: (是否成功, 错误信息或响应)
    """
    if not user:
        return False, "用户不存在"
    
    if not user.push_subscription:
        return False, "用户未订阅推送通知"
    
    # 解析订阅信息
    try:
        if isinstance(user.push_subscription, str):
            subscription = json.loads(user.push_subscription)
        else:
            subscription = user.push_subscription
    except json.JSONDecodeError:
        return False, "订阅信息格式错误"
    
    # 验证订阅信息完整性
    required_fields = ['endpoint']
    for field in required_fields:
        if field not in subscription:
            return False, f"订阅信息缺少必要字段: {field}"
    
    return send_push_notification(subscription, title, body, **kwargs)


def send_task_reminder(user, task) -> Tuple[bool, str]:
    """
    发送任务提醒推送
    
    Args:
        user: 用户对象
        task: 任务对象
    
    Returns:
        Tuple[bool, str]: (是否成功, 错误信息或响应)
    """
    if not task:
        return False, "任务不存在"
    
    title = f"⏰ 任务提醒: {task.title}"
    
    # 构建提醒内容
    body_parts = []
    if task.end_time:
        body_parts.append(f"截止时间: {task.end_time}")
    if task.category:
        body_parts.append(f"分类: {task.category}")
    if task.priority:
        priority_text = {5: "[紧急]", 4: "[高]", 3: "[中]", 2: "[低]", 1: "[很低]"}
        body_parts.append(f"优先级: {priority_text.get(task.priority, task.priority)}")
    
    body = "\n".join(body_parts) if body_parts else "请及时处理"
    
    return send_push_to_user(
        user, title, body,
        data={'taskId': task.id, 'type': 'reminder'},
        tag=f'task-{task.id}',
        actions=[
            {'action': 'complete', 'title': '标记完成'},
            {'action': 'delay', 'title': '稍后提醒'}
        ]
    )


def send_deadline_warning(user, task, minutes_left: int) -> Tuple[bool, str]:
    """
    发送截止时间警告推送
    
    Args:
        user: 用户对象
        task: 任务对象
        minutes_left: 剩余分钟数
    
    Returns:
        Tuple[bool, str]: (是否成功, 错误信息或响应)
    """
    if not task:
        return False, "任务不存在"
    
    if minutes_left <= 0:
        title = f"[过期] 任务已过期: {task.title}"
        body = f"该任务已超过截止时间，请尽快处理"
    elif minutes_left <= 30:
        title = f"[即将到期] 即将到期: {task.title}"
        body = f"距离截止还有 {minutes_left} 分钟"
    elif minutes_left <= 60:
        title = f"[提醒] 任务提醒: {task.title}"
        body = f"距离截止还有约 1 小时"
    else:
        hours = minutes_left // 60
        title = f"🟡 任务提醒: {task.title}"
        body = f"距离截止还有约 {hours} 小时"
    
    return send_push_to_user(
        user, title, body,
        data={'taskId': task.id, 'type': 'deadline_warning', 'minutesLeft': minutes_left},
        tag=f'task-{task.id}',
        require_interaction=True
    )


# 导出公共接口
__all__ = [
    'generate_vapid_keys',
    'get_or_create_vapid_keys',
    'clear_vapid_keys_cache',
    'get_vapid_public_key',
    'get_vapid_subject',
    'send_push_notification',
    'send_push_to_user',
    'send_task_reminder',
    'send_deadline_warning'
]
