"""
自然语言时间解析模块 - 简化可靠版
将用户输入的自然语言转换为标准datetime对象
"""

import re
from datetime import datetime, timedelta


class TimeParser:
    """时间解析器"""
    
    def __init__(self, base_time=None):
        self.base = base_time or datetime.now()
    
    def parse(self, text):
        """解析自然语言时间"""
        if not text:
            return None
        
        text = text.strip()
        
        # 1. 特殊词
        if text in ['马上', '立刻', '立即', '现在']:
            return self.base + timedelta(minutes=5)
        
        # 2. 相对时间: X小时后/天后
        match = re.search(r'(\d+)\s*小时\s*后', text)
        if match:
            return self.base + timedelta(hours=int(match.group(1)))
        
        match = re.search(r'(\d+)\s*分钟\s*后', text)
        if match:
            return self.base + timedelta(minutes=int(match.group(1)))
        
        match = re.search(r'(\d+)\s*天\s*后', text)
        if match:
            return self.base + timedelta(days=int(match.group(1)))
        
        # 3. 提取日期偏移
        days = 0
        if '大后天' in text:
            days = 3
        elif '后天' in text:
            days = 2
        elif '明天' in text or '明日' in text:
            days = 1
        elif '今天' in text or '今晚' in text:
            days = 0
        elif '昨天' in text:
            days = -1
        
        target_date = self.base + timedelta(days=days)
        
        # 4. 提取具体时间
        hour, minute = self._extract_time(text)
        
        # 5. 如果没有提取到时间，根据时间段设置默认时间
        if hour is None:
            if '凌晨' in text or '半夜' in text:
                hour, minute = 0, 0
            elif '早上' in text:
                hour, minute = 7, 0
            elif '上午' in text:
                hour, minute = 9, 0
            elif '中午' in text:
                hour, minute = 12, 0
            elif '下午' in text:
                hour, minute = 14, 0
            elif '傍晚' in text:
                hour, minute = 17, 0
            elif '晚上' in text or '今晚' in text:
                hour, minute = 21, 0
            else:
                hour, minute = 21, 0  # 默认晚上9点
        
        result = target_date.replace(hour=hour, minute=minute, second=0, microsecond=0)
        
        # 如果结果时间已经过去，且是今天，则可能是明天
        if result < self.base and days == 0 and '今天' not in text and '今晚' not in text:
            result += timedelta(days=1)
        
        return result
    
    def _extract_time(self, text):
        """提取具体时间"""
        # 匹配 9:30, 14:00, 21:30
        match = re.search(r'(\d{1,2}):(\d{2})', text)
        if match:
            return int(match.group(1)), int(match.group(2))
        
        # 匹配 9点, 9点钟, 晚上9点
        match = re.search(r'(\d{1,2})\s*点', text)
        if match:
            hour = int(match.group(1))
            # 处理12点特殊情况
            if hour == 12:
                if '凌晨' in text or '半夜' in text or ('今晚' in text and '晚上' not in text):
                    hour = 0  # 凌晨12点 = 0点
            # 智能判断上午/下午
            elif hour < 12 and ('下午' in text or '晚上' in text):
                hour += 12
            return hour, 0
        
        return None, 0


# 便捷函数
def parse_time(text, base_time=None):
    """解析时间"""
    parser = TimeParser(base_time)
    return parser.parse(text)
