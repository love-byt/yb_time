"""
工具包初始化
"""

from utils.ai_helper import AIHelper
from utils.ai_sorter import SixDimensionSorter, sort_tasks_by_ai
from utils.ai_sorter_optimized import OptimizedAISorter, sort_tasks_optimized

# 校园场景模块
try:
    from utils.campus_keywords import (
        CAMPUS_KEYWORDS, 
        detect_campus_scenario, 
        get_campus_scenario_weight,
        get_campus_scenario_name
    )
    from utils.campus_ai_enhancer import (
        enhance_ai_score_for_campus,
        get_campus_enhancement_explanation,
        is_exam_week,
        is_gpa_related
    )
    CAMPUS_AVAILABLE = True
except ImportError:
    CAMPUS_AVAILABLE = False

__all__ = [
    'AIHelper', 
    'SixDimensionSorter', 
    'sort_tasks_by_ai',
    'OptimizedAISorter',
    'sort_tasks_optimized',
    'CAMPUS_AVAILABLE'
]

# 校园场景模块导出
if CAMPUS_AVAILABLE:
    __all__.extend([
        'CAMPUS_KEYWORDS',
        'detect_campus_scenario',
        'get_campus_scenario_weight',
        'get_campus_scenario_name',
        'enhance_ai_score_for_campus',
        'get_campus_enhancement_explanation',
        'is_exam_week',
        'is_gpa_related'
    ])
