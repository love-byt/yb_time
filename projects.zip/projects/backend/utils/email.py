"""
邮件发送工具模块

支持多种邮件发送方式：
1. Resend API (推荐) - 免费3000封/月
2. SMTP 服务器 - 传统方式

环境变量配置：
- RESEND_API_KEY: Resend API Key (推荐)
- SMTP_SERVER: SMTP服务器地址
- SMTP_PORT: SMTP端口 (默认587)
- SMTP_USERNAME: SMTP用户名
- SMTP_PASSWORD: SMTP密码
- SMTP_FROM: 发件人地址
"""

import os
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime
import urllib.request
import json


def send_email_via_resend(to_email: str, subject: str, html_content: str, text_content: str = None) -> dict:
    """
    使用 Resend API 发送邮件
    
    Args:
        to_email: 收件人邮箱
        subject: 邮件主题
        html_content: HTML 内容
        text_content: 纯文本内容（可选）
    
    Returns:
        {'success': bool, 'message': str, 'id': str}
    """
    api_key = os.getenv('RESEND_API_KEY')
    if not api_key:
        return {
            'success': False,
            'message': '未配置 RESEND_API_KEY'
        }
    
    from_email = os.getenv('SMTP_FROM', 'onboarding@resend.dev')
    
    data = {
        'from': from_email,
        'to': [to_email],
        'subject': subject,
        'html': html_content
    }
    
    if text_content:
        data['text'] = text_content
    
    try:
        req = urllib.request.Request(
            'https://api.resend.com/emails',
            data=json.dumps(data).encode('utf-8'),
            headers={
                'Authorization': f'Bearer {api_key}',
                'Content-Type': 'application/json'
            },
            method='POST'
        )
        
        with urllib.request.urlopen(req, timeout=30) as response:
            result = json.loads(response.read().decode('utf-8'))
            return {
                'success': True,
                'message': '邮件发送成功',
                'id': result.get('id')
            }
    except urllib.error.HTTPError as e:
        error_body = e.read().decode('utf-8') if e.fp else str(e)
        return {
            'success': False,
            'message': f'Resend API 错误: {error_body}'
        }
    except Exception as e:
        return {
            'success': False,
            'message': f'发送失败: {str(e)}'
        }


def send_email_via_smtp(to_email: str, subject: str, html_content: str, text_content: str = None) -> dict:
    """
    使用 SMTP 服务器发送邮件
    
    Args:
        to_email: 收件人邮箱
        subject: 邮件主题
        html_content: HTML 内容
        text_content: 纯文本内容（可选）
    
    Returns:
        {'success': bool, 'message': str}
    """
    smtp_server = os.getenv('SMTP_SERVER')
    smtp_port = int(os.getenv('SMTP_PORT', '587'))
    smtp_username = os.getenv('SMTP_USERNAME')
    smtp_password = os.getenv('SMTP_PASSWORD')
    from_email = os.getenv('SMTP_FROM', smtp_username)
    
    if not all([smtp_server, smtp_username, smtp_password]):
        return {
            'success': False,
            'message': 'SMTP 配置不完整'
        }
    
    try:
        # 创建邮件
        msg = MIMEMultipart('alternative')
        msg['Subject'] = subject
        msg['From'] = from_email
        msg['To'] = to_email
        
        # 添加纯文本内容
        if text_content:
            msg.attach(MIMEText(text_content, 'plain', 'utf-8'))
        
        # 添加 HTML 内容
        msg.attach(MIMEText(html_content, 'html', 'utf-8'))
        
        # 发送邮件
        with smtplib.SMTP(smtp_server, smtp_port) as server:
            server.starttls()
            server.login(smtp_username, smtp_password)
            server.sendmail(from_email, to_email, msg.as_string())
        
        return {
            'success': True,
            'message': '邮件发送成功'
        }
    except Exception as e:
        return {
            'success': False,
            'message': f'发送失败: {str(e)}'
        }


def send_email(to_email: str, subject: str, html_content: str, text_content: str = None) -> dict:
    """
    发送邮件（自动选择发送方式）
    
    优先级：
    1. Resend API (如果配置了 RESEND_API_KEY)
    2. SMTP (如果配置了 SMTP 服务器信息)
    
    Args:
        to_email: 收件人邮箱
        subject: 邮件主题
        html_content: HTML 内容
        text_content: 纯文本内容（可选）
    
    Returns:
        {'success': bool, 'message': str, 'id': str (可选)}
    """
    # 优先使用 Resend API
    if os.getenv('RESEND_API_KEY'):
        return send_email_via_resend(to_email, subject, html_content, text_content)
    
    # 其次使用 SMTP
    if os.getenv('SMTP_SERVER'):
        return send_email_via_smtp(to_email, subject, html_content, text_content)
    
    # 没有配置任何邮件服务
    return {
        'success': False,
        'message': '未配置邮件服务'
    }


def send_password_reset_email(to_email: str, reset_token: str, username: str = None) -> dict:
    """
    发送密码重置邮件
    
    Args:
        to_email: 收件人邮箱
        reset_token: 重置令牌
        username: 用户名（可选）
    
    Returns:
        {'success': bool, 'message': str}
    """
    # 构建重置链接
    domain = os.getenv('COZE_PROJECT_DOMAIN_DEFAULT', 'localhost:5000')
    protocol = 'https' if 'coze.site' in domain else 'http'
    reset_url = f'{protocol}://{domain}?reset_token={reset_token}'
    
    app_name = '智能日程助手'
    
    html_content = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <style>
            body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; }}
            .container {{ max-width: 600px; margin: 0 auto; padding: 20px; }}
            .header {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }}
            .content {{ background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }}
            .button {{ display: inline-block; background: #667eea; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; margin: 20px 0; }}
            .footer {{ text-align: center; color: #999; font-size: 12px; margin-top: 20px; }}
            .warning {{ background: #fff3cd; border-left: 4px solid #ffc107; padding: 10px; margin: 20px 0; }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>{app_name}</h1>
                <p>密码重置请求</p>
            </div>
            <div class="content">
                <p>您好{f'，{username}' if username else ''}！</p>
                <p>我们收到了重置您账户密码的请求。请点击下方按钮重置密码：</p>
                
                <div style="text-align: center;">
                    <a href="{reset_url}" class="button">重置密码</a>
                </div>
                
                <p>或复制以下链接到浏览器：</p>
                <p style="word-break: break-all; background: #eee; padding: 10px; border-radius: 5px;">{reset_url}</p>
                
                <div class="warning">
                    <strong>[安全提示] </strong>
                    <ul>
                        <li>此链接将在 <strong>1小时</strong> 后失效</li>
                        <li>如果您没有请求重置密码，请忽略此邮件</li>
                        <li>请勿将此链接分享给他人</li>
                    </ul>
                </div>
            </div>
            <div class="footer">
                <p>此邮件由系统自动发送，请勿回复</p>
                <p>© {datetime.now().year} {app_name}</p>
            </div>
        </div>
    </body>
    </html>
    """
    
    text_content = f"""
您好{f'，{username}' if username else ''}！

我们收到了重置您账户密码的请求。

请访问以下链接重置密码：
{reset_url}

此链接将在1小时后失效。
如果您没有请求重置密码，请忽略此邮件。

© {datetime.now().year} {app_name}
    """
    
    subject = f'【{app_name}】重置您的密码'
    
    return send_email(to_email, subject, html_content, text_content)


def get_email_config_status() -> dict:
    """
    获取邮件服务配置状态
    
    Returns:
        {
            'configured': bool,
            'method': str,  # 'resend' | 'smtp' | None
            'from_email': str
        }
    """
    if os.getenv('RESEND_API_KEY'):
        return {
            'configured': True,
            'method': 'resend',
            'from_email': os.getenv('SMTP_FROM', 'onboarding@resend.dev')
        }
    
    if os.getenv('SMTP_SERVER') and os.getenv('SMTP_USERNAME') and os.getenv('SMTP_PASSWORD'):
        return {
            'configured': True,
            'method': 'smtp',
            'from_email': os.getenv('SMTP_FROM', os.getenv('SMTP_USERNAME'))
        }
    
    return {
        'configured': False,
        'method': None,
        'from_email': None
    }
