"""
多轮对话状态机模块
提供对话状态管理和状态转移功能
"""

from enum import Enum
from typing import Any, Callable, Dict, List, Optional
from dataclasses import dataclass, field

from utils.dialogue_history import DialogueSession, Message, MessageType, IntentType
from utils.intent_recognition import UserIntent, ExtractedEntity


class DialogueState(Enum):
    """对话状态枚举"""
    IDLE = "idle"                           # 空闲状态
    AWAITING_TASK_DETAILS = "awaiting_task_details"    # 等待任务详情
    AWAITING_CONFIRMATION = "awaiting_confirmation"    # 等待确认
    CLARIFYING = "clarifying"               # 澄清状态
    COLLECTING_DEPENDENCIES = "collecting_dependencies" # 收集依赖
    EXECUTING_ACTION = "executing_action"   # 执行中
    ERROR_RECOVERY = "error_recovery"       # 错误恢复
    FOLLOW_UP = "follow_up"                 # 跟进状态


class StateTransition:
    """状态转移"""
    
    def __init__(self, 
                 from_state: DialogueState,
                 to_state: DialogueState,
                 condition: Callable,
                 action: Callable = None):
        self.from_state = from_state
        self.to_state = to_state
        self.condition = condition
        self.action = action


@dataclass
class StateContext:
    """状态上下文"""
    current_intent: Optional[UserIntent] = None
    pending_action: Optional[str] = None
    collected_data: Dict[str, Any] = field(default_factory=dict)
    missing_fields: List[str] = field(default_factory=list)
    last_error: Optional[str] = None
    retry_count: int = 0


class DialogueStateMachine:
    """多轮对话状态机"""
    
    def __init__(self):
        self.state = DialogueState.IDLE
        self.context = StateContext()
        self.transitions: Dict[DialogueState, List[StateTransition]] = {}
        self.state_handlers: Dict[DialogueState, Callable] = {}
        self._setup_transitions()
        self._setup_handlers()
    
    def _setup_transitions(self):
        """设置状态转移规则"""
        
        # IDLE 状态转移
        self.transitions[DialogueState.IDLE] = [
            StateTransition(
                DialogueState.IDLE,
                DialogueState.AWAITING_TASK_DETAILS,
                lambda intent, ctx: intent == UserIntent.CREATE_TASK and not ctx.collected_data.get('title')
            ),
            StateTransition(
                DialogueState.IDLE,
                DialogueState.AWAITING_CONFIRMATION,
                lambda intent, ctx: intent == UserIntent.DELETE_TASK and ctx.collected_data.get('task_id')
            ),
            StateTransition(
                DialogueState.IDLE,
                DialogueState.CLARIFYING,
                lambda intent, ctx: intent == UserIntent.UNKNOWN
            ),
            StateTransition(
                DialogueState.IDLE,
                DialogueState.COLLECTING_DEPENDENCIES,
                lambda intent, ctx: intent == UserIntent.ADD_DEPENDENCY
            ),
        ]
        
        # AWAITING_TASK_DETAILS 状态转移
        self.transitions[DialogueState.AWAITING_TASK_DETAILS] = [
            StateTransition(
                DialogueState.AWAITING_TASK_DETAILS,
                DialogueState.AWAITING_CONFIRMATION,
                lambda intent, ctx: self._has_required_fields(ctx, ['title'])
            ),
            StateTransition(
                DialogueState.AWAITING_TASK_DETAILS,
                DialogueState.IDLE,
                lambda intent, ctx: intent == UserIntent.CANCEL
            ),
        ]
        
        # AWAITING_CONFIRMATION 状态转移
        self.transitions[DialogueState.AWAITING_CONFIRMATION] = [
            StateTransition(
                DialogueState.AWAITING_CONFIRMATION,
                DialogueState.EXECUTING_ACTION,
                lambda intent, ctx: intent == UserIntent.CONFIRM
            ),
            StateTransition(
                DialogueState.AWAITING_CONFIRMATION,
                DialogueState.IDLE,
                lambda intent, ctx: intent == UserIntent.CANCEL
            ),
            StateTransition(
                DialogueState.AWAITING_CONFIRMATION,
                DialogueState.CLARIFYING,
                lambda intent, ctx: intent == UserIntent.CLARIFY
            ),
        ]
        
        # CLARIFYING 状态转移
        self.transitions[DialogueState.CLARIFYING] = [
            StateTransition(
                DialogueState.CLARIFYING,
                DialogueState.IDLE,
                lambda intent, ctx: True  # 澄清后返回空闲
            ),
        ]
        
        # EXECUTING_ACTION 状态转移
        self.transitions[DialogueState.EXECUTING_ACTION] = [
            StateTransition(
                DialogueState.EXECUTING_ACTION,
                DialogueState.FOLLOW_UP,
                lambda intent, ctx: ctx.last_error is None
            ),
            StateTransition(
                DialogueState.EXECUTING_ACTION,
                DialogueState.ERROR_RECOVERY,
                lambda intent, ctx: ctx.last_error is not None
            ),
        ]
        
        # ERROR_RECOVERY 状态转移
        self.transitions[DialogueState.ERROR_RECOVERY] = [
            StateTransition(
                DialogueState.ERROR_RECOVERY,
                DialogueState.EXECUTING_ACTION,
                lambda intent, ctx: ctx.retry_count < 3 and intent == UserIntent.CONFIRM
            ),
            StateTransition(
                DialogueState.ERROR_RECOVERY,
                DialogueState.IDLE,
                lambda intent, ctx: ctx.retry_count >= 3 or intent == UserIntent.CANCEL
            ),
        ]
    
    def _setup_handlers(self):
        """设置状态处理器"""
        self.state_handlers = {
            DialogueState.IDLE: self._handle_idle,
            DialogueState.AWAITING_TASK_DETAILS: self._handle_awaiting_details,
            DialogueState.AWAITING_CONFIRMATION: self._handle_awaiting_confirmation,
            DialogueState.CLARIFYING: self._handle_clarifying,
            DialogueState.COLLECTING_DEPENDENCIES: self._handle_collecting_dependencies,
            DialogueState.EXECUTING_ACTION: self._handle_executing,
            DialogueState.ERROR_RECOVERY: self._handle_error_recovery,
            DialogueState.FOLLOW_UP: self._handle_follow_up,
        }
    
    def process(self, user_input: str, 
               intent: UserIntent,
               entities: List[ExtractedEntity],
               session: DialogueSession) -> Dict[str, Any]:
        """处理用户输入"""
        
        # 更新上下文
        self._update_context(user_input, intent, entities)
        
        # 尝试状态转移
        new_state = self._try_transition(intent)
        if new_state:
            self.state = new_state
        
        # 执行当前状态处理
        handler = self.state_handlers.get(self.state)
        if handler:
            response = handler(user_input, intent, entities, session)
        else:
            response = {"message": "未知状态", "state": self.state.value}
        
        response['current_state'] = self.state.value
        return response
    
    def _try_transition(self, intent: UserIntent) -> Optional[DialogueState]:
        """尝试状态转移"""
        transitions = self.transitions.get(self.state, [])
        
        for transition in transitions:
            if transition.condition(intent, self.context):
                if transition.action:
                    transition.action()
                return transition.to_state
        
        return None
    
    def _update_context(self, text: str, intent: UserIntent, entities: List[ExtractedEntity]):
        """更新状态上下文"""
        self.context.current_intent = intent
        
        # 提取实体到 collected_data
        for entity in entities:
            self.context.collected_data[entity.type] = entity.value
        
        # 更新缺失字段
        self._update_missing_fields()
    
    def _update_missing_fields(self):
        """更新缺失字段列表"""
        required_fields_map = {
            UserIntent.CREATE_TASK: ['title'],
            UserIntent.UPDATE_TASK: ['task_id'],
            UserIntent.DELETE_TASK: ['task_id'],
        }
        
        intent = self.context.current_intent
        if intent in required_fields_map:
            required = required_fields_map[intent]
            self.context.missing_fields = [
                f for f in required 
                if f not in self.context.collected_data
            ]
    
    def _has_required_fields(self, ctx: StateContext, fields: List[str]) -> bool:
        """检查是否有所有必需字段"""
        return all(f in ctx.collected_data for f in fields)
    
    # ========== 状态处理器 ==========
    
    def _handle_idle(self, text: str, intent: UserIntent, 
                    entities: List[ExtractedEntity],
                    session: DialogueSession) -> Dict:
        """处理空闲状态"""
        if intent == UserIntent.GREETING:
            return {"message": "你好！有什么我可以帮你的吗？"}
        
        elif intent == UserIntent.CREATE_TASK:
            if 'title' in self.context.collected_data:
                return {"message": f"确认创建任务：{self.context.collected_data['title']}？"}
            else:
                return {"message": "请告诉我任务标题是什么？"}
        
        elif intent == UserIntent.LIST_TASKS:
            return {"message": "正在为您获取任务列表...", "action": "list_tasks"}
        
        elif intent == UserIntent.QUERY_TASK:
            return {"message": "请告诉我您想查询哪个任务？"}
        
        elif intent == UserIntent.SORT_TASKS:
            return {"message": "正在为您智能排序任务...", "action": "sort_tasks"}
        
        elif intent == UserIntent.ADD_DEPENDENCY:
            return {"message": "请指定任务之间的依赖关系"}
        
        elif intent == UserIntent.GENERAL_QUESTION:
            return {"message": "请问您想了解什么？"}
        
        elif intent == UserIntent.CHITCHAT:
            return {"message": "不客气！有什么其他需要帮忙的吗？"}
        
        else:
            return {"message": "我不太明白您的意思，能再详细说明一下吗？"}
    
    def _handle_awaiting_details(self, text: str, intent: UserIntent,
                                entities: List[ExtractedEntity],
                                session: DialogueSession) -> Dict:
        """处理等待详情状态"""
        if self.context.missing_fields:
            field = self.context.missing_fields[0]
            prompts = {
                'title': '请提供任务标题',
                'deadline': '请设置截止时间',
                'priority': '请设置优先级（高/中/低）'
            }
            return {"message": prompts.get(field, f'请提供{field}')}
        
        # 收集完成，准备确认
        summary = self._generate_task_summary()
        return {"message": f"请确认创建以下任务：\n{summary}"}
    
    def _handle_awaiting_confirmation(self, text: str, intent: UserIntent,
                                     entities: List[ExtractedEntity],
                                     session: DialogueSession) -> Dict:
        """处理等待确认状态"""
        return {"message": "等待用户确认..."}
    
    def _handle_clarifying(self, text: str, intent: UserIntent,
                          entities: List[ExtractedEntity],
                          session: DialogueSession) -> Dict:
        """处理澄清状态"""
        # 基于历史上下文提供解释
        recent_messages = session.get_recent_context(3)
        context_summary = self._summarize_context(recent_messages)
        
        return {
            "message": f"根据我们的对话：{context_summary}\n\n您是想...？",
            "suggestions": ["创建任务", "查看任务", "排序任务"]
        }
    
    def _handle_collecting_dependencies(self, text: str, intent: UserIntent,
                                       entities: List[ExtractedEntity],
                                       session: DialogueSession) -> Dict:
        """处理收集依赖状态"""
        return {"message": "请指定任务之间的依赖关系"}
    
    def _handle_executing(self, text: str, intent: UserIntent,
                         entities: List[ExtractedEntity],
                         session: DialogueSession) -> Dict:
        """处理执行状态"""
        return {"message": "正在执行操作..."}
    
    def _handle_error_recovery(self, text: str, intent: UserIntent,
                              entities: List[ExtractedEntity],
                              session: DialogueSession) -> Dict:
        """处理错误恢复"""
        error_msg = self.context.last_error
        return {
            "message": f"执行出错：{error_msg}\n是否重试？",
            "retry_count": self.context.retry_count
        }
    
    def _handle_follow_up(self, text: str, intent: UserIntent,
                         entities: List[ExtractedEntity],
                         session: DialogueSession) -> Dict:
        """处理跟进状态"""
        return {
            "message": "操作已完成！还需要其他帮助吗？",
            "suggestions": ["查看结果", "继续创建", "返回主菜单"]
        }
    
    def _generate_task_summary(self) -> str:
        """生成任务摘要"""
        data = self.context.collected_data
        lines = [f"标题：{data.get('title', '未指定')}"]
        
        if 'deadline' in data:
            lines.append(f"截止时间：{data['deadline']}")
        if 'priority' in data:
            lines.append(f"优先级：{data['priority']}")
        if 'time_duration' in data:
            lines.append(f"预估耗时：{data['time_duration']}")
        
        return '\n'.join(lines)
    
    def _summarize_context(self, messages: List[Message]) -> str:
        """总结上下文"""
        if not messages:
            return "暂无对话历史"
        
        # 提取关键信息
        topics = []
        for msg in messages:
            if msg.intent:
                topics.append(msg.intent.value)
        
        return f"我们刚才讨论了：{', '.join(set(topics))}" if topics else "暂无对话历史"
    
    def reset(self):
        """重置状态机"""
        self.state = DialogueState.IDLE
        self.context = StateContext()


# 导出公共接口
__all__ = [
    'DialogueState',
    'StateTransition',
    'StateContext',
    'DialogueStateMachine'
]
