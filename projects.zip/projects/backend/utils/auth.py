"""
统一认证模块
整合 JWT Token 生成、验证和装饰器

使用方式：
    from utils.auth import AuthManager, require_auth, generate_token, verify_token
    
    # 生成Token
    token = AuthManager.generate_token(user_id)
    
    # 验证Token
    user_id = AuthManager.verify_token(token)
    
    # 使用装饰器
    @require_auth
    def protected_route(user):
        return {'user_id': user.id}
"""

import jwt
import logging
from functools import wraps
from flask import request, jsonify, current_app
from datetime import datetime, timedelta

logger = logging.getLogger('auth')


class AuthManager:
    """
    统一认证管理器
    
    功能：
    - JWT Token 生成与验证
    - 统一认证装饰器
    - 认证状态管理
    """
    
    # 默认Token过期时间（7天）
    DEFAULT_EXPIRES_HOURS = 24 * 7
    
    # 支持的算法
    ALGORITHM = 'HS256'
    
    @staticmethod
    def generate_token(user_id, expires_hours=None):
        """
        生成JWT Token
        
        Args:
            user_id: 用户ID
            expires_hours: 过期时间（小时），默认7天
            
        Returns:
            JWT Token字符串
        """
        if expires_hours is None:
            expires_hours = AuthManager.DEFAULT_EXPIRES_HOURS
        
        payload = {
            'user_id': user_id,
            'exp': datetime.utcnow() + timedelta(hours=expires_hours),
            'iat': datetime.utcnow(),
            'type': 'access'
        }
        
        token = jwt.encode(
            payload,
            current_app.config['SECRET_KEY'],
            algorithm=AuthManager.ALGORITHM
        )
        
        return token
    
    @staticmethod
    def verify_token(token):
        """
        验证JWT Token
        
        Args:
            token: JWT Token字符串
            
        Returns:
            用户ID（如果验证成功），否则返回None
        """
        if not token:
            return None
        
        try:
            payload = jwt.decode(
                token,
                current_app.config['SECRET_KEY'],
                algorithms=[AuthManager.ALGORITHM]
            )
            
            # 验证token类型
            if payload.get('type') != 'access':
                return None
            
            return payload.get('user_id')
        
        except jwt.ExpiredSignatureError:
            logger.debug("Token已过期")
            return None
        except jwt.InvalidTokenError as e:
            logger.debug(f"无效Token: {e}")
            return None
        except Exception as e:
            logger.error(f"Token验证异常: {e}")
            return None
    
    @staticmethod
    def refresh_token(token, expires_hours=None):
        """
        刷新Token（如果当前Token有效）
        
        Args:
            token: 当前有效的Token
            expires_hours: 新Token的过期时间
            
        Returns:
            新的Token，如果原Token无效则返回None
        """
        user_id = AuthManager.verify_token(token)
        if not user_id:
            return None
        
        return AuthManager.generate_token(user_id, expires_hours)
    
    @staticmethod
    def extract_token_from_request():
        """
        从请求中提取Token
        
        支持方式：
        1. Authorization: Bearer <token>
        2. httpOnly Cookie (auth_token) - 推荐，更安全
        3. 查询参数 ?token=<token>
        
        Returns:
            Token字符串或None
        """
        # 优先从Authorization头获取
        auth_header = request.headers.get('Authorization', '')
        if auth_header.startswith('Bearer '):
            return auth_header[7:]
        
        # 从httpOnly Cookie获取（更安全的方式）
        cookie_token = request.cookies.get('auth_token')
        if cookie_token:
            return cookie_token
        
        # 从查询参数获取（可选）
        token = request.args.get('token')
        if token:
            return token
        
        return None
    
    @staticmethod
    def get_current_user_id():
        """
        获取当前请求的用户ID
        
        优先级：
        1. JWT Token（Authorization: Bearer <token>）
        2. X-User-ID 兼容模式（将逐步废弃）
        
        Returns:
            (user_id, auth_type) 元组
            - user_id: 用户ID或None
            - auth_type: 'jwt' | 'compat' | None
        """
        # 优先从JWT Token获取
        token = AuthManager.extract_token_from_request()
        if token:
            user_id = AuthManager.verify_token(token)
            if user_id:
                return user_id, 'jwt'
        
        # 兼容模式：从X-User-ID获取
        user_id = request.headers.get('X-User-ID')
        if user_id:
            return user_id, 'compat'
        
        return None, None
    
    @staticmethod
    def require_auth(f=None, allow_compat=True):
        """
        统一认证装饰器
        
        Args:
            f: 被装饰的函数
            allow_compat: 是否允许X-User-ID兼容模式
            
        使用方式：
            @AuthManager.require_auth
            def protected_route(user):
                return {'user_id': user.id}
                
            # 或禁止兼容模式
            @AuthManager.require_auth(allow_compat=False)
            def strict_route(user):
                return {'user_id': user.id}
        """
        def decorator(func):
            @wraps(func)
            def decorated_function(*args, **kwargs):
                user_id, auth_type = AuthManager.get_current_user_id()
                
                if not user_id:
                    return jsonify({
                        "success": False,
                        "message": "缺少认证信息，请登录或刷新页面重试",
                        "error_code": "AUTH_REQUIRED"
                    }), 401
                
                # 如果禁止兼容模式，检查认证类型
                if not allow_compat and auth_type == 'compat':
                    return jsonify({
                        "success": False,
                        "message": "请使用JWT Token认证",
                        "error_code": "JWT_REQUIRED"
                    }), 401
                
                # 记录兼容模式使用情况
                if auth_type == 'compat':
                    logger.warning(
                        f"使用了兼容模式认证: X-User-ID, user_id={user_id}. "
                        "建议迁移到JWT Token认证。"
                    )
                
                # 获取或创建用户
                from models.task import User
                from extensions import db
                
                user = User.query.filter_by(id=user_id).first()
                
                if not user:
                    # 自动创建用户
                    try:
                        user = User(id=user_id)
                        db.session.add(user)
                        db.session.commit()
                    except Exception as e:
                        db.session.rollback()
                        # 重试获取
                        user = User.query.filter_by(id=user_id).first()
                        if not user:
                            return jsonify({
                                "success": False,
                                "message": "用户创建失败",
                                "error_code": "USER_CREATION_FAILED"
                            }), 500
                
                # 更新最后访问时间
                user.last_visit = datetime.now()
                try:
                    db.session.commit()
                except:
                    db.session.rollback()
                
                # 将user对象传递给被装饰的函数
                return func(user=user, *args, **kwargs)
            
            return decorated_function
        
        if f is not None:
            return decorator(f)
        return decorator


# 导出便捷函数
generate_token = AuthManager.generate_token
verify_token = AuthManager.verify_token
require_auth = AuthManager.require_auth
refresh_token = AuthManager.refresh_token


def create_token_response(user, expires_hours=None):
    """
    创建包含Token的响应
    
    Args:
        user: User对象
        expires_hours: Token过期时间
        
    Returns:
        包含token和user信息的字典
    """
    token = generate_token(user.id, expires_hours)
    
    return {
        'success': True,
        'token': token,
        'user': user.to_dict(include_sensitive=True)
    }
