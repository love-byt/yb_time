"""
智能时间解析工具
从文本中提取时间信息，支持多种自然语言格式
"""

import re
from datetime import datetime, timedelta
from typing import Optional, Tuple
from dateutil import parser as date_parser


class SmartTimeParser:
    """智能时间解析器"""
    
    # 时间关键词模式（中文）
    TIME_PATTERNS = {
        # 相对时间 - 今天/明天/后天
        r'今天(\d{1,2})[点时](\d{1,2})分?': 0,
        r'今天(\d{1,2})[点时]': 0,
        r'明天(\d{1,2})[点时](\d{1,2})分?': 1,
        r'明天(\d{1,2})[点时]': 1,
        r'后天(\d{1,2})[点时](\d{1,2})分?': 2,
        r'后天(\d{1,2})[点时]': 2,
        
        # 具体日期 - X月X日
        r'(\d{1,2})月(\d{1,2})[日号](\d{1,2})[点时](\d{1,2})分?': 'month_day_time',
        r'(\d{1,2})月(\d{1,2})[日号](\d{1,2})[点时]': 'month_day_hour',
        r'(\d{1,2})月(\d{1,2})[日号]': 'month_day',
        
        # 时间段 - 早上/下午/晚上
        r'早上?(\d{1,2})[点时](\d{1,2})分?': 'morning',
        r'早上?(\d{1,2})[点时]': 'morning',
        r'上午(\d{1,2})[点时](\d{1,2})分?': 'morning',
        r'上午(\d{1,2})[点时]': 'morning',
        r'下午(\d{1,2})[点时](\d{1,2})分?': 'afternoon',
        r'下午(\d{1,2})[点时]': 'afternoon',
        r'晚上?(\d{1,2})[点时](\d{1,2})分?': 'evening',
        r'晚上?(\d{1,2})[点时]': 'evening',
        
        # 相对时长 - X小时后/X天后
        r'(\d+)小时后': 'hours_later',
        r'(\d+)天后': 'days_later',
        r'(\d+)周后': 'weeks_later',
        
        # 周几
        r'下?周[一二三四五六七日天](\d{1,2})[点时](\d{1,2})分?': 'weekday_time',
        r'下?周[一二三四五六七日天](\d{1,2})[点时]': 'weekday_hour',
        r'下?周[一二三四五六七日天]': 'weekday',
        
        # 截止时间关键词
        r'截止[时间]?:?\s*(\d{1,2})月(\d{1,2})[日号](\d{1,2})[点时](\d{1,2})分?': 'deadline_full',
        r'截止[时间]?:?\s*(\d{1,2})月(\d{1,2})[日号]': 'deadline_date',
        r'截止[时间]?:?\s*(\d{4})[年\-/](\d{1,2})[月\-/](\d{1,2})[日号]?': 'deadline_ymd',
        
        # 标准格式
        r'(\d{4})[年\-/](\d{1,2})[月\-/](\d{1,2})[日号]?\s*(\d{1,2})[点时:](\d{1,2})分?': 'standard_full',
        r'(\d{4})[年\-/](\d{1,2})[月\-/](\d{1,2})[日号]?': 'standard_date',
    }
    
    # 时间段映射
    TIME_PERIODS = {
        'morning': (6, 12),      # 早上 6-12 点
        'afternoon': (13, 18),   # 下午 1-6 点
        'evening': (18, 23),     # 晚上 6-11 点
    }
    
    # 周几映射
    WEEKDAY_MAP = {
        '一': 0, '二': 1, '三': 2, '四': 3, 
        '五': 4, '六': 5, '日': 6, '天': 6
    }
    
    @classmethod
    def extract_time_from_text(cls, text: str, base_time: Optional[datetime] = None) -> Tuple[Optional[datetime], Optional[datetime]]:
        """
        从文本中提取开始时间和结束时间

        Args:
            text: 待解析的文本（标题或描述）
            base_time: 基准时间，默认为当前时间

        Returns:
            (start_time, end_time) 元组
        """
        if not text:
            return None, None

        if base_time is None:
            base_time = datetime.now()

        start_time = None
        end_time = None

        # 尝试提取截止时间
        end_time = cls._extract_deadline(text, base_time)

        # 尝试提取开始时间
        # 注意：如果end_time是通过"X点前"等截止时间模式提取的，不应该再提取相同的start_time
        # 因为"X点前"是截止时间，不是开始时间
        deadline_patterns = ['点前', '之前', '前完成', '截止', 'deadline']
        has_deadline_keyword = any(keyword in text for keyword in deadline_patterns)

        if not has_deadline_keyword or end_time is None:
            start_time = cls._extract_start_time(text, base_time)

        return start_time, end_time
    
    @classmethod
    def _extract_deadline(cls, text: str, base_time: datetime) -> Optional[datetime]:
        """提取截止时间"""
        # 截止时间关键词
        deadline_patterns = [
            # 今天 X点前（含时间段，支持"点前"和"点之前"）- 优先匹配
            (r'今天晚[上间]?\s*(\d{1,2})\s*[点时](?:之)?前',
             lambda m: cls._parse_time_today(base_time,
                                            int(m.group(1)) + 12 if int(m.group(1)) <= 12 else int(m.group(1)), 0)),
            (r'今天下午\s*(\d{1,2})\s*[点时](?:之)?前',
             lambda m: cls._parse_time_today(base_time,
                                            int(m.group(1)) + 12 if int(m.group(1)) <= 12 else int(m.group(1)), 0)),
            (r'今天早[上晨]\s*(\d{1,2})\s*[点时](?:之)?前',
             lambda m: cls._parse_time_today(base_time, int(m.group(1)), 0)),
            (r'今天上午\s*(\d{1,2})\s*[点时](?:之)?前',
             lambda m: cls._parse_time_today(base_time, int(m.group(1)), 0)),
            (r'今天\s*(\d{1,2})\s*[点时](?:之)?前',
             lambda m: cls._parse_time_today(base_time, int(m.group(1)), 0)),
            # 明天 X点前（含时间段，支持"点前"和"点之前"）- 优先匹配
            (r'明天晚[上间]?\s*(\d{1,2})\s*[点时](?:之)?前',
             lambda m: cls._parse_time_tomorrow(base_time,
                                               int(m.group(1)) + 12 if int(m.group(1)) <= 12 else int(m.group(1)), 0)),
            (r'明天下午\s*(\d{1,2})\s*[点时](?:之)?前',
             lambda m: cls._parse_time_tomorrow(base_time,
                                               int(m.group(1)) + 12 if int(m.group(1)) <= 12 else int(m.group(1)), 0)),
            (r'明天早[上晨]\s*(\d{1,2})\s*[点时](?:之)?前',
             lambda m: cls._parse_time_tomorrow(base_time, int(m.group(1)), 0)),
            (r'明天上午\s*(\d{1,2})\s*[点时](?:之)?前',
             lambda m: cls._parse_time_tomorrow(base_time, int(m.group(1)), 0)),
            (r'明天\s*(\d{1,2})\s*[点时](?:之)?前',
             lambda m: cls._parse_time_tomorrow(base_time, int(m.group(1)), 0)),
            # 后天 X点前（含时间段，支持"点前"和"点之前"）- 优先匹配
            (r'后天晚[上间]?\s*(\d{1,2})\s*[点时](?:之)?前',
             lambda m: cls._parse_time_after_tomorrow(base_time,
                                                     int(m.group(1)) + 12 if int(m.group(1)) <= 12 else int(m.group(1)), 0)),
            (r'后天下午\s*(\d{1,2})\s*[点时](?:之)?前',
             lambda m: cls._parse_time_after_tomorrow(base_time,
                                                     int(m.group(1)) + 12 if int(m.group(1)) <= 12 else int(m.group(1)), 0)),
            (r'后天早[上晨]\s*(\d{1,2})\s*[点时](?:之)?前',
             lambda m: cls._parse_time_after_tomorrow(base_time, int(m.group(1)), 0)),
            (r'后天上午\s*(\d{1,2})\s*[点时](?:之)?前',
             lambda m: cls._parse_time_after_tomorrow(base_time, int(m.group(1)), 0)),
            (r'后天\s*(\d{1,2})\s*[点时](?:之)?前',
             lambda m: cls._parse_time_after_tomorrow(base_time, int(m.group(1)), 0)),
            # 无日期前缀的截止时间（智能判断今天/明天/后天）- 兜底匹配
            (r'晚[上间]\s*(\d{1,2})\s*[点时](?:之)?前',
             lambda m: cls._parse_time_smart(base_time, text, int(m.group(1)) + 12 if int(m.group(1)) <= 12 else int(m.group(1)), 0)),
            (r'下午\s*(\d{1,2})\s*[点时](?:之)?前',
             lambda m: cls._parse_time_smart(base_time, text, int(m.group(1)) + 12 if int(m.group(1)) <= 12 else int(m.group(1)), 0)),
            (r'早[上晨]\s*(\d{1,2})\s*[点时](?:之)?前',
             lambda m: cls._parse_time_smart(base_time, text, int(m.group(1)), 0)),
            (r'上午\s*(\d{1,2})\s*[点时](?:之)?前',
             lambda m: cls._parse_time_smart(base_time, text, int(m.group(1)), 0)),
            (r'(\d{1,2})\s*[点时](?:之)?前',
             lambda m: cls._parse_time_smart(base_time, text, int(m.group(1)), 0)),
            # 截止：X月X日X点X分
            (r'截止[时间]?:?\s*(\d{1,2})月(\d{1,2})[日号](?:\s*(\d{1,2})[点时](?:\s*(\d{1,2})分?)?)?', 
             lambda m: cls._parse_month_day(base_time, int(m.group(1)), int(m.group(2)), 
                                           int(m.group(3)) if m.group(3) else 23,
                                           int(m.group(4)) if m.group(4) else 59)),
            # 截止：YYYY-MM-DD
            (r'截止[时间]?:?\s*(\d{4})[年\-/](\d{1,2})[月\-/](\d{1,2})[日号]?',
             lambda m: datetime(int(m.group(1)), int(m.group(2)), int(m.group(3)), 23, 59)),
            # X月X日之前
            (r'(\d{1,2})月(\d{1,2})[日号][之前以]前',
             lambda m: cls._parse_month_day(base_time, int(m.group(1)), int(m.group(2)), 23, 59)),
            # X天后截止
            (r'(\d+)天后(?:截止|完成)',
             lambda m: base_time + timedelta(days=int(m.group(1)))),
            # 本周X
            (r'本周[一二三四五六七日天]',
             lambda m: cls._get_next_weekday(base_time, cls.WEEKDAY_MAP[m.group(0)[-1]], 23, 59)),
            # 下周X
            (r'下周[一二三四五六七日天]',
             lambda m: cls._get_next_weekday(base_time + timedelta(days=7), 
                                            cls.WEEKDAY_MAP[m.group(0)[-1]], 23, 59)),
        ]
        
        for pattern, parser in deadline_patterns:
            match = re.search(pattern, text)
            if match:
                try:
                    return parser(match)
                except Exception:
                    continue
        
        return None
    
    @classmethod
    def _extract_start_time(cls, text: str, base_time: datetime) -> Optional[datetime]:
        """提取开始时间"""
        # 开始时间关键词（注意顺序：组合模式优先于单模式）
        start_patterns = [
            # 明天下午/晚上X点（组合模式）
            (r'明天下午(\d{1,2})[点时](?:\s*(\d{1,2})分?)?',
             lambda m: cls._parse_time_tomorrow(base_time, 
                                               int(m.group(1)) + 12 if int(m.group(1)) <= 12 else int(m.group(1)), 
                                               int(m.group(2)) if m.group(2) else 0)),
            (r'明天晚[上间]?(\d{1,2})[点时](?:\s*(\d{1,2})分?)?',
             lambda m: cls._parse_time_tomorrow(base_time, 
                                               int(m.group(1)) + 12 if int(m.group(1)) <= 12 else int(m.group(1)), 
                                               int(m.group(2)) if m.group(2) else 0)),
            (r'明天早[上晨](\d{1,2})[点时](?:\s*(\d{1,2})分?)?',
             lambda m: cls._parse_time_tomorrow(base_time, int(m.group(1)), 
                                               int(m.group(2)) if m.group(2) else 0)),
            (r'明天上午(\d{1,2})[点时](?:\s*(\d{1,2})分?)?',
             lambda m: cls._parse_time_tomorrow(base_time, int(m.group(1)), 
                                               int(m.group(2)) if m.group(2) else 0)),
            # 后天下午/晚上X点（组合模式）
            (r'后天下午(\d{1,2})[点时](?:\s*(\d{1,2})分?)?',
             lambda m: cls._parse_time_after_tomorrow(base_time, 
                                               int(m.group(1)) + 12 if int(m.group(1)) <= 12 else int(m.group(1)), 
                                               int(m.group(2)) if m.group(2) else 0)),
            (r'后天晚[上间]?(\d{1,2})[点时](?:\s*(\d{1,2})分?)?',
             lambda m: cls._parse_time_after_tomorrow(base_time, 
                                               int(m.group(1)) + 12 if int(m.group(1)) <= 12 else int(m.group(1)), 
                                               int(m.group(2)) if m.group(2) else 0)),
            (r'后天早[上晨](\d{1,2})[点时](?:\s*(\d{1,2})分?)?',
             lambda m: cls._parse_time_after_tomorrow(base_time, int(m.group(1)), 
                                               int(m.group(2)) if m.group(2) else 0)),
            (r'后天上午(\d{1,2})[点时](?:\s*(\d{1,2})分?)?',
             lambda m: cls._parse_time_after_tomorrow(base_time, int(m.group(1)), 
                                               int(m.group(2)) if m.group(2) else 0)),
            # 今天下午/晚上X点（组合模式）
            (r'今天下午(\d{1,2})[点时](?:\s*(\d{1,2})分?)?',
             lambda m: cls._parse_time_today(base_time, 
                                            int(m.group(1)) + 12 if int(m.group(1)) <= 12 else int(m.group(1)), 
                                            int(m.group(2)) if m.group(2) else 0)),
            (r'今天晚[上间]?(\d{1,2})[点时](?:\s*(\d{1,2})分?)?',
             lambda m: cls._parse_time_today(base_time, 
                                            int(m.group(1)) + 12 if int(m.group(1)) <= 12 else int(m.group(1)), 
                                            int(m.group(2)) if m.group(2) else 0)),
            (r'今天早[上晨](\d{1,2})[点时](?:\s*(\d{1,2})分?)?',
             lambda m: cls._parse_time_today(base_time, int(m.group(1)), 
                                            int(m.group(2)) if m.group(2) else 0)),
            (r'今天上午(\d{1,2})[点时](?:\s*(\d{1,2})分?)?',
             lambda m: cls._parse_time_today(base_time, int(m.group(1)), 
                                            int(m.group(2)) if m.group(2) else 0)),
            # 今天X点（单模式，放在组合模式之后）
            (r'今天(\d{1,2})[点时](?:\s*(\d{1,2})分?)?',
             lambda m: cls._parse_time_today(base_time, int(m.group(1)), 
                                            int(m.group(2)) if m.group(2) else 0)),
            # 明天X点（单模式，放在组合模式之后）
            (r'明天(\d{1,2})[点时](?:\s*(\d{1,2})分?)?',
             lambda m: cls._parse_time_tomorrow(base_time, int(m.group(1)), 
                                               int(m.group(2)) if m.group(2) else 0)),
            # X月X日X点
            (r'(\d{1,2})月(\d{1,2})[日号](?:\s*(\d{1,2})[点时](?:\s*(\d{1,2})分?)?)?',
             lambda m: cls._parse_month_day(base_time, int(m.group(1)), int(m.group(2)),
                                           int(m.group(3)) if m.group(3) else 9,
                                           int(m.group(4)) if m.group(4) else 0)),
            # 早上/上午X点
            (r'[早上午](\d{1,2})[点时](?:\s*(\d{1,2})分?)?',
             lambda m: cls._parse_time_today(base_time, int(m.group(1)), 
                                            int(m.group(2)) if m.group(2) else 0)),
            # 下午X点
            (r'下午(\d{1,2})[点时](?:\s*(\d{1,2})分?)?',
             lambda m: cls._parse_time_today(base_time, int(m.group(1)) + 12 if int(m.group(1)) <= 12 else int(m.group(1)), 
                                            int(m.group(2)) if m.group(2) else 0)),
            # 晚上X点
            (r'晚[上间]?(\d{1,2})[点时](?:\s*(\d{1,2})分?)?',
             lambda m: cls._parse_time_today(base_time, int(m.group(1)) + 12 if int(m.group(1)) <= 12 else int(m.group(1)), 
                                            int(m.group(2)) if m.group(2) else 0)),
            # X小时后
            (r'(\d+)小时[后之]后?',
             lambda m: base_time + timedelta(hours=int(m.group(1)))),
            # YYYY-MM-DD HH:MM
            (r'(\d{4})[年\-/](\d{1,2})[月\-/](\d{1,2})[日号]?\s*(\d{1,2})[点时:](\d{1,2})分?',
             lambda m: datetime(int(m.group(1)), int(m.group(2)), int(m.group(3)), 
                               int(m.group(4)), int(m.group(5)))),
            # ISO 格式
            (r'(\d{4})\-(\d{2})\-(\d{2})T(\d{2}):(\d{2})',
             lambda m: datetime(int(m.group(1)), int(m.group(2)), int(m.group(3)), 
                               int(m.group(4)), int(m.group(5)))),
        ]
        
        for pattern, parser in start_patterns:
            match = re.search(pattern, text)
            if match:
                try:
                    return parser(match)
                except Exception:
                    continue
        
        return None
    
    @classmethod
    def _parse_month_day(cls, base_time: datetime, month: int, day: int, 
                         hour: int = 9, minute: int = 0) -> datetime:
        """解析月日格式"""
        year = base_time.year
        
        # 如果月份小于当前月份，说明是明年
        if month < base_time.month:
            year += 1
        # 如果月份相同但日期已过，也是明年
        elif month == base_time.month and day < base_time.day:
            year += 1
        
        return datetime(year, month, day, hour, minute)
    
    @classmethod
    def _parse_time_today(cls, base_time: datetime, hour: int, minute: int = 0, force_today: bool = False) -> datetime:
        """
        解析今天的时间

        Args:
            base_time: 基准时间
            hour: 目标小时
            minute: 目标分钟
            force_today: 是否强制使用今天（即使时间已过）

        Returns:
            datetime对象
        """
        result = base_time.replace(hour=hour, minute=minute, second=0, microsecond=0)

        # 如果时间已过且不强制使用今天，设为明天
        if not force_today and result < base_time:
            result += timedelta(days=1)

        return result
    
    @classmethod
    def _parse_time_tomorrow(cls, base_time: datetime, hour: int, minute: int = 0) -> datetime:
        """解析明天的时间"""
        tomorrow = base_time + timedelta(days=1)
        return tomorrow.replace(hour=hour, minute=minute, second=0, microsecond=0)

    @classmethod
    def _parse_time_smart(cls, base_time: datetime, text: str, hour: int, minute: int = 0) -> datetime:
        """
        智能解析时间（自动判断今天/明天/后天）

        如果目标时间已经过了当前时间，则用明天；否则用今天
        但如果文本中明确包含"今天"、"明天"、"后天"，则强制使用对应日期

        Args:
            base_time: 基准时间
            text: 原始文本（用于检测日期关键词）
            hour: 目标小时
            minute: 目标分钟

        Returns:
            datetime对象
        """
        # 检测文本中的日期关键词
        if '后天' in text:
            # 强制使用后天
            return cls._parse_time_after_tomorrow(base_time, hour, minute)
        elif '明天' in text:
            # 强制使用明天
            return cls._parse_time_tomorrow(base_time, hour, minute)
        elif '今天' in text:
            # 强制使用今天（即使时间已过）
            return cls._parse_time_today(base_time, hour, minute, force_today=True)
        else:
            # 自动判断：如果目标时间已经过了当前时间，则用明天；否则用今天
            today_time = base_time.replace(hour=hour, minute=minute, second=0, microsecond=0)
            if today_time <= base_time:
                return cls._parse_time_tomorrow(base_time, hour, minute)
            return today_time

    @classmethod
    def _parse_time_after_tomorrow(cls, base_time: datetime, hour: int, minute: int = 0) -> datetime:
        """解析后天的时间"""
        after_tomorrow = base_time + timedelta(days=2)
        return after_tomorrow.replace(hour=hour, minute=minute, second=0, microsecond=0)
    
    @classmethod
    def _get_next_weekday(cls, base_time: datetime, weekday: int, 
                          hour: int = 9, minute: int = 0) -> datetime:
        """获取下一个指定周几"""
        days_ahead = weekday - base_time.weekday()
        if days_ahead <= 0:  # 如果今天已经过了或就是这一天
            days_ahead += 7
        result = base_time + timedelta(days=days_ahead)
        return result.replace(hour=hour, minute=minute, second=0, microsecond=0)
    
    @classmethod
    def smart_parse(cls, title: str, description: str = '', 
                    base_time: Optional[datetime] = None) -> Tuple[Optional[datetime], Optional[datetime]]:
        """
        智能解析任务的开始时间和结束时间
        
        Args:
            title: 任务标题
            description: 任务描述
            base_time: 基准时间，默认为当前时间
            
        Returns:
            (start_time, end_time) 元组
        """
        if base_time is None:
            base_time = datetime.now()
        
        # 合并标题和描述
        full_text = f"{title} {description}"
        
        # 提取时间
        start_time, end_time = cls.extract_time_from_text(full_text, base_time)
        
        # 如果没有提取到开始时间，使用当前时刻
        if start_time is None:
            start_time = base_time
        
        # 如果没有提取到结束时间，根据任务类型推断默认时长
        if end_time is None and start_time:
            end_time = cls._infer_default_end_time(title, description, start_time)
        
        return start_time, end_time
    
    @classmethod
    def _infer_default_end_time(cls, title: str, description: str, 
                                 start_time: datetime) -> Optional[datetime]:
        """
        根据任务内容推断默认结束时间
        
        Args:
            title: 任务标题
            description: 任务描述
            start_time: 开始时间
            
        Returns:
            推断的结束时间
        """
        full_text = f"{title} {description}".lower()
        
        # 根据关键词判断任务时长
        if any(keyword in full_text for keyword in ['会议', '约会', '见面', '面试', '通话', '电话']):
            # 短时任务：默认1小时
            return start_time + timedelta(hours=1)
        
        elif any(keyword in full_text for keyword in ['项目', '作业', '论文', '报告', '开发', '设计']):
            # 长时任务：默认3天后
            return start_time + timedelta(days=3)
        
        elif any(keyword in full_text for keyword in ['学习', '复习', '练习', '阅读', '看书']):
            # 学习任务：默认当天晚上
            return start_time.replace(hour=22, minute=0, second=0)
        
        elif any(keyword in full_text for keyword in ['健身', '运动', '跑步', '游泳', '瑜伽']):
            # 运动任务：默认1.5小时
            return start_time + timedelta(hours=1, minutes=30)
        
        elif any(keyword in full_text for keyword in ['购物', '买菜', '取快递', '缴费']):
            # 日常任务：默认2小时
            return start_time + timedelta(hours=2)
        
        else:
            # 默认：当天23:59
            return start_time.replace(hour=23, minute=59, second=0)


# 便捷函数
def smart_parse_time(title: str, description: str = '', 
                     base_time: Optional[datetime] = None) -> Tuple[Optional[datetime], Optional[datetime]]:
    """
    智能解析时间的便捷函数
    
    Args:
        title: 任务标题
        description: 任务描述
        base_time: 基准时间
        
    Returns:
        (start_time, end_time) 元组
    """
    return SmartTimeParser.smart_parse(title, description, base_time)
