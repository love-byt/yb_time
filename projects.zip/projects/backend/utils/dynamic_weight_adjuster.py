"""
动态权重调整器
根据用户执行反馈自动调整AI排序权重
"""
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime, timedelta
import json
import logging

logger = logging.getLogger(__name__)


@dataclass
class WeightAdjustment:
    """权重调整记录"""
    dimension: str  # 维度名称
    old_value: float
    new_value: float
    reason: str
    confidence: float  # 调整置信度 0-1


@dataclass
class ExecutionPattern:
    """执行模式分析结果"""
    dimension: str
    trend: str  # 'increase', 'decrease', 'stable'
    avg_deviation: float  # 平均偏差
    sample_count: int
    recommended_adjustment: float


@dataclass
class ColdStartConfig:
    """冷启动配置 - 降低新用户使用门槛"""
    # 阶段阈值
    STAGE_0_SAMPLES: int = 0      # 纯新用户：使用全局默认
    STAGE_1_SAMPLES: int = 1      # 1-2次执行：使用相似用户推荐
    STAGE_2_SAMPLES: int = 3      # 3-5次执行：混合推荐+个人数据
    STAGE_3_SAMPLES: int = 6      # 6次以上：完全个性化
    
    # 冷启动权重混合比例
    GLOBAL_WEIGHT_RATIO: float = 0.7   # 全局默认权重占比
    SIMILAR_USER_RATIO: float = 0.3    # 相似用户权重占比
    
    # 探索策略
    EXPLORATION_RATE: float = 0.1      # 探索率（随机扰动）
    MIN_EXPLORATION_SAMPLES: int = 5   # 最小探索样本数
    
    # 快速学习参数
    FAST_LEARNING_RATE: float = 0.15   # 冷启动阶段学习率（正常2倍）
    FAST_ADJUSTMENT_RATE: float = 0.2  # 冷启动阶段调整率


class DynamicWeightAdjuster:
    """
    动态权重调整器
    
    基于用户执行反馈，自动调整六维度权重：
    - 时间紧迫度 (urgency)
    - 重要性 (importance)
    - 影响力 (impact)
    - 金钱价值 (money_value)
    - 关系价值 (relationship_value)
    - 技能成长 (skill_growth)
    """
    
    # 维度名称映射
    DIMENSION_MAP = {
        'urgency': '时间紧迫度',
        'importance': '重要性',
        'impact': '影响力',
        'money_value': '金钱价值',
        'relationship_value': '关系价值',
        'skill_growth': '技能成长'
    }
    
    # 调整参数
    ADJUSTMENT_RATE = 0.1  # 基础调整率
    MAX_ADJUSTMENT = 0.3   # 单次最大调整幅度
    MIN_CONFIDENCE = 3     # 最小样本数才进行调整
    LEARNING_RATE = 0.05   # 学习率
    
    # 冷启动配置
    COLD_START = ColdStartConfig()
    
    # 全局默认权重（用于冷启动）
    GLOBAL_DEFAULT_WEIGHTS = {
        'urgency': 0.25,
        'importance': 0.20,
        'impact': 0.20,
        'money_value': 0.15,
        'relationship_value': 0.10,
        'skill_growth': 0.10
    }
    
    def __init__(self, db_connection=None):
        self.db = db_connection
        self._adjustment_history: List[WeightAdjustment] = []
    
    def get_user_cold_start_stage(self, user_id: int) -> Tuple[int, int]:
        """
        获取用户冷启动阶段
        
        Returns:
            (阶段, 样本数)
            阶段: 0=纯新用户, 1=探索期, 2=成长期, 3=成熟期
        """
        try:
            cursor = self.db.cursor()
            cursor.execute("""
                SELECT COUNT(*) FROM sort_execution_feedback
                WHERE user_id = ? AND actual_duration IS NOT NULL
            """, (user_id,))
            
            count = cursor.fetchone()[0]
            
            if count >= self.COLD_START.STAGE_3_SAMPLES:
                return 3, count
            elif count >= self.COLD_START.STAGE_2_SAMPLES:
                return 2, count
            elif count >= self.COLD_START.STAGE_1_SAMPLES:
                return 1, count
            else:
                return 0, count
        except Exception as e:
            logger.error(f"获取用户冷启动阶段失败: {e}")
            return 0, 0
    
    def get_similar_user_weights(self, user_id: int, top_k: int = 5) -> Optional[Dict[str, float]]:
        """
        获取相似用户的权重配置（协同过滤冷启动）
        
        基于用户画像相似度找到最相似的K个用户，返回他们的平均权重
        """
        try:
            cursor = self.db.cursor()
            
            # 获取当前用户的任务特征（分类偏好、优先级分布）
            cursor.execute("""
                SELECT 
                    category,
                    priority,
                    COUNT(*) as count
                FROM tasks
                WHERE user_id = ?
                GROUP BY category, priority
            """, (user_id,))
            
            user_profile = cursor.fetchall()
            if not user_profile:
                return None
            
            # 构建用户特征向量（简化版：按分类统计）
            category_pref = {}
            for row in user_profile:
                category, priority, count = row
                category_pref[category] = category_pref.get(category, 0) + count
            
            # 找到有相似分类偏好的用户
            cursor.execute("""
                SELECT 
                    t.user_id,
                    COUNT(DISTINCT t.category) as common_categories,
                    AVG(w.weights) as avg_weights
                FROM tasks t
                JOIN user_weight_preferences w ON t.user_id = w.user_id
                WHERE t.user_id != ? 
                    AND t.category IN ({})
                    AND t.user_id IN (
                        SELECT user_id FROM sort_execution_feedback 
                        GROUP BY user_id HAVING COUNT(*) >= ?
                    )
                GROUP BY t.user_id
                HAVING common_categories >= 1
                ORDER BY common_categories DESC
                LIMIT ?
            """.format(','.join(['?'] * len(category_pref)), 
                       self.COLD_START.STAGE_2_SAMPLES, top_k),
                (user_id,) + tuple(category_pref.keys()))
            
            similar_users = cursor.fetchall()
            if not similar_users:
                return None
            
            # 聚合相似用户的权重
            all_weights = []
            for row in similar_users:
                try:
                    weights = json.loads(row[2]) if isinstance(row[2], str) else row[2]
                    if weights and isinstance(weights, dict):
                        all_weights.append(weights)
                except:
                    continue
            
            if not all_weights:
                return None
            
            # 计算平均权重
            avg_weights = {}
            dimensions = self.DIMENSION_MAP.keys()
            for dim in dimensions:
                values = [w.get(dim, self.GLOBAL_DEFAULT_WEIGHTS[dim]) for w in all_weights]
                avg_weights[dim] = round(sum(values) / len(values), 3)
            
            logger.info(f"为用户 {user_id} 找到 {len(similar_users)} 个相似用户")
            return avg_weights
            
        except Exception as e:
            logger.error(f"获取相似用户权重失败: {e}")
            return None
    
    def get_cold_start_weights(self, user_id: int) -> Dict[str, float]:
        """
        获取冷启动阶段的推荐权重
        
        根据用户所处阶段，返回不同的权重策略：
        - 阶段0: 纯全局默认权重
        - 阶段1: 全局默认 + 相似用户权重混合
        - 阶段2: 相似用户权重 + 个人数据微调
        - 阶段3: 完全个性化（正常流程）
        """
        stage, sample_count = self.get_user_cold_start_stage(user_id)
        
        logger.info(f"用户 {user_id} 冷启动阶段: {stage}, 样本数: {sample_count}")
        
        if stage == 0:
            # 纯新用户：使用全局默认
            return self.GLOBAL_DEFAULT_WEIGHTS.copy()
        
        elif stage == 1:
            # 探索期：混合全局默认 + 相似用户权重
            similar_weights = self.get_similar_user_weights(user_id)
            if similar_weights:
                mixed = {}
                for dim in self.DIMENSION_MAP.keys():
                    global_w = self.GLOBAL_DEFAULT_WEIGHTS[dim]
                    similar_w = similar_weights.get(dim, global_w)
                    mixed[dim] = round(
                        global_w * self.COLD_START.GLOBAL_WEIGHT_RATIO + 
                        similar_w * self.COLD_START.SIMILAR_USER_RATIO, 
                        3
                    )
                return self._normalize_weights(mixed)
            return self.GLOBAL_DEFAULT_WEIGHTS.copy()
        
        elif stage == 2:
            # 成长期：相似用户权重为主，开始引入个人数据
            similar_weights = self.get_similar_user_weights(user_id)
            if similar_weights:
                # 添加探索扰动，加速学习
                exploration_weights = self._add_exploration_noise(similar_weights)
                return exploration_weights
            return self.GLOBAL_DEFAULT_WEIGHTS.copy()
        
        else:
            # 成熟期：返回None，使用正常流程
            return None
    
    def _add_exploration_noise(self, weights: Dict[str, float]) -> Dict[str, float]:
        """添加探索噪声，帮助快速找到最优权重"""
        import random
        noisy = {}
        for dim, value in weights.items():
            noise = random.uniform(-self.COLD_START.EXPLORATION_RATE, 
                                   self.COLD_START.EXPLORATION_RATE)
            noisy[dim] = max(0.05, min(0.5, value + noise))
        return self._normalize_weights(noisy)
    
    def analyze_execution_patterns(self, user_id: int, days: int = 30) -> Dict[str, ExecutionPattern]:
        """
        分析用户执行模式（支持冷启动）
        
        Args:
            user_id: 用户ID
            days: 分析天数
            
        Returns:
            各维度的执行模式
        """
        patterns = {}
        
        try:
            cursor = self.db.cursor()
            
            # 获取指定时间范围内的执行反馈
            cursor.execute("""
                SELECT 
                    dimension_scores,
                    actual_duration,
                    estimated_duration,
                    execution_order,
                    ai_recommended_order,
                    on_time,
                    completed_at
                FROM sort_execution_feedback
                WHERE user_id = ? 
                    AND completed_at >= datetime('now', '-{} days')
                    AND actual_duration IS NOT NULL
                ORDER BY completed_at DESC
            """.format(days), (user_id,))
            
            rows = cursor.fetchall()
            
            # 获取冷启动阶段
            stage, sample_count = self.get_user_cold_start_stage(user_id)
            
            # 冷启动阶段使用降低的阈值
            min_samples = 1 if stage <= 1 else (2 if stage == 2 else self.MIN_CONFIDENCE)
            
            if len(rows) < min_samples:
                logger.info(f"用户 {user_id} 的执行数据不足 ({len(rows)} < {min_samples})，跳过调整")
                return patterns
            
            # 按维度分组分析
            dimension_stats = {dim: {'deviations': [], 'accuracies': []} 
                             for dim in self.DIMENSION_MAP.keys()}
            
            for row in rows:
                dimension_scores = json.loads(row[0]) if row[0] else {}
                actual_duration = row[1]
                estimated_duration = row[2]
                execution_order = row[3]
                ai_order = row[4]
                on_time = row[5]
                
                # 计算时间偏差
                if estimated_duration and estimated_duration > 0:
                    time_deviation = (actual_duration - estimated_duration) / estimated_duration
                else:
                    time_deviation = 0
                
                # 计算排序偏差
                order_deviation = abs(execution_order - ai_order) if execution_order and ai_order else 0
                
                # 分析各维度
                for dim, score in dimension_scores.items():
                    if dim in dimension_stats:
                        # 如果按时完成且排序偏差小，该维度权重合适
                        # 如果延迟完成或排序偏差大，需要调整
                        accuracy = 1.0 if on_time and order_deviation <= 2 else 0.0
                        dimension_stats[dim]['accuracies'].append(accuracy)
                        dimension_stats[dim]['deviations'].append(time_deviation)
            
            # 计算各维度的模式
            for dim, stats in dimension_stats.items():
                # 冷启动阶段降低样本要求
                required_samples = 1 if stage <= 1 else (2 if stage == 2 else self.MIN_CONFIDENCE)
                if len(stats['accuracies']) >= required_samples:
                    avg_accuracy = sum(stats['accuracies']) / len(stats['accuracies'])
                    avg_deviation = sum(stats['deviations']) / len(stats['deviations'])
                    
                    # 确定趋势
                    if avg_accuracy < 0.5:
                        trend = 'decrease'
                        recommended = -self.ADJUSTMENT_RATE
                    elif avg_accuracy > 0.8:
                        trend = 'stable'
                        recommended = 0
                    else:
                        trend = 'increase'
                        recommended = self.ADJUSTMENT_RATE
                    
                    patterns[dim] = ExecutionPattern(
                        dimension=dim,
                        trend=trend,
                        avg_deviation=avg_deviation,
                        sample_count=len(stats['accuracies']),
                        recommended_adjustment=recommended
                    )
            
        except Exception as e:
            logger.error(f"分析执行模式失败: {e}")
        
        return patterns
    
    def calculate_weight_adjustments(
        self, 
        user_id: int, 
        current_weights: Dict[str, float],
        patterns: Optional[Dict[str, ExecutionPattern]] = None
    ) -> List[WeightAdjustment]:
        """
        计算权重调整建议
        
        Args:
            user_id: 用户ID
            current_weights: 当前权重配置
            patterns: 预分析的执行模式（可选）
            
        Returns:
            权重调整列表
        """
        if patterns is None:
            patterns = self.analyze_execution_patterns(user_id)
        
        adjustments = []
        
        for dim, pattern in patterns.items():
            if dim not in current_weights:
                continue
            
            current_value = current_weights[dim]
            
            # 根据推荐调整计算新值
            # 冷启动阶段使用更高的学习率
            stage, _ = self.get_user_cold_start_stage(user_id)
            learning_rate = (self.COLD_START.FAST_LEARNING_RATE if stage <= 2 
                           else self.LEARNING_RATE)
            adjustment = pattern.recommended_adjustment * learning_rate
            
            # 限制调整幅度
            adjustment = max(-self.MAX_ADJUSTMENT, min(self.MAX_ADJUSTMENT, adjustment))
            
            new_value = current_value + adjustment
            
            # 确保权重在合理范围内
            new_value = max(0.05, min(0.5, new_value))
            
            if abs(new_value - current_value) > 0.001:  # 忽略微小变化
                adjustments.append(WeightAdjustment(
                    dimension=dim,
                    old_value=current_value,
                    new_value=round(new_value, 3),
                    reason=f"基于{pattern.sample_count}次执行分析，准确率{self._calculate_accuracy(pattern):.1%}",
                    confidence=min(1.0, pattern.sample_count / 10)
                ))
        
        return adjustments
    
    def apply_adjustments(
        self, 
        user_id: int, 
        adjustments: List[WeightAdjustment]
    ) -> Dict[str, float]:
        """
        应用权重调整
        
        Args:
            user_id: 用户ID
            adjustments: 权重调整列表
            
        Returns:
            调整后的权重
        """
        try:
            cursor = self.db.cursor()
            
            # 获取当前权重
            cursor.execute("""
                SELECT weights FROM user_weight_preferences 
                WHERE user_id = ?
            """, (user_id,))
            
            row = cursor.fetchone()
            if not row:
                logger.warning(f"用户 {user_id} 没有权重配置")
                return {}
            
            weights = json.loads(row[0])
            
            # 应用调整
            for adj in adjustments:
                weights[adj.dimension] = adj.new_value
            
            # 归一化权重
            weights = self._normalize_weights(weights)
            
            # 保存到数据库
            cursor.execute("""
                UPDATE user_weight_preferences 
                SET weights = ?, updated_at = datetime('now')
                WHERE user_id = ?
            """, (json.dumps(weights), user_id))
            
            # 记录调整历史
            for adj in adjustments:
                cursor.execute("""
                    INSERT INTO weight_adjustment_history 
                    (user_id, dimension, old_value, new_value, reason, confidence, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, datetime('now'))
                """, (user_id, adj.dimension, adj.old_value, adj.new_value, 
                      adj.reason, adj.confidence))
            
            self.db.commit()
            
            # 更新内存中的历史
            self._adjustment_history.extend(adjustments)
            
            logger.info(f"已为用户 {user_id} 应用 {len(adjustments)} 项权重调整")
            
            return weights
            
        except Exception as e:
            logger.error(f"应用权重调整失败: {e}")
            return {}
    
    def process_user_feedback(
        self, 
        user_id: int, 
        feedback_type: str,  # 'positive', 'negative', 'reorder'
        task_id: Optional[int] = None,
        details: Optional[str] = None
    ) -> List[WeightAdjustment]:
        """
        处理用户显式反馈
        
        Args:
            user_id: 用户ID
            feedback_type: 反馈类型
            task_id: 相关任务ID
            details: 详细说明
            
        Returns:
            触发的权重调整
        """
        adjustments = []
        
        try:
            cursor = self.db.cursor()
            
            # 获取当前权重
            cursor.execute("""
                SELECT weights FROM user_weight_preferences 
                WHERE user_id = ?
            """, (user_id,))
            
            row = cursor.fetchone()
            if not row:
                return adjustments
            
            weights = json.loads(row[0])
            
            # 根据反馈类型调整
            if feedback_type == 'negative':
                # 用户认为排序不合理，降低各维度权重差异
                avg_weight = sum(weights.values()) / len(weights)
                for dim in weights:
                    old_value = weights[dim]
                    new_value = old_value * 0.9 + avg_weight * 0.1  # 向平均值靠拢
                    adjustments.append(WeightAdjustment(
                        dimension=dim,
                        old_value=old_value,
                        new_value=round(new_value, 3),
                        reason="用户反馈排序不合理，降低极端权重",
                        confidence=0.7
                    ))
                    weights[dim] = new_value
                    
            elif feedback_type == 'reorder' and task_id:
                # 用户手动重排序，分析差异并调整
                adjustments = self._learn_from_reorder(user_id, task_id, weights)
                
            elif feedback_type == 'positive':
                # 用户认可排序，轻微强化当前权重
                for dim in weights:
                    old_value = weights[dim]
                    new_value = old_value * 1.02  # 轻微增加
                    new_value = min(0.5, new_value)
                    if new_value != old_value:
                        adjustments.append(WeightAdjustment(
                            dimension=dim,
                            old_value=old_value,
                            new_value=round(new_value, 3),
                            reason="用户认可排序，强化当前配置",
                            confidence=0.5
                        ))
                        weights[dim] = new_value
            
            # 归一化并保存
            if adjustments:
                weights = self._normalize_weights(weights)
                self.apply_adjustments(user_id, adjustments)
            
            # 记录反馈
            cursor.execute("""
                INSERT INTO sort_user_feedback 
                (user_id, feedback_type, task_id, details, adjustments, created_at)
                VALUES (?, ?, ?, ?, ?, datetime('now'))
            """, (user_id, feedback_type, task_id, details,
                  json.dumps([{'dim': a.dimension, 'old': a.old_value, 'new': a.new_value} 
                             for a in adjustments])))
            
            self.db.commit()
            
        except Exception as e:
            logger.error(f"处理用户反馈失败: {e}")
        
        return adjustments
    
    def _learn_from_reorder(
        self, 
        user_id: int, 
        task_id: int, 
        current_weights: Dict[str, float]
    ) -> List[WeightAdjustment]:
        """从用户手动重排序中学习"""
        adjustments = []
        
        try:
            cursor = self.db.cursor()
            
            # 获取任务信息和AI排序时的维度分数
            cursor.execute("""
                SELECT 
                    t.category,
                    t.priority,
                    t.deadline,
                    sef.dimension_scores,
                    sef.ai_recommended_order,
                    sef.execution_order
                FROM tasks t
                LEFT JOIN sort_execution_feedback sef ON t.id = sef.task_id
                WHERE t.id = ? AND t.user_id = ?
                ORDER BY sef.completed_at DESC
                LIMIT 1
            """, (task_id, user_id))
            
            row = cursor.fetchone()
            if not row:
                return adjustments
            
            category, priority, deadline, dim_scores_json, ai_order, exec_order = row
            
            if not dim_scores_json or ai_order is None or exec_order is None:
                return adjustments
            
            dim_scores = json.loads(dim_scores_json)
            
            # 分析用户把任务提前还是推后了
            order_diff = exec_order - ai_order
            
            if order_diff < 0:
                # 用户提前了任务，说明某些维度被低估了
                # 根据任务特征判断哪些维度应该加强
                if category in ['考试', '工作']:
                    adjustments.append(self._create_adjustment(
                        current_weights, 'urgency', 0.05, "用户提前重要任务"
                    ))
                if priority == 'high':
                    adjustments.append(self._create_adjustment(
                        current_weights, 'importance', 0.05, "用户提前高优先级任务"
                    ))
                    
            elif order_diff > 0:
                # 用户推后了任务，说明某些维度被高估了
                adjustments.append(self._create_adjustment(
                    current_weights, 'urgency', -0.03, "用户推后任务"
                ))
            
        except Exception as e:
            logger.error(f"学习重排序失败: {e}")
        
        return [a for a in adjustments if a is not None]
    
    def _create_adjustment(
        self, 
        weights: Dict[str, float], 
        dimension: str, 
        delta: float,
        reason: str
    ) -> Optional[WeightAdjustment]:
        """创建权重调整"""
        if dimension not in weights:
            return None
        
        old_value = weights[dimension]
        new_value = max(0.05, min(0.5, old_value + delta))
        
        if abs(new_value - old_value) < 0.001:
            return None
        
        return WeightAdjustment(
            dimension=dimension,
            old_value=old_value,
            new_value=round(new_value, 3),
            reason=reason,
            confidence=0.6
        )
    
    def _normalize_weights(self, weights: Dict[str, float]) -> Dict[str, float]:
        """归一化权重，使总和为1"""
        total = sum(weights.values())
        if total == 0:
            # 默认均等权重
            n = len(self.DIMENSION_MAP)
            return {dim: round(1.0/n, 3) for dim in self.DIMENSION_MAP.keys()}
        
        return {dim: round(v/total, 3) for dim, v in weights.items()}
    
    def _calculate_accuracy(self, pattern: ExecutionPattern) -> float:
        """计算准确率"""
        if pattern.trend == 'stable':
            return 0.85
        elif pattern.trend == 'increase':
            return 0.65
        else:
            return 0.45
    
    def get_adjustment_history(
        self, 
        user_id: int, 
        limit: int = 50
    ) -> List[Dict]:
        """获取权重调整历史"""
        try:
            cursor = self.db.cursor()
            cursor.execute("""
                SELECT dimension, old_value, new_value, reason, confidence, created_at
                FROM weight_adjustment_history
                WHERE user_id = ?
                ORDER BY created_at DESC
                LIMIT ?
            """, (user_id, limit))
            
            return [
                {
                    'dimension': row[0],
                    'dimension_name': self.DIMENSION_MAP.get(row[0], row[0]),
                    'old_value': row[1],
                    'new_value': row[2],
                    'reason': row[3],
                    'confidence': row[4],
                    'created_at': row[5]
                }
                for row in cursor.fetchall()
            ]
            
        except Exception as e:
            logger.error(f"获取调整历史失败: {e}")
            return []
    
    def auto_adjust_weights(self, user_id: int) -> Dict:
        """
        自动调整权重（供定时任务调用）
        
        Returns:
            调整结果
        """
        try:
            cursor = self.db.cursor()
            
            # 获取当前权重
            cursor.execute("""
                SELECT weights FROM user_weight_preferences 
                WHERE user_id = ?
            """, (user_id,))
            
            row = cursor.fetchone()
            if not row:
                return {'success': False, 'message': '没有找到权重配置'}
            
            current_weights = json.loads(row[0])
            
            # 分析执行模式
            patterns = self.analyze_execution_patterns(user_id)
            
            if not patterns:
                return {'success': False, 'message': '数据不足，无法调整'}
            
            # 计算调整
            adjustments = self.calculate_weight_adjustments(
                user_id, current_weights, patterns
            )
            
            if not adjustments:
                return {'success': True, 'message': '当前权重配置良好，无需调整', 'adjustments': []}
            
            # 应用调整
            new_weights = self.apply_adjustments(user_id, adjustments)
            
            return {
                'success': True,
                'message': f'已自动调整 {len(adjustments)} 项权重',
                'adjustments': [
                    {
                        'dimension': a.dimension,
                        'dimension_name': self.DIMENSION_MAP.get(a.dimension, a.dimension),
                        'old_value': a.old_value,
                        'new_value': a.new_value,
                        'reason': a.reason,
                        'confidence': a.confidence
                    }
                    for a in adjustments
                ],
                'weights': new_weights
            }
            
        except Exception as e:
            logger.error(f"自动调整权重失败: {e}")
            return {'success': False, 'message': str(e)}


# 全局调整器实例
_weight_adjuster: Optional[DynamicWeightAdjuster] = None


def get_weight_adjuster(db_connection=None) -> DynamicWeightAdjuster:
    """获取权重调整器实例"""
    global _weight_adjuster
    if _weight_adjuster is None:
        _weight_adjuster = DynamicWeightAdjuster(db_connection)
    elif db_connection:
        _weight_adjuster.db = db_connection
    return _weight_adjuster


def initialize_user_weights(user_id: int, db_connection=None) -> Dict[str, float]:
    """
    初始化新用户权重（冷启动入口）
    
    在以下场景调用：
    1. 新用户注册时
    2. 首次使用AI排序功能时
    3. 用户主动重置权重时
    
    Args:
        user_id: 用户ID
        db_connection: 数据库连接
        
    Returns:
        初始化后的权重配置
    """
    adjuster = get_weight_adjuster(db_connection)
    
    # 获取冷启动推荐权重
    weights = adjuster.get_cold_start_weights(user_id)
    
    # 如果返回None，说明用户已进入成熟期，使用全局默认
    if weights is None:
        weights = DynamicWeightAdjuster.GLOBAL_DEFAULT_WEIGHTS.copy()
    
    try:
        cursor = adjuster.db.cursor()
        
        # 检查是否已有权重配置
        cursor.execute("""
            SELECT id FROM user_weight_preferences WHERE user_id = ?
        """, (user_id,))
        
        if cursor.fetchone():
            # 更新现有配置
            cursor.execute("""
                UPDATE user_weight_preferences 
                SET weights = ?, updated_at = datetime('now'), is_cold_start = 1
                WHERE user_id = ?
            """, (json.dumps(weights), user_id))
        else:
            # 插入新配置
            cursor.execute("""
                INSERT INTO user_weight_preferences 
                (user_id, weights, created_at, updated_at, is_cold_start)
                VALUES (?, ?, datetime('now'), datetime('now'), 1)
            """, (user_id, json.dumps(weights)))
        
        adjuster.db.commit()
        
        # 记录冷启动初始化
        logger.info(f"用户 {user_id} 权重冷启动初始化完成: {weights}")
        
    except Exception as e:
        logger.error(f"初始化用户权重失败: {e}")
    
    return weights


def get_user_weights_with_fallback(user_id: int, db_connection=None) -> Dict[str, float]:
    """
    获取用户权重（带冷启动回退）
    
    如果用户没有权重配置，自动进行冷启动初始化
    
    Args:
        user_id: 用户ID
        db_connection: 数据库连接
        
    Returns:
        用户权重配置
    """
    adjuster = get_weight_adjuster(db_connection)
    
    try:
        cursor = adjuster.db.cursor()
        cursor.execute("""
            SELECT weights FROM user_weight_preferences WHERE user_id = ?
        """, (user_id,))
        
        row = cursor.fetchone()
        if row:
            return json.loads(row[0])
        
        # 用户没有权重配置，进行冷启动初始化
        return initialize_user_weights(user_id, db_connection)
        
    except Exception as e:
        logger.error(f"获取用户权重失败: {e}")
        return DynamicWeightAdjuster.GLOBAL_DEFAULT_WEIGHTS.copy()
