"""
用户认证与隔离助手

提供用户ID验证、自动创建用户、数据隔离等功能
支持JWT Token认证和匿名访问（X-User-ID）

统一认证装饰器 - 使用 AuthManager 统一模块
"""

from functools import wraps
from flask import request, jsonify, current_app
import jwt
import logging
from models.task import User
from extensions import db
from datetime import datetime

logger = logging.getLogger('auth')

# 导入统一认证管理器
from utils.auth import AuthManager, generate_token, verify_token


# 保留原有的便捷函数，使用 AuthManager 实现
verify_jwt_token = AuthManager.verify_token


def get_or_create_user(user_id):
    """
    根据user_id获取用户，如果不存在则自动创建
    
    Args:
        user_id: 用户唯一标识符
        
    Returns:
        User对象
    """
    if not user_id:
        return None
    
    try:
        # User模型的id字段是主键
        user = User.query.filter_by(id=user_id).first()
        
        if user:
            # 刷新用户数据，确保获取最新信息
            db.session.refresh(user)
            return user
        
        # 自动创建新用户，id字段是主键
        user = User(id=user_id)
        db.session.add(user)
        db.session.commit()
        
        return user
    except Exception as e:
        db.session.rollback()
        # 如果是唯一约束失败，尝试重新获取
        if 'UNIQUE constraint' in str(e) or 'IntegrityError' in str(type(e).__name__):
            user = User.query.filter_by(id=user_id).first()
            if user:
                return user
        raise


def log_deprecated_auth(user_id, auth_type='X-User-ID'):
    """
    记录使用了兼容模式的认证方式
    
    Args:
        user_id: 用户ID
        auth_type: 认证类型
    """
    logger.warning(
        f"使用了兼容模式认证: {auth_type}, user_id={user_id}. "
        f"建议迁移到JWT Token认证。"
    )


def get_current_user_id():
    """
    从请求头或请求体获取当前用户ID
    
    使用 AuthManager 统一处理
    
    Returns:
        (user_id, auth_type) 元组
    """
    return AuthManager.get_current_user_id()


def require_user(f):
    """
    统一认证装饰器
    
    使用 AuthManager 实现认证逻辑
    
    支持两种认证方式（优先级从高到低）：
    1. JWT Token（Authorization: Bearer <token>）
    2. X-User-ID 兼容模式（将逐步废弃）
    
    使用方式：
        @task_bp.route('/api/tasks', methods=['GET'])
        @require_user
        def get_tasks(user):
            # user 是 User 对象
            tasks = Task.query.filter_by(user_id=user.id).all()
            ...
    """
    return AuthManager.require_auth(f)


def get_user_id_optional():
    """
    获取用户ID（可选，不强制要求）
    
    Returns:
        用户ID字符串或None
    """
    user_id, _ = get_current_user_id()
    return user_id


def filter_by_user(query, model, user):
    """
    为查询添加用户过滤条件
    
    Args:
        query: SQLAlchemy查询对象
        model: 数据模型类
        user: User对象
        
    Returns:
        添加了用户过滤的查询对象
    """
    if hasattr(model, 'user_id'):
        return query.filter(model.user_id == user.id)
    return query
