"""
分层上下文管理系统
实现工作记忆、短期记忆、长期记忆的三层架构
"""

import json
import sqlite3
import numpy as np
from dataclasses import dataclass, field, asdict
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Tuple, Set
from collections import deque
import heapq

from utils.dialogue_history import DialogueSession, Message, MessageType


@dataclass
class RetrievedContext:
    """检索到的上下文"""
    working_memory: List[Message]
    semantic_results: List[Tuple[Message, float]]  # (消息, 相似度)
    kg_results: List[Dict[str, Any]]  # 知识图谱结果
    fused_ranking: List[Message]  # 融合排序后的结果
    total_tokens: int = 0


class WorkingMemory:
    """
    工作记忆层
    存储当前活跃的最近几轮对话（完整内容）
    """
    
    def __init__(self, capacity: int = 5):
        self.capacity = capacity
        self.messages: deque = deque(maxlen=capacity)
        self.active_entities: Set[str] = set()
        self.current_intent: Optional[str] = None
        
    def add(self, message: Message):
        """添加消息到工作记忆"""
        self.messages.append(message)
        
        # 更新活跃实体
        if hasattr(message, 'entities') and message.entities:
            self.active_entities.update(message.entities)
        
        # 更新当前意图
        if hasattr(message, 'intent') and message.intent:
            self.current_intent = message.intent
    
    def get_all(self) -> List[Message]:
        """获取所有工作记忆内容"""
        return list(self.messages)
    
    def get_recent(self, n: int = 3) -> List[Message]:
        """获取最近n条消息"""
        return list(self.messages)[-n:]
    
    def clear(self):
        """清空工作记忆"""
        self.messages.clear()
        self.active_entities.clear()
        self.current_intent = None
    
    def is_full(self) -> bool:
        """检查是否已满"""
        return len(self.messages) >= self.capacity
    
    def get_context_string(self) -> str:
        """获取上下文字符串表示
        
        Returns:
            格式化的上下文字符串
        """
        parts: List[str] = []
        for msg in self.messages:
            if msg is None:
                continue
            role: str = "用户" if getattr(msg, 'role', None) == "user" else "助手"
            content: str = getattr(msg, 'content', '') or ''
            parts.append(f"{role}: {content}")
        return "\n".join(parts)


class VectorStore:
    """
    向量存储（短期记忆）
    使用HNSW索引进行高效相似度搜索
    """
    
    def __init__(self, embedding_model: str = "text2vec", index_type: str = "hnsw"):
        self.embedding_model_name = embedding_model
        self.index_type = index_type
        self.embedding_model = None
        self.messages: List[Message] = []
        self.embeddings: List[np.ndarray] = []
        self._load_model()
        
    def _load_model(self):
        """加载嵌入模型"""
        try:
            from sentence_transformers import SentenceTransformer
            # 尝试使用 model_downloader 获取模型路径
            try:
                from utils.model_downloader import get_model_path
                model_path = get_model_path("paraphrase-multilingual-MiniLM-L12-v2")
                self.embedding_model = SentenceTransformer(model_path)
                print("[上下文管理] 向量存储模型加载成功（使用 model_downloader）")
            except ImportError:
                # model_downloader 不可用，直接加载
                self.embedding_model = SentenceTransformer('paraphrase-multilingual-MiniLM-L12-v2')
                print("[上下文管理] 向量存储模型加载成功")
        except ImportError:
            print("[WARN] sentence-transformers 未安装，向量存储将使用降级方案")
            self.embedding_model = None
    
    def add(self, message: Message):
        """添加消息到向量存储"""
        self.messages.append(message)
        
        # 计算嵌入
        if self.embedding_model is not None:
            try:
                embedding = self.embedding_model.encode(message.content)
                self.embeddings.append(embedding)
            except Exception as e:
                print(f"[ERROR] 嵌入计算失败: {e}")
                self.embeddings.append(np.zeros(384))
        else:
            # 降级方案：使用零向量
            self.embeddings.append(np.zeros(384))
    
    async def similarity_search(self, 
                               query: str, 
                               top_k: int = 10,
                               min_score: float = 0.5) -> List[Tuple[Message, float]]:
        """
        相似度搜索
        返回: [(消息, 相似度), ...]
        """
        if not self.messages or self.embedding_model is None:
            return []
        
        try:
            # 计算查询嵌入
            query_embedding = self.embedding_model.encode(query)
            
            # 计算相似度
            similarities = []
            for i, embedding in enumerate(self.embeddings):
                # 余弦相似度
                dot_product = np.dot(query_embedding, embedding)
                norm_query = np.linalg.norm(query_embedding)
                norm_embedding = np.linalg.norm(embedding)
                
                if norm_query > 0 and norm_embedding > 0:
                    similarity = dot_product / (norm_query * norm_embedding)
                    if similarity >= min_score:
                        similarities.append((self.messages[i], float(similarity)))
            
            # 按相似度排序
            similarities.sort(key=lambda x: x[1], reverse=True)
            return similarities[:top_k]
            
        except Exception as e:
            print(f"[ERROR] 相似度搜索失败: {e}")
            return []
    
    def clear(self):
        """清空存储"""
        self.messages.clear()
        self.embeddings.clear()


class KnowledgeGraphStore:
    """
    知识图谱存储（长期记忆）
    存储跨会话的实体关系和用户画像
    """
    
    def __init__(self, db_path: str = "knowledge_graph.db"):
        self.db_path = db_path
        self._init_db()
    
    def _init_db(self):
        """初始化数据库"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # 实体表
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS entities (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                type TEXT NOT NULL,
                user_id TEXT,
                attributes TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(name, type, user_id)
            )
        """)
        
        # 关系表
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS relations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_id INTEGER,
                target_id INTEGER,
                relation_type TEXT NOT NULL,
                confidence REAL DEFAULT 1.0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (source_id) REFERENCES entities(id),
                FOREIGN KEY (target_id) REFERENCES entities(id)
            )
        """)
        
        # 用户画像表
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS user_profiles (
                user_id TEXT PRIMARY KEY,
                preferences TEXT,
                frequent_tasks TEXT,
                work_patterns TEXT,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        conn.commit()
        conn.close()
    
    def add_entity(self, name: str, entity_type: str, 
                   user_id: Optional[str] = None,
                   attributes: Optional[Dict] = None) -> int:
        """添加实体"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute("""
                INSERT OR REPLACE INTO entities (name, type, user_id, attributes, updated_at)
                VALUES (?, ?, ?, ?, ?)
            """, (name, entity_type, user_id, 
                  json.dumps(attributes) if attributes else None,
                  datetime.now().isoformat()))
            
            entity_id = cursor.lastrowid
            conn.commit()
            return entity_id
        except Exception as e:
            print(f"[ERROR] 添加实体失败: {e}")
            return -1
        finally:
            conn.close()
    
    def add_relation(self, source_name: str, target_name: str,
                    relation_type: str, confidence: float = 1.0):
        """添加关系"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            # 获取实体ID
            cursor.execute("SELECT id FROM entities WHERE name = ?", (source_name,))
            source_row = cursor.fetchone()
            cursor.execute("SELECT id FROM entities WHERE name = ?", (target_name,))
            target_row = cursor.fetchone()
            
            if source_row and target_row:
                cursor.execute("""
                    INSERT INTO relations (source_id, target_id, relation_type, confidence)
                    VALUES (?, ?, ?, ?)
                """, (source_row[0], target_row[0], relation_type, confidence))
                conn.commit()
        except Exception as e:
            print(f"[ERROR] 添加关系失败: {e}")
        finally:
            conn.close()
    
    def query_related(self, entities: List[str],
                     relations: Optional[List[str]] = None,
                     user_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        查询相关实体
        """
        if not entities:
            return []
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        results = []
        
        try:
            for entity_name in entities:
                # 查询实体
                cursor.execute("""
                    SELECT id, name, type, attributes FROM entities
                    WHERE name = ? AND (user_id = ? OR user_id IS NULL)
                """, (entity_name, user_id))
                
                row = cursor.fetchone()
                if row:
                    entity_id, name, entity_type, attributes = row
                    
                    # 查询相关关系
                    relation_filter = ""
                    if relations:
                        placeholders = ','.join(['?' for _ in relations])
                        relation_filter = f"AND r.relation_type IN ({placeholders})"
                    
                    query = f"""
                        SELECT e.name, e.type, r.relation_type, r.confidence
                        FROM relations r
                        JOIN entities e ON r.target_id = e.id
                        WHERE r.source_id = ? {relation_filter}
                        ORDER BY r.confidence DESC
                        LIMIT 10
                    """
                    
                    params = [entity_id]
                    if relations:
                        params.extend(relations)
                    
                    cursor.execute(query, params)
                    
                    for rel_row in cursor.fetchall():
                        results.append({
                            "source": name,
                            "target": rel_row[0],
                            "target_type": rel_row[1],
                            "relation": rel_row[2],
                            "confidence": rel_row[3]
                        })
        except Exception as e:
            print(f"[ERROR] 查询关系失败: {e}")
        finally:
            conn.close()
        
        return results


class ContextCompressor:
    """
    上下文压缩器
    实现多种压缩策略
    """
    
    def __init__(self):
        self.summary_model = None
        
    def sliding_window(self, messages: List[Message], 
                      window_size: int = 20) -> List[Message]:
        """
        滑动窗口压缩
        保留最近N条消息
        """
        return messages[-window_size:] if len(messages) > window_size else messages
    
    def semantic_summary(self, messages: List[Message],
                        max_length: int = 500) -> str:
        """
        语义摘要
        提取关键决策点和实体
        """
        if not messages:
            return ""
        
        # 提取关键信息
        key_points = []
        entities = set()
        decisions = []
        
        for msg in messages:
            content = msg.content if hasattr(msg, 'content') else str(msg)
            
            # 提取实体（简单实现）
            # 这里可以使用NER模型
            
            # 检测决策点
            decision_indicators = ['确认', '决定', '选择', '创建', '删除', '修改']
            if any(ind in content for ind in decision_indicators):
                decisions.append(content[:100])  # 截断
        
        # 构建摘要
        summary_parts = []
        if decisions:
            summary_parts.append("关键决策:\n" + "\n".join(f"- {d}" for d in decisions[-5:]))
        
        summary = "\n\n".join(summary_parts)
        return summary[:max_length]
    
    def extract_key_entities(self, messages: List[Message]) -> Dict[str, List[str]]:
        """
        提取关键实体
        """
        entities = {
            "tasks": [],
            "dates": [],
            "people": [],
            "concepts": []
        }
        
        # 简单的实体提取规则
        for msg in messages:
            content = msg.content if hasattr(msg, 'content') else str(msg)
            
            # 提取任务引用
            task_patterns = ['任务', 'todo', '待办']
            for pattern in task_patterns:
                if pattern in content:
                    # 提取任务名称（简化）
                    entities["tasks"].append(content[:50])
                    break
            
            # 提取日期
            date_patterns = [r'\d{4}[-/]\d{1,2}[-/]\d{1,2}', r'明天', r'后天', r'下周']
            import re
            for pattern in date_patterns:
                matches = re.findall(pattern, content)
                entities["dates"].extend(matches)
        
        return entities


class HierarchicalContextManager:
    """
    分层上下文管理器
    实现工作记忆、短期记忆、长期记忆的三层架构
    """
    
    def __init__(self, 
                 working_capacity: int = 5,
                 use_semantic: bool = True,
                 use_kg: bool = True):
        self.working_memory = WorkingMemory(capacity=working_capacity)
        self.short_term_store = VectorStore() if use_semantic else None
        self.long_term_memory = KnowledgeGraphStore() if use_kg else None
        self.compressor = ContextCompressor()
        
        # 配置
        self.max_context_tokens = 4000
        self.semantic_top_k = 10
        
    async def add_message(self, message: Message):
        """
        添加消息到上下文系统
        """
        # 1. 添加到工作记忆
        self.working_memory.add(message)
        
        # 2. 添加到短期记忆（向量存储）
        if self.short_term_store:
            self.short_term_store.add(message)
        
        # 3. 提取实体到长期记忆
        if self.long_term_memory and hasattr(message, 'entities'):
            for entity in message.entities:
                self.long_term_memory.add_entity(
                    name=entity,
                    entity_type="extracted",
                    user_id=getattr(message, 'user_id', None)
                )
    
    async def retrieve_relevant_context(self,
                                       query: str,
                                       current_session: Optional[DialogueSession] = None,
                                       top_k: int = 10) -> RetrievedContext:
        """
        多路召回上下文检索
        
        1. 工作记忆直接获取
        2. 向量相似度检索（短期记忆）
        3. 知识图谱检索（长期记忆）
        4. 重排序融合
        """
        # 1. 工作记忆
        working_context = self.working_memory.get_all()
        
        # 2. 向量相似度检索
        semantic_results = []
        if self.short_term_store:
            semantic_results = await self.short_term_store.similarity_search(
                query, top_k=self.semantic_top_k
            )
        
        # 3. 知识图谱检索
        kg_results = []
        if self.long_term_memory:
            # 从查询中提取实体
            entities = self._extract_entities_from_query(query)
            kg_results = self.long_term_memory.query_related(
                entities=entities,
                relations=["depends_on", "related_to", "part_of"]
            )
        
        # 4. 重排序融合
        fused_results = self._reciprocal_rank_fusion(
            working_context,
            [msg for msg, _ in semantic_results],
            kg_results,
            top_k=top_k
        )
        
        # 计算token数（简化估计）
        total_tokens = sum(len(m.content) // 4 for m in fused_results)
        
        return RetrievedContext(
            working_memory=working_context,
            semantic_results=semantic_results,
            kg_results=kg_results,
            fused_ranking=fused_results,
            total_tokens=total_tokens
        )
    
    def _extract_entities_from_query(self, query: str) -> List[str]:
        """从查询中提取实体"""
        # 简化实现：提取引号内的内容和特定模式
        import re
        entities = []
        
        # 引号内的内容
        quoted = re.findall(r'["""]([^"""]+)["""]', query)
        entities.extend(quoted)
        
        # 书名号
        titled = re.findall(r'《([^》]+)》', query)
        entities.extend(titled)
        
        return entities
    
    def _reciprocal_rank_fusion(self,
                                working: List[Message],
                                semantic: List[Message],
                                kg: List[Dict],
                                top_k: int = 10) -> List[Message]:
        """
        倒数排序融合（RRF）
        合并多个来源的检索结果
        """
        k = 60  # RRF常数
        scores = {}
        
        # 工作记忆（最高权重）
        for rank, msg in enumerate(working):
            msg_id = id(msg)
            scores[msg_id] = scores.get(msg_id, 0) + 1.0 / (k + rank)
            scores[msg_id + '_msg'] = msg
        
        # 语义结果
        for rank, msg in enumerate(semantic):
            msg_id = id(msg)
            scores[msg_id] = scores.get(msg_id, 0) + 0.8 / (k + rank)
            scores[msg_id + '_msg'] = msg
        
        # 按分数排序
        sorted_ids = sorted(scores.keys(), key=lambda x: scores[x], reverse=True)
        
        # 去重并返回
        seen = set()
        result = []
        for msg_id in sorted_ids:
            if '_msg' in str(msg_id):
                continue
            msg = scores.get(msg_id + '_msg')
            if msg and id(msg) not in seen:
                seen.add(id(msg))
                result.append(msg)
                if len(result) >= top_k:
                    break
        
        return result
    
    def compress_if_needed(self, messages: List[Message]) -> str:
        """
        如果需要，压缩上下文
        """
        # 估算token数
        estimated_tokens = sum(len(m.content) // 4 for m in messages)
        
        if estimated_tokens <= self.max_context_tokens:
            # 不需要压缩
            return "\n".join(f"{m.role}: {m.content}" for m in messages)
        
        # 需要压缩
        # 1. 保留工作记忆
        working = self.working_memory.get_all()
        
        # 2. 对其余消息进行摘要
        other_messages = [m for m in messages if m not in working]
        summary = self.compressor.semantic_summary(other_messages)
        
        # 3. 组合
        parts = []
        parts.append("=== 当前对话 ===")
        for m in working:
            parts.append(f"{m.role}: {m.content}")
        
        if summary:
            parts.append("\n=== 历史摘要 ===")
            parts.append(summary)
        
        return "\n".join(parts)
    
    def clear_session(self):
        """清空当前会话的上下文"""
        self.working_memory.clear()
        if self.short_term_store:
            self.short_term_store.clear()


# 导出
__all__ = [
    'HierarchicalContextManager',
    'WorkingMemory',
    'VectorStore',
    'KnowledgeGraphStore',
    'ContextCompressor',
    'RetrievedContext',
]