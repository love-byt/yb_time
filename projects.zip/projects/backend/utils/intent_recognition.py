"""
意图识别模块
提供用户意图分类和实体提取功能
"""

import re
from dataclasses import dataclass
from datetime import datetime, timedelta
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple


class UserIntent(Enum):
    """用户意图枚举"""
    # 任务管理
    CREATE_TASK = "create_task"
    UPDATE_TASK = "update_task"
    DELETE_TASK = "delete_task"
    QUERY_TASK = "query_task"
    LIST_TASKS = "list_tasks"
    SORT_TASKS = "sort_tasks"
    
    # 依赖管理
    ADD_DEPENDENCY = "add_dependency"
    REMOVE_DEPENDENCY = "remove_dependency"
    QUERY_DEPENDENCIES = "query_dependencies"
    
    # 上下文相关
    REFER_TO_PREVIOUS = "refer_to_previous"
    CLARIFY = "clarify"
    CONFIRM = "confirm"
    CANCEL = "cancel"
    
    # 一般对话
    GREETING = "greeting"
    GENERAL_QUESTION = "general_question"
    CHITCHAT = "chitchat"
    UNKNOWN = "unknown"


class IntentType(Enum):
    """意图类型枚举（兼容 dialogue_history）"""
    CREATE_TASK = "create_task"
    UPDATE_TASK = "update_task"
    DELETE_TASK = "delete_task"
    QUERY_TASK = "query_task"
    SORT_TASK = "sort_task"
    ADD_DEPENDENCY = "add_dependency"
    GENERAL_CHAT = "general_chat"
    CLARIFICATION = "clarification"


class IntentClassifier:
    """意图分类器 - 基于规则匹配"""
    
    def __init__(self):
        self.intent_patterns = self._build_intent_patterns()
        self.confidence_threshold = 0.6
        
    def _build_intent_patterns(self) -> Dict[UserIntent, List[str]]:
        """构建意图匹配模式"""
        return {
            UserIntent.CREATE_TASK: [
                "创建任务", "新建任务", "添加任务", "增加任务",
                "create task", "add task", "new task",
                "帮我记一下", "提醒我"
            ],
            UserIntent.UPDATE_TASK: [
                "修改任务", "更新任务", "编辑任务", "改一下",
                "update task", "edit task", "modify task",
                "把.*改成", "调整"
            ],
            UserIntent.DELETE_TASK: [
                "删除任务", "移除任务", "取消任务", "删掉",
                "delete task", "remove task", "cancel task"
            ],
            UserIntent.QUERY_TASK: [
                "查询任务", "查看任务", "任务详情", "显示任务",
                "show task", "view task", "task details",
                "告诉我.*的情况"
            ],
            UserIntent.LIST_TASKS: [
                "列出任务", "所有任务", "任务列表", "有哪些任务",
                "list tasks", "show all tasks", "what tasks"
            ],
            UserIntent.SORT_TASKS: [
                "排序任务", "重新排序", "优先级排序", "智能排序",
                "sort tasks", "reorder", "prioritize"
            ],
            UserIntent.ADD_DEPENDENCY: [
                "添加依赖", "设置依赖", "依赖于", "前置任务",
                "add dependency", "depends on", "blocker"
            ],
            UserIntent.REMOVE_DEPENDENCY: [
                "移除依赖", "删除依赖", "取消依赖",
                "remove dependency", "delete dependency"
            ],
            UserIntent.QUERY_DEPENDENCIES: [
                "查看依赖", "依赖关系", "前置任务有哪些",
                "query dependencies", "show dependencies"
            ],
            UserIntent.REFER_TO_PREVIOUS: [
                "刚才", "之前", "上一个", "那个", "它",
                "刚才说的", "之前提到的", "the previous one",
                "that one", "it"
            ],
            UserIntent.CLARIFY: [
                "什么意思", "解释一下", "详细说明", "为什么",
                "what do you mean", "explain", "why"
            ],
            UserIntent.CONFIRM: [
                "确认", "是的", "没错", "对", "好",
                "confirm", "yes", "correct", "ok", "sure"
            ],
            UserIntent.CANCEL: [
                "取消", "算了", "不要", "撤销",
                "cancel", "never mind", "abort", "undo"
            ],
            UserIntent.GREETING: [
                "你好", "嗨", "早上好", "下午好", "晚上好",
                "hello", "hi", "hey", "good morning", "good afternoon", "good evening"
            ],
            UserIntent.GENERAL_QUESTION: [
                "怎么", "如何", "什么", "为什么", "多少",
                "how", "what", "why", "when", "where"
            ],
            UserIntent.CHITCHAT: [
                "谢谢", "感谢", "再见", "拜拜",
                "thanks", "thank you", "bye", "goodbye"
            ],
        }
    
    def classify(self, text: str, 
                context: Any = None) -> Tuple[UserIntent, float]:
        """
        分类用户意图
        返回: (意图, 置信度)
        """
        text_lower = text.lower()
        scores = {}
        
        # 基于规则匹配
        for intent, patterns in self.intent_patterns.items():
            score = 0
            for pattern in patterns:
                if pattern.lower() in text_lower:
                    score += 1
            if score > 0:
                scores[intent] = score / len(patterns)
        
        # 上下文增强
        if context:
            context_score = self._context_enhancement(text, context)
            for intent, boost in context_score.items():
                scores[intent] = scores.get(intent, 0) + boost
        
        if not scores:
            return UserIntent.UNKNOWN, 0.0
        
        # 选择最高分
        best_intent = max(scores, key=scores.get)
        confidence = scores[best_intent]
        
        # 如果置信度低于阈值，返回UNKNOWN
        if confidence < self.confidence_threshold:
            return UserIntent.UNKNOWN, confidence
        
        return best_intent, confidence
    
    def _context_enhancement(self, text: str, 
                            context: Any) -> Dict[UserIntent, float]:
        """基于上下文增强意图识别"""
        boost = {}
        
        # 检查是否有指代词
        referential_words = ["它", "那个", "这个", "刚才", "之前", "it", "that", "this"]
        if any(w in text for w in referential_words):
            boost[UserIntent.REFER_TO_PREVIOUS] = 0.3
        
        # 检查是否在等待确认
        if hasattr(context, 'state') and context.state == "awaiting_confirmation":
            if any(w in text for w in ["是", "对", "好", "yes", "ok"]):
                boost[UserIntent.CONFIRM] = 0.5
            elif any(w in text for w in ["不", "算了", "no", "cancel"]):
                boost[UserIntent.CANCEL] = 0.5
        
        # 检查是否在澄清模式
        if hasattr(context, 'state') and context.state == "clarifying":
            boost[UserIntent.CLARIFY] = 0.3
        
        return boost
    
    def batch_classify(self, texts: List[str]) -> List[Tuple[UserIntent, float]]:
        """批量分类"""
        return [self.classify(text) for text in texts]


class IntentClassifierML:
    """基于机器学习的意图分类器"""
    
    def __init__(self, model_path: str = None):
        self.tokenizer = None
        self.model = None
        self.intent_map = {i: intent for i, intent in enumerate(UserIntent)}
        self._load_model(model_path)
    
    def _load_model(self, model_path: str = None):
        """加载模型"""
        try:
            from transformers import AutoTokenizer, AutoModelForSequenceClassification
            
            self.tokenizer = AutoTokenizer.from_pretrained(
                model_path or "distilbert-base-uncased"
            )
            self.model = AutoModelForSequenceClassification.from_pretrained(
                model_path or "distilbert-base-uncased",
                num_labels=len(UserIntent)
            )
        except ImportError:
            print("[WARN] transformers 未安装，ML意图分类器不可用")
        except Exception as e:
            print(f"[WARN] 加载ML意图分类模型失败: {e}")
    
    def predict(self, text: str) -> Tuple[UserIntent, float]:
        """预测意图"""
        if self.model is None or self.tokenizer is None:
            return UserIntent.UNKNOWN, 0.0
        
        try:
            import torch
            
            inputs = self.tokenizer(
                text, 
                return_tensors="pt", 
                truncation=True, 
                padding=True
            )
            
            with torch.no_grad():
                outputs = self.model(**inputs)
                probabilities = torch.softmax(outputs.logits, dim=1)
                predicted_class = torch.argmax(probabilities, dim=1).item()
                confidence = probabilities[0][predicted_class].item()
            
            return self.intent_map[predicted_class], confidence
        except Exception as e:
            print(f"[ERROR] ML意图预测失败: {e}")
            return UserIntent.UNKNOWN, 0.0


@dataclass
class ExtractedEntity:
    """提取的实体"""
    type: str
    value: Any
    raw_text: str
    confidence: float
    start_pos: int
    end_pos: int


class EntityExtractor:
    """实体提取器"""
    
    ENTITY_PATTERNS = {
        "task_id": [
            r"任务[#\s]*(\w+)",
            r"task[#\s]*(\w+)",
            r"#(\w+)"
        ],
        "priority": [
            r"(高|中|低)优先级",
            r"priority\s*(high|medium|low)",
            r"(urgent|important|normal)"
        ],
        "time_duration": [
            r"(\d+)\s*(分钟|小时|天)",
            r"(\d+)\s*(min|hour|day)s?"
        ],
        "deadline": [
            r"截止[时间日期]?[是为]?\s*([\d\-/:年月日\s]+)",
            r"deadline[\s:]*([\d\-/:\s]+)",
            r"due[\s:]*([\d\-/:\s]+)"
        ],
        "task_type": [
            r"类型[是为]?\s*(\w+)",
            r"type[\s:]*(\w+)"
        ]
    }
    
    def __init__(self):
        self.compiled_patterns = {
            entity_type: [re.compile(p, re.IGNORECASE) for p in patterns]
            for entity_type, patterns in self.ENTITY_PATTERNS.items()
        }
    
    def extract(self, text: str) -> List[ExtractedEntity]:
        """提取所有实体"""
        entities = []
        
        for entity_type, patterns in self.compiled_patterns.items():
            for pattern in patterns:
                for match in pattern.finditer(text):
                    value = self._normalize_entity(entity_type, match.group(1))
                    entity = ExtractedEntity(
                        type=entity_type,
                        value=value,
                        raw_text=match.group(0),
                        confidence=0.8,
                        start_pos=match.start(),
                        end_pos=match.end()
                    )
                    entities.append(entity)
        
        # 去重和冲突解决
        entities = self._resolve_conflicts(entities)
        
        return entities
    
    def _normalize_entity(self, entity_type: str, raw_value: str) -> Any:
        """标准化实体值"""
        if entity_type == "priority":
            priority_map = {
                "高": "high", "high": "high", "urgent": "high",
                "中": "medium", "medium": "medium", "normal": "medium",
                "低": "low", "low": "low"
            }
            return priority_map.get(raw_value.lower(), "medium")
        
        elif entity_type == "time_duration":
            # 解析持续时间
            number = int(re.search(r'\d+', raw_value).group())
            if "小时" in raw_value or "hour" in raw_value:
                return timedelta(hours=number)
            elif "天" in raw_value or "day" in raw_value:
                return timedelta(days=number)
            else:
                return timedelta(minutes=number)
        
        elif entity_type == "deadline":
            # 解析时间
            return self._parse_datetime(raw_value)
        
        return raw_value
    
    def _parse_datetime(self, text: str) -> Optional[datetime]:
        """解析日期时间"""
        formats = [
            "%Y-%m-%d %H:%M",
            "%Y/%m/%d %H:%M",
            "%m-%d %H:%M",
            "%H:%M",
            "%Y年%m月%d日"
        ]
        
        for fmt in formats:
            try:
                return datetime.strptime(text.strip(), fmt)
            except ValueError:
                continue
        
        # 相对时间解析
        if "今天" in text or "today" in text:
            return datetime.now().replace(hour=23, minute=59)
        elif "明天" in text or "tomorrow" in text:
            return datetime.now() + timedelta(days=1)
        elif "下周" in text or "next week" in text:
            return datetime.now() + timedelta(weeks=1)
        
        return None
    
    def _resolve_conflicts(self, entities: List[ExtractedEntity]) -> List[ExtractedEntity]:
        """解决实体冲突"""
        # 按位置排序
        entities.sort(key=lambda e: e.start_pos)
        
        # 移除重叠的实体（保留置信度高的）
        filtered = []
        for entity in entities:
            overlap = False
            for existing in filtered:
                if not (entity.end_pos <= existing.start_pos or 
                       entity.start_pos >= existing.end_pos):
                    # 有重叠
                    if entity.confidence > existing.confidence:
                        filtered.remove(existing)
                    else:
                        overlap = True
                        break
            if not overlap:
                filtered.append(entity)
        
        return filtered
    
    def extract_task_references(self, text: str, 
                               available_tasks: List[Dict]) -> List[str]:
        """提取文本中引用的任务"""
        referenced = []
        text_lower = text.lower()
        
        for task in available_tasks:
            # 匹配任务标题
            if task.get('title', '').lower() in text_lower:
                referenced.append(task['id'])
            # 匹配任务ID
            elif task.get('id', '').lower() in text_lower:
                referenced.append(task['id'])
        
        return referenced


# 导出公共接口
__all__ = [
    'UserIntent',
    'IntentType',
    'IntentClassifier',
    'IntentClassifierML',
    'ExtractedEntity',
    'EntityExtractor'
]
