"""
AI智能排序算法优化版本
基于开发文档《AI排序算法优化开发文档.md》实现

优化维度：
1. 时间压力指数（预估/剩余时间）
2. 关键词否定词处理
3. 用户行为学习
4. 时间上下文感知
5. 统一分数范围
6. 精力匹配度
7. 校园场景增强（新增）

输出范围: [0, 100]
"""

import math
import re
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Set, Union

# 导入校园场景增强模块
try:
    from .campus_ai_enhancer import enhance_ai_score_for_campus, get_campus_enhancement_explanation
    from .campus_keywords import detect_campus_scenario, get_campus_scenario_name
    CAMPUS_SUPPORT = True
except ImportError:
    CAMPUS_SUPPORT = False


class OptimizedAISorter:
    """优化版AI任务排序器"""
    
    # 优化后的权重配置（6维度）
    DEFAULT_WEIGHTS = {
        'time_pressure': 0.25,      # 时间压力指数
        'priority': 0.20,           # 任务优先级
        'energy_match': 0.15,       # 精力匹配度
        'user_preference': 0.20,    # 用户行为偏好
        'semantic_importance': 0.15, # 语义重要性
        'context_fit': 0.05         # 上下文适配度
    }
    
    # 正面关键词及其权重
    POSITIVE_KEYWORDS = {
        '紧急': 1.0, 'urgent': 1.0,
        '重要': 0.9, 'important': 0.9,
        '关键': 0.9, 'critical': 0.9, 'key': 0.9,
        '必须': 0.8, 'must': 0.8, 'required': 0.8,
        '尽快': 0.7, 'asap': 0.7, 'soon': 0.6,
        '优先': 0.8, 'priority': 0.8,
        '截止': 0.8, 'deadline': 0.8,
        '考试': 0.9, '面试': 0.8,
        '客户': 0.7, 'customer': 0.7,
        '交付': 0.8, 'deliver': 0.8
    }
    
    # 否定词列表
    NEGATIVE_WORDS = ['不', '没', '无', '非', 'not', 'no', "don't", "doesn't", "didn't", "won't", "wouldn't"]
    
    # 程度修饰词
    INTENSITY_WORDS = {
        '非常': 1.3, '极其': 1.4, '特别': 1.2, '十分': 1.25,
        'very': 1.3, 'extremely': 1.4, 'especially': 1.25,
        '有点': 0.7, '稍微': 0.6, '略': 0.75,
        'a bit': 0.7, 'slightly': 0.6, 'somewhat': 0.75
    }
    
    # 任务类型与精力需求映射
    TASK_ENERGY_MAP = {
        'creative': 8,      # 创造性工作
        'analytical': 7,    # 分析性工作
        'routine': 3,       # 常规工作
        'meeting': 4,       # 会议
        'learning': 6,      # 学习
        'admin': 2,         # 行政
        '考试': 8,          # 考试
        '工作': 6,          # 工作
        '项目': 7,          # 项目
        '学习': 5,          # 学习
        '健康': 4,          # 健康
        '财务': 5,          # 财务
        '会议': 4,          # 会议
        '生活': 3,          # 生活
        '娱乐': 2           # 娱乐
    }
    
    def __init__(self, weights: Optional[Dict[str, float]] = None):
        self.weights = weights or self.DEFAULT_WEIGHTS.copy()
        self._validate_weights()
    
    def _validate_weights(self):
        """验证权重配置"""
        required_keys = set(self.DEFAULT_WEIGHTS.keys())
        
        # 补充缺失维度
        for key in required_keys:
            if key not in self.weights:
                self.weights[key] = self.DEFAULT_WEIGHTS[key]
        
        # 归一化
        total = sum(self.weights.values())
        if total > 0 and not 0.99 <= total <= 1.01:
            factor = 1.0 / total
            for key in self.weights:
                self.weights[key] = round(self.weights[key] * factor, 4)
    
    def calculate_time_pressure_index(self, task: Dict[str, Any]) -> float:
        """
        计算时间压力指数 (0-100)
        时间压力 = (预估耗时 / 剩余时间) × 紧迫系数 × 截止时间衰减
        """
        end_time_str = task.get('end_time') or task.get('start_time')
        
        if not end_time_str:
            return 50.0  # 无截止时间，中等压力
        
        try:
            if isinstance(end_time_str, str):
                end_time = datetime.fromisoformat(end_time_str.replace('Z', '+00:00'))
            else:
                end_time = end_time_str
        except:
            return 50.0
        
        if end_time is None:
            return 50.0
            
        now: datetime = datetime.now()
        remaining_seconds: float = (end_time - now).total_seconds()
        
        if remaining_seconds <= 0:
            return 100.0  # 已逾期，最高压力
        
        remaining_minutes = remaining_seconds / 60
        
        # 获取预估耗时（分钟）
        estimated_minutes = self._get_estimated_duration(task)
        
        # 基础压力比（预估耗时 / 剩余时间）
        pressure_ratio = estimated_minutes / max(remaining_minutes, estimated_minutes * 0.1)
        
        # 紧迫系数（非线性，剩余时间越短系数越高）
        hours_remaining = remaining_minutes / 60
        if hours_remaining < 1:
            urgency_coefficient = 2.0
        elif hours_remaining < 4:
            urgency_coefficient = 1.5
        elif hours_remaining < 24:
            urgency_coefficient = 1.2
        elif hours_remaining < 72:
            urgency_coefficient = 1.0
        else:
            urgency_coefficient = 0.8
        
        # 截止时间衰减（指数衰减，鼓励提前完成）
        deadline_decay = 1 + math.exp(-remaining_minutes / 60 / 24)
        
        # 计算最终时间压力指数
        time_pressure = pressure_ratio * urgency_coefficient * deadline_decay * 50
        
        return min(max(time_pressure, 0), 100)
    
    def _get_estimated_duration(self, task: Dict[str, Any]) -> float:
        """获取任务预估耗时（分钟）"""
        # 优先使用 estimated_duration 字段
        if task.get('estimated_duration'):
            return float(task['estimated_duration'])
        
        # 其次使用 estimated_hours 字段
        if task.get('estimated_hours'):
            return float(task['estimated_hours']) * 60
        
        # 根据任务类型估算默认值
        category = task.get('category', '')
        default_durations = {
            '考试': 120, '工作': 60, '项目': 90, '学习': 45,
            '健康': 30, '财务': 30, '会议': 30, '生活': 20, '娱乐': 60
        }
        return default_durations.get(category, 30)
    
    def calculate_priority_score(self, task: Dict[str, Any]) -> float:
        """
        计算任务优先级分数 (0-100)
        基于用户设置的优先级 + 分类加成
        """
        # 基础优先级（1-5映射到20-100）
        priority = task.get('priority', 3)
        if priority is None or priority == 0:
            priority = 3
        
        base_score = (priority / 5.0) * 100
        
        # 分类加成
        category = task.get('category', '')
        category_bonus = {
            '考试': 15, '工作': 10, '项目': 10,
            '学习': 8, '健康': 8, '财务': 8,
            '会议': 5, '生活': 0, '娱乐': -10
        }
        
        bonus = 0
        if category in category_bonus:
            bonus = category_bonus[category]
        else:
            # 模糊匹配
            for cat, b in category_bonus.items():
                if cat in category:
                    bonus = b
                    break
        
        return min(max(base_score + bonus, 0), 100)
    
    def calculate_energy_match(self, task: Dict[str, Any], user_context: Optional[Dict] = None) -> float:
        """
        计算精力匹配度 (0-100)
        精力匹配度 = f(任务所需精力, 用户当前精力)
        """
        # 任务所需精力 (1-10)
        task_energy = self._assess_task_energy(task)
        
        # 用户当前精力 (默认5，中等)
        user_energy = 5
        if user_context and 'current_energy' in user_context:
            user_energy = user_context['current_energy']
        
        # 计算匹配度
        if task_energy <= user_energy:
            # 任务精力需求 <= 用户精力：较好匹配
            energy_match = 100 - (user_energy - task_energy) * 5
        else:
            # 任务精力需求 > 用户精力：匹配度下降
            deficit = task_energy - user_energy
            energy_match = max(100 - deficit * 15, 20)
        
        return min(max(energy_match, 0), 100)
    
    def _assess_task_energy(self, task: Dict[str, Any]) -> int:
        """评估任务所需精力 (1-10)"""
        category = task.get('category', '')
        
        # 基础精力需求
        energy = self.TASK_ENERGY_MAP.get(category, 5)
        
        # 根据预估耗时调整
        duration = self._get_estimated_duration(task)
        if duration > 120:  # 超过2小时
            energy += 2
        elif duration > 60:  # 超过1小时
            energy += 1
        
        # 根据标题/描述中的关键词调整
        text = (task.get('title', '') + ' ' + task.get('description', '')).lower()
        high_energy_keywords = ['复杂', '困难', '挑战', '复杂', 'difficult', 'complex', 'challenge']
        low_energy_keywords = ['简单', '快速', 'easy', 'quick', 'simple']
        
        for keyword in high_energy_keywords:
            if keyword in text:
                energy += 1
                break
        
        for keyword in low_energy_keywords:
            if keyword in text:
                energy -= 1
                break
        
        return min(max(energy, 1), 10)
    
    def calculate_user_preference(self, task: Dict[str, Any], behavior_data: Optional[Dict] = None) -> float:
        """
        计算用户行为偏好分数 (0-100)
        基于历史行为数据学习用户偏好
        """
        if not behavior_data:
            return 50.0  # 无历史数据，中性分数
        
        preference_score = 50.0
        category = task.get('category', '')
        
        # 分类偏好
        category_preferences = behavior_data.get('category_preferences', {})
        if category in category_preferences:
            # 用户对该分类的历史完成率和偏好
            pref_data = category_preferences[category]
            completion_rate = pref_data.get('completion_rate', 0.5)
            frequency = pref_data.get('frequency', 0)
            
            # 完成率高且频率适中的分类得分更高
            preference_score = completion_rate * 100
            if frequency > 10:  # 经常处理的任务类型
                preference_score *= 1.1
        
        # 时间偏好（用户倾向于在什么时间处理此类任务）
        time_preferences = behavior_data.get('time_preferences', {})
        current_hour = datetime.now().hour
        if category in time_preferences:
            preferred_hours = time_preferences[category]
            if current_hour in preferred_hours:
                preference_score += 10
        
        return min(max(preference_score, 0), 100)
    
    def calculate_semantic_importance(self, task: Dict[str, Any]) -> float:
        """
        计算语义重要性 (0-100)
        含否定词处理和程度修饰
        """
        title = task.get('title', '').lower()
        description = (task.get('description') or '').lower()
        combined_text = title + ' ' + description
        
        semantic_score = 50.0  # 基础分50（中性）
        
        for keyword, weight in self.POSITIVE_KEYWORDS.items():
            if keyword in combined_text:
                # 检查否定
                is_negated = self._check_negation(combined_text, keyword)
                # 检查程度修饰
                intensity = self._check_intensity(combined_text, keyword)
                
                if is_negated:
                    # 被否定：减分（但保留一定基础分）
                    semantic_score -= weight * 30 * intensity
                else:
                    # 未被否定：加分
                    semantic_score += weight * 30 * intensity
        
        return min(max(semantic_score, 0), 100)
    
    def _check_negation(self, text: str, keyword: str) -> bool:
        """检查关键词是否被否定"""
        # 找到关键词位置
        pattern = re.compile(r'[^。！？.!?]*' + re.escape(keyword) + r'[^。！？.!?]*')
        matches = pattern.findall(text)
        
        for match in matches:
            # 检查关键词前3个词内是否有否定词
            words = match.replace(keyword, '').split()
            negation_count = sum(1 for w in words if any(n in w for n in self.NEGATIVE_WORDS))
            if negation_count % 2 == 1:  # 奇数个否定词 = 否定
                return True
        
        return False
    
    def _check_intensity(self, text: str, keyword: str) -> float:
        """检查关键词的程度修饰"""
        # 找到关键词位置
        pattern = re.compile(r'[^。！？.!?]*' + re.escape(keyword) + r'[^。！？.!?]*')
        matches = pattern.findall(text)
        
        intensity = 1.0
        for match in matches:
            for int_word, factor in self.INTENSITY_WORDS.items():
                if int_word in match:
                    intensity = max(intensity, factor)
        
        return intensity
    
    def calculate_context_fit(self, task: Dict[str, Any], user_context: Optional[Dict] = None) -> float:
        """
        计算上下文适配度 (0-100)
        考虑当前时间、用户状态、场景等
        """
        if not user_context:
            return 50.0
        
        fit_score = 50.0
        current_hour = datetime.now().hour
        category = task.get('category', '')
        
        # 工作时间适配 (9-18点)
        is_work_hours = 9 <= current_hour < 18
        
        if is_work_hours:
            # 工作时间：工作、会议、项目类任务适配度高
            if category in ['工作', '会议', '项目']:
                fit_score += 20
            elif category in ['娱乐', '生活']:
                fit_score -= 10
        else:
            # 非工作时间：学习、生活、娱乐类任务适配度高
            if category in ['学习', '生活', '娱乐', '健康']:
                fit_score += 15
            elif category in ['工作', '会议']:
                fit_score -= 5
        
        # 深夜时段 (22-6点)
        is_late_night = current_hour >= 22 or current_hour < 6
        if is_late_night:
            # 深夜降低高难度任务适配度
            task_energy = self._assess_task_energy(task)
            if task_energy >= 7:
                fit_score -= 20
            elif category in ['生活']:
                fit_score += 10
        
        # 用户专注模式
        if user_context.get('focus_mode'):
            # 专注模式下，复杂任务适配度提高
            task_energy = self._assess_task_energy(task)
            if task_energy >= 6:
                fit_score += 15
            else:
                fit_score -= 5
        
        return min(max(fit_score, 0), 100)
    
    def calculate_time_context_factor(self, task: Dict[str, Any], user_context: Optional[Dict] = None) -> float:
        """
        计算时间上下文系数 (0.8-1.2)
        用于调整最终分数
        """
        factor = 1.0
        current_hour = datetime.now().hour
        
        # 深夜时段降低系数
        if current_hour >= 23 or current_hour < 6:
            factor *= 0.9
        
        # 周末调整
        if datetime.now().weekday() >= 5:  # 周六日
            category = task.get('category', '')
            if category in ['工作', '会议']:
                factor *= 0.85
            elif category in ['学习', '娱乐', '生活']:
                factor *= 1.1
        
        # 用户自定义时间偏好
        if user_context and 'preferred_categories' in user_context:
            preferred = user_context['preferred_categories']
            if task.get('category') in preferred:
                factor *= 1.1
        
        return min(max(factor, 0.8), 1.2)
    
    def calculate_personalization_factor(self, task: Dict[str, Any], behavior_data: Optional[Dict] = None) -> float:
        """
        计算个性化系数 (0.9-1.1)
        基于用户历史行为微调
        """
        if not behavior_data:
            return 1.0
        
        factor = 1.0
        category = task.get('category', '')
        
        # 根据用户对该分类的完成率调整
        category_prefs = behavior_data.get('category_preferences', {})
        if category in category_prefs:
            completion_rate = category_prefs[category].get('completion_rate', 0.5)
            # 完成率高，稍微提升；完成率低，稍微降低
            factor += (completion_rate - 0.5) * 0.2
        
        return min(max(factor, 0.9), 1.1)
    
    @staticmethod
    def normalize_to_100(score: float) -> float:
        """
        使用sigmoid函数平滑映射到[0,100]
        使分数分布更合理，避免极端值
        """
        normalized = 100 / (1 + math.exp(-0.05 * (score - 50)))
        return round(normalized, 2)
    
    def calculate_optimized_score(self, task: Dict[str, Any], 
                                   user_context: Optional[Dict] = None,
                                   behavior_data: Optional[Dict] = None,
                                   enable_campus: bool = True) -> Dict[str, Any]:
        """
        计算优化后的AI排序分数
        
        Args:
            task: 任务数据
            user_context: 用户上下文
            behavior_data: 用户行为数据
            enable_campus: 是否启用校园场景增强
        
        Returns:
            {
                'total_score': float,      # 最终分数 (0-100)
                'dimensions': dict,         # 各维度分数
                'factors': dict,            # 调整系数
                'explanation': str,         # 排序解释
                'campus_enhancement': dict  # 校园场景增强信息（新增）
            }
        """
        # 计算6个维度分数
        dimensions = {
            'time_pressure': self.calculate_time_pressure_index(task),
            'priority': self.calculate_priority_score(task),
            'energy_match': self.calculate_energy_match(task, user_context),
            'user_preference': self.calculate_user_preference(task, behavior_data),
            'semantic_importance': self.calculate_semantic_importance(task),
            'context_fit': self.calculate_context_fit(task, user_context)
        }
        
        # 计算加权基础分数
        base_score = sum(
            dimensions[dim] * weight
            for dim, weight in self.weights.items()
        )
        
        # 计算调整系数
        personalization_factor = self.calculate_personalization_factor(task, behavior_data)
        time_context_factor = self.calculate_time_context_factor(task, user_context)
        
        # 应用系数并归一化
        adjusted_score = base_score * personalization_factor * time_context_factor
        final_score = self.normalize_to_100(adjusted_score)
        
        # 校园场景增强
        campus_info = None
        if enable_campus and CAMPUS_SUPPORT:
            final_score = enhance_ai_score_for_campus(task, user_context, final_score)
            campus_explanations = get_campus_enhancement_explanation(task, user_context)
            if campus_explanations:
                campus_info = {
                    'enhanced': True,
                    'reasons': campus_explanations
                }
        
        # 生成解释
        explanation = self._generate_explanation(dimensions, final_score, campus_info)
        
        result = {
            'total_score': final_score,
            'dimensions': dimensions,
            'factors': {
                'personalization': personalization_factor,
                'time_context': time_context_factor
            },
            'explanation': explanation
        }
        
        if campus_info:
            result['campus_enhancement'] = campus_info
        
        return result
    
    def _generate_explanation(self, dimensions: Dict[str, float], total_score: float, campus_info: Dict = None) -> str:
        """生成排序解释"""
        explanations = []
        
        # 找出得分最高的2个维度
        sorted_dims = sorted(dimensions.items(), key=lambda x: x[1], reverse=True)
        
        dim_names = {
            'time_pressure': '时间压力',
            'priority': '任务优先级',
            'energy_match': '精力匹配度',
            'user_preference': '用户偏好',
            'semantic_importance': '语义重要性',
            'context_fit': '上下文适配'
        }
        
        for dim, score in sorted_dims[:2]:
            if score >= 70:
                explanations.append(f"{dim_names.get(dim, dim)}高({score:.0f})")
            elif score <= 30:
                explanations.append(f"{dim_names.get(dim, dim)}低({score:.0f})")
        
        if not explanations:
            explanations.append(f"{dim_names.get(sorted_dims[0][0])}最显著")
        
        # 添加校园场景说明
        if campus_info and campus_info.get('enhanced'):
            campus_reasons = campus_info.get('reasons', [])
            if campus_reasons:
                explanations.append(f"校园场景: {', '.join(campus_reasons[:2])}")
        
        return f"AI得分{total_score:.1f}，主要因{'，'.join(explanations)}"
    
    def sort_tasks(self, tasks: List[Dict[str, Any]], 
                   user_context: Optional[Dict] = None,
                   behavior_data: Optional[Dict] = None) -> List[Dict[str, Any]]:
        """
        对任务列表进行优化后的智能排序
        
        Returns:
            排序后的任务列表，每个任务包含 'ai_sort_score' 和 'ai_score_details'
        """
        scored_tasks = []
        
        for task in tasks:
            score_result = self.calculate_optimized_score(task, user_context, behavior_data)
            
            scored_task = task.copy()
            scored_task['ai_sort_score'] = score_result['total_score']
            scored_task['ai_score_details'] = score_result
            
            scored_tasks.append(scored_task)
        
        # 按AI分数降序排序
        scored_tasks.sort(key=lambda x: x['ai_sort_score'], reverse=True)
        
        return scored_tasks


# 全局排序器实例
optimized_sorter = OptimizedAISorter()


def sort_tasks_optimized(tasks: List[Dict[str, Any]], 
                         user_context: Optional[Dict] = None,
                         behavior_data: Optional[Dict] = None,
                         weights: Optional[Dict[str, float]] = None) -> List[Dict[str, Any]]:
    """
    便捷函数：使用优化后的AI排序器对任务排序
    
    Args:
        tasks: 任务列表
        user_context: 用户上下文（当前时间、精力、专注模式等）
        behavior_data: 用户行为数据（历史偏好等）
        weights: 自定义权重配置
    
    Returns:
        排序后的任务列表
    """
    if weights:
        sorter = OptimizedAISorter(weights)
    else:
        sorter = optimized_sorter
    
    return sorter.sort_tasks(tasks, user_context, behavior_data)
