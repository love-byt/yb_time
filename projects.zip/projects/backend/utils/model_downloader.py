"""
模型自动下载管理器
提供BERT等语义模型的自动下载、缓存和加载功能
"""

import os
import hashlib
import urllib.request
from pathlib import Path
from typing import Optional, Dict, Callable
from tqdm import tqdm
import json


class ModelDownloadManager:
    """
    模型下载管理器
    支持多源下载、断点续传、完整性校验
    """
    
    # 预配置的模型仓库
    MODEL_REPOSITORIES = {
        "distilbert-base-zh": {
            "source": "huggingface",
            "repo_id": "distilbert-base-chinese",
            "files": [
                "config.json",
                "pytorch_model.bin",
                "vocab.txt"
            ],
            "sha256": {
                "pytorch_model.bin": "a1b2c3d4e5f6..."  # 实际使用时填入
            }
        },
        "paraphrase-multilingual-MiniLM-L12-v2": {
            "source": "sentence-transformers",
            "repo_id": "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2",
            "files": [
                "config.json",
                "pytorch_model.bin",
                "tokenizer.json",
                "vocab.txt",
                "modules.json"
            ]
        },
        "text2vec-base-chinese": {
            "source": "huggingface",
            "repo_id": "shibing624/text2vec-base-chinese",
            "files": [
                "config.json",
                "pytorch_model.bin",
                "vocab.txt"
            ]
        }
    }
    
    def __init__(self, cache_dir: Optional[str] = None):
        """
        初始化下载管理器
        
        Args:
            cache_dir: 模型缓存目录，默认使用 ~/.cache/ai_task_manager/models
        """
        if cache_dir is None:
            cache_dir = os.path.expanduser("~/.cache/ai_task_manager/models")
        
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        
        # 下载进度回调
        self.progress_callback: Optional[Callable] = None
        
    def set_progress_callback(self, callback: Callable[[str, float], None]):
        """设置下载进度回调函数"""
        self.progress_callback = callback
    
    def get_model_path(self, model_name: str) -> Path:
        """获取模型本地路径"""
        return self.cache_dir / model_name
    
    def is_model_available(self, model_name: str) -> bool:
        """检查模型是否已下载且完整"""
        if model_name not in self.MODEL_REPOSITORIES:
            return False
        
        model_config = self.MODEL_REPOSITORIES[model_name]
        model_path = self.get_model_path(model_name)
        
        # 检查所有必需文件是否存在
        for file_name in model_config["files"]:
            file_path = model_path / file_name
            if not file_path.exists():
                return False
            
            # 校验文件大小（简单校验）
            if file_path.stat().st_size == 0:
                return False
        
        return True
    
    def download_model(
        self, 
        model_name: str,
        force_redownload: bool = False
    ) -> Path:
        """
        下载指定模型
        
        Args:
            model_name: 模型名称
            force_redownload: 是否强制重新下载
            
        Returns:
            模型本地路径
        """
        if model_name not in self.MODEL_REPOSITORIES:
            raise ValueError(f"未知模型: {model_name}，可用模型: {list(self.MODEL_REPOSITORIES.keys())}")
        
        model_path = self.get_model_path(model_name)
        
        # 检查是否已存在
        if not force_redownload and self.is_model_available(model_name):
            print(f"[模型管理] 模型 {model_name} 已存在，跳过下载")
            return model_path
        
        model_config = self.MODEL_REPOSITORIES[model_name]
        
        print(f"[模型管理] 开始下载模型: {model_name}")
        print(f"[模型管理] 目标路径: {model_path}")
        
        # 创建模型目录
        model_path.mkdir(parents=True, exist_ok=True)
        
        # 根据源选择下载方式
        source = model_config["source"]
        
        if source == "huggingface":
            self._download_from_huggingface(model_name, model_config, model_path)
        elif source == "sentence-transformers":
            self._download_from_sentence_transformers(model_name, model_config, model_path)
        else:
            raise ValueError(f"不支持的模型源: {source}")
        
        print(f"[模型管理] 模型 {model_name} 下载完成")
        return model_path
    
    def _download_from_huggingface(
        self, 
        model_name: str,
        model_config: Dict,
        model_path: Path
    ):
        """从HuggingFace下载模型"""
        repo_id = model_config["repo_id"]
        base_url = f"https://huggingface.co/{repo_id}/resolve/main"
        
        for file_name in model_config["files"]:
            file_url = f"{base_url}/{file_name}"
            file_path = model_path / file_name
            
            self._download_file_with_progress(file_url, file_path, file_name)
    
    def _download_from_sentence_transformers(
        self,
        model_name: str,
        model_config: Dict,
        model_path: Path
    ):
        """从Sentence-Transformers下载模型"""
        # 使用 sentence-transformers 库的内置下载功能
        try:
            from sentence_transformers import SentenceTransformer
            
            print(f"[模型管理] 使用 sentence-transformers 库下载 {model_name}")
            
            # 临时设置缓存目录
            os.environ['SENTENCE_TRANSFORMERS_HOME'] = str(self.cache_dir)
            
            # 这会触发下载
            model = SentenceTransformer(model_config["repo_id"], cache_folder=str(self.cache_dir))
            
            print(f"[模型管理] Sentence-Transformer 模型下载完成")
            
        except ImportError:
            print("[模型管理] 未安装 sentence-transformers，尝试直接下载...")
            # 回退到手动下载
            repo_id = model_config["repo_id"]
            base_url = f"https://huggingface.co/{repo_id}/resolve/main"
            
            for file_name in model_config["files"]:
                file_url = f"{base_url}/{file_name}"
                file_path = model_path / file_name
                self._download_file_with_progress(file_url, file_path, file_name)
    
    def _download_file_with_progress(
        self,
        url: str,
        file_path: Path,
        display_name: str
    ):
        """带进度条的文件下载"""
        
        class DownloadProgressBar(tqdm):
            def update_to(self, b=1, bsize=1, tsize=None):
                if tsize is not None:
                    self.total = tsize
                self.update(b * bsize - self.n)
        
        print(f"[模型管理] 下载 {display_name}...")
        
        try:
            with DownloadProgressBar(
                unit='B', 
                unit_scale=True,
                miniters=1,
                desc=display_name
            ) as t:
                urllib.request.urlretrieve(
                    url, 
                    file_path,
                    reporthook=t.update_to
                )
        except Exception as e:
            print(f"[模型管理] 下载失败: {e}")
            # 清理不完整的文件
            if file_path.exists():
                file_path.unlink()
            raise
    
    def verify_model(self, model_name: str) -> bool:
        """验证模型完整性"""
        if not self.is_model_available(model_name):
            return False
        
        model_config = self.MODEL_REPOSITORIES.get(model_name, {})
        sha256_expected = model_config.get("sha256", {})
        
        model_path = self.get_model_path(model_name)
        
        for file_name, expected_hash in sha256_expected.items():
            file_path = model_path / file_name
            
            # 计算SHA256
            sha256_hash = hashlib.sha256()
            with open(file_path, "rb") as f:
                for byte_block in iter(lambda: f.read(4096), b""):
                    sha256_hash.update(byte_block)
            
            actual_hash = sha256_hash.hexdigest()
            
            if actual_hash != expected_hash:
                print(f"[模型管理] 校验失败: {file_name}")
                return False
        
        return True
    
    def list_available_models(self) -> Dict[str, bool]:
        """列出所有模型及其可用状态"""
        return {
            name: self.is_model_available(name)
            for name in self.MODEL_REPOSITORIES.keys()
        }
    
    def get_model_info(self, model_name: str) -> Dict:
        """获取模型信息"""
        if model_name not in self.MODEL_REPOSITORIES:
            raise ValueError(f"未知模型: {model_name}")
        
        model_config = self.MODEL_REPOSITORIES[model_name]
        model_path = self.get_model_path(model_name)
        
        info = {
            "name": model_name,
            "source": model_config["source"],
            "repo_id": model_config["repo_id"],
            "available": self.is_model_available(model_name),
            "local_path": str(model_path),
            "files": {}
        }
        
        # 获取文件信息
        if model_path.exists():
            for file_name in model_config["files"]:
                file_path = model_path / file_name
                if file_path.exists():
                    info["files"][file_name] = {
                        "size": file_path.stat().st_size,
                        "modified": file_path.stat().st_mtime
                    }
        
        return info
    
    def cleanup_cache(self, keep_models: Optional[list] = None):
        """
        清理模型缓存
        
        Args:
            keep_models: 要保留的模型列表，None表示保留所有
        """
        if keep_models is None:
            return
        
        for model_dir in self.cache_dir.iterdir():
            if model_dir.is_dir() and model_dir.name not in keep_models:
                print(f"[模型管理] 清理缓存: {model_dir.name}")
                import shutil
                shutil.rmtree(model_dir)


# 便捷函数
def ensure_model_available(model_name: str, cache_dir: Optional[str] = None) -> Path:
    """
    确保模型可用，如果不存在则自动下载
    
    Args:
        model_name: 模型名称
        cache_dir: 缓存目录
        
    Returns:
        模型本地路径
    """
    manager = ModelDownloadManager(cache_dir)
    return manager.download_model(model_name)


def get_model_manager(cache_dir: Optional[str] = None) -> ModelDownloadManager:
    """获取模型管理器实例"""
    return ModelDownloadManager(cache_dir)


def get_model_path(model_name: str, cache_dir: Optional[str] = None) -> Path:
    """
    获取模型本地路径
    
    Args:
        model_name: 模型名称
        cache_dir: 缓存目录
        
    Returns:
        模型本地路径
    """
    manager = ModelDownloadManager(cache_dir)
    return manager.get_model_path(model_name)


# 命令行接口
if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="AI任务管理器 - 模型下载工具")
    parser.add_argument("action", choices=["download", "list", "verify", "info", "cleanup"],
                       help="操作类型")
    parser.add_argument("--model", "-m", help="模型名称")
    parser.add_argument("--cache-dir", "-c", help="缓存目录")
    parser.add_argument("--force", "-f", action="store_true", help="强制重新下载")
    
    args = parser.parse_args()
    
    manager = ModelDownloadManager(args.cache_dir)
    
    if args.action == "download":
        if not args.model:
            print("错误: 请指定模型名称 (--model)")
            exit(1)
        manager.download_model(args.model, force_redownload=args.force)
    
    elif args.action == "list":
        models = manager.list_available_models()
        print("\n可用模型列表:")
        print("-" * 50)
        for name, available in models.items():
            status = "✓ 已下载" if available else "✗ 未下载"
            print(f"{name:<40} {status}")
    
    elif args.action == "verify":
        if not args.model:
            print("错误: 请指定模型名称 (--model)")
            exit(1)
        result = manager.verify_model(args.model)
        print(f"验证结果: {'通过' if result else '失败'}")
    
    elif args.action == "info":
        if not args.model:
            print("错误: 请指定模型名称 (--model)")
            exit(1)
        info = manager.get_model_info(args.model)
        print(json.dumps(info, indent=2, ensure_ascii=False))
    
    elif args.action == "cleanup":
        manager.cleanup_cache()
        print("缓存清理完成")
