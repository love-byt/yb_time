"""
行为树对话管理系统
结合状态机和行为树的优点，实现复杂的对话流程控制
"""

import asyncio
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, Callable, Dict, List, Optional, Tuple, Union

from utils.intent_recognition import UserIntent
from utils.dialogue_history import DialogueSession, Message


class NodeStatus(Enum):
    """行为树节点状态"""
    SUCCESS = auto()  # 成功
    FAILURE = auto()  # 失败
    RUNNING = auto()  # 运行中（需要继续执行）


class DialogueContext:
    """
    对话上下文
    存储对话过程中的状态和数据
    """
    
    def __init__(self):
        self.user_input: str = ""
        self.intent: Optional[UserIntent] = None
        self.intent_confidence: float = 0.0
        self.collected_data: Dict[str, Any] = {}
        self.session: Optional[DialogueSession] = None
        self.current_task: Optional[Dict] = None
        self.pending_action: Optional[str] = None
        self.executed_actions: set = set()
        self.response_queue: List[str] = []
        self.state_data: Dict[str, Any] = {}
        
    def update(self, user_input: str, session: DialogueSession):
        """更新上下文"""
        self.user_input = user_input
        self.session = session
        self.executed_actions.clear()
    
    def set_intent(self, intent: Optional[UserIntent], confidence: float) -> None:
        """设置识别的意图
        
        Args:
            intent: 用户意图
            confidence: 置信度（0-1）
        """
        self.intent = intent
        self.intent_confidence = float(confidence) if isinstance(confidence, (int, float)) else 0.0
    
    def has_action_executed(self, action) -> bool:
        """检查动作是否已执行"""
        return id(action) in self.executed_actions
    
    def mark_action_executed(self, action):
        """标记动作已执行"""
        self.executed_actions.add(id(action))
    
    def send_message(self, message: str):
        """发送消息到响应队列"""
        self.response_queue.append(message)
    
    def get_response(self) -> str:
        """获取响应"""
        if self.response_queue:
            return self.response_queue.pop(0)
        return ""
    
    def has_response(self) -> bool:
        """检查是否有待发送响应"""
        return len(self.response_queue) > 0
    
    def set_data(self, key: str, value: Any):
        """设置数据"""
        self.state_data[key] = value
    
    def get_data(self, key: str, default=None) -> Any:
        """获取数据"""
        return self.state_data.get(key, default)


class BTNode(ABC):
    """行为树节点基类"""
    
    @abstractmethod
    def tick(self, context: DialogueContext) -> NodeStatus:
        """执行节点逻辑"""
        pass
    
    def reset(self):
        """重置节点状态"""
        pass


class Sequence(BTNode):
    """
    顺序节点
    子节点全部成功才算成功，有一个失败就失败
    """
    
    def __init__(self, children: List[BTNode], name: str = "Sequence"):
        self.name = name
        self.children = children
        self.current_index = 0
    
    def tick(self, context: DialogueContext) -> NodeStatus:
        while self.current_index < len(self.children):
            child = self.children[self.current_index]
            status = child.tick(context)
            
            if status == NodeStatus.RUNNING:
                return NodeStatus.RUNNING
            elif status == NodeStatus.FAILURE:
                self.current_index = 0
                return NodeStatus.FAILURE
            
            self.current_index += 1
        
        self.current_index = 0
        return NodeStatus.SUCCESS
    
    def reset(self):
        self.current_index = 0
        for child in self.children:
            child.reset()


class Selector(BTNode):
    """
    选择节点
    有一个子节点成功就算成功，全部失败才失败
    """
    
    def __init__(self, children: List[BTNode], name: str = "Selector"):
        self.name = name
        self.children = children
        self.current_index = 0
    
    def tick(self, context: DialogueContext) -> NodeStatus:
        while self.current_index < len(self.children):
            child = self.children[self.current_index]
            status = child.tick(context)
            
            if status == NodeStatus.RUNNING:
                return NodeStatus.RUNNING
            elif status == NodeStatus.SUCCESS:
                self.current_index = 0
                return NodeStatus.SUCCESS
            
            self.current_index += 1
        
        self.current_index = 0
        return NodeStatus.FAILURE
    
    def reset(self):
        self.current_index = 0
        for child in self.children:
            child.reset()


class Parallel(BTNode):
    """
    并行节点
    同时执行所有子节点
    """
    
    def __init__(self, children: List[BTNode], 
                 success_threshold: int = None,
                 name: str = "Parallel"):
        self.name = name
        self.children = children
        self.success_threshold = success_threshold or len(children)
        self.child_statuses: Dict[int, NodeStatus] = {}
    
    def tick(self, context: DialogueContext) -> NodeStatus:
        success_count = 0
        failure_count = 0
        
        for i, child in enumerate(self.children):
            if i not in self.child_statuses:
                self.child_statuses[i] = NodeStatus.RUNNING
            
            if self.child_statuses[i] == NodeStatus.RUNNING:
                status = child.tick(context)
                self.child_statuses[i] = status
            
            if self.child_statuses[i] == NodeStatus.SUCCESS:
                success_count += 1
            elif self.child_statuses[i] == NodeStatus.FAILURE:
                failure_count += 1
        
        if success_count >= self.success_threshold:
            self.child_statuses.clear()
            return NodeStatus.SUCCESS
        elif failure_count > len(self.children) - self.success_threshold:
            self.child_statuses.clear()
            return NodeStatus.FAILURE
        
        return NodeStatus.RUNNING
    
    def reset(self):
        self.child_statuses.clear()
        for child in self.children:
            child.reset()


class Condition(BTNode):
    """条件节点"""
    
    def __init__(self, check: Callable[[DialogueContext], bool], 
                 name: str = "Condition"):
        self.name = name
        self.check = check
    
    def tick(self, context: DialogueContext) -> NodeStatus:
        return NodeStatus.SUCCESS if self.check(context) else NodeStatus.FAILURE


class Action(BTNode):
    """
    动作节点
    执行具体的对话动作
    """
    
    def __init__(self, 
                 execute: Callable[[DialogueContext], NodeStatus],
                 prompt: Optional[str] = None,
                 name: str = "Action"):
        self.name = name
        self.execute = execute
        self.prompt = prompt
        self._prompt_sent = False
    
    def tick(self, context: DialogueContext) -> NodeStatus:
        # 如果有提示且未发送，先发送提示
        if self.prompt and not self._prompt_sent and not context.has_action_executed(self):
            context.send_message(self.prompt)
            context.mark_action_executed(self)
            self._prompt_sent = True
            return NodeStatus.RUNNING
        
        # 执行动作
        result = self.execute(context)
        
        if result != NodeStatus.RUNNING:
            self._prompt_sent = False
        
        return result
    
    def reset(self):
        self._prompt_sent = False


class Inverter(BTNode):
    """反转节点 - 反转子节点的结果"""
    
    def __init__(self, child: BTNode, name: str = "Inverter"):
        self.name = name
        self.child = child
    
    def tick(self, context: DialogueContext) -> NodeStatus:
        status = self.child.tick(context)
        
        if status == NodeStatus.SUCCESS:
            return NodeStatus.FAILURE
        elif status == NodeStatus.FAILURE:
            return NodeStatus.SUCCESS
        
        return status


class Repeat(BTNode):
    """重复节点 - 重复执行子节点N次"""
    
    def __init__(self, child: BTNode, times: int, name: str = "Repeat"):
        self.name = name
        self.child = child
        self.times = times
        self.current = 0
    
    def tick(self, context: DialogueContext) -> NodeStatus:
        while self.current < self.times:
            status = self.child.tick(context)
            
            if status == NodeStatus.RUNNING:
                return NodeStatus.RUNNING
            elif status == NodeStatus.FAILURE:
                self.current = 0
                return NodeStatus.FAILURE
            
            self.current += 1
        
        self.current = 0
        return NodeStatus.SUCCESS
    
    def reset(self):
        self.current = 0
        self.child.reset()


class HierarchicalDialogueManager:
    """
    分层对话管理器
    结合状态机和行为树的优点
    """
    
    def __init__(self):
        self.context = DialogueContext()
        self.root_behavior_tree = self._build_behavior_tree()
        self.state_stack: List[str] = []
        self.current_state = "idle"
        
        # 意图识别引擎
        from utils.intent_recognition_v2 import IntentRecognitionEngine
        self.intent_engine = IntentRecognitionEngine()
    
    def _build_behavior_tree(self) -> BTNode:
        """构建任务管理行为树"""
        
        # ========== 创建任务分支 ==========
        create_task_branch = Sequence([
            Condition(
                lambda ctx: ctx.intent == UserIntent.CREATE_TASK,
                "IsCreateTask"
            ),
            Selector([
                # 尝试从消息中提取标题
                Action(
                    lambda ctx: self._extract_title(ctx),
                    "",
                    "ExtractTitle"
                ),
                # 如果提取失败，询问用户
                Action(
                    lambda ctx: self._ask_for_title(ctx),
                    "请告诉我任务标题是什么？",
                    "AskForTitle"
                )
            ], "TitleSelector"),
            
            # 可选：收集截止时间
            Selector([
                Sequence([
                    Condition(
                        lambda ctx: self._has_deadline_hint(ctx),
                        "HasDeadlineHint"
                    ),
                    Action(
                        lambda ctx: self._extract_deadline(ctx),
                        "",
                        "ExtractDeadline"
                    )
                ], "ExtractDeadlineSeq"),
                Action(
                    lambda ctx: NodeStatus.SUCCESS,
                    "需要设置截止时间吗？（可选）",
                    "AskForDeadline"
                )
            ], "DeadlineSelector"),
            
            # 可选：收集优先级
            Selector([
                Sequence([
                    Condition(
                        lambda ctx: self._has_priority_hint(ctx),
                        "HasPriorityHint"
                    ),
                    Action(
                        lambda ctx: self._extract_priority(ctx),
                        "",
                        "ExtractPriority"
                    )
                ], "ExtractPrioritySeq"),
                Action(
                    lambda ctx: NodeStatus.SUCCESS,
                    "需要设置优先级吗？（可选：高/中/低）",
                    "AskForPriority"
                )
            ], "PrioritySelector"),
            
            # 确认创建
            Action(
                lambda ctx: self._confirm_creation(ctx),
                "确认创建任务吗？",
                "ConfirmCreation"
            )
        ], "CreateTaskBranch")
        
        # ========== 更新任务分支 ==========
        update_task_branch = Sequence([
            Condition(
                lambda ctx: ctx.intent == UserIntent.UPDATE_TASK,
                "IsUpdateTask"
            ),
            Selector([
                Action(
                    lambda ctx: self._extract_task_reference(ctx),
                    "",
                    "ExtractTaskRef"
                ),
                Action(
                    lambda ctx: self._ask_for_task_reference(ctx),
                    "请告诉我您想修改哪个任务？",
                    "AskForTaskRef"
                )
            ], "TaskRefSelector"),
            Action(
                lambda ctx: self._collect_update_fields(ctx),
                "请告诉我需要修改什么内容？",
                "CollectUpdateFields"
            ),
            Action(
                lambda ctx: self._confirm_update(ctx),
                "确认修改吗？",
                "ConfirmUpdate"
            )
        ], "UpdateTaskBranch")
        
        # ========== 删除任务分支 ==========
        delete_task_branch = Sequence([
            Condition(
                lambda ctx: ctx.intent == UserIntent.DELETE_TASK,
                "IsDeleteTask"
            ),
            Selector([
                Action(
                    lambda ctx: self._extract_task_reference(ctx),
                    "",
                    "ExtractTaskRefDel"
                ),
                Action(
                    lambda ctx: self._ask_for_task_reference(ctx),
                    "请告诉我您想删除哪个任务？",
                    "AskForTaskRefDel"
                )
            ], "TaskRefSelectorDel"),
            Action(
                lambda ctx: self._confirm_deletion(ctx),
                "确认删除该任务吗？此操作不可撤销。",
                "ConfirmDeletion"
            )
        ], "DeleteTaskBranch")
        
        # ========== 查询任务分支 ==========
        query_task_branch = Sequence([
            Condition(
                lambda ctx: ctx.intent in [UserIntent.QUERY_TASK, UserIntent.LIST_TASKS],
                "IsQueryTask"
            ),
            Action(
                lambda ctx: self._execute_query(ctx),
                "",
                "ExecuteQuery"
            )
        ], "QueryTaskBranch")
        
        # ========== 确认/取消分支 ==========
        confirmation_branch = Sequence([
            Condition(
                lambda ctx: ctx.intent in [UserIntent.CONFIRM, UserIntent.CANCEL],
                "IsConfirmation"
            ),
            Action(
                lambda ctx: self._handle_confirmation(ctx),
                "",
                "HandleConfirmation"
            )
        ], "ConfirmationBranch")
        
        # ========== 指代消解分支 ==========
        reference_branch = Sequence([
            Condition(
                lambda ctx: ctx.intent == UserIntent.REFER_TO_PREVIOUS,
                "IsReference"
            ),
            Action(
                lambda ctx: self._resolve_reference(ctx),
                "",
                "ResolveReference"
            )
        ], "ReferenceBranch")
        
        # ========== 根节点选择器 ==========
        root = Selector([
            confirmation_branch,
            reference_branch,
            create_task_branch,
            update_task_branch,
            delete_task_branch,
            query_task_branch,
            # 默认分支：通用对话
            Action(
                lambda ctx: self._handle_general_chat(ctx),
                "",
                "GeneralChat"
            )
        ], "RootSelector")
        
        return root
    
    # ========== 动作实现 ==========
    
    def _extract_title(self, ctx: DialogueContext) -> NodeStatus:
        """从用户输入中提取任务标题"""
        text = ctx.user_input
        
        # 简单的标题提取逻辑
        patterns = [
            r'(?:创建|新建|添加)\s*["""]?([^"""]+)["""]?',
            r'(?:任务叫|标题是|名字是)\s*["""]?([^"""]+)["""]?',
            r'["""]([^"""]+)["""]\s*(?:任务)?',
        ]
        
        import re
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                title = match.group(1).strip()
                ctx.set_data("task_title", title)
                return NodeStatus.SUCCESS
        
        # 如果没有匹配到模式，使用整个输入作为标题（去除常见前缀）
        prefixes = ['创建', '新建', '添加', '任务', 'create', 'add', 'new task']
        title = text
        for prefix in prefixes:
            if title.startswith(prefix):
                title = title[len(prefix):].strip()
        
        if title:
            ctx.set_data("task_title", title)
            return NodeStatus.SUCCESS
        
        return NodeStatus.FAILURE
    
    def _ask_for_title(self, ctx: DialogueContext) -> NodeStatus:
        """询问任务标题"""
        # 设置状态等待用户输入
        ctx.set_data("awaiting", "task_title")
        return NodeStatus.RUNNING
    
    def _has_deadline_hint(self, ctx: DialogueContext) -> bool:
        """检查是否有截止时间提示"""
        text = ctx.user_input.lower()
        deadline_indicators = ['截止', '期限', 'deadline', 'due', '之前完成', '号之前', '号前']
        return any(ind in text for ind in deadline_indicators)
    
    def _extract_deadline(self, ctx: DialogueContext) -> NodeStatus:
        """提取截止时间"""
        # 简化实现，实际应该使用日期解析库
        ctx.set_data("has_deadline_hint", True)
        return NodeStatus.SUCCESS
    
    def _has_priority_hint(self, ctx: DialogueContext) -> bool:
        """检查是否有优先级提示"""
        text = ctx.user_input.lower()
        priority_indicators = ['紧急', '重要', '优先', 'urgent', 'high priority', 'critical']
        return any(ind in text for ind in priority_indicators)
    
    def _extract_priority(self, ctx: DialogueContext) -> NodeStatus:
        """提取优先级"""
        text = ctx.user_input
        if any(w in text for w in ['高', '紧急', 'urgent', 'high']):
            ctx.set_data("priority", "high")
        elif any(w in text for w in ['中', 'medium', 'normal']):
            ctx.set_data("priority", "medium")
        elif any(w in text for w in ['低', '不急', 'low']):
            ctx.set_data("priority", "low")
        return NodeStatus.SUCCESS
    
    def _confirm_creation(self, ctx: DialogueContext) -> NodeStatus:
        """确认创建任务"""
        title = ctx.get_data("task_title", "未命名任务")
        ctx.set_data("awaiting", "confirmation")
        ctx.set_data("pending_action", "create_task")
        ctx.set_data("action_data", {"title": title})
        return NodeStatus.RUNNING
    
    def _extract_task_reference(self, ctx: DialogueContext) -> NodeStatus:
        """提取任务引用"""
        # 简化实现
        text = ctx.user_input
        import re
        
        # 尝试提取任务ID或名称
        patterns = [
            r'["""]([^"""]+)["""]',
            r'任务\s*["""]?([^"""\s]+)["""]?',
            r'#?(\d+)',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                ctx.set_data("task_ref", match.group(1))
                return NodeStatus.SUCCESS
        
        return NodeStatus.FAILURE
    
    def _ask_for_task_reference(self, ctx: DialogueContext) -> NodeStatus:
        """询问任务引用"""
        ctx.set_data("awaiting", "task_reference")
        return NodeStatus.RUNNING
    
    def _collect_update_fields(self, ctx: DialogueContext) -> NodeStatus:
        """收集更新字段"""
        ctx.set_data("awaiting", "update_fields")
        return NodeStatus.RUNNING
    
    def _confirm_update(self, ctx: DialogueContext) -> NodeStatus:
        """确认更新"""
        ctx.set_data("awaiting", "confirmation")
        ctx.set_data("pending_action", "update_task")
        return NodeStatus.RUNNING
    
    def _confirm_deletion(self, ctx: DialogueContext) -> NodeStatus:
        """确认删除"""
        ctx.set_data("awaiting", "confirmation")
        ctx.set_data("pending_action", "delete_task")
        return NodeStatus.RUNNING
    
    def _execute_query(self, ctx: DialogueContext) -> NodeStatus:
        """执行查询"""
        ctx.set_data("action", "query_tasks")
        return NodeStatus.SUCCESS
    
    def _handle_confirmation(self, ctx: DialogueContext) -> NodeStatus:
        """处理确认/取消"""
        if ctx.intent == UserIntent.CONFIRM:
            ctx.set_data("confirmed", True)
        else:
            ctx.set_data("confirmed", False)
        return NodeStatus.SUCCESS
    
    def _resolve_reference(self, ctx: DialogueContext) -> NodeStatus:
        """解析指代"""
        # 简化实现
        ctx.set_data("action", "resolve_reference")
        return NodeStatus.SUCCESS
    
    def _handle_general_chat(self, ctx: DialogueContext) -> NodeStatus:
        """处理通用对话"""
        ctx.set_data("action", "general_chat")
        ctx.set_data("needs_llm_response", True)
        return NodeStatus.SUCCESS
    
    # ========== 公共接口 ==========
    
    async def process(self, user_input: str, 
                     session: DialogueSession) -> Dict[str, Any]:
        """
        处理用户输入
        
        Returns:
            {
                "status": "success|running|error",
                "response": "回复消息",
                "action": "需要执行的动作",
                "data": "动作数据",
                "context": "上下文信息"
            }
        """
        # 1. 更新上下文
        self.context.update(user_input, session)
        
        # 2. 识别意图
        intent_result = await self.intent_engine.recognize(user_input, session)
        self.context.set_intent(intent_result.intent, intent_result.confidence)
        
        # 3. 执行行为树
        status = self.root_behavior_tree.tick(self.context)
        
        # 4. 生成响应
        response = self._generate_response(status)
        
        # 5. 构建结果
        result = {
            "status": self._status_to_string(status),
            "response": response,
            "intent": intent_result.intent.value,
            "intent_confidence": intent_result.confidence,
            "action": self.context.get_data("action"),
            "action_data": self.context.get_data("action_data"),
            "collected_data": self.context.collected_data,
            "awaiting": self.context.get_data("awaiting"),
        }
        
        return result
    
    def _generate_response(self, status: NodeStatus) -> str:
        """根据状态生成响应"""
        if self.context.has_response():
            return self.context.get_response()
        
        if status == NodeStatus.SUCCESS:
            action = self.context.get_data("action")
            if action == "create_task" and self.context.get_data("confirmed"):
                return f"任务已创建：{self.context.get_data('task_title', '')}"
            elif action == "general_chat":
                return "我在听，请继续。"
            return "操作已完成。"
        elif status == NodeStatus.FAILURE:
            return "抱歉，我没有理解您的意思，能再详细说明一下吗？"
        else:  # RUNNING
            return ""
    
    def _status_to_string(self, status: NodeStatus) -> str:
        """状态转字符串"""
        return {
            NodeStatus.SUCCESS: "success",
            NodeStatus.FAILURE: "failure",
            NodeStatus.RUNNING: "running"
        }.get(status, "unknown")
    
    def reset(self):
        """重置对话管理器"""
        self.context = DialogueContext()
        self.root_behavior_tree.reset()
        self.state_stack.clear()
        self.current_state = "idle"


# 导出
__all__ = [
    'HierarchicalDialogueManager',
    'DialogueContext',
    'BTNode',
    'Sequence',
    'Selector',
    'Parallel',
    'Condition',
    'Action',
    'Inverter',
    'Repeat',
    'NodeStatus',
]