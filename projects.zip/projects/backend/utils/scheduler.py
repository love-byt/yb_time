"""
智能提醒调度器
使用APScheduler实现定时任务
"""

import json
import atexit
from datetime import datetime, timedelta
from flask import current_app

try:
    from apscheduler.schedulers.background import BackgroundScheduler
    from apscheduler.triggers.cron import CronTrigger
    APSCHEDULER_AVAILABLE = True
except ImportError:
    APSCHEDULER_AVAILABLE = False
    print("[WARN] APScheduler未安装，定时任务功能将不可用")

from extensions import db
from models.task import Task, Reminder, User


class ReminderScheduler:
    """提醒调度器"""
    
    _instance = None
    scheduler = None
    app = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            if APSCHEDULER_AVAILABLE:
                cls.scheduler = BackgroundScheduler()
        return cls._instance
    
    def init_app(self, app):
        """初始化调度器"""
        if not APSCHEDULER_AVAILABLE:
            print("[WARN] APScheduler不可用，跳过调度器初始化")
            return
        
        self.app = app
        
        # 添加定时任务：每分钟检查一次即将到期的提醒
        self.scheduler.add_job(
            func=self.check_reminders,
            trigger=CronTrigger(minute='*'),
            id='check_reminders',
            name='检查提醒任务',
            replace_existing=True
        )
        
        # 添加定时任务：每天凌晨生成智能提醒
        self.scheduler.add_job(
            func=self.generate_smart_reminders,
            trigger=CronTrigger(hour=0, minute=5),
            id='generate_smart_reminders',
            name='生成智能提醒',
            replace_existing=True
        )
        
        # 添加定时任务：每小时检查即将到期任务并创建提醒
        self.scheduler.add_job(
            func=self.check_upcoming_tasks,
            trigger=CronTrigger(minute=0),
            id='check_upcoming_tasks',
            name='检查即将到期任务',
            replace_existing=True
        )
        
        self.scheduler.start()
        
        # 程序退出时关闭调度器
        atexit.register(lambda: self.scheduler.shutdown() if self.scheduler and self.scheduler.running else None)
        
        print("[SCHEDULER] 提醒调度器已启动")
    
    def check_reminders(self):
        """检查并触发到期的提醒"""
        if not self.app:
            return
        
        with self.app.app_context():
            now = datetime.now()
            
            # 查找已到期但未触发的提醒
            due_reminders = Reminder.query.filter(
                Reminder.remind_time <= now,
                Reminder.is_sent == 0
            ).all()
            
            for reminder in due_reminders:
                # 发送推送通知
                self.send_push_notification(reminder)
                
                # 标记为已触发
                reminder.is_sent = 1
                db.session.commit()
                
                print(f"[REMINDER] 提醒已触发: 任务ID {reminder.task_id}")
    
    def generate_smart_reminders(self):
        """为所有用户的即将到期任务生成智能提醒"""
        if not self.app:
            return
        
        with self.app.app_context():
            now = datetime.now()
            
            # 获取未来24小时内到期的任务
            upcoming_tasks = Task.query.filter(
                Task.is_completed == 0,
                Task.end_time.isnot(None)
            ).all()
            
            for task in upcoming_tasks:
                try:
                    end_time = self.parse_end_time(task.end_time)
                    if not end_time:
                        continue
                    
                    time_left = end_time - now
                    
                    # 根据剩余时间和优先级决定提醒策略
                    if time_left <= timedelta(hours=2) and task.priority >= 4:
                        # 高优先级且2小时内到期：立即提醒
                        self.create_reminder(task, now + timedelta(minutes=5), 'urgent')
                    elif time_left <= timedelta(hours=24) and task.priority >= 3:
                        # 中优先级且24小时内到期：提前提醒
                        self.create_reminder(task, end_time - timedelta(hours=2), 'warning')
                    elif time_left <= timedelta(days=3) and time_left > timedelta(hours=24):
                        # 3天内到期：提前一天提醒
                        self.create_reminder(task, end_time - timedelta(days=1), 'info')
                        
                except Exception as e:
                    print(f"生成提醒失败: {e}")
                    continue
    
    def check_upcoming_tasks(self):
        """检查即将到期的任务并创建提醒"""
        if not self.app:
            return
        
        with self.app.app_context():
            now = datetime.now()
            
            # 获取未来2小时内到期的任务
            tasks = Task.query.filter(
                Task.is_completed == 0,
                Task.end_time.isnot(None)
            ).all()
            
            for task in tasks:
                try:
                    end_time = self.parse_end_time(task.end_time)
                    if not end_time:
                        continue
                    
                    time_left = end_time - now
                    
                    if timedelta(0) < time_left <= timedelta(hours=2):
                        # 检查是否已存在提醒
                        existing = Reminder.query.filter_by(task_id=task.id).first()
                        if not existing:
                            self.create_reminder(
                                task, 
                                now + timedelta(minutes=10),
                                'deadline_approaching'
                            )
                except Exception as e:
                    print(f"检查任务失败: {e}")
                    continue
    
    def parse_end_time(self, end_time_str):
        """解析截止时间字符串"""
        if not end_time_str:
            return None
        
        try:
            # 尝试多种格式解析
            formats = [
                '%Y-%m-%dT%H:%M',
                '%Y-%m-%dT%H:%M:%S',
                '%Y-%m-%dT%H:%M:%S.%f',
                '%Y-%m-%d %H:%M:%S',
                '%Y-%m-%d %H:%M',
            ]
            
            for fmt in formats:
                try:
                    return datetime.strptime(end_time_str.replace('Z', ''), fmt)
                except ValueError:
                    continue
            
            # 尝试ISO格式
            if 'T' in end_time_str:
                return datetime.fromisoformat(end_time_str.replace('Z', '+00:00').replace('+00:00', ''))
            
            return None
        except Exception as e:
            print(f"解析时间失败: {end_time_str}, {e}")
            return None
    
    def create_reminder(self, task, remind_time, remind_type='before'):
        """创建提醒"""
        # 检查是否已存在相同时间的提醒
        existing = Reminder.query.filter(
            Reminder.task_id == task.id,
            Reminder.remind_time == remind_time
        ).first()
        
        if existing:
            return
        
        # 确保 task 有 user_id
        if not task.user_id:
            return
        
        reminder = Reminder(
            user_id=task.user_id,
            task_id=task.id,
            remind_time=remind_time,
            remind_type=remind_type,
            is_sent=0
        )
        
        db.session.add(reminder)
        db.session.commit()
        print(f"[REMINDER] 创建提醒: 任务 '{task.title}' - {remind_time}")
    
    def send_push_notification(self, reminder):
        """发送浏览器推送通知"""
        task = Task.query.get(reminder.task_id)
        if not task:
            return False, "任务不存在"
        
        user = User.query.get(task.user_id)
        if not user:
            return False, "用户不存在"
        
        if not user.push_subscription:
            return False, "用户未订阅推送通知"
        
        # 使用推送通知工具模块发送
        from utils.push_notification import send_task_reminder
        
        success, message = send_task_reminder(user, task)
        
        if success:
            print(f"[PUSH] 推送通知已发送: {task.title}")
        else:
            print(f"[PUSH] 推送通知发送失败: {message}")
        
        return success, message


# 单例实例
scheduler = ReminderScheduler()
