"""
上下文推理引擎模块
提供指代消解、上下文推理和对话管理功能
"""

import hashlib
import uuid
from typing import Any, Dict, List, Optional

from utils.dialogue_history import (
    DialogueHistoryStore, DialogueSession, Message, 
    MessageType, IntentType, ContextCompressor
)
from utils.task_dependency import TaskDependencyGraph
from utils.intent_recognition import (
    IntentClassifier, EntityExtractor, UserIntent
)
from utils.dialogue_state_machine import DialogueStateMachine


class ReferenceResolver:
    """指代消解器"""
    
    def __init__(self, session: DialogueSession):
        self.session = session
        self.referential_map = {
            "它": "last_task",
            "那个": "last_task",
            "这个": "last_task",
            "刚才": "last_action",
            "之前": "previous_topic",
            "上一个": "last_item",
            "it": "last_task",
            "that": "last_task",
            "this": "last_task"
        }
    
    def resolve(self, text: str) -> Optional[str]:
        """解析文本中的指代词"""
        # 获取最近的消息
        recent = self.session.get_recent_context(3)
        
        for word, ref_type in self.referential_map.items():
            if word in text:
                resolved = self._resolve_by_type(ref_type, recent, text)
                if resolved:
                    return resolved
        
        return None
    
    def _resolve_by_type(self, ref_type: str, recent_messages: List[Message], 
                        original_text: str) -> Optional[str]:
        """根据指代类型解析"""
        if ref_type == "last_task" and recent_messages:
            # 查找最近提到的任务
            for msg in reversed(recent_messages):
                if 'task_id' in msg.entities:
                    return original_text.replace(
                        next(w for w in self.referential_map.keys() if w in original_text),
                        msg.entities['task_id']
                    )
        
        elif ref_type == "last_action" and recent_messages:
            # 使用上一次的意图
            last_msg = recent_messages[-1]
            if last_msg.intent:
                # 移除指代词，保留其余内容
                for word in ["刚才", "之前"]:
                    if word in original_text:
                        return original_text.replace(word, "")
        
        elif ref_type == "previous_topic" and recent_messages:
            # 返回上下文摘要
            return f"关于{self.session.context_summary}，{original_text}"
        
        return None


class ContextInferenceEngine:
    """上下文推理引擎"""
    
    def __init__(self, user_id: str, db_path: str = None):
        self.user_id = user_id
        self.session_id = self._generate_session_id()
        
        # 初始化各模块
        if db_path:
            self.history_store = DialogueHistoryStore(db_path)
        else:
            # 使用默认路径
            import os
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            db_path = os.path.join(base_dir, '..', 'instance', 'dialogue_history.db')
            self.history_store = DialogueHistoryStore(db_path)
            
        self.task_graph = TaskDependencyGraph()
        self.intent_classifier = IntentClassifier()
        self.entity_extractor = EntityExtractor()
        self.state_machine = DialogueStateMachine()
        self.context_compressor = ContextCompressor()
        
        # 加载或创建会话
        self.session = self._load_or_create_session()
        
    def _generate_session_id(self) -> str:
        """生成会话ID"""
        return str(uuid.uuid4())
    
    def _load_or_create_session(self) -> DialogueSession:
        """加载或创建新会话"""
        session = self.history_store.load_session(self.session_id)
        if session:
            return session
        
        return DialogueSession(
            session_id=self.session_id,
            user_id=self.user_id,
            created_at=__import__('datetime').datetime.now(),
            updated_at=__import__('datetime').datetime.now()
        )
    
    def process_message(self, user_input: str) -> Dict[str, Any]:
        """处理用户消息 - 主入口"""
        
        # 1. 创建消息对象
        message = Message(
            id=self._generate_message_id(),
            session_id=self.session_id,
            type=MessageType.USER,
            content=user_input,
            timestamp=__import__('datetime').datetime.now()
        )
        
        # 2. 意图识别
        intent, confidence = self.intent_classifier.classify(
            user_input, self.session
        )
        message.intent = IntentType(intent.value) if hasattr(intent, 'value') else None
        
        # 3. 实体提取
        entities = self.entity_extractor.extract(user_input)
        message.entities = {e.type: str(e.value) for e in entities}
        
        # 4. 处理指代消解
        if intent == UserIntent.REFER_TO_PREVIOUS:
            resolver = ReferenceResolver(self.session)
            resolved_input = resolver.resolve(user_input)
            if resolved_input:
                user_input = resolved_input
                # 重新识别意图
                intent, confidence = self.intent_classifier.classify(user_input)
                message.intent = IntentType(intent.value) if hasattr(intent, 'value') else None
        
        # 5. 状态机处理
        response = self.state_machine.process(
            user_input, intent, entities, self.session
        )
        
        # 6. 执行动作
        if response.get('action'):
            action_result = self._execute_action(
                response['action'], 
                message.entities
            )
            response['action_result'] = action_result
        
        # 7. 生成语义向量
        message.context_vector = self._generate_embedding(user_input)
        
        # 8. 保存消息
        self.session.add_message(message)
        self.history_store.save_message(message)
        
        # 9. 更新会话状态
        self.session.state = response['current_state']
        self.history_store.save_session(self.session)
        
        # 10. 上下文压缩（如果消息过多）
        if len(self.session.messages) > 50:
            self._compress_context()
        
        # 添加推理信息到响应
        response['intent'] = intent.value
        response['confidence'] = confidence
        response['entities'] = message.entities
        
        return response
    
    def _execute_action(self, action: str, params: Dict) -> Dict:
        """执行动作"""
        try:
            if action == "create_task":
                return self._action_create_task(params)
            elif action == "update_task":
                return self._action_update_task(params)
            elif action == "delete_task":
                return self._action_delete_task(params)
            elif action == "list_tasks":
                return self._action_list_tasks(params)
            elif action == "sort_tasks":
                return self._action_sort_tasks(params)
            elif action == "add_dependency":
                return self._action_add_dependency(params)
            else:
                return {"success": False, "error": "未知动作"}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def _action_create_task(self, params: Dict) -> Dict:
        """创建任务动作"""
        task_id = self._generate_task_id()
        
        # 添加到任务图
        self.task_graph.add_task(task_id, params)
        
        return {
            "success": True,
            "task_id": task_id,
            "message": f"任务 {params.get('title', '未命名')} 创建成功"
        }
    
    def _action_update_task(self, params: Dict) -> Dict:
        """更新任务动作"""
        task_id = params.get('task_id')
        if task_id and task_id in self.task_graph.nodes:
            self.task_graph.nodes[task_id].task_data.update(params)
            return {
                "success": True,
                "message": f"任务 {task_id} 更新成功"
            }
        return {"success": False, "error": "任务不存在"}
    
    def _action_delete_task(self, params: Dict) -> Dict:
        """删除任务动作"""
        task_id = params.get('task_id')
        if task_id and task_id in self.task_graph.nodes:
            del self.task_graph.nodes[task_id]
            return {
                "success": True,
                "message": f"任务 {task_id} 删除成功"
            }
        return {"success": False, "error": "任务不存在"}
    
    def _action_list_tasks(self, params: Dict) -> Dict:
        """列出任务动作"""
        tasks = [
            {
                "id": tid,
                "data": node.task_data,
                "status": node.status
            }
            for tid, node in self.task_graph.nodes.items()
        ]
        return {
            "success": True,
            "tasks": tasks,
            "count": len(tasks)
        }
    
    def _action_sort_tasks(self, params: Dict) -> Dict:
        """排序任务动作"""
        try:
            order = self.task_graph.topological_sort()
            return {
                "success": True,
                "order": order,
                "message": "任务已按依赖关系排序"
            }
        except ValueError as e:
            return {
                "success": False,
                "error": str(e),
                "cycles": self.task_graph.detect_cycles()
            }
    
    def _action_add_dependency(self, params: Dict) -> Dict:
        """添加依赖动作"""
        from_task = params.get('from_task')
        to_task = params.get('to_task')
        
        if from_task and to_task:
            try:
                self.task_graph.add_dependency(from_task, to_task)
                return {
                    "success": True,
                    "message": f"已设置 {to_task} 为 {from_task} 的前置任务"
                }
            except ValueError as e:
                return {"success": False, "error": str(e)}
        
        return {"success": False, "error": "缺少任务ID"}
    
    def _generate_embedding(self, text: str) -> List[float]:
        """生成文本嵌入向量（简化版）"""
        # 实际实现应调用嵌入模型
        # 这里返回基于哈希的模拟向量
        hash_val = int(hashlib.md5(text.encode()).hexdigest(), 16)
        return [float((hash_val >> i) % 1000) / 1000 for i in range(0, 128, 4)]
    
    def _compress_context(self):
        """压缩上下文"""
        summary = self.context_compressor.compress_session(self.session)
        self.session.context_summary = summary
        
        # 保存快照
        self.history_store.save_snapshot(self.session)
        
        # 清理旧消息（保留最近10条）
        self.session.messages = self.session.messages[-10:]
    
    def get_task_execution_plan(self) -> Dict:
        """获取任务执行计划"""
        try:
            order = self.task_graph.topological_sort()
            critical_path = self.task_graph.get_critical_path()
            parallel_groups = self.task_graph.get_parallel_groups()
            
            return {
                "execution_order": order,
                "critical_path": critical_path,
                "parallel_groups": [list(g) for g in parallel_groups],
                "total_tasks": len(order)
            }
        except ValueError as e:
            return {"error": str(e), "cycles": self.task_graph.detect_cycles()}
    
    def get_dialogue_context(self) -> Dict:
        """获取当前对话上下文"""
        return {
            "session_id": self.session_id,
            "message_count": len(self.session.messages),
            "current_state": self.session.state,
            "context_summary": self.session.context_summary,
            "active_tasks": self.session.active_tasks,
            "recent_messages": [m.to_dict() for m in self.session.get_recent_context(5)]
        }
    
    def _generate_message_id(self) -> str:
        """生成消息ID"""
        return str(uuid.uuid4())
    
    def _generate_task_id(self) -> str:
        """生成任务ID"""
        return f"task_{str(uuid.uuid4())[:8]}"


# 导出公共接口
__all__ = [
    'ReferenceResolver',
    'ContextInferenceEngine'
]
