"""
任务难度自动评估器
基于任务标题、描述、分类自动评估难度等级
"""

from __future__ import annotations
import re
from typing import Optional


class DifficultyEvaluator:
    """任务难度评估器"""
    
    # 难度关键词
    DIFFICULTY_KEYWORDS = {
        'very_hard': [
            '考试', '答辩', '面试', '汇报', '演讲', '竞赛',
            '项目', '论文', '研究', '开发', '设计',
            'exam', 'defense', 'interview', 'presentation', 'competition'
        ],
        'hard': [
            '复习', '学习', '练习', '作业', '报告', '总结',
            '会议', '讨论', '分析', '规划',
            'study', 'homework', 'report', 'meeting', 'analysis'
        ],
        'medium': [
            '预习', '阅读', '整理', '记录', '笔记',
            '购物', '缴费', '预约',
            'reading', 'organize', 'notes', 'shopping'
        ],
        'easy': [
            '背诵', '打卡', '签到', '提醒', '查看',
            '休息', '娱乐', '放松',
            'reminder', 'check', 'relax', 'entertainment'
        ]
    }
    
    # 分类难度权重
    CATEGORY_DIFFICULTY_WEIGHT = {
        '考试': 'very_hard',
        '项目': 'very_hard',
        '工作': 'hard',
        '学习': 'hard',
        '会议': 'medium',
        '生活': 'easy',
        '娱乐': 'easy'
    }
    
    @classmethod
    def evaluate(
        cls,
        title: str,
        description: str = '',
        category: str = '',
        estimated_duration: int | None = None
    ) -> dict[str, any]:
        """
        评估任务难度
        
        Args:
            title: 任务标题
            description: 任务描述
            category: 任务分类
            estimated_duration: 预估时长（分钟）
            
        Returns:
            包含难度等级和评分的字典
        """
        text = f"{title} {description}".lower()
        
        # 1. 基于关键词匹配
        keyword_score = cls._calculate_keyword_score(text)
        
        # 2. 基于分类
        category_difficulty = cls.CATEGORY_DIFFICULTY_WEIGHT.get(category, 'medium')
        category_score = cls._difficulty_to_score(category_difficulty)
        
        # 3. 基于预估时长
        duration_score = cls._calculate_duration_score(estimated_duration)
        
        # 4. 综合评分（加权平均）
        final_score = (
            keyword_score * 0.5 +
            category_score * 0.3 +
            duration_score * 0.2
        )
        
        # 5. 转换为难度等级
        difficulty_level = cls._score_to_difficulty(final_score)
        
        return {
            'difficulty_level': difficulty_level,
            'difficulty_score': round(final_score, 2),
            'factors': {
                'keyword_score': round(keyword_score, 2),
                'category_score': round(category_score, 2),
                'duration_score': round(duration_score, 2)
            }
        }
    
    @classmethod
    def _calculate_keyword_score(cls, text: str) -> float:
        """基于关键词计算难度分数"""
        scores = {
            'very_hard': 4.0,
            'hard': 3.0,
            'medium': 2.0,
            'easy': 1.0
        }
        
        matched_scores = []
        
        for level, keywords in cls.DIFFICULTY_KEYWORDS.items():
            for keyword in keywords:
                if keyword in text:
                    matched_scores.append(scores[level])
        
        if not matched_scores:
            return 2.0  # 默认中等难度
        
        # 取最高难度（更保守的估计）
        return max(matched_scores)
    
    @classmethod
    def _calculate_duration_score(cls, duration: int | None) -> float:
        """基于时长计算难度分数"""
        if duration is None:
            return 2.0  # 默认中等
        
        if duration >= 180:  # 3小时以上
            return 4.0
        elif duration >= 120:  # 2-3小时
            return 3.0
        elif duration >= 60:  # 1-2小时
            return 2.0
        else:  # 1小时以内
            return 1.0
    
    @classmethod
    def _difficulty_to_score(cls, difficulty: str) -> float:
        """难度等级转分数"""
        mapping = {
            'very_hard': 4.0,
            'hard': 3.0,
            'medium': 2.0,
            'easy': 1.0
        }
        return mapping.get(difficulty, 2.0)
    
    @classmethod
    def _score_to_difficulty(cls, score: float) -> str:
        """分数转难度等级"""
        if score >= 3.5:
            return 'very_hard'
        elif score >= 2.5:
            return 'hard'
        elif score >= 1.5:
            return 'medium'
        else:
            return 'easy'
