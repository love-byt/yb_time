"""
AI工具类
封装通义千问API调用
"""

import json
import re

import requests

from config import Config


class AIHelper:
    """AI助手类"""

    PRIORITY_LEVELS = {
        5: "最高优先级，必须立即处理",
        4: "高优先级，今天内完成",
        3: "中等优先级，本周内完成",
        2: "低优先级，有空时处理",
        1: "最低优先级，可延后"
    }

    def __init__(self, api_key=None):
        self.api_key = api_key or Config.TONGYI_API_KEY
        self.api_url = 'https://dashscope.aliyuncs.com/api/v1/services/aigc/text-generation/generation'

    def call_api(self, prompt, model='qwen-turbo'):
        """调用通义千问API"""
        if not self.api_key:
            return "提示：未配置通义千问API Key，请在设置中配置API密钥以启用AI功能。"

        headers = {
            'Authorization': f'Bearer {self.api_key}',
            'Content-Type': 'application/json'
        }

        data = {
            'model': model,
            'input': {
                'messages': [
                    {'role': 'system', 'content': '你是一个专业的时间管理助手，帮助用户合理安排时间。'},
                    {'role': 'user', 'content': prompt}
                ]
            },
            'parameters': {
                'result_format': 'message',
                'max_tokens': 1500,
                'temperature': 0.7
            }
        }

        try:
            response = requests.post(
                self.api_url, headers=headers, json=data, timeout=30
            )
            response.raise_for_status()
            result = response.json()

            if 'output' in result and 'choices' in result['output']:
                return result['output']['choices'][0]['message']['content']
            return f"API返回格式错误: {json.dumps(result, ensure_ascii=False)}"

        except requests.exceptions.Timeout:
            return "请求超时，请稍后重试"
        except requests.exceptions.RequestException as e:
            return f"请求错误: {str(e)}"
        except Exception as e:
            return f"未知错误: {str(e)}"

    def intelligent_scheduling(self, tasks_list):
        """AI智能排期"""
        prompt = f"""你是一个专业的时间管理助手。请根据以下任务列表，为用户制定合理的时间安排。

任务列表：
{tasks_list}

请按照以下格式输出：

1. 任务优先级排序
   - 列出任务的优先级顺序
   - 简要说明排序理由

2. 具体时间安排建议
   - 为每个任务建议具体的时间段
   - 考虑任务的紧急度和重要性

3. 时间管理建议
   - 提供3-5条具体的时间管理建议
   - 帮助用户提高效率

不超过300字，语言简洁明了。"""

        return self.call_api(prompt)

    def evaluate_priority(self, task_title, task_desc="", deadline=""):
        """AI评估任务优先级"""
        prompt = f"""你是一个任务优先级评估专家。请评估以下任务的优先级。

任务信息：
- 标题：{task_title}
- 描述：{task_desc or '无'}
- 截止时间：{deadline or '未设置'}

请按照以下格式输出（JSON格式）：
{{
    "priority": 1-5,
    "urgency": 1-5,
    "importance": 1-5,
    "analysis": "简要分析理由"
}}

评分标准：
- 5分：{self.PRIORITY_LEVELS[5]}
- 4分：{self.PRIORITY_LEVELS[4]}
- 3分：{self.PRIORITY_LEVELS[3]}
- 2分：{self.PRIORITY_LEVELS[2]}
- 1分：{self.PRIORITY_LEVELS[1]}

只返回JSON格式，不要其他内容。"""

        result = self.call_api(prompt)
        return self._parse_priority_result(result)

    def _parse_priority_result(self, result):
        """解析优先级评估结果"""
        try:
            json_match = re.search(r'\{{[\s\S]*\}}', result)
            if json_match:
                data = json.loads(json_match.group())
                return {
                    'priority': data.get('priority', 0),
                    'urgency': data.get('urgency', 0),
                    'importance': data.get('importance', 0),
                    'analysis': data.get('analysis', '')
                }
        except (json.JSONDecodeError, AttributeError):
            pass

        return {
            'priority': 3,
            'urgency': 3,
            'importance': 3,
            'analysis': result[:200] if result else '评估失败'
        }

    def analyze_completion(self, tasks_data):
        """AI分析完成事项"""
        prompt = f"""你是一个专业的时间管理分析师。请分析用户最近完成的任务数据，提供洞察和建议。

任务数据：
{tasks_data}

请按以下格式输出分析：

## 完成情况总结
- 总体完成度评价
- 时间投入分布

## 效率分析
- 平均任务耗时
- 高效任务识别

## 分类洞察
- 各分类投入是否合理
- 建议调整的方向

## 改进建议（3-5条）
- 具体可执行的建议

## 下周计划建议
- 建议的时间分配比例

请用简洁专业的语言，不超过400字。"""

        return self.call_api(prompt)
