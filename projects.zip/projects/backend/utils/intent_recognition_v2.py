"""
意图识别引擎 v2.0 - 混合架构
结合规则匹配、语义理解和上下文感知的意图识别系统
"""

import asyncio
import hashlib
import re
from dataclasses import dataclass, field
from enum import Enum
from functools import lru_cache
from typing import Any, Dict, List, Optional, Tuple, Set
import numpy as np

# 导入现有模块
from utils.intent_recognition import UserIntent, IntentClassifier, IntentClassifierML
from utils.dialogue_history import DialogueSession


@dataclass
class IntentResult:
    """意图识别结果"""
    intent: UserIntent
    confidence: float
    candidates: List[Tuple[UserIntent, float]] = field(default_factory=list)
    semantic_embedding: Optional[np.ndarray] = None
    context_features: Dict[str, Any] = field(default_factory=dict)
    reasoning: str = ""


class FastRuleClassifier:
    """
    快速规则分类器
    轻量级，用于快速筛选候选意图
    """
    
    def __init__(self):
        self.intent_patterns = self._build_enhanced_patterns()
        self.regex_patterns = self._build_regex_patterns()
        
    def _build_enhanced_patterns(self) -> Dict[UserIntent, List[str]]:
        """构建增强的意图匹配模式"""
        return {
            UserIntent.CREATE_TASK: [
                "创建", "新建", "添加", "增加", "记一下", "提醒我",
                "create", "add", "new", "remind me", "make a task",
                "帮我", "给我", "需要"
            ],
            UserIntent.UPDATE_TASK: [
                "修改", "更新", "编辑", "改", "调整", "变更",
                "update", "edit", "modify", "change", "revise",
                "把.*改成", "换成", "改为"
            ],
            UserIntent.DELETE_TASK: [
                "删除", "移除", "取消", "删掉", "清除",
                "delete", "remove", "cancel", "clear", "drop"
            ],
            UserIntent.QUERY_TASK: [
                "查询", "查看", "显示", "详情", "情况", "状态",
                "show", "view", "check", "status", "details",
                "告诉我", "怎么样", "完成了吗"
            ],
            UserIntent.LIST_TASKS: [
                "列出", "所有", "列表", "有哪些", "全部",
                "list", "all", "show all", "what tasks"
            ],
            UserIntent.SORT_TASKS: [
                "排序", "重新排序", "优先级", "智能排序", "整理",
                "sort", "reorder", "prioritize", "organize"
            ],
            UserIntent.ADD_DEPENDENCY: [
                "依赖", "前置", "依赖于", "必须先", "在.*之前",
                "depends on", "blocker", "prerequisite", "before"
            ],
            UserIntent.REMOVE_DEPENDENCY: [
                "移除依赖", "取消依赖", "删除依赖",
                "remove dependency", "unlink"
            ],
            UserIntent.QUERY_DEPENDENCIES: [
                "查看依赖", "依赖关系", "前置任务",
                "dependencies", "dependency graph"
            ],
            UserIntent.REFER_TO_PREVIOUS: [
                "刚才", "之前", "上一个", "那个", "这个", "它",
                "the previous", "that one", "it", "this one",
                "刚才说的", "之前提到的"
            ],
            UserIntent.CLARIFY: [
                "什么意思", "解释", "详细", "为什么", "怎么说",
                "explain", "what do you mean", "clarify", "why"
            ],
            UserIntent.CONFIRM: [
                "确认", "是的", "没错", "对", "好", "可以",
                "confirm", "yes", "correct", "ok", "sure", "right"
            ],
            UserIntent.CANCEL: [
                "取消", "算了", "不要", "撤销", "放弃",
                "cancel", "never mind", "abort", "undo", "forget it"
            ],
            UserIntent.GREETING: [
                "你好", "嗨", "早上好", "下午好", "晚上好", "在吗",
                "hello", "hi", "hey", "good morning", "good afternoon",
                "good evening", "how are you"
            ],
            UserIntent.GENERAL_QUESTION: [
                "怎么", "如何", "什么", "为什么", "多少", "哪里",
                "how", "what", "why", "when", "where", "which"
            ],
            UserIntent.CHITCHAT: [
                "谢谢", "感谢", "再见", "拜拜", "辛苦",
                "thanks", "thank you", "bye", "goodbye", "appreciate"
            ],
        }
    
    def _build_regex_patterns(self) -> Dict[UserIntent, List[re.Pattern]]:
        """构建正则表达式模式"""
        patterns = {
            UserIntent.CREATE_TASK: [
                re.compile(r'帮我.*(?:记|记录|添加|创建)'),
                re.compile(r'(?:提醒|通知)我.*'),
                re.compile(r'(?:需要|要).*任务'),
            ],
            UserIntent.UPDATE_TASK: [
                re.compile(r'把.*(?:改|换|调整)'),
                re.compile(r'(?:修改|更新).*(?:为|成|到)'),
            ],
            UserIntent.REFER_TO_PREVIOUS: [
                re.compile(r'^[那这]个$'),
                re.compile(r'^[它他她]$'),
            ],
        }
        return patterns
    
    def get_candidates(self, text: str, top_k: int = 5) -> List[Tuple[UserIntent, float]]:
        """
        获取候选意图列表
        返回: [(意图, 分数), ...] 按分数降序排列
        """
        text_lower = text.lower().strip()
        scores = {}
        
        # 1. 关键词匹配
        for intent, patterns in self.intent_patterns.items():
            score = 0
            matched_patterns = []
            for pattern in patterns:
                if pattern.lower() in text_lower:
                    score += 1.0
                    matched_patterns.append(pattern)
                elif len(pattern) > 2:  # 对于较长的模式，尝试部分匹配
                    # 计算字符重叠度
                    overlap = len(set(pattern) & set(text_lower))
                    if overlap / len(pattern) > 0.7:
                        score += 0.5
            
            if score > 0:
                # 归一化分数
                normalized_score = min(score / 2, 1.0)  # 最多匹配2个关键词得满分
                scores[intent] = normalized_score
        
        # 2. 正则表达式匹配（更高权重）
        for intent, patterns in self.regex_patterns.items():
            for pattern in patterns:
                if pattern.search(text):
                    scores[intent] = scores.get(intent, 0) + 0.8
        
        # 3. 特殊模式检测
        self._apply_special_rules(text_lower, scores)
        
        # 按分数排序，返回top_k
        sorted_scores = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        return sorted_scores[:top_k]
    
    def _apply_special_rules(self, text: str, scores: Dict[UserIntent, float]):
        """应用特殊规则"""
        # 疑问句检测
        if any(text.endswith(end) for end in ['?', '？', '吗', '呢', '吧']):
            if UserIntent.GENERAL_QUESTION not in scores:
                scores[UserIntent.GENERAL_QUESTION] = 0.3
        
        # 命令式检测（以动词开头）
        command_verbs = ['创建', '新建', '添加', '修改', '删除', '查看', '显示', 'create', 'add', 'update', 'delete', 'show']
        for verb in command_verbs:
            if text.startswith(verb):
                scores[UserIntent.CREATE_TASK] = scores.get(UserIntent.CREATE_TASK, 0) + 0.2
                break


class SemanticIntentEncoder:
    """
    语义意图编码器
    使用文本嵌入理解深层语义
    """
    
    def __init__(self, model_name: str = "text2vec"):
        self.model_name = model_name
        self.embedding_model = None
        self.intent_prototypes = {}  # 意图原型向量
        self._load_model()
        self._build_intent_prototypes()
    
    def _load_model(self):
        """加载嵌入模型"""
        try:
            # 尝试加载 sentence-transformers
            from sentence_transformers import SentenceTransformer
            self.embedding_model = SentenceTransformer('paraphrase-multilingual-MiniLM-L12-v2')
            print("[意图识别] 语义编码器加载成功")
        except ImportError:
            print("[WARN] sentence-transformers 未安装，使用降级方案")
            self.embedding_model = None
    
    def _build_intent_prototypes(self):
        """构建意图原型向量"""
        # 每个意图的示例句子
        intent_examples = {
            UserIntent.CREATE_TASK: [
                "创建一个新任务",
                "帮我添加任务",
                "新建一个待办事项",
                "create a new task",
                "add something to my list"
            ],
            UserIntent.UPDATE_TASK: [
                "修改任务",
                "更新这个任务",
                "把任务改成",
                "update the task",
                "change task details"
            ],
            UserIntent.DELETE_TASK: [
                "删除任务",
                "移除这个任务",
                "取消任务",
                "delete the task",
                "remove from list"
            ],
            UserIntent.QUERY_TASK: [
                "查看任务详情",
                "任务状态如何",
                "显示任务信息",
                "show task details",
                "check task status"
            ],
            UserIntent.CONFIRM: [
                "确认",
                "是的",
                "没错",
                "yes",
                "correct"
            ],
            UserIntent.CANCEL: [
                "取消",
                "算了",
                "不要",
                "cancel",
                "never mind"
            ],
        }
        
        if self.embedding_model is None:
            return
        
        # 计算每个意图的原型向量（示例句子的平均）
        for intent, examples in intent_examples.items():
            embeddings = self.embedding_model.encode(examples)
            self.intent_prototypes[intent] = np.mean(embeddings, axis=0)
    
    async def encode(self, text: str) -> np.ndarray:
        """
        编码文本为语义向量
        """
        if self.embedding_model is None:
            # 降级方案：返回零向量
            return np.zeros(384)  # MiniLM-L12 的维度
        
        try:
            embedding = self.embedding_model.encode(text)
            return embedding
        except Exception as e:
            print(f"[ERROR] 语义编码失败: {e}")
            return np.zeros(384)
    
    def compute_similarity(self, text_embedding: np.ndarray, 
                          intent: UserIntent) -> float:
        """
        计算文本与意图原型的相似度
        """
        if intent not in self.intent_prototypes:
            return 0.0
        
        prototype = self.intent_prototypes[intent]
        
        # 余弦相似度
        dot_product = np.dot(text_embedding, prototype)
        norm_text = np.linalg.norm(text_embedding)
        norm_proto = np.linalg.norm(prototype)
        
        if norm_text == 0 or norm_proto == 0:
            return 0.0
        
        similarity = dot_product / (norm_text * norm_proto)
        return float(similarity)


class ContextDisambiguator:
    """
    上下文消歧器
    基于对话历史进行意图消歧
    """
    
    def __init__(self):
        self.state_intent_map = {
            "awaiting_confirmation": [UserIntent.CONFIRM, UserIntent.CANCEL],
            "awaiting_task_details": [UserIntent.CREATE_TASK, UserIntent.CLARIFY],
            "awaiting_clarification": [UserIntent.CLARIFY, UserIntent.CONFIRM],
            "task_selected": [UserIntent.UPDATE_TASK, UserIntent.DELETE_TASK, UserIntent.QUERY_TASK],
        }
    
    def extract_context_features(self, session: DialogueSession) -> Dict[str, Any]:
        """
        从对话会话中提取上下文特征
        """
        features = {
            "message_count": len(session.messages) if session.messages else 0,
            "last_intent": None,
            "current_state": getattr(session, 'state', 'idle'),
            "recent_entities": [],
            "pending_confirmation": False,
            "referenced_task": None,
        }
        
        if not session.messages:
            return features
        
        # 获取最近的消息
        recent_messages = session.messages[-5:] if len(session.messages) >= 5 else session.messages
        
        # 提取最近的实体
        for msg in recent_messages:
            if hasattr(msg, 'entities') and msg.entities:
                features["recent_entities"].extend(msg.entities)
        
        # 检测待确认状态
        last_bot_message = None
        for msg in reversed(session.messages):
            if hasattr(msg, 'role') and msg.role == 'assistant':
                last_bot_message = msg
                break
        
        if last_bot_message:
            confirm_indicators = ['确认', '对吗', '是否正确', 'confirm', 'correct', 'right']
            if any(ind in getattr(last_bot_message, 'content', '') for ind in confirm_indicators):
                features["pending_confirmation"] = True
        
        return features
    
    def disambiguate(self, candidates: List[Tuple[UserIntent, float]],
                    context_features: Dict[str, Any]) -> List[Tuple[UserIntent, float]]:
        """
        基于上下文进行意图消歧
        """
        if not candidates:
            return candidates
        
        current_state = context_features.get("current_state", "idle")
        adjusted_scores = []
        
        for intent, score in candidates:
            adjusted_score = score
            
            # 状态增强
            if current_state in self.state_intent_map:
                expected_intents = self.state_intent_map[current_state]
                if intent in expected_intents:
                    adjusted_score += 0.2  # 状态匹配加分
            
            # 待确认状态增强
            if context_features.get("pending_confirmation"):
                if intent in [UserIntent.CONFIRM, UserIntent.CANCEL]:
                    adjusted_score += 0.3
            
            # 有引用任务时增强任务操作意图
            if context_features.get("referenced_task"):
                if intent in [UserIntent.UPDATE_TASK, UserIntent.DELETE_TASK, UserIntent.QUERY_TASK]:
                    adjusted_score += 0.15
            
            adjusted_scores.append((intent, min(adjusted_score, 1.0)))
        
        # 重新排序
        adjusted_scores.sort(key=lambda x: x[1], reverse=True)
        return adjusted_scores


class IntentRecognitionEngine:
    """
    混合意图识别引擎 v2.0
    结合规则匹配、语义编码和上下文消歧
    """
    
    def __init__(self, use_semantic: bool = True, use_context: bool = True):
        self.rule_classifier = FastRuleClassifier()
        self.semantic_encoder = SemanticIntentEncoder() if use_semantic else None
        self.context_disambiguator = ContextDisambiguator() if use_context else None
        
        # 缓存配置
        self._cache = {}
        self._cache_size = 1000
        
        # 性能统计
        self.stats = {
            "total_requests": 0,
            "cache_hits": 0,
            "rule_only": 0,
            "semantic_used": 0,
        }
    
    def _get_cache_key(self, text: str, session_id: Optional[str]) -> str:
        """生成缓存键"""
        key = f"{text}:{session_id or 'none'}"
        return hashlib.md5(key.encode()).hexdigest()
    
    async def recognize(self, text: str, 
                       session: Optional[DialogueSession] = None) -> IntentResult:
        """
        识别用户意图
        
        流程：
        1. 快速规则筛选候选意图
        2. 语义编码（如果有语义编码器）
        3. 上下文特征提取
        4. 融合决策
        """
        self.stats["total_requests"] += 1
        
        # 1. 检查缓存
        cache_key = self._get_cache_key(text, getattr(session, 'session_id', None) if session else None)
        if cache_key in self._cache:
            self.stats["cache_hits"] += 1
            return self._cache[cache_key]
        
        # 2. 快速规则筛选
        candidates = self.rule_classifier.get_candidates(text, top_k=5)
        
        if not candidates:
            # 如果没有候选，返回UNKNOWN
            result = IntentResult(
                intent=UserIntent.UNKNOWN,
                confidence=0.0,
                candidates=[],
                reasoning="无匹配规则"
            )
            self._update_cache(cache_key, result)
            return result
        
        # 3. 语义编码（并行执行）
        semantic_scores = {}
        text_embedding = None
        
        if self.semantic_encoder and self.semantic_encoder.embedding_model is not None:
            self.stats["semantic_used"] += 1
            text_embedding = await self.semantic_encoder.encode(text)
            
            # 计算与每个候选意图的语义相似度
            for intent, _ in candidates:
                similarity = self.semantic_encoder.compute_similarity(text_embedding, intent)
                if similarity > 0.5:  # 相似度阈值
                    semantic_scores[intent] = similarity
        else:
            self.stats["rule_only"] += 1
        
        # 4. 上下文特征提取
        context_features = {}
        if self.context_disambiguator and session:
            context_features = self.context_disambiguator.extract_context_features(session)
        
        # 5. 融合决策
        final_scores = self._fusion_decision(candidates, semantic_scores, context_features)
        
        # 6. 构建结果
        best_intent = final_scores[0][0] if final_scores else UserIntent.UNKNOWN
        best_confidence = final_scores[0][1] if final_scores else 0.0
        
        result = IntentResult(
            intent=best_intent,
            confidence=best_confidence,
            candidates=final_scores,
            semantic_embedding=text_embedding,
            context_features=context_features,
            reasoning=self._generate_reasoning(candidates, semantic_scores, context_features)
        )
        
        # 更新缓存
        self._update_cache(cache_key, result)
        
        return result
    
    def _fusion_decision(self, 
                        rule_candidates: List[Tuple[UserIntent, float]],
                        semantic_scores: Dict[UserIntent, float],
                        context_features: Dict[str, Any]) -> List[Tuple[UserIntent, float]]:
        """
        融合决策层
        结合规则匹配、语义理解和上下文进行最终决策
        """
        # 合并分数
        fused_scores = {}
        
        # 规则匹配分数（权重 0.5）
        for intent, score in rule_candidates:
            fused_scores[intent] = score * 0.5
        
        # 语义相似度分数（权重 0.3）
        for intent, score in semantic_scores.items():
            fused_scores[intent] = fused_scores.get(intent, 0) + score * 0.3
        
        # 转换为列表
        fused_list = list(fused_scores.items())
        
        # 上下文消歧（调整分数）
        if self.context_disambiguator and context_features:
            fused_list = self.context_disambiguator.disambiguate(fused_list, context_features)
        
        # 按分数排序
        fused_list.sort(key=lambda x: x[1], reverse=True)
        
        return fused_list
    
    def _generate_reasoning(self, 
                           rule_candidates: List[Tuple[UserIntent, float]],
                           semantic_scores: Dict[UserIntent, float],
                           context_features: Dict[str, Any]) -> str:
        """生成推理说明"""
        parts = []
        
        if rule_candidates:
            parts.append(f"规则匹配: {rule_candidates[0][0].value}({rule_candidates[0][1]:.2f})")
        
        if semantic_scores:
            best_semantic = max(semantic_scores.items(), key=lambda x: x[1])
            parts.append(f"语义相似: {best_semantic[0].value}({best_semantic[1]:.2f})")
        
        if context_features.get("pending_confirmation"):
            parts.append("上下文: 待确认状态")
        
        return " | ".join(parts) if parts else "无额外推理"
    
    def _update_cache(self, key: str, result: IntentResult):
        """更新缓存"""
        if len(self._cache) >= self._cache_size:
            # 简单LRU：清除最早的10%
            keys_to_remove = list(self._cache.keys())[:self._cache_size // 10]
            for k in keys_to_remove:
                del self._cache[k]
        
        self._cache[key] = result
    
    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        total = self.stats["total_requests"]
        return {
            **self.stats,
            "cache_hit_rate": self.stats["cache_hits"] / total if total > 0 else 0,
            "semantic_usage_rate": self.stats["semantic_used"] / total if total > 0 else 0,
        }


# 保持向后兼容的接口
class IntentClassifierV2(IntentRecognitionEngine):
    """向后兼容的包装类"""
    pass


# 导出
__all__ = [
    'IntentRecognitionEngine',
    'IntentClassifierV2',
    'IntentResult',
    'FastRuleClassifier',
    'SemanticIntentEncoder',
    'ContextDisambiguator',
]