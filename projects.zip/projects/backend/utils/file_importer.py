"""
任务文件导入器
支持Excel和CSV文件批量导入任务
"""

import pandas as pd
import io
from typing import List, Dict, Any, Optional, BinaryIO
from datetime import datetime


class TaskFileImporter:
    """任务文件导入器"""
    
    # 必需列
    REQUIRED_COLUMNS = ['任务名称', 'title', '任务', 'task']
    
    # 可选列及其映射
    COLUMN_MAPPINGS = {
        '任务名称': 'title',
        'title': 'title',
        '任务': 'title',
        'task': 'title',
        '课程': 'course',
        'course': 'course',
        '科目': 'course',
        '截止时间': 'deadline',
        'deadline': 'deadline',
        '截止日期': 'deadline',
        '预计耗时': 'duration',
        'duration': 'duration',
        '预计时长': 'duration',
        '耗时': 'duration',
        '预计耗时(分钟)': 'duration',
        '优先级': 'priority',
        'priority': 'priority',
        '重要程度': 'priority',
        '分类': 'category',
        'category': 'category',
        '类型': 'category',
        '描述': 'description',
        'description': 'description',
        '备注': 'description',
    }
    
    def __init__(self):
        self.errors = []
        self.warnings = []
    
    def import_excel(self, file_content: bytes, field_mapping: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
        """
        导入Excel文件
        
        Args:
            file_content: 文件二进制内容
            field_mapping: 自定义字段映射
            
        Returns:
            包含tasks、errors、warnings的结果字典
        """
        try:
            df = pd.read_excel(io.BytesIO(file_content))
            return self._process_dataframe(df, field_mapping)
        except Exception as e:
            return {
                'success': False,
                'tasks': [],
                'errors': [f'Excel文件读取失败: {str(e)}'],
                'warnings': []
            }
    
    def import_csv(self, file_content: bytes, field_mapping: Optional[Dict[str, str]] = None,
                   encoding: str = 'utf-8') -> Dict[str, Any]:
        """
        导入CSV文件
        
        Args:
            file_content: 文件二进制内容
            field_mapping: 自定义字段映射
            encoding: 文件编码
            
        Returns:
            包含tasks、errors、warnings的结果字典
        """
        try:
            # 尝试指定编码
            try:
                df = pd.read_csv(io.BytesIO(file_content), encoding=encoding)
            except UnicodeDecodeError:
                # 尝试其他编码
                df = pd.read_csv(io.BytesIO(file_content), encoding='gbk')
            
            return self._process_dataframe(df, field_mapping)
        except Exception as e:
            return {
                'success': False,
                'tasks': [],
                'errors': [f'CSV文件读取失败: {str(e)}'],
                'warnings': []
            }
    
    def _process_dataframe(self, df: pd.DataFrame, field_mapping: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
        """
        处理数据框
        
        Args:
            df: pandas DataFrame
            field_mapping: 自定义字段映射
            
        Returns:
            处理结果
        """
        self.errors = []
        self.warnings = []
        
        if df.empty:
            return {
                'success': False,
                'tasks': [],
                'errors': ['文件为空'],
                'warnings': []
            }
        
        # 合并字段映射
        mapping = self.COLUMN_MAPPINGS.copy()
        if field_mapping:
            mapping.update(field_mapping)
        
        # 查找标题列
        title_column = None
        for col in df.columns:
            if col in self.REQUIRED_COLUMNS:
                title_column = col
                break
        
        if not title_column:
            return {
                'success': False,
                'tasks': [],
                'errors': [f'未找到任务名称列，支持的列名: {self.REQUIRED_COLUMNS}'],
                'warnings': []
            }
        
        tasks = []
        
        for index, row in df.iterrows():
            try:
                task = self._row_to_task(row, mapping, title_column)
                if task:
                    tasks.append(task)
            except Exception as e:
                self.errors.append(f'第 {index + 2} 行处理失败: {str(e)}')
        
        return {
            'success': len(self.errors) == 0,
            'tasks': tasks,
            'total': len(df),
            'success_count': len(tasks),
            'error_count': len(self.errors),
            'errors': self.errors,
            'warnings': self.warnings
        }
    
    def _row_to_task(self, row: pd.Series, mapping: Dict[str, str], title_column: str) -> Optional[Dict[str, Any]]:
        """
        将一行数据转换为任务字典
        
        Args:
            row: DataFrame行
            mapping: 字段映射
            title_column: 标题列名
            
        Returns:
            任务字典或None
        """
        # 获取标题
        title = row.get(title_column)
        if pd.isna(title) or not str(title).strip():
            return None
        
        task = {
            'title': str(title).strip(),
            'category': '学习'
        }
        
        # 映射其他字段
        for source_col, target_field in mapping.items():
            if source_col in row.index and not pd.isna(row[source_col]):
                value = row[source_col]
                
                if target_field == 'duration':
                    # 处理耗时字段
                    task['duration'] = self._parse_duration(value)
                elif target_field == 'priority':
                    # 处理优先级字段
                    task['priority'] = self._parse_priority(value)
                elif target_field == 'deadline':
                    # 处理截止时间字段
                    task['deadline'] = self._parse_deadline(value)
                else:
                    task[target_field] = str(value).strip()
        
        return task
    
    def _parse_duration(self, value: Any) -> Optional[int]:
        """解析耗时为分钟数"""
        if pd.isna(value):
            return None
        
        try:
            # 如果是数字，直接返回
            if isinstance(value, (int, float)):
                return int(value)
            
            # 如果是字符串，尝试解析
            value_str = str(value).strip().lower()
            
            # 匹配 "2小时"、"2h" 等
            import re
            hour_match = re.match(r'(\d+(?:\.\d+)?)\s*(小时|h|hr)', value_str)
            if hour_match:
                return int(float(hour_match.group(1)) * 60)
            
            # 匹配 "30分钟"、"30min" 等
            min_match = re.match(r'(\d+)\s*(分钟|min|分)?', value_str)
            if min_match:
                return int(min_match.group(1))
            
            # 纯数字
            return int(float(value_str))
        except (ValueError, TypeError):
            return None
    
    def _parse_priority(self, value: Any) -> Optional[int]:
        """解析优先级为数字"""
        if pd.isna(value):
            return None
        
        try:
            # 如果是数字
            if isinstance(value, (int, float)):
                return max(1, min(5, int(value)))
            
            # 如果是字符串
            value_str = str(value).strip().lower()
            
            priority_map = {
                '高': 4, '紧急': 5, '重要': 4, '高优先级': 4,
                '中': 3, '普通': 3, '一般': 3, '中优先级': 3,
                '低': 2, '不急': 2, '低优先级': 2,
                '最低': 1
            }
            
            if value_str in priority_map:
                return priority_map[value_str]
            
            # 尝试解析数字
            return max(1, min(5, int(float(value_str))))
        except (ValueError, TypeError):
            return None
    
    def _parse_deadline(self, value: Any) -> Optional[str]:
        """解析截止时间为ISO格式字符串"""
        if pd.isna(value):
            return None
        
        try:
            # 如果是pandas Timestamp
            if isinstance(value, pd.Timestamp):
                return value.strftime('%Y-%m-%dT%H:%M:%S')
            
            # 如果是datetime
            if isinstance(value, datetime):
                return value.strftime('%Y-%m-%dT%H:%M:%S')
            
            # 如果是字符串，尝试多种格式
            value_str = str(value).strip()
            
            formats = [
                '%Y-%m-%d %H:%M:%S',
                '%Y-%m-%d %H:%M',
                '%Y-%m-%d',
                '%Y/%m/%d %H:%M:%S',
                '%Y/%m/%d %H:%M',
                '%Y/%m/%d',
                '%m-%d',
                '%m/%d',
            ]
            
            for fmt in formats:
                try:
                    dt = datetime.strptime(value_str, fmt)
                    # 如果没有年份，使用当前年
                    if dt.year == 1900:
                        dt = dt.replace(year=datetime.now().year)
                    return dt.strftime('%Y-%m-%dT%H:%M:%S')
                except ValueError:
                    continue
            
            return None
        except Exception:
            return None
    
    @staticmethod
    def generate_template() -> pd.DataFrame:
        """
        生成导入模板
        
        Returns:
            模板DataFrame
        """
        template_data = {
            '任务名称': [
                '数学第三章习题',
                '英语阅读理解',
                '物理实验报告',
                '化学期中复习',
                '编程项目提交'
            ],
            '课程': [
                '高等数学',
                '大学英语',
                '大学物理',
                '有机化学',
                '程序设计'
            ],
            '截止时间': [
                '2026-05-10',
                '2026-05-12',
                '2026-05-15',
                '2026-05-18',
                '2026-05-20'
            ],
            '预计耗时(分钟)': [120, 60, 180, 240, 300],
            '优先级': [4, 3, 5, 4, 5],
            '分类': ['学习', '学习', '实验', '学习', '项目'],
            '描述': [
                '完成课本P100-105习题',
                '阅读Unit 3文章并回答问题',
                '完成光学实验并撰写报告',
                '复习第1-5章内容',
                '完成期末项目代码和文档'
            ]
        }
        return pd.DataFrame(template_data)
    
    @staticmethod
    def generate_template_excel() -> bytes:
        """
        生成Excel模板文件
        
        Returns:
            Excel文件二进制内容
        """
        df = TaskFileImporter.generate_template()
        output = io.BytesIO()
        df.to_excel(output, index=False, sheet_name='任务导入模板')
        output.seek(0)
        return output.getvalue()
    
    @staticmethod
    def generate_template_csv() -> bytes:
        """
        生成CSV模板文件
        
        Returns:
            CSV文件二进制内容
        """
        df = TaskFileImporter.generate_template()
        output = io.BytesIO()
        df.to_csv(output, index=False, encoding='utf-8-sig')
        output.seek(0)
        return output.getvalue()


# 便捷函数
def import_tasks_from_file(file_content: bytes, file_type: str, 
                           field_mapping: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
    """
    便捷函数：从文件导入任务
    
    Args:
        file_content: 文件二进制内容
        file_type: 文件类型 ('excel' 或 'csv')
        field_mapping: 自定义字段映射
        
    Returns:
        导入结果
    """
    importer = TaskFileImporter()
    
    if file_type.lower() in ['excel', 'xlsx', 'xls']:
        return importer.import_excel(file_content, field_mapping)
    elif file_type.lower() in ['csv', 'txt']:
        return importer.import_csv(file_content, field_mapping)
    else:
        return {
            'success': False,
            'tasks': [],
            'errors': [f'不支持的文件类型: {file_type}'],
            'warnings': []
        }


if __name__ == '__main__':
    # 测试模板生成
    importer = TaskFileImporter()
    
    print("生成模板预览:")
    template = importer.generate_template()
    print(template.to_string())
    
    print("\n模板Excel大小:", len(importer.generate_template_excel()), "bytes")
    print("模板CSV大小:", len(importer.generate_template_csv()), "bytes")
