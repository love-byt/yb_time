"""
六维度任务评估与排序模块
严格基于六个核心维度进行任务评估和排序

================================================================================
六维度定义
================================================================================

维度1: 时间紧迫度 (time)
  含义: 距离截止时间的紧迫程度
  权重: 25%
  计算: 基于剩余小时数的时间梯度评分

维度2: 重要性 (importance)
  含义: 任务本身的重要程度
  权重: 20%
  计算: 基于优先级、分类标签、关键词的综合评分

维度3: 影响力 (impact)
  含义: 任务对目标/成果的推动作用
  权重: 20%
  计算: 基于影响范围和复合价值的评分

维度4: 金钱价值 (money)
  含义: 任务的财务相关性和潜在收益
  权重: 15%
  计算: 基于财务关键词的匹配评分

维度5: 关系价值 (relation)
  含义: 任务对人际关系的影响
  权重: 10%
  计算: 基于社交/沟通相关关键词的评分

维度6: 技能成长 (skill)
  含义: 任务对个人能力的提升价值
  权重: 10%
  计算: 基于学习和成长相关关键词的评分

================================================================================
算法特点
================================================================================

1. 纯6维度评估: 所有评估严格基于上述6个维度
2. 权重可配置: 每个维度的权重可动态调整
3. 结构化输出: 返回完整的维度评分详情
4. 归一化处理: 权重总和始终为1.0
5. 无外部依赖: 纯本地计算，无需API

================================================================================
"""

from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional


# =================================================================================
# 六维度常量定义
# =================================================================================

class SixDimensions:
    """
    六维度常量定义类
    
    定义6个核心维度的名称、权重、评分范围和计算规则
    """
    
    # 维度名称列表（固定顺序）
    NAMES: List[str] = [
        'time',        # 维度1: 时间紧迫度
        'importance',  # 维度2: 重要性
        'impact',      # 维度3: 影响力
        'money',       # 维度4: 金钱价值
        'relation',    # 维度5: 关系价值
        'skill'        # 维度6: 技能成长
    ]
    
    # 默认权重配置（总和=1.0）
    DEFAULT_WEIGHTS: Dict[str, float] = {
        'time': 0.25,
        'importance': 0.20,
        'impact': 0.20,
        'money': 0.15,
        'relation': 0.10,
        'skill': 0.10
    }
    
    # 维度中文名称（用于展示）
    CHINESE_NAMES: Dict[str, str] = {
        'time': '时间紧迫度',
        'importance': '重要性',
        'impact': '影响力',
        'money': '金钱价值',
        'relation': '关系价值',
        'skill': '技能成长'
    }
    
    # 维度英文名称（用于展示）
    ENGLISH_NAMES: Dict[str, str] = {
        'time': 'Time Urgency',
        'importance': 'Importance',
        'impact': 'Impact',
        'money': 'Money Value',
        'relation': 'Relation Value',
        'skill': 'Skill Growth'
    }
    
    # 维度说明（用于展示）
    DESCRIPTIONS: Dict[str, str] = {
        'time': '距离截止时间的紧迫程度，越近越紧急',
        'importance': '任务本身的重要程度，基于优先级和分类',
        'impact': '对目标/成果的推动作用，高影响任务优先',
        'money': '财务相关性和潜在收益/损失',
        'relation': '对人际关系的影响，如会议、沟通等',
        'skill': '对个人能力提升的价值'
    }
    
    @classmethod
    def validate_weights(cls, weights: Dict[str, float]) -> bool:
        """
        验证权重配置是否有效
        
        Args:
            weights: 权重配置字典
            
        Returns:
            是否有效
        """
        if set(weights.keys()) != set(cls.NAMES):
            return False
        if abs(sum(weights.values()) - 1.0) > 0.001:
            return False
        return True
    
    @classmethod
    def normalize_weights(cls, weights: Dict[str, float]) -> Dict[str, float]:
        """
        归一化权重配置
        
        Args:
            weights: 原始权重配置
            
        Returns:
            归一化后的权重配置
        """
        result = {}
        total = sum(weights.get(dim, 0) for dim in cls.NAMES)
        if total > 0:
            for dim in cls.NAMES:
                result[dim] = round(weights.get(dim, 0) / total, 4)
        else:
            result = cls.DEFAULT_WEIGHTS.copy()
        return result


# =================================================================================
# 关键词库定义
# =================================================================================

class DimensionKeywords:
    """
    各维度关键词库
    
    用于文本匹配计算维度分数
    """
    
    # 重要性维度关键词
    IMPORTANCE_KEYWORDS = {
        'high': [
            '重要', '紧急', '必须', '务必', '关键', '核心',
            'deadline', '截止', '截止时间', '截止日期',
            '考试', '面试', '答辩', '审核', '审批'
        ],
        'low': [
            '可选', '也许', '可能', '考虑', '有空', '随意', '随便'
        ]
    }
    
    # 影响力维度关键词
    IMPACT_KEYWORDS = {
        'high': [
            '战略', '规划', '架构', '设计', '优化', '团队', '公司',
            '产品', '用户', '长期', '发展', '决策', '方案'
        ],
        'compound': [
            '习惯', '系统', '框架', '模板', '工具', '知识库', '文档',
            '流程', '规范', '标准', '自动化', '脚手架'
        ]
    }
    
    # 金钱维度关键词
    MONEY_KEYWORDS = {
        'income': ['收入', '赚钱', '盈利', '收益', '工资', '奖金', '报酬'],
        'cost': ['成本', '节约', '省钱', '费用', '支出'],
        'business': ['客户', '销售', '订单', '合同', '报价'],
        'investment': ['投资', '理财', '股票', '基金', '资产']
    }
    
    # 关系维度关键词
    RELATION_KEYWORDS = {
        'meeting': ['会议', '会面', '约见', '拜访'],
        'communication': ['沟通', '交流', '汇报', '反馈', '回复'],
        'people': ['客户', '领导', '同事', '团队', '合作', '协作'],
        'social': ['社交', '聚会', '应酬', '活动']
    }
    
    # 技能维度关键词
    SKILL_KEYWORDS = {
        'learning': ['学习', '研究', '阅读', '课程', '培训', '讲座'],
        'practice': ['练习', '训练', '实践', '实验'],
        'growth': ['技能', '能力', '提升', '掌握', '精通', '成长'],
        'certification': ['考试', '证书', '认证', '考核', '测评']
    }
    
    # 截止强度关键词（用于时间维度调整）
    DEADLINE_STRENGTH_KEYWORDS = {
        'strong': ['必须', '务必', '截止', 'deadline', '错过', '逾期', '紧急', '立刻'],
        'weak': ['尽量', '最好', '有空', '灵活', '计划', '打算', '考虑']
    }


# =================================================================================
# 维度评分计算器
# =================================================================================

class DimensionCalculator:
    """
    六维度评分计算器
    
    负责计算每个任务的6个维度分数
    """
    
    def __init__(self):
        self.keywords = DimensionKeywords()
    
    def calculate(self, task: Dict[str, Any]) -> Dict[str, float]:
        """
        计算任务的所有维度分数
        
        Args:
            task: 任务字典
            
        Returns:
            6个维度的分数字典，每个分数范围[0, 5]
        """
        return {
            'time': self.calculate_time_score(task),
            'importance': self.calculate_importance_score(task),
            'impact': self.calculate_impact_score(task),
            'money': self.calculate_money_score(task),
            'relation': self.calculate_relation_score(task),
            'skill': self.calculate_skill_score(task)
        }
    
    def calculate_time_score(self, task: Dict[str, Any]) -> float:
        """
        计算时间紧迫度分数 (0-5)
        
        计算规则:
        - 过期任务: 5.0分
        - 2小时内: 5.0分
        - 2-6小时: 4.5分
        - 6-12小时: 4.0分
        - 12-24小时: 3.5分
        - 24-48小时: 3.0分
        - 48-72小时: 2.5分
        - 72小时-7天: 2.0分
        - 7天以上: 1.0分
        
        额外调整:
        - 有强截止词(必须/截止)且<24小时: +0.5分
        - 有弱截止词(尽量/有空)且>24小时: -0.5分
        - 长任务(>8小时)且>24小时: +0.5分
        """
        score = 2.5  # 基础分
        
        # 获取截止时间
        end_time_str = task.get('end_time') or task.get('start_time')
        if not end_time_str:
            return 2.5
        
        try:
            if isinstance(end_time_str, str):
                end_time = datetime.fromisoformat(end_time_str.replace('Z', '+00:00'))
            else:
                end_time = end_time_str
        except:
            return 2.5
        
        now = datetime.now()
        time_diff = end_time - now
        hours_remaining = time_diff.total_seconds() / 3600
        
        # 过期任务
        if hours_remaining < 0:
            return 5.0
        
        # 时间梯度评分
        if hours_remaining <= 2:
            score = 5.0
        elif hours_remaining <= 6:
            score = 4.5
        elif hours_remaining <= 12:
            score = 4.0
        elif hours_remaining <= 24:
            score = 3.5
        elif hours_remaining <= 48:
            score = 3.0
        elif hours_remaining <= 72:
            score = 2.5
        elif hours_remaining <= 168:  # 7天
            score = 2.0
        else:
            score = 1.0
        
        # 截止强度调整
        text = (task.get('title', '') + ' ' + task.get('description', '')).lower()
        
        has_strong = any(kw in text for kw in self.keywords.DEADLINE_STRENGTH_KEYWORDS['strong'])
        has_weak = any(kw in text for kw in self.keywords.DEADLINE_STRENGTH_KEYWORDS['weak'])
        
        if has_strong and hours_remaining <= 24:
            score = min(5.0, score + 0.5)
        elif has_weak and hours_remaining > 24:
            score = max(1.0, score - 0.5)
        
        # 长任务提前因子
        estimated_hours = task.get('estimated_hours', 0)
        if estimated_hours >= 8 and hours_remaining > 24:
            score = min(5.0, score + 0.5)
        
        return score
    
    def calculate_importance_score(self, task: Dict[str, Any]) -> float:
        """
        计算重要性分数 (0-5)
        
        计算规则:
        - 基础分: 2.5
        - 优先级加成: priority字段 1-5映射到 1-5分
        - 分类加成: 考试+0.5, 工作+0.3, 项目+0.3等
        - 高重要性关键词: 每个+0.3分
        - 低重要性关键词: 每个-0.2分
        """
        score = 2.5
        
        # 优先级加成
        priority = task.get('priority', 0)
        if isinstance(priority, (int, float)) and priority > 0:
            score = min(5.0, float(priority))
        
        # 分类加成
        category = task.get('category', '') or ''
        category_bonus = {
            '考试': 0.5, '工作': 0.3, '项目': 0.3,
            '学习': 0.2, '健康': 0.2, '财务': 0.2,
            '会议': 0.15, '生活': 0.0, '娱乐': -0.3
        }
        for cat, bonus in category_bonus.items():
            if cat in category:
                score = min(5.0, max(0.0, score + bonus))
                break
        
        # 关键词调整
        text = (task.get('title', '') + ' ' + task.get('description', '')).lower()
        
        for kw in self.keywords.IMPORTANCE_KEYWORDS['high']:
            if kw in text:
                score = min(5.0, score + 0.3)
        
        for kw in self.keywords.IMPORTANCE_KEYWORDS['low']:
            if kw in text:
                score = max(0.0, score - 0.2)
        
        return score
    
    def calculate_impact_score(self, task: Dict[str, Any]) -> float:
        """
        计算影响力分数 (0-5)
        
        计算规则:
        - 基础分: 2.5
        - 高影响关键词: 每个+0.4分
        - 复合价值关键词: 每个+0.5分(系统/框架等)
        """
        score = 2.5
        
        text = (task.get('title', '') + ' ' + task.get('description', '')).lower()
        
        for kw in self.keywords.IMPACT_KEYWORDS['high']:
            if kw in text:
                score = min(5.0, score + 0.4)
        
        for kw in self.keywords.IMPACT_KEYWORDS['compound']:
            if kw in text:
                score = min(5.0, score + 0.5)
        
        return score
    
    def calculate_money_score(self, task: Dict[str, Any]) -> float:
        """
        计算金钱价值分数 (0-5)
        
        计算规则:
        - 基础分: 2.0
        - 收入相关: 每个+0.5分
        - 成本相关: 每个+0.4分
        - 业务相关: 每个+0.3分
        - 投资相关: 每个+0.4分
        """
        score = 2.0
        
        text = (task.get('title', '') + ' ' + task.get('description', '')).lower()
        
        for kw in self.keywords.MONEY_KEYWORDS['income']:
            if kw in text:
                score = min(5.0, score + 0.5)
        
        for kw in self.keywords.MONEY_KEYWORDS['cost']:
            if kw in text:
                score = min(5.0, score + 0.4)
        
        for kw in self.keywords.MONEY_KEYWORDS['business']:
            if kw in text:
                score = min(5.0, score + 0.3)
        
        for kw in self.keywords.MONEY_KEYWORDS['investment']:
            if kw in text:
                score = min(5.0, score + 0.4)
        
        return score
    
    def calculate_relation_score(self, task: Dict[str, Any]) -> float:
        """
        计算关系价值分数 (0-5)
        
        计算规则:
        - 基础分: 2.0
        - 会议相关: 每个+0.3分
        - 沟通相关: 每个+0.4分
        - 人员相关: 每个+0.3分
        - 社交相关: 每个+0.4分
        """
        score = 2.0
        
        text = (task.get('title', '') + ' ' + task.get('description', '')).lower()
        
        for kw in self.keywords.RELATION_KEYWORDS['meeting']:
            if kw in text:
                score = min(5.0, score + 0.3)
        
        for kw in self.keywords.RELATION_KEYWORDS['communication']:
            if kw in text:
                score = min(5.0, score + 0.4)
        
        for kw in self.keywords.RELATION_KEYWORDS['people']:
            if kw in text:
                score = min(5.0, score + 0.3)
        
        for kw in self.keywords.RELATION_KEYWORDS['social']:
            if kw in text:
                score = min(5.0, score + 0.4)
        
        return score
    
    def calculate_skill_score(self, task: Dict[str, Any]) -> float:
        """
        计算技能成长分数 (0-5)
        
        计算规则:
        - 基础分: 2.5
        - 学习相关: 每个+0.4分
        - 实践相关: 每个+0.4分
        - 成长相关: 每个+0.4分
        - 认证相关: 每个+0.5分
        """
        score = 2.5
        
        text = (task.get('title', '') + ' ' + task.get('description', '')).lower()
        
        for kw in self.keywords.SKILL_KEYWORDS['learning']:
            if kw in text:
                score = min(5.0, score + 0.4)
        
        for kw in self.keywords.SKILL_KEYWORDS['practice']:
            if kw in text:
                score = min(5.0, score + 0.4)
        
        for kw in self.keywords.SKILL_KEYWORDS['growth']:
            if kw in text:
                score = min(5.0, score + 0.4)
        
        for kw in self.keywords.SKILL_KEYWORDS['certification']:
            if kw in text:
                score = min(5.0, score + 0.5)
        
        return score


# =================================================================================
# 六维度排序器
# =================================================================================

class SixDimensionSorter:
    """
    六维度任务排序器
    
    严格基于6个核心维度进行任务排序
    """
    
    def __init__(self, weights: Optional[Dict[str, float]] = None):
        """
        初始化排序器
        
        Args:
            weights: 6维度权重配置，None时使用默认权重
        """
        self.dimensions = SixDimensions()
        self.calculator = DimensionCalculator()
        
        if weights:
            self.weights = self.dimensions.normalize_weights(weights)
        else:
            self.weights = self.dimensions.DEFAULT_WEIGHTS.copy()
    
    def evaluate(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """
        评估单个任务的6维度得分
        
        Args:
            task: 任务字典
            
        Returns:
            结构化评估结果
        """
        # 计算6维度分数
        scores = self.calculator.calculate(task)
        
        # 计算加权综合分
        weighted_score = sum(
            scores[dim] * self.weights[dim]
            for dim in self.dimensions.NAMES
        )
        
        # 构建结构化结果
        return {
            'task_id': task.get('id', task.get('title', 'unknown')),
            'task_title': task.get('title', '未命名'),
            'dimensions': {
                dim: {
                    'name_cn': self.dimensions.CHINESE_NAMES[dim],
                    'name_en': self.dimensions.ENGLISH_NAMES[dim],
                    'description': self.dimensions.DESCRIPTIONS[dim],
                    'weight': self.weights[dim],
                    'score': round(scores[dim], 2),
                    'weighted_contribution': round(scores[dim] * self.weights[dim], 4)
                }
                for dim in self.dimensions.NAMES
            },
            'total_score': round(weighted_score, 2),
            'weights_config': self.weights.copy()
        }
    
    def sort_tasks(self, tasks: List[Dict[str, Any]], 
                   include_scores: bool = True) -> List[Dict[str, Any]]:
        """
        对任务列表进行6维度排序
        
        Args:
            tasks: 任务列表
            include_scores: 是否包含详细维度评分
            
        Returns:
            按综合得分降序排列的任务列表
        """
        evaluated_tasks = []
        
        for task in tasks:
            evaluation = self.evaluate(task)
            
            result = task.copy()
            result['ai_sort_score'] = evaluation['total_score']
            
            if include_scores:
                result['six_dimension_evaluation'] = evaluation
            
            evaluated_tasks.append(result)
        
        # 按综合得分降序排列
        evaluated_tasks.sort(key=lambda x: x['ai_sort_score'], reverse=True)
        
        return evaluated_tasks
    
    def get_comparison(self, task1: Dict[str, Any], 
                       task2: Dict[str, Any]) -> Dict[str, Any]:
        """
        比较两个任务的6维度评估结果
        
        Args:
            task1: 任务1
            task2: 任务2
            
        Returns:
            结构化比较结果
        """
        eval1 = self.evaluate(task1)
        eval2 = self.evaluate(task2)
        
        # 确定推荐顺序
        if eval1['total_score'] > eval2['total_score']:
            recommended = task1
            loser = task2
        elif eval1['total_score'] < eval2['total_score']:
            recommended = task2
            loser = task1
        else:
            # 分数相同时，按时间维度决定
            if eval1['dimensions']['time']['score'] >= eval2['dimensions']['time']['score']:
                recommended = task1
                loser = task2
            else:
                recommended = task2
                loser = task1
        
        return {
            'task1': {
                'title': task1.get('title', '任务1'),
                'evaluation': eval1
            },
            'task2': {
                'title': task2.get('title', '任务2'),
                'evaluation': eval2
            },
            'recommended': {
                'title': recommended.get('title', ''),
                'total_score': self.evaluate(recommended)['total_score']
            },
            'reason': self._generate_reason(eval1, eval2)
        }
    
    def _generate_reason(self, eval1: Dict, eval2: Dict) -> str:
        """
        生成比较原因说明
        """
        reasons = []
        
        for dim in self.dimensions.NAMES:
            score1 = eval1['dimensions'][dim]['score']
            score2 = eval2['dimensions'][dim]['score']
            
            if score1 > score2 + 0.5:
                reasons.append(
                    f"{self.dimensions.CHINESE_NAMES[dim]}更高"
                    f"({score1:.1f}>{score2:.1f})"
                )
        
        if not reasons:
            return "各维度得分相近，综合得分决定排序"
        
        return '，'.join(reasons[:2])
    
    def get_dimension_info(self) -> Dict[str, Any]:
        """
        获取6维度的定义信息
        
        Returns:
            维度定义字典
        """
        return {
            'dimensions': {
                dim: {
                    'name_cn': self.dimensions.CHINESE_NAMES[dim],
                    'name_en': self.dimensions.ENGLISH_NAMES[dim],
                    'description': self.dimensions.DESCRIPTIONS[dim],
                    'default_weight': self.dimensions.DEFAULT_WEIGHTS[dim],
                    'current_weight': self.weights[dim]
                }
                for dim in self.dimensions.NAMES
            },
            'weight_validation': {
                'is_valid': self.dimensions.validate_weights(self.weights),
                'total': round(sum(self.weights.values()), 4)
            }
        }
    
    def calculate_all_scores(self, task: Dict[str, Any]) -> Dict[str, float]:
        """
        计算任务的所有维度分数（批量更新专用）
        
        Args:
            task: 任务字典
            
        Returns:
            6个维度的分数字典 {'time': 2.5, 'importance': 3.0, ...}
        """
        return self.calculator.calculate(task)
    
    def calculate_weighted_score(self, scores: Dict[str, float]) -> float:
        """
        计算加权综合分数（批量更新专用）
        
        Args:
            scores: 6个维度的分数字典
            
        Returns:
            加权综合分数
        """
        return sum(
            scores.get(dim, 2.5) * self.weights.get(dim, 0.0)
            for dim in self.dimensions.NAMES
        )


# =================================================================================
# 便捷函数
# =================================================================================

def sort_tasks_by_six_dimensions(
    tasks: List[Dict[str, Any]],
    weights: Optional[Dict[str, float]] = None
) -> List[Dict[str, Any]]:
    """
    使用6维度评估对任务排序
    
    Args:
        tasks: 任务列表
        weights: 6维度权重配置
        
    Returns:
        排序后的任务列表
    """
    sorter = SixDimensionSorter(weights)
    return sorter.sort_tasks(tasks)


def evaluate_task_six_dimensions(
    task: Dict[str, Any],
    weights: Optional[Dict[str, float]] = None
) -> Dict[str, Any]:
    """
    评估单个任务的6维度得分
    
    Args:
        task: 任务字典
        weights: 6维度权重配置
        
    Returns:
        结构化评估结果
    """
    sorter = SixDimensionSorter(weights)
    return sorter.evaluate(task)


def get_six_dimensions_info() -> Dict[str, Any]:
    """
    获取6维度的定义信息
    
    Returns:
        维度定义字典
    """
    return SixDimensionSorter().get_dimension_info()


# =================================================================================
# 向后兼容别名（兼容旧API）
# =================================================================================

def sort_tasks_by_ai(tasks: List[Dict[str, Any]], 
                     weights: Optional[Dict[str, float]] = None) -> List[Dict[str, Any]]:
    """
    便捷函数：使用6维度评估对任务排序
    
    (向后兼容别名，推荐使用 sort_tasks_by_six_dimensions)
    
    Args:
        tasks: 任务列表
        weights: 6维度权重配置
        
    Returns:
        排序后的任务列表
    """
    return sort_tasks_by_six_dimensions(tasks, weights)


def ai_sorter() -> SixDimensionSorter:
    """
    获取默认的6维度排序器实例
    
    (向后兼容函数)
    """
    return SixDimensionSorter()
