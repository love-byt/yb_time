"""
任务依赖图（DAG）管理模块
提供任务依赖关系管理、拓扑排序、关键路径计算等功能
"""

import re
from collections import deque
from datetime import datetime
from typing import Any, Dict, List, Optional, Set, Tuple


class TaskNode:
    """任务节点"""
    
    def __init__(self, task_id: str, task_data: Dict[str, Any]):
        self.task_id = task_id
        self.task_data = task_data
        self.dependencies: Set[str] = set()      # 依赖的任务ID
        self.dependents: Set[str] = set()        # 依赖此任务的任务ID
        self.status: str = "pending"             # pending/active/completed/blocked
        self.priority: int = 0
        self.estimated_duration: int = 0         # 预估耗时（分钟）
        self.deadline: Optional[datetime] = None
        
    def add_dependency(self, task_id: str):
        """添加依赖"""
        self.dependencies.add(task_id)
        
    def add_dependent(self, task_id: str):
        """添加被依赖"""
        self.dependents.add(task_id)
        
    def is_blocked(self) -> bool:
        """检查是否被阻塞（有未完成的前置依赖）"""
        return len(self.dependencies) > 0 and self.status == "pending"
    
    def to_dict(self) -> Dict:
        """序列化为字典"""
        return {
            "task_id": self.task_id,
            "task_data": self.task_data,
            "dependencies": list(self.dependencies),
            "dependents": list(self.dependents),
            "status": self.status,
            "priority": self.priority,
            "estimated_duration": self.estimated_duration,
            "deadline": self.deadline.isoformat() if self.deadline else None
        }


class TaskDependencyGraph:
    """任务依赖图管理器"""
    
    def __init__(self):
        self.nodes: Dict[str, TaskNode] = {}
        self._cache_valid = False
        self._topological_order: List[str] = []
        
    def add_task(self, task_id: str, task_data: Dict[str, Any]) -> TaskNode:
        """添加任务节点"""
        if task_id not in self.nodes:
            self.nodes[task_id] = TaskNode(task_id, task_data)
            self._cache_valid = False
        return self.nodes[task_id]
    
    def add_dependency(self, from_task: str, to_task: str) -> bool:
        """
        添加依赖关系: from_task 依赖于 to_task
        即 to_task 必须在 from_task 之前完成
        """
        if from_task not in self.nodes:
            raise ValueError(f"任务 {from_task} 不存在")
        if to_task not in self.nodes:
            raise ValueError(f"任务 {to_task} 不存在")
        
        # 检查是否会产生循环依赖
        if self._would_create_cycle(from_task, to_task):
            raise ValueError(f"添加依赖 {to_task} -> {from_task} 会产生循环依赖")
        
        self.nodes[from_task].add_dependency(to_task)
        self.nodes[to_task].add_dependent(from_task)
        self._cache_valid = False
        return True
    
    def remove_dependency(self, from_task: str, to_task: str):
        """移除依赖关系"""
        if from_task in self.nodes and to_task in self.nodes:
            self.nodes[from_task].dependencies.discard(to_task)
            self.nodes[to_task].dependents.discard(from_task)
            self._cache_valid = False
    
    def _would_create_cycle(self, from_task: str, to_task: str) -> bool:
        """检查添加依赖是否会创建循环"""
        # 如果 to_task 已经依赖于 from_task（直接 or 间接），则会产生循环
        visited = set()
        stack = [to_task]
        
        while stack:
            current = stack.pop()
            if current == from_task:
                return True
            if current not in visited:
                visited.add(current)
                if current in self.nodes:
                    stack.extend(self.nodes[current].dependencies)
        
        return False
    
    def topological_sort(self) -> List[str]:
        """拓扑排序 - 返回任务的执行顺序"""
        if self._cache_valid:
            return self._topological_order
        
        in_degree = {task_id: len(node.dependencies) 
                    for task_id, node in self.nodes.items()}
        
        queue = deque([task_id for task_id, degree in in_degree.items() 
                      if degree == 0])
        result = []
        
        while queue:
            task_id = queue.popleft()
            result.append(task_id)
            
            for dependent in self.nodes[task_id].dependents:
                in_degree[dependent] -= 1
                if in_degree[dependent] == 0:
                    queue.append(dependent)
        
        if len(result) != len(self.nodes):
            raise ValueError("图中存在循环依赖，无法进行拓扑排序")
        
        self._topological_order = result
        self._cache_valid = True
        return result
    
    def get_execution_order(self, task_id: str) -> List[str]:
        """获取执行指定任务前需要完成的所有任务"""
        if task_id not in self.nodes:
            return []
        
        order = []
        visited = set()
        
        def dfs(current_id: str):
            if current_id in visited:
                return
            visited.add(current_id)
            
            for dep_id in self.nodes[current_id].dependencies:
                dfs(dep_id)
                if dep_id not in order:
                    order.append(dep_id)
        
        dfs(task_id)
        return order
    
    def get_critical_path(self) -> List[str]:
        """计算关键路径（耗时最长的依赖链）"""
        # 初始化
        earliest_start = {task_id: 0 for task_id in self.nodes}
        
        # 按拓扑顺序计算最早开始时间
        for task_id in self.topological_sort():
            node = self.nodes[task_id]
            earliest_finish = earliest_start[task_id] + node.estimated_duration
            for dependent in node.dependents:
                earliest_start[dependent] = max(
                    earliest_start[dependent], 
                    earliest_finish
                )
        
        # 找到最晚完成的任务
        latest_finish = max(
            earliest_start[tid] + self.nodes[tid].estimated_duration
            for tid in self.nodes
        )
        
        # 回溯找到关键路径
        critical_path = []
        current = max(self.nodes.keys(), 
                     key=lambda tid: earliest_start[tid] + self.nodes[tid].estimated_duration)
        
        while current:
            critical_path.insert(0, current)
            node = self.nodes[current]
            if not node.dependencies:
                break
            # 找到使当前任务最晚开始的依赖
            current = max(node.dependencies,
                         key=lambda tid: earliest_start[tid] + self.nodes[tid].estimated_duration)
        
        return critical_path
    
    def get_parallel_groups(self) -> List[Set[str]]:
        """获取可以并行执行的任务组"""
        in_degree = {task_id: len(node.dependencies) 
                    for task_id, node in self.nodes.items()}
        
        groups = []
        remaining = set(self.nodes.keys())
        
        while remaining:
            # 找到当前可以执行的任务（入度为0）
            available = {tid for tid in remaining if in_degree[tid] == 0}
            if not available:
                raise ValueError("存在循环依赖")
            
            groups.append(available)
            remaining -= available
            
            # 更新入度
            for tid in available:
                for dependent in self.nodes[tid].dependents:
                    in_degree[dependent] -= 1
        
        return groups
    
    def detect_cycles(self) -> List[List[str]]:
        """检测图中所有的循环"""
        cycles = []
        visited = set()
        rec_stack = set()
        path = []
        
        def dfs(node_id: str):
            visited.add(node_id)
            rec_stack.add(node_id)
            path.append(node_id)
            
            for dependent in self.nodes[node_id].dependents:
                if dependent not in visited:
                    dfs(dependent)
                elif dependent in rec_stack:
                    # 发现循环
                    cycle_start = path.index(dependent)
                    cycles.append(path[cycle_start:] + [dependent])
            
            path.pop()
            rec_stack.remove(node_id)
        
        for node_id in self.nodes:
            if node_id not in visited:
                dfs(node_id)
        
        return cycles
    
    def get_blocked_tasks(self) -> List[str]:
        """获取被阻塞的任务列表"""
        return [tid for tid, node in self.nodes.items() if node.is_blocked()]
    
    def get_ready_tasks(self) -> List[str]:
        """获取可以立即执行的任务（无依赖或依赖已完成）"""
        ready = []
        for tid, node in self.nodes.items():
            if node.status == "pending" and not node.dependencies:
                ready.append(tid)
            elif node.status == "pending":
                # 检查所有依赖是否已完成
                all_deps_completed = all(
                    self.nodes[dep_id].status == "completed"
                    for dep_id in node.dependencies
                    if dep_id in self.nodes
                )
                if all_deps_completed:
                    ready.append(tid)
        return ready
    
    def to_dict(self) -> Dict:
        """序列化为字典"""
        return {
            "nodes": {tid: node.to_dict() for tid, node in self.nodes.items()},
            "topological_order": self._topological_order if self._cache_valid else None
        }


class DependencyParser:
    """从自然语言解析任务依赖关系"""
    
    # 依赖关系关键词
    DEPENDENCY_PATTERNS = {
        "blocks": [
            r"(.+?)必须在(.+?)之前",
            r"(.+?)完成后才能开始(.+?)",
            r"(.+?)是(.+?)的前置条件",
            r"(.+?)blocks(.+?)",
            r"(.+?)must be done before (.+?)",
        ],
        "depends_on": [
            r"(.+?)依赖于(.+?)",
            r"(.+?)需要(.+?)完成后",
            r"(.+?)depends on (.+?)",
            r"(.+?)requires (.+?) to be completed",
        ],
        "parallel": [
            r"(.+?)和(.+?)可以并行",
            r"(.+?)和(.+?)同时进行",
            r"(.+?) and (.+?) can run in parallel",
        ]
    }
    
    def __init__(self, task_graph: TaskDependencyGraph):
        self.graph = task_graph
        self.task_name_to_id: Dict[str, str] = {}
    
    def register_task(self, task_name: str, task_id: str):
        """注册任务名称映射"""
        self.task_name_to_id[task_name.lower()] = task_id
    
    def parse_dependency_statement(self, text: str) -> List[Tuple[str, str, str]]:
        """
        解析依赖声明语句
        返回: [(关系类型, 任务A, 任务B), ...]
        """
        relations = []
        
        for relation_type, patterns in self.DEPENDENCY_PATTERNS.items():
            for pattern in patterns:
                matches = re.finditer(pattern, text, re.IGNORECASE)
                for match in matches:
                    task_a = match.group(1).strip()
                    task_b = match.group(2).strip()
                    relations.append((relation_type, task_a, task_b))
        
        return relations
    
    def apply_relations(self, relations: List[Tuple[str, str, str]]):
        """应用解析出的关系到图中"""
        for relation_type, task_a_name, task_b_name in relations:
            task_a_id = self._resolve_task_id(task_a_name)
            task_b_id = self._resolve_task_id(task_b_name)
            
            if not task_a_id or not task_b_id:
                continue
            
            if relation_type == "blocks":
                # A 阻塞 B，即 B 依赖于 A
                self.graph.add_dependency(task_b_id, task_a_id)
            elif relation_type == "depends_on":
                # A 依赖于 B
                self.graph.add_dependency(task_a_id, task_b_id)
            elif relation_type == "parallel":
                # 标记为可并行（不添加依赖）
                pass
    
    def _resolve_task_id(self, task_name: str) -> Optional[str]:
        """解析任务名称到ID"""
        task_name_lower = task_name.lower()
        
        # 直接匹配
        if task_name_lower in self.task_name_to_id:
            return self.task_name_to_id[task_name_lower]
        
        # 模糊匹配
        for name, tid in self.task_name_to_id.items():
            if task_name_lower in name or name in task_name_lower:
                return tid
        
        return None
    
    def suggest_dependencies(self, task_id: str, 
                           task_description: str,
                           all_tasks: List[Dict]) -> List[str]:
        """基于语义相似度建议可能的依赖"""
        try:
            # 使用语义嵌入计算任务间的相似度
            from sentence_transformers import SentenceTransformer
            
            model = SentenceTransformer('paraphrase-multilingual-MiniLM-L12-v2')
            
            task_embedding = model.encode(task_description)
            
            suggestions = []
            for other_task in all_tasks:
                if other_task['id'] == task_id:
                    continue
                
                other_embedding = model.encode(other_task.get('description', ''))
                similarity = self._cosine_similarity(task_embedding, other_embedding)
                
                # 高相似度可能表示依赖关系
                if similarity > 0.7:
                    suggestions.append(other_task['id'])
            
            return suggestions
        except ImportError:
            # sentence-transformers 未安装时返回空列表
            return []
    
    def _cosine_similarity(self, a, b) -> float:
        """计算余弦相似度"""
        try:
            from numpy import dot
            from numpy.linalg import norm
            return dot(a, b) / (norm(a) * norm(b))
        except ImportError:
            return 0.0


# 导出公共接口
__all__ = [
    'TaskNode',
    'TaskDependencyGraph',
    'DependencyParser'
]
